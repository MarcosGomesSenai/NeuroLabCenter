# NeuroLab Center

Sistema web escolar/técnico para uma clínica neurológica, com site público, área do paciente, agendamento, painel administrativo, API Flask e banco MySQL.

## Como abrir o site

Abra o arquivo `index.html`. Ele redireciona para:

```text
site/paginas/index.html
```

## Como rodar o servidor Flask

```bash
python -m pip install -r servidor/requirements.txt
python -m servidor.banco_de_dados.criar_banco
python -m servidor.app
```

## Estrutura principal

```text
NeuroLabCenter/
├── site/                 # páginas HTML do site
├── recursos/             # CSS, JS, imagens e Bootstrap local
├── servidor/             # API Flask e conexão MySQL
├── api-do-chatbot/       # microserviço Node.js do chatbot
├── documentacao/         # guias de instalação, manutenção e apresentação
├── scripts/              # scripts auxiliares
└── index.html            # entrada rápida do projeto
```

## Regra de manutenção

Nenhum arquivo principal deve passar de 550 linhas. Quando crescer demais, divida por responsabilidade.
