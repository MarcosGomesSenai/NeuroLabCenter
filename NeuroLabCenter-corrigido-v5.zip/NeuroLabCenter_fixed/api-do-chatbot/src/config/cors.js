/*
 * Arquivo: api-do-chatbot/src/config/cors.js
 * Objetivo: controlar comportamentos da interface do NeuroLab Center.
 * Como manter: mantenha funções pequenas, nomes claros e evite misturar páginas diferentes.
 * Observação: comentários explicam blocos, funções, validações e integração com o servidor.
 */

/*
 * NeuroLab Center - api-do-chatbot/src/config/cors.js
 * Responsabilidade: Microserviço Node.js do chatbot/assistente virtual.
 * Usado por: api-do-chatbot/server.js.
 * Manutenção: mantenha funções relacionadas juntas e evite misturar regras de páginas diferentes.
 */

const DEFAULT_ORIGINS = [
  "http://localhost:5500",
  "http://127.0.0.1:5500",
  "http://localhost:5000",
  "http://127.0.0.1:5000",
  "http://localhost:8080",
  "http://127.0.0.1:8080",
  "http://localhost:8090",
  "http://127.0.0.1:8090"
];

export const CORS_ALLOW_ALL = process.env.CORS_ALLOW_ALL === "true";

export const ALLOWED_ORIGINS = (process.env.ALLOWED_ORIGINS || DEFAULT_ORIGINS.join(","))
  .split(",")
  .map((origin) => origin.trim())
  .filter(Boolean);

export const corsOptions = {
  origin(origin, callback) {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (CORS_ALLOW_ALL) return callback(null, true);
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (!origin) return callback(null, true);
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (ALLOWED_ORIGINS.includes(origin)) return callback(null, true);
    return callback(null, false);
  }
};
