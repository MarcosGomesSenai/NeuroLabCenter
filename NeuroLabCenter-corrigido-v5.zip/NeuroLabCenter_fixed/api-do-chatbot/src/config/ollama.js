/*
 * Arquivo: api-do-chatbot/src/config/ollama.js
 * Objetivo: controlar comportamentos da interface do NeuroLab Center.
 * Como manter: mantenha funções pequenas, nomes claros e evite misturar páginas diferentes.
 * Observação: comentários explicam blocos, funções, validações e integração com o servidor.
 */

/*
 * NeuroLab Center - api-do-chatbot/src/config/ollama.js
 * Responsabilidade: Microserviço Node.js do chatbot/assistente virtual.
 * Usado por: api-do-chatbot/server.js.
 * Manutenção: mantenha funções relacionadas juntas e evite misturar regras de páginas diferentes.
 */

export const OLLAMA_URL = process.env.OLLAMA_URL || "http://localhost:11434/api/generate";
export const MODEL = process.env.OLLAMA_MODEL || "llama3.1";
export const OLLAMA_REQUIRED = String(process.env.OLLAMA_REQUIRED || "false").toLowerCase() === "true";
