/*
 * Arquivo: api-do-chatbot/src/app.js
 * Objetivo: controlar comportamentos da interface do NeuroLab Center.
 * Como manter: mantenha funções pequenas, nomes claros e evite misturar páginas diferentes.
 * Observação: comentários explicam blocos, funções, validações e integração com o servidor.
 */

/*
 * NeuroLab Center - api-do-chatbot/src/app.js
 * Responsabilidade: Microserviço Node.js do chatbot/assistente virtual.
 * Usado por: api-do-chatbot/server.js.
 * Manutenção: mantenha funções relacionadas juntas e evite misturar regras de páginas diferentes.
 */

import express from "express";
import cors from "cors";
import { corsOptions } from "./config/cors.js";
import chatRoutes from "./routes/chatRoutes.js";

const app = express();

app.use(cors(corsOptions));
app.use(express.json());
app.use("/api", chatRoutes);

export default app;
