/*
 * Arquivo: api-do-chatbot/src/controllers/chatController.js
 * Objetivo: controlar comportamentos da interface do NeuroLab Center.
 * Como manter: mantenha funções pequenas, nomes claros e evite misturar páginas diferentes.
 * Observação: comentários explicam blocos, funções, validações e integração com o servidor.
 */

/*
 * NeuroLab Center - api-do-chatbot/src/controllers/chatController.js
 * Responsabilidade: Microserviço Node.js do chatbot/assistente virtual.
 * Usado por: api-do-chatbot/server.js.
 * Manutenção: mantenha funções relacionadas juntas e evite misturar regras de páginas diferentes.
 */

import { generateChatAnswer } from "../models/chatModel.js";

export async function chatController(req, res) {
// Bloco protegido: tenta executar a ação e permite tratar falhas sem travar a página.
  try {
    const message = String(req.body?.message || "").trim();

// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (!message) {
      return res.status(400).json({ answer: "Digite sua duvida ou sintoma para eu ajudar." });
    }

    const answer = await generateChatAnswer(message);
    return res.json({ answer });
  } catch (error) {
    return res.status(500).json({
      answer: "A IA local nao respondeu. Verifique se o Ollama/Llama esta aberto na porta 11434."
    });
  }
}
