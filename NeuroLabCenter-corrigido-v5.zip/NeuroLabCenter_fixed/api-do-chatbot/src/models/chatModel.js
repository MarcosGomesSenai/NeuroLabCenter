/*
 * Arquivo: api-do-chatbot/src/models/chatModel.js
 * Objetivo: controlar comportamentos da interface do NeuroLab Center.
 * Como manter: mantenha funções pequenas, nomes claros e evite misturar páginas diferentes.
 * Observação: comentários explicam blocos, funções, validações e integração com o servidor.
 */

/*
 * NeuroLab Center - api-do-chatbot/src/models/chatModel.js
 * Responsabilidade: Microserviço Node.js do chatbot/assistente virtual.
 * Usado por: api-do-chatbot/server.js.
 * Manutenção: mantenha funções relacionadas juntas e evite misturar regras de páginas diferentes.
 */

import { MODEL, OLLAMA_REQUIRED, OLLAMA_URL } from "../config/ollama.js";

// Configuração ou referência reutilizada pelas funções deste arquivo.
const SYSTEM_PROMPT = `
Voce e um assistente virtual de duvidas da clinica NeuroLab Center.
Responda em portugues do Brasil, de forma curta, educada, segura e facil de entender.
Voce pode responder duvidas gerais sobre sintomas, preparo de exames, agendamento, unidades, consulta online e quando procurar ajuda.
Voce nao e medico e nao substitui consulta.
E proibido prescrever remedios, citar doses, indicar antibioticos, anti-inflamatorios, tarja preta, combinacoes de medicamentos ou tratamentos especificos.
Se o usuario pedir remedio, responda que por seguranca nao pode indicar medicamento e recomende avaliacao medica ou farmaceutica.
Nao faca diagnostico fechado.
Quando houver sinais de alerta como dor subita muito forte, desmaio, confusao, fraqueza em um lado do corpo, fala enrolada, convulsao, falta de ar, dor no peito, febre alta persistente, rigidez na nuca, pior dor da vida ou alteracao visual grave, oriente procurar emergencia imediatamente.
Sempre finalize lembrando que a orientacao e informativa e nao substitui avaliacao medica.
`;

// Função fallbackAnswer: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function fallbackAnswer(message) {
  const text = String(message || "").toLowerCase();
  const emergencyTerms = [
    "dor no peito",
    "falta de ar",
    "desmaio",
    "convuls",
    "fraqueza",
    "fala enrolada",
    "pior dor",
    "confus"
  ];

// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (emergencyTerms.some((term) => text.includes(term))) {
    return "Pelos sinais descritos, procure atendimento de emergencia imediatamente. Esta orientacao e informativa e nao substitui avaliacao medica.";
  }

// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (text.includes("remedio") || text.includes("medicamento") || text.includes("dose")) {
    return "Por seguranca, nao posso indicar medicamentos, doses ou tratamentos. Procure avaliacao medica ou farmaceutica. Esta orientacao e informativa e nao substitui avaliacao medica.";
  }

// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (text.includes("agend")) {
    return "Voce pode seguir pelo agendamento online, escolhendo tipo de atendimento, cobertura, unidade, profissional e horario. Esta orientacao e informativa e nao substitui avaliacao medica.";
  }

// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (text.includes("exame")) {
    return "Para exames neurologicos, confira o preparo informado na pagina de exames e confirme a orientacao ao agendar. Esta orientacao e informativa e nao substitui avaliacao medica.";
  }

  return "Posso ajudar com duvidas gerais sobre sintomas, exames, agendamento, unidades e teleconsulta. Para diagnostico ou tratamento, agende uma avaliacao medica.";
}

export async function generateChatAnswer(message) {
// Bloco protegido: tenta executar a ação e permite tratar falhas sem travar a página.
  try {
    const response = await fetch(OLLAMA_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      signal: AbortSignal.timeout(5000),
      body: JSON.stringify({
        model: MODEL,
        stream: false,
        prompt: `${SYSTEM_PROMPT}\nPaciente: ${message}\nAssistente:`
      })
    });

// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (!response.ok) {
      throw new Error("Erro ao chamar Ollama/Llama");
    }

    const data = await response.json();
    return data.response || fallbackAnswer(message);
  } catch (error) {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (OLLAMA_REQUIRED) {
      throw error;
    }
    return fallbackAnswer(message);
  }
}
