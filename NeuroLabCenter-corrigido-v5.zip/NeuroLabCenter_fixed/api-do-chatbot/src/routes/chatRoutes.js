/*
 * Arquivo: api-do-chatbot/src/routes/chatRoutes.js
 * Objetivo: controlar comportamentos da interface do NeuroLab Center.
 * Como manter: mantenha funções pequenas, nomes claros e evite misturar páginas diferentes.
 * Observação: comentários explicam blocos, funções, validações e integração com o servidor.
 */

/*
 * NeuroLab Center - api-do-chatbot/src/routes/chatRoutes.js
 * Responsabilidade: Microserviço Node.js do chatbot/assistente virtual.
 * Usado por: api-do-chatbot/server.js.
 * Manutenção: mantenha funções relacionadas juntas e evite misturar regras de páginas diferentes.
 */

import { Router } from "express";
import { chatController } from "../controllers/chatController.js";

const router = Router();

router.post("/chat", chatController);

export default router;
