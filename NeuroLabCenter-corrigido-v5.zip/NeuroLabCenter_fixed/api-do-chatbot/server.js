/*
 * Arquivo: api-do-chatbot/server.js
 * Objetivo: controlar comportamentos da interface do NeuroLab Center.
 * Como manter: mantenha funções pequenas, nomes claros e evite misturar páginas diferentes.
 * Observação: comentários explicam blocos, funções, validações e integração com o servidor.
 */

/*
 * NeuroLab Center - api-do-chatbot/server.js
 * Responsabilidade: Microserviço Node.js do chatbot/assistente virtual.
 * Usado por: api-do-chatbot/server.js.
 * Manutenção: mantenha funções relacionadas juntas e evite misturar regras de páginas diferentes.
 */

import app from "./src/app.js";
import { MODEL } from "./src/config/ollama.js";

// Configuração ou referência reutilizada pelas funções deste arquivo.
const PORT = process.env.PORT || 3001;

app.listen(PORT, () => {
  console.log(`API NeuroLab rodando em http://localhost:${PORT}`);
  console.log(`Modelo: ${MODEL}`);
});
