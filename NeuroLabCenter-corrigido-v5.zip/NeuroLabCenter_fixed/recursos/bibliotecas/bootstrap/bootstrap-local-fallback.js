/*
 * Arquivo: recursos/bibliotecas/bootstrap/bootstrap-local-fallback.js
 * Objetivo: controlar comportamentos da interface do NeuroLab Center.
 * Como manter: mantenha funções pequenas, nomes claros e evite misturar páginas diferentes.
 * Observação: comentários explicam blocos, funções, validações e integração com o servidor.
 */

/*
 * NeuroLab Center - recursos/bibliotecas/bootstrap/bootstrap-local-fallback.js
 * Responsabilidade: Arquivo de apoio do projeto NeuroLab Center.
 * Usado por: estrutura principal do projeto.
 * Manutenção: mantenha funções relacionadas juntas e evite misturar regras de páginas diferentes.
 */

// Fallback leve para apresentação sem internet. Mantém páginas sem erro quando Bootstrap CDN falha.
window.bootstrap = window.bootstrap || {
  Modal: class { constructor(element){ this.element = element; } show(){ this.element?.classList.add('show'); this.element?.style && (this.element.style.display='block'); } hide(){ this.element?.classList.remove('show'); this.element?.style && (this.element.style.display='none'); } static getOrCreateInstance(element){ return new this(element); } },
  Collapse: class { constructor(element){ this.element = element; } show(){ this.element?.classList.add('show'); } hide(){ this.element?.classList.remove('show'); } toggle(){ this.element?.classList.toggle('show'); } }
};
