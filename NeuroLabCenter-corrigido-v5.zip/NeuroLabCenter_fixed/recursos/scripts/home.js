/*
 * Arquivo: recursos/scripts/home.js
 * Objetivo: controlar comportamentos da interface do NeuroLab Center.
 * Como manter: mantenha funções pequenas, nomes claros e evite misturar páginas diferentes.
 * Observação: comentários explicam blocos, funções, validações e integração com o servidor.
 */

/*
 * NeuroLab Center - recursos/scripts/home.js
 * Responsabilidade: Comportamentos da página inicial: layout, busca de comandos e feedback dos formulários.
 * Usado por: Páginas HTML em site/paginas/.
 * Manutenção: mantenha funções relacionadas juntas e evite misturar regras de páginas diferentes.
 */

/**
 * NeuroLab Center — home.js
 * Arquivo consolidado para apresentação e manutenção.
 * Carregadores document.write e pastas part/section foram substituídos por código direto.
 */

// ============================================================================
// ============================================================================

// Ações leves da home para apresentação.
// A home direciona fluxos completos para as páginas específicas, evitando carregar scripts pesados de agendamento,
// avaliação, endereço, exame e teleconsulta somente para cobrir botões antigos.

(function () {
  // A home não precisa carregar todo o fluxo pesado de agendamento/teleconsulta.
  // Por isso, este arquivo cria atalhos seguros para redirecionar botões antigos.
  function toastOrAlert(msg, tipo = 'info') {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (typeof window.mostrarToast === 'function') window.mostrarToast(msg, tipo);
    else alert(msg);
  }

// Função go: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
  function go(page) {
    window.location.href = page;
  }

  window.abrirAgendamento = window.abrirAgendamento || function () { go('agendamento.html'); };
  window.abrirAgendamentoOnline = window.abrirAgendamentoOnline || function () { go('teleconsulta.html'); };
  window.abrirModalPaciente = window.abrirModalPaciente || function () { go('area-paciente.html'); };

  window.abrirFilaEspera = window.abrirFilaEspera || function () {
    toastOrAlert('A fila de espera fica disponível na página de agendamento.', 'info');
    go('agendamento.html');
  };

  window.abrirModalAvaliacao = window.abrirModalAvaliacao || function () {
    toastOrAlert('Avaliações podem ser feitas após o atendimento na Área do Paciente.', 'info');
    go('area-paciente.html');
  };

  window.verificarAvaliacao = window.verificarAvaliacao || function () {
    toastOrAlert('Entre na Área do Paciente para avaliar consultas concluídas.', 'info');
    go('area-paciente.html');
  };

  window.enviarAvaliacao = window.enviarAvaliacao || function () {
    toastOrAlert('Use a Área do Paciente para registrar avaliações vinculadas ao MySQL.', 'info');
    go('area-paciente.html');
  };

  window.confirmarFilaEspera = window.confirmarFilaEspera || function () {
    toastOrAlert('Use a página de agendamento para entrar na fila de espera.', 'info');
    go('agendamento.html');
  };

  window.atualizarCharCount = window.atualizarCharCount || function (textarea, outputId, max = 500) {
    const output = document.getElementById(outputId);
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (!output || !textarea) return;
    output.textContent = `${Math.min(textarea.value.length, max)}/${max}`;
  };

  // Compatibilidade para elementos antigos de agendamento na home.
  window.selecionarTipo = window.selecionarTipo || function () { go('agendamento.html'); };
  window.selecionarCobertura = window.selecionarCobertura || function () { go('agendamento.html'); };
  window.confirmarConvenio = window.confirmarConvenio || function () { go('agendamento.html'); };
  window.selecionarUnidade = window.selecionarUnidade || function () { go('agendamento.html'); };
  window.selecionarMedico = window.selecionarMedico || function () { go('agendamento.html'); };
  window.selecionarHorarioHome = window.selecionarHorarioHome || function () { go('agendamento.html'); };
  window.avancarParaConfirmacao = window.avancarParaConfirmacao || function () { go('agendamento.html'); };
  window.confirmarAgendamentoFinal = window.confirmarAgendamentoFinal || function () { go('agendamento.html'); };
  window.novoAgendamento = window.novoAgendamento || function () { go('agendamento.html'); };
  window.voltarPasso = window.voltarPasso || function () { go('agendamento.html'); };
  window.voltarPassoComHold = window.voltarPassoComHold || function () { go('agendamento.html'); };

  // Compatibilidade para endereço/exames/teleconsulta em elementos antigos da home.
  window.mascararCep = window.mascararCep || function (input) {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (!input) return;
    let valor = input.value.replace(/\D/g, '').slice(0, 8);
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (valor.length > 5) valor = valor.replace(/^(\d{5})(\d{1,3})$/, '$1-$2');
    input.value = valor;
  };
  window.buscarUnidadePorCep = window.buscarUnidadePorCep || function () { go('unidades.html'); };
  window.pesquisarEnderecoInteligente = window.pesquisarEnderecoInteligente || function () { go('unidades.html'); };
  window.selecionarExame = window.selecionarExame || function () { go('exames.html'); };
  window.confirmarConsultaOnline = window.confirmarConsultaOnline || function () { go('teleconsulta.html'); };
  window.entrarLigacaoMedico = window.entrarLigacaoMedico || function () { go('teleconsulta.html'); };
  window.enviarMensagemSala = window.enviarMensagemSala || function () {
    toastOrAlert('Abra a página de teleconsulta para usar a sala virtual.', 'info');
    go('teleconsulta.html');
  };
  window.enviarSalaComEnter = window.enviarSalaComEnter || function (event) {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (event && event.key === 'Enter') window.enviarMensagemSala();
  };
})();

// ============================================================================
// ============================================================================

// CARROSSEL DA ÁREA PRINCIPAL
let slideAtual = 0;
const totalSlides = 3;

// Função atualizarCarrossel: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function atualizarCarrossel() {
  const track = document.getElementById('carouselTrack');
  const dots = document.querySelectorAll('.dot');

// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!track) return;

  track.style.transform = `translateX(-${slideAtual * 100}%)`;
  dots.forEach((dot, index) => dot.classList.toggle('active', index === slideAtual));
}

// Função mudarSlide: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function mudarSlide(direcao) {
  slideAtual += direcao;
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (slideAtual < 0) slideAtual = totalSlides - 1;
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (slideAtual >= totalSlides) slideAtual = 0;
  atualizarCarrossel();
}

// Função irParaSlide: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function irParaSlide(numero) {
  slideAtual = numero;
  atualizarCarrossel();
}

setInterval(() => mudarSlide(1), 4500);

// FUNDO ANIMADO COM MOUSE
const canvas = document.getElementById('bgCanvas');
const ctx = canvas ? canvas.getContext('2d') : null;
let particles = [];
// Configuração ou referência reutilizada pelas funções deste arquivo.
let mouse = { x: null, y: null };

// Função resizeCanvas: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function resizeCanvas() {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!canvas) return;
  const hero = document.querySelector('.hero');
  canvas.width = window.innerWidth;
  canvas.height = hero ? hero.offsetHeight : 600;
}

// Evento da interface: conecta uma ação do usuário com uma função do sistema.
window.addEventListener('resize', resizeCanvas);
resizeCanvas();

// Evento da interface: conecta uma ação do usuário com uma função do sistema.
window.addEventListener('mousemove', function(e) {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!canvas) return;
  const rect = canvas.getBoundingClientRect();
  mouse.x = e.clientX - rect.left;
  mouse.y = e.clientY - rect.top;
});

// Classe Particle: agrupa dados e comportamentos relacionados ao mesmo recurso.
class Particle {
  constructor() {
    this.x = Math.random() * canvas.width;
    this.y = Math.random() * canvas.height;
    this.size = Math.random() * 3 + 1;
    this.speedX = Math.random() * 1 - 0.5;
    this.speedY = Math.random() * 1 - 0.5;
  }

  update() {
    this.x += this.speedX;
    this.y += this.speedY;

// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (this.x < 0 || this.x > canvas.width) this.speedX *= -1;
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (this.y < 0 || this.y > canvas.height) this.speedY *= -1;

// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (mouse.x !== null && mouse.y !== null) {
      const dx = mouse.x - this.x;
      const dy = mouse.y - this.y;
      const dist = Math.sqrt(dx * dx + dy * dy);
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
      if (dist < 130) {
        this.x -= dx * 0.012;
        this.y -= dy * 0.012;
      }
    }
  }

  draw() {
    ctx.fillStyle = 'rgba(0,116,118,0.42)';
    ctx.beginPath();
    ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
    ctx.fill();
  }
}

// Função initParticles: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function initParticles() {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!canvas) return;
  particles = [];
  for (let i = 0; i < 120; i++) particles.push(new Particle());
}

// Função ligarPontos: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function ligarPontos() {
  for (let a = 0; a < particles.length; a++) {
    for (let b = a; b < particles.length; b++) {
      const dx = particles[a].x - particles[b].x;
      const dy = particles[a].y - particles[b].y;
      const dist = Math.sqrt(dx * dx + dy * dy);
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
      if (dist < 95) {
        ctx.strokeStyle = `rgba(72,163,167,${1 - dist / 95})`;
        ctx.lineWidth = 0.45;
        ctx.beginPath();
        ctx.moveTo(particles[a].x, particles[a].y);
        ctx.lineTo(particles[b].x, particles[b].y);
        ctx.stroke();
      }
    }
  }
}

// Função animateParticles: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function animateParticles() {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!ctx || !canvas) return;
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  particles.forEach(p => { p.update(); p.draw(); });
  ligarPontos();
  requestAnimationFrame(animateParticles);
}

initParticles();
animateParticles();

/* ============================================================
   NEUROLAB UX REFRESH - navegacao, calendario e modulos
   ============================================================ */
Object.assign(window.NLUX, {
  calendarOffset: window.NLUX?.calendarOffset ?? 0,
  selectedDateISO: window.NLUX?.selectedDateISO ?? '',
  selectedSlot: window.NLUX?.selectedSlot ?? '',
  portalTab: window.NLUX?.portalTab ?? 'historico'
});
