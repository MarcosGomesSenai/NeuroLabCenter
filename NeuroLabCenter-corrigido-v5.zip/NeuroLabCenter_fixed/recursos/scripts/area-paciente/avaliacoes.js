/*
 * Arquivo: recursos/scripts/area-paciente/avaliacoes.js
 * Objetivo: controlar comportamentos da interface do NeuroLab Center.
 * Como manter: mantenha funções pequenas, nomes claros e evite misturar páginas diferentes.
 * Observação: comentários explicam blocos, funções, validações e integração com o servidor.
 */

/*
 * NeuroLab Center - recursos/scripts/area-paciente/avaliacoes.js
 * Responsabilidade: Comportamentos da Área do Paciente: painel, documentos, convênios e integração com portal.
 * Usado por: Páginas HTML em site/paginas/.
 * Manutenção: mantenha funções relacionadas juntas e evite misturar regras de páginas diferentes.
 */

/**
 * NeuroLab Center — Área do Paciente — 01-ratings-dashboard.js
 * Origem reorganizada: recursos/scripts/app/ratings-dashboard.js
 * Responsabilidade isolada para facilitar manutenção sem arquivos gigantes.
 */

function abrirFilaEspera() {
  preencherResumo('filaResumo');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!abrirModal('modalFilaEspera')) mostrarToast('Fila de espera registrada para o médico e unidade selecionados.', 'sucesso');
}

// Função confirmarFilaEspera: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
async function confirmarFilaEspera() {
  const whatsapp = $('filaWhatsapp')?.value;
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (somenteDigitos(whatsapp).length < 10) {
    mostrarToast('Informe um WhatsApp válido para receber a notificação.', 'aviso');
    return;
  }

// Bloco protegido: tenta executar a ação e permite tratar falhas sem travar a página.
  try {
    await apiEntrarFilaEsperaMySQL({ ...agendamentoAtual, whatsapp });
    fecharModal('modalFilaEspera');
    mostrarToast('Você entrou na fila de espera pelo MySQL. A clínica avisará quando surgir desistência.', 'sucesso');
  } catch (erro) {
    mostrarToast(erro.message || 'Não foi possível salvar a fila de espera no MySQL.', 'erro', 7000);
  }
}

// Função criarEstrelas: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function criarEstrelas(container) {
  const campo = container.dataset.campo;
  container.innerHTML = '';
  for (let nota = 1; nota <= 5; nota++) {
    const estrela = document.createElement('button');
    estrela.type = 'button';
    estrela.className = 'estrela';
    estrela.textContent = '★';
    estrela.setAttribute('aria-label', `${nota} estrela${nota > 1 ? 's' : ''}`);
// Evento da interface: conecta uma ação do usuário com uma função do sistema.
    estrela.addEventListener('click', () => {
      avaliacaoAtual[campo] = nota;
      [...container.children].forEach((item, index) => item.classList.toggle('ativa', index < nota));
      verificarAvaliacao();
    });
    container.appendChild(estrela);
  }
}

// Função criarNps: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function criarNps(container) {
  container.innerHTML = '';
  for (let nota = 0; nota <= 10; nota++) {
    const botao = document.createElement('button');
    botao.type = 'button';
    botao.className = 'nps-btn';
    botao.textContent = nota;
// Evento da interface: conecta uma ação do usuário com uma função do sistema.
    botao.addEventListener('click', () => {
      avaliacaoAtual.nps = nota;
      [...container.children].forEach(item => item.classList.toggle('ativo', Number(item.textContent) === nota));
      verificarAvaliacao();
    });
    container.appendChild(botao);
  }
}

// Função verificarAvaliacao: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function verificarAvaliacao() {
  const pronto = avaliacaoAtual.medico && avaliacaoAtual.recepcao && avaliacaoAtual.agendamento && avaliacaoAtual.nps !== null;
  const btn = $('btnEnviarAvaliacao');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (btn) btn.disabled = !pronto;
  setHint('avaliacaoHint', pronto ? 'Tudo pronto para enviar.' : 'Preencha as três notas e o NPS.', pronto ? 'success' : 'info');
}

// Função atualizarCharCount: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function atualizarCharCount() {
  const texto = $('avaliacaoComentario')?.value || '';
  const contador = $('charCount');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (contador) contador.textContent = `${texto.length} / 500`;
}

// Função enviarAvaliacao: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
async function enviarAvaliacao() {
  verificarAvaliacao();
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if ($('btnEnviarAvaliacao')?.disabled) return;

// Bloco protegido: tenta executar a ação e permite tratar falhas sem travar a página.
  try {
    await apiEnviarAvaliacaoGeralMySQL({
      ...avaliacaoAtual,
      comentario: $('avaliacaoComentario')?.value || '',
      publicar: Boolean($('consentimentoPublicacao')?.checked)
    });
    fecharModal('modalAvaliacao');
    mostrarToast('Avaliação enviada para o MySQL. Comentários seguem para moderação.', 'sucesso');
  } catch (erro) {
    mostrarToast(erro.message || 'Não foi possível salvar a avaliação no MySQL.', 'erro', 7000);
  }
}

// Função renderDashboardAgendamentos: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
async function renderDashboardAgendamentos() {
  const container = $('dashboardAgendamentos');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!container) return;

  const cpfPerfil = typeof getPerfilAtivoCpf === 'function' ? getPerfilAtivoCpf() : lerJson(STORAGE_KEYS.usuarioAtual, null)?.cpf;
  let agendamentos = [];

// Bloco protegido: tenta executar a ação e permite tratar falhas sem travar a página.
  try {
    agendamentos = await apiListarAgendamentosPaciente(cpfPerfil);
  } catch (erro) {
    container.innerHTML = `
      <div class="empty-state">
        <span>⚠️</span>
        <p>Não foi possível carregar os agendamentos do MySQL.<br>Verifique se Flask e MySQL estão ligados.</p>
      </div>
    `;
    return;
  }

  agendamentos = (agendamentos || []).slice(0, 6);

// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!agendamentos.length) {
    container.innerHTML = `
      <div class="empty-state">
        <span>📋</span>
        <p>Nenhum agendamento encontrado no MySQL.<br>Agende sua primeira consulta agora!</p>
        <button class="btn btn-primary" onclick="abrirAgendamento()" style="margin-top:12px;">Agendar consulta</button>
      </div>
    `;
    return;
  }

  container.innerHTML = agendamentos.map(item => {
    const status = String(item.status || 'confirmado').toLowerCase();
    const isCancelado = status === 'cancelado' || status === 'falta' || status === 'expirado';
    const isConfirmado = status === 'confirmado' || status === 'pendente';
    const pillClass = isCancelado ? 'style="background:#FFF5F5;color:#C44444;"' : '';
    const dataBR = item.data_consulta ? new Date(`${item.data_consulta}T00:00:00`).toLocaleDateString('pt-BR') : (item.dia || '-');
    const hora = String(item.hora_consulta || item.horario || '-').slice(0, 5);
    const medico = item.medico_nome || item.medico || item.tipoNome || 'Agendamento NeuroLab';
    const unidade = item.unidade_nome || item.unidade || '-';
    const acoes = isConfirmado ? `
      <div style="display:flex;gap:8px;flex-wrap:wrap;">
        <button class="btn btn-light" onclick="abrirAgendamento()">Reagendar</button>
        <button class="btn btn-light" style="color:#C44444;border-color:#FFD5D5;" onclick="cancelarAgendamento('${item.id}')">Cancelar</button>
      </div>
    ` : isCancelado ? `<span style="font-size:13px;color:var(--texto-claro);">Cancelado/encerrado</span>` : '';

    return `
      <div class="appointment-card" ${isCancelado ? 'style="opacity:0.6;"' : ''}>
        <span class="status-pill" ${pillClass}>${status.toUpperCase()}</span>
        <strong>${medico}</strong>
        <span>${dataBR} às ${hora} · ${unidade}</span>
        ${acoes}
      </div>
    `;
  }).join('');
}
