/*
 * Arquivo: recursos/scripts/area-paciente/convenios.js
 * Objetivo: controlar comportamentos da interface do NeuroLab Center.
 * Como manter: mantenha funções pequenas, nomes claros e evite misturar páginas diferentes.
 * Observação: comentários explicam blocos, funções, validações e integração com o servidor.
 */

/*
 * NeuroLab Center - recursos/scripts/area-paciente/convenios.js
 * Responsabilidade: Comportamentos da Área do Paciente: painel, documentos, convênios e integração com portal.
 * Usado por: Páginas HTML em site/paginas/.
 * Manutenção: mantenha funções relacionadas juntas e evite misturar regras de páginas diferentes.
 */

/**
 * NeuroLab Center — Área do Paciente — 02-health-plans.js
 * Origem reorganizada: recursos/scripts/paginas/health-plans.js
 * Responsabilidade isolada para facilitar manutenção sem arquivos gigantes.
 */

function renderConveniosMelhorados(lista = NL_PLANOS) {
  const grid = document.getElementById('planGrid');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!grid) return;
  const unidadeSelect = document.getElementById('planUnit');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (unidadeSelect && unidadeSelect.dataset.ready !== 'true') {
    unidadeSelect.dataset.ready = 'true';
    unidadeSelect.innerHTML = '<option value="">Todas as unidades</option>' + NL_UNIDADES.map(unidade => `<option>${nlSafeText(unidade.nome)}</option>`).join('');
  }
  grid.innerHTML = lista.map(plano => `
    <article class="plan-card plan-card-rich">
      <div><strong>${nlSafeText(plano.nome)}</strong><span>${plano.servicos.join(' · ')}</span></div>
      <div class="plan-badges">${plano.servicos.map(servico => `<small>${nlSafeText(servico)}</small>`).join('')}</div>
      <div class="tags">${plano.unidades.map(unidade => `<span class="tag">${nlSafeText(unidade)}</span>`).join('')}</div>
      <div class="plan-card-actions">
        <button class="btn btn-agendar-plano" onclick="abrirAgendamento()">Agendar com plano</button>
        <button class="btn btn-comparar-plano" onclick="alternarComparacaoPlano('${plano.nome.replace(/'/g, "\\'")}', this)">Comparar</button>
      </div>
    </article>
  `).join('') || '<div class="safe-note">Nenhum convênio encontrado para o filtro informado.</div>';
  renderComparadorPlanos();
}



// Função alternarComparacaoPlano: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function alternarComparacaoPlano(nome, botao) {
  const plano = String(nome || '').trim();
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (botao) botao.classList.toggle('active');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (typeof mostrarToast === 'function') {
    mostrarToast(plano ? `Comparação rápida selecionada: ${plano}.` : 'Plano selecionado para comparação.', 'info', 3500);
  }
  return false;
}

// Função renderComparadorPlanos: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function renderComparadorPlanos() {
  const alvo = document.getElementById('planComparator');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!alvo) return;
  alvo.innerHTML = '<div class="safe-note">Selecione planos para comparação visual. Nenhum dado de negócio é salvo fora do MySQL.</div>';
}
