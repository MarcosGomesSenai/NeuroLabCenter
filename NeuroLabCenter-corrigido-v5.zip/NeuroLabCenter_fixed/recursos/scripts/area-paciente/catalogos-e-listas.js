/*
 * Arquivo: recursos/scripts/area-paciente/catalogos-e-listas.js
 * Objetivo: controlar comportamentos da interface do NeuroLab Center.
 * Como manter: mantenha funções pequenas, nomes claros e evite misturar páginas diferentes.
 * Observação: comentários explicam blocos, funções, validações e integração com o servidor.
 */

/*
 * NeuroLab Center - recursos/scripts/area-paciente/catalogos-e-listas.js
 * Responsabilidade: Comportamentos da Área do Paciente: painel, documentos, convênios e integração com portal.
 * Usado por: Páginas HTML em site/paginas/.
 * Manutenção: mantenha funções relacionadas juntas e evite misturar regras de páginas diferentes.
 */

/**
 * NeuroLab Center — Área do Paciente — 03-catalog-paginas.js
 * Origem reorganizada: recursos/scripts/paginas/plans-units-patient/catalog-paginas.js
 * Responsabilidade isolada para facilitar manutenção sem arquivos gigantes.
 */

function renderConvenios(lista = NL_PLANOS) {
  const grid = document.getElementById('planGrid');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!grid) return;
  grid.innerHTML = lista.map(plano => `
    <div class="plan-card">
      <strong>${plano.nome}</strong>
      <span>${plano.servicos.join(' · ')}</span>
      <div class="tags" style="margin-top:12px;">${plano.unidades.map(unidade => `<span class="tag">${unidade}</span>`).join('')}</div>
    </div>
  `).join('') || '<div class="safe-note">Nenhum convênio encontrado para o filtro informado.</div>';
}

// Função filtrarConvenios: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function filtrarConvenios() {
  const termo = normalizarTexto(document.getElementById('planSearch')?.value || '');
  const unidade = document.getElementById('planUnit')?.value || '';
  const filtrados = NL_PLANOS.filter(plano =>
    (!termo || normalizarTexto(plano.nome).includes(termo)) &&
    (!unidade || plano.unidades.some(u => normalizarTexto(u) === normalizarTexto(unidade)))
  );
  renderConveniosMelhorados(filtrados);
}

// Função aprimorarUnidadesMapas: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function aprimorarUnidadesMapas() {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (paginaArquivo() !== 'unidades.html') return;
  document.querySelectorAll('.unidade-rica').forEach(card => {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (card.querySelector('.map-card')) return;
    const titulo = card.querySelector('h3')?.textContent || '';
    const unidade = NL_UNIDADES.find(item => titulo.includes(item.nome.split(' - ')[0]) || titulo.includes('Teleconsulta'));
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (!unidade?.mapa) return;
    card.insertAdjacentHTML('beforeend', `<div class="map-card" style="margin-top:16px;"><iframe title="Mapa ${unidade.nome}" loading="lazy" src="${unidade.mapa}"></iframe></div>`);
  });
}

// Função renderPortalPaciente: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function renderPortalPaciente() {
  // Mantido apenas como compatibilidade. A Área do Paciente oficial inicializa via initPortalPaciente() e MySQL.
  if (typeof initPortalPaciente === 'function') initPortalPaciente();
}

// Função alternarPortalTab: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function alternarPortalTab() {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (typeof renderPortalPacienteNovo === 'function') renderPortalPacienteNovo();
}

// Função renderDependentes: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function renderDependentes(content = document.getElementById('portalContent')) {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (content) content.innerHTML = '<div class="patient-empty-state"><strong>Conta família via MySQL</strong><p>Dependentes e familiares são carregados pela API do portal.</p></div>';
}

// Função adicionarDependente: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function adicionarDependente() {
  mostrarToast('Use o cadastro de familiar conectado ao MySQL na Área do Paciente.', 'aviso', 5000);
}

// nlSafeText centralizado em recursos/scripts/compartilhado/global-utils.js.

function nlModalidadeLabel(codigo) {
  return {
    'CONS-ADULT': 'Consulta adulto',
    'CONS-INF': 'Neuropediatria',
    'EXAM': 'Exames',
    'TELE': 'Online'
  }[codigo] || codigo;
}

// Função nlDoctorInitials: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function nlDoctorInitials(nome) {
  return String(nome || '')
    .replace(/^Dr(a)?\.\s*/i, '')
    .split(/\s+/)
    .slice(0, 2)
    .map(parte => parte[0])
    .join('')
    .toUpperCase();
}

// Função nlClassificarEspecialidade: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function nlClassificarEspecialidade(medico) {
  const texto = normalizarTexto(`${medico.especialidade} ${medico.tipos.join(' ')}`);
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (texto.includes('pediatria') || medico.tipos.includes('CONS-INF')) return 'Neuropediatria';
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (texto.includes('sono')) return 'Sono e cognição';
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (texto.includes('exame') || texto.includes('neurofisiologico') || medico.tipos.includes('EXAM')) return 'Exames neurofisiológicos';
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (texto.includes('cefaleia') || texto.includes('enxaqueca')) return 'Cefaleia e dor';
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (texto.includes('memoria') || texto.includes('alzheimer') || texto.includes('cognicao')) return 'Memória e cognição';
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (texto.includes('movimento') || texto.includes('parkinson')) return 'Distúrbios do movimento';
  return 'Neurologia geral';
}

// Função nlMedicoCard: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function nlMedicoCard(medico) {
  const unidadePrincipal = medico.unidades[0] || 'Unidade a confirmar';
  return `
    <article class="doctor-profile-card">
      <div class="doctor-profile-top">
        <div class="doctor-photo">${nlDoctorInitials(medico.nome)}</div>
        <div>
          <strong>${nlSafeText(medico.nome)}</strong>
          <span>${nlSafeText(medico.crm)} · ${nlSafeText(medico.especialidade)}</span>
        </div>
      </div>
      <div class="doctor-profile-meta">
        <span>${medico.rating.toFixed(1)} avaliação</span>
        <span>${medico.avaliacoes} opiniões</span>
        <span>${nlSafeText(unidadePrincipal)}</span>
      </div>
      <div class="tags">${medico.coberturas.map(item => `<span class="tag">${nlSafeText(item)}</span>`).join('')}</div>
      <button class="btn btn-primary" onclick="abrirAgendamento()">Agendar com este médico</button>
    </article>
  `;
}


// Função renderMedicosPage: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function renderMedicosPage() {
  const pageRoot = document.getElementById('medicosPageRoot');
  const root = pageRoot;
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!pageRoot || pageRoot.dataset.medicosEnhanced === 'true') return;
  pageRoot.dataset.medicosEnhanced = 'true';

  const grupos = [...new Set(NL_MEDICOS.map(nlClassificarEspecialidade))];
  const content = `
    <div class="doctor-filter-panel">
      <button class="doctor-filter-chip active" onclick="filtrarMedicosEspecialidade('Todos', this)">Todos</button>
      ${grupos.map(grupo => `<button class="doctor-filter-chip" onclick="filtrarMedicosEspecialidade('${grupo.replace(/'/g, "\\'")}', this)">${grupo}</button>`).join('')}
    </div>
    <div class="doctor-specialty-grid" id="doctorSpecialtyGrid">
      ${NL_MEDICOS.map(medico => `<div data-specialty="${nlClassificarEspecialidade(medico)}">${nlMedicoCard(medico)}</div>`).join('')}
    </div>
  `;

  pageRoot.innerHTML = content;
  return;

  root.innerHTML = `
    <div class="container">
      <div class="section-title">
        <h2>Médicos por especialidade</h2>
        <p>Uma visão clara de quem atende cada linha de cuidado, unidade e modalidade.</p>
      </div>
      ${content}
      <div class="text-center mt-4"><a class="btn btn-light" href="medicos.html">Abrir página completa de médicos</a></div>
    </div>
  `;
}

// Função filtrarMedicosEspecialidade: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function filtrarMedicosEspecialidade(especialidade, botao) {
  document.querySelectorAll('.doctor-filter-chip').forEach(chip => chip.classList.remove('active'));
  botao?.classList.add('active');
  document.querySelectorAll('#doctorSpecialtyGrid > div').forEach(card => {
    card.classList.toggle('hidden', especialidade !== 'Todos' && card.dataset.specialty !== especialidade);
  });
}

// Função renderUnidadesCompleta: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function renderUnidadesCompleta() {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (paginaArquivo() !== 'unidades.html') return;
  const grid = document.querySelector('.unidade-rica')?.parentElement;
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!grid || grid.dataset.unitEnhanced === 'true') return;
  grid.dataset.unitEnhanced = 'true';

  const imagensClinicas = [
    '../../recursos/imagens/Area-de-espera.jpg',
    '../../recursos/imagens/central-de-saude.jpg',
    '../../recursos/imagens/diagnosticos-completos.jpg'
  ];

  grid.className = 'unit-showcase-grid unit-showcase-grid-refined';
  grid.innerHTML = NL_UNIDADES.map((unidade, index) => {
    const imagem = unidade.imagem || imagensClinicas[index % imagensClinicas.length];
    const recursos = (unidade.recursos && unidade.recursos.length ? unidade.recursos : [
      unidade.modalidades.includes('EXAM') ? 'Exames neurológicos' : 'Consultas presenciais',
      unidade.modalidades.includes('TELE') ? 'Teleconsulta de apoio' : 'Recepção presencial',
      unidade.coberturas.includes('SUS') ? 'Cotas SUS' : 'Convênios privados'
    ]).slice(0, 4);
    const enderecoEsc = unidade.endereco.replace(/'/g, "\\'");
    const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(unidade.endereco)}`;
    const horario = unidade.horario || (unidade.nome.includes('Centro') ? 'Seg–Sex 7h às 19h · Sáb 8h às 13h' : 'Seg–Sex 8h às 18h · Sáb 8h às 12h');
    const possuiExames = unidade.modalidades.includes('EXAM');
    const possuiTele = unidade.modalidades.includes('TELE');

    return `
      <article class="unit-showcase-card unit-visual-card">
        <div class="unit-showcase-photo">
          <img src="${imagem}" alt="Recepção e frente da unidade ${nlSafeText(unidade.nome)}" loading="lazy">
          <span class="unit-photo-badge">Unidade física</span>
          <a class="unit-map-link" href="${mapsUrl}" target="_blank" rel="noopener">Abrir no Maps ↗</a>
        </div>
        <div class="unit-map-preview">
          <iframe title="Mapa da unidade ${nlSafeText(unidade.nome)}" loading="lazy" referrerpolicy="no-referrer-when-downgrade" src="${unidade.mapa}"></iframe>
        </div>
        <div class="unit-showcase-body">
          <div class="unit-heading unit-heading-clean">
            <div>
              <span class="unit-city-label">NeuroLab Center</span>
              <h3>${nlSafeText(unidade.nome)}</h3>
            </div>
            <span>${nlSafeText(unidade.distancia)}</span>
          </div>
          <p class="unit-address-line">${nlSafeText(unidade.endereco)}</p>
          <div class="unit-info-row">
            <span>🕐 ${nlSafeText(horario)}</span>
            <span>${possuiExames ? '🧠 Exames no local' : '🩺 Consultas presenciais'}</span>
            <span>${possuiTele ? '💻 Suporte à teleconsulta' : '👥 Atendimento presencial'}</span>
          </div>
          <div class="unit-resource-grid unit-resource-fixed">
            ${recursos.map(recurso => `<span>${nlSafeText(recurso)}</span>`).join('')}
          </div>
          <div class="tags unit-tags-fixed">${unidade.coberturas.map(item => `<span class="tag">${nlSafeText(item)}</span>`).join('')}</div>
          <div class="unit-card-actions unit-card-actions-single">
            <button class="btn btn-primary" onclick="abrirAgendamento()">Agendar nesta unidade</button>
            <button class="btn btn-outline-unit" type="button" onclick="copiarEnderecoUnidade('${enderecoEsc}')">Copiar endereço</button>
          </div>
        </div>
      </article>
    `;
  }).join('');
}

// Função copiarEnderecoUnidade: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function copiarEnderecoUnidade(endereco) {
  const texto = String(endereco || '').trim();
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!texto) return;
  navigator.clipboard?.writeText(texto)
    .then(() => mostrarToast('Endereço copiado.', 'sucesso'))
    .catch(() => mostrarToast(texto, 'info'));
}
