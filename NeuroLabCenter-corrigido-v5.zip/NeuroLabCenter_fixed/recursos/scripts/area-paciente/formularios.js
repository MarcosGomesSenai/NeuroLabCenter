/*
 * Arquivo: recursos/scripts/area-paciente/formularios.js
 * Objetivo: controlar comportamentos da interface do NeuroLab Center.
 * Como manter: mantenha funções pequenas, nomes claros e evite misturar páginas diferentes.
 * Observação: comentários explicam blocos, funções, validações e integração com o servidor.
 */

/*
 * NeuroLab Center - recursos/scripts/area-paciente/formularios.js
 * Responsabilidade: Comportamentos da Área do Paciente: painel, documentos, convênios e integração com portal.
 * Usado por: Páginas HTML em site/paginas/.
 * Manutenção: mantenha funções relacionadas juntas e evite misturar regras de páginas diferentes.
 */

/**
 * NeuroLab Center — Área do Paciente — 05-patient-form-helpers.js
 * Origem reorganizada: recursos/scripts/paginas/plans-units-patient/patient-form-helpers.js
 * Responsabilidade isolada para facilitar manutenção sem arquivos gigantes.
 */

/* === Área do Paciente 2.0 — visual refinado + persistência de formulários === */
function nlMascaraCpf(cpf) {
  const clean = String(cpf || '').replace(/\D/g, '');
  return clean.length === 11 ? `${clean.slice(0, 3)}.***.***-${clean.slice(-2)}` : 'CPF não informado';
}

// Função nlInputValue: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function nlInputValue(value) {
  return nlSafeText(value || '');
}

// Função nlPacienteStorageKey: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function nlPacienteStorageKey(tipo, cpf = getPerfilAtivoCpf()) {
  return chaveDadosPerfil(`neurolab_area_${tipo}`, cpf);
}
/* Removido: definição duplicada antiga de nlFormularioLocal; mantida a versão final oficial no arquivo. */

/* Removido: definição duplicada antiga de nlCarregarFormularioPaciente; mantida a versão final oficial no arquivo. */

/* Removido: definição duplicada antiga de nlSalvarFormularioPaciente; mantida a versão final oficial no arquivo. */


function nlDadosPacientePadrao(perfil = {}) {
  return {
    email: perfil.email || getPerfilAtivoUsuario()?.email || getUsuarioLogado()?.email || '',
    telefone: perfil.telefone || getPerfilAtivoUsuario()?.telefone || getUsuarioLogado()?.telefone || getUsuarioLogado()?.celular || '',
    emergencia_nome: '',
    emergencia_telefone: '',
    convenio: '',
    carteirinha: '',
    endereco: '',
    cep: '',
    cidade: '',
    observacao_recepcao: '',
  };
}

// Função nlContarCamposPreenchidos: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function nlContarCamposPreenchidos(obj, chaves) {
  return chaves.reduce((total, chave) => total + (String(obj?.[chave] || '').trim() ? 1 : 0), 0);
}
/* Removido: definição duplicada antiga de nlCalcularCompletudeArea; mantida a versão final oficial no arquivo. */

/* Removido: definição duplicada antiga de nlStatusSincronizacao; mantida a versão final oficial no arquivo. */

/* Removido: definição duplicada antiga de renderPortalPacienteNovo; mantida a versão final oficial no arquivo. */


function nlPacienteFormInput(id, label, value, placeholder = '', type = 'text') {
  return `<label class="patient-field"><span>${label}</span><input id="${id}" type="${type}" value="${nlInputValue(value)}" placeholder="${nlInputValue(placeholder)}"></label>`;
}

// Função nlPacienteFormTextarea: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function nlPacienteFormTextarea(id, label, value, placeholder = '') {
  return `<label class="patient-field patient-field-full"><span>${label}</span><textarea id="${id}" placeholder="${nlInputValue(placeholder)}">${nlSafeText(value || '')}</textarea></label>`;
}
/* Removido: definição duplicada antiga de alternarPacienteSecao; mantida a versão final oficial no arquivo. */

/* Removido: definição duplicada antiga de lerDadosCadastraisCampos; mantida a versão final oficial no arquivo. */

/* Removido: definição duplicada antiga de salvarDadosCadastraisPaciente; mantida a versão final oficial no arquivo. */

/* Removido: definição duplicada antiga de preconsultaVazia; mantida a versão final oficial no arquivo. */

/* Removido: definição duplicada antiga de lerPreConsultaCampos; mantida a versão final oficial no arquivo. */


function salvarRascunhoPreConsultaPaciente() {
  const status = document.getElementById('preconsultaStatus');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (status) status.textContent = 'Rascunho desativado: use Enviar pré-consulta para salvar no MySQL';
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (typeof mostrarToast === 'function') {
    mostrarToast('Rascunho local desativado. O salvamento oficial acontece apenas no MySQL ao enviar a pré-consulta.', 'aviso', 5500);
  }
  return false;
}
/* Removido: definição duplicada antiga de salvarPreConsultaPaciente; mantida a versão final oficial no arquivo. */

/* Removido: definição duplicada antiga de salvarPreferenciasExtrasPaciente; mantida a versão final oficial no arquivo. */

/* Removido: definição duplicada antiga de registrarCheckinPaciente; mantida a versão final oficial no arquivo. */
