/*
 * Arquivo: recursos/scripts/area-paciente/documentos.js
 * Objetivo: controlar comportamentos da interface do NeuroLab Center.
 * Como manter: mantenha funções pequenas, nomes claros e evite misturar páginas diferentes.
 * Observação: comentários explicam blocos, funções, validações e integração com o servidor.
 */

/*
 * NeuroLab Center - recursos/scripts/area-paciente/documentos.js
 * Responsabilidade: Comportamentos da Área do Paciente: painel, documentos, convênios e integração com portal.
 * Usado por: Páginas HTML em site/paginas/.
 * Manutenção: mantenha funções relacionadas juntas e evite misturar regras de páginas diferentes.
 */

/**
 * NeuroLab Center — Área do Paciente — 08-patient-documents.js
 * Origem reorganizada: recursos/scripts/paginas/plans-units-patient/patient-documents.js
 * Responsabilidade isolada para facilitar manutenção sem arquivos gigantes.
 */

/* ============================================================
   HOTFIX 4.0 — visualização de documentos + responsividade real
   Sobrescreve as funções anteriores sem alterar a identidade visual.
   ============================================================ */
// Função nlDocDecodeRef: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function nlDocDecodeRef(ref) {
// Bloco protegido: tenta executar a ação e permite tratar falhas sem travar a página.
  try { return decodeURIComponent(String(ref || '')); }
  catch (_) { return String(ref || ''); }
}

// Função nlDocCandidateValues: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function nlDocCandidateValues(doc) {
  return [
    doc?.local_id,
    doc?.id,
    doc?.id_mysql,
    doc?.nome_arquivo,
    doc?.nome
  ].filter(value => value !== undefined && value !== null && String(value).trim() !== '').map(value => String(value));
}

// Função documentoPacienteRef: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function documentoPacienteRef(doc) {
  const value = doc?.local_id || doc?.id || doc?.id_mysql || doc?.nome_arquivo || doc?.nome || '';
  return encodeURIComponent(String(value));
}
/* Removido: definição duplicada antiga de documentoPacienteLocal; mantida a versão final oficial no arquivo. */


function nlNormalizarDocumentoBase64(doc) {
  const raw = String(doc?.conteudo_base64 || doc?.base64 || doc?.arquivo_base64 || '').trim();
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!raw) return '';
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (raw.startsWith('data:')) return raw;
  const nome = String(doc?.nome_arquivo || doc?.nome || '').toLowerCase();
  const tipo = String(doc?.tipo_arquivo || doc?.tipo || '').toLowerCase();
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (tipo.includes('pdf') || nome.endsWith('.pdf')) return `data:application/pdf;base64,${raw}`;
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (nome.endsWith('.webp') || tipo.includes('webp')) return `data:image/webp;base64,${raw}`;
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (nome.endsWith('.png') || tipo.includes('png')) return `data:image/png;base64,${raw}`;
  return `data:image/jpeg;base64,${raw}`;
}

// Função nlDataUriToBlob: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function nlDataUriToBlob(dataUri) {
  const match = String(dataUri || '').match(/^data:([^;,]+)(;base64)?,(.*)$/);
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!match) return null;
  const mime = match[1] || 'application/octet-stream';
  const isBase64 = Boolean(match[2]);
  const payload = match[3] || '';
  let bytes;
// Bloco protegido: tenta executar a ação e permite tratar falhas sem travar a página.
  try {
    const binary = isBase64 ? atob(payload) : decodeURIComponent(payload);
    const slices = [];
    for (let offset = 0; offset < binary.length; offset += 1024) {
      const chunk = binary.slice(offset, offset + 1024);
      const numbers = new Array(chunk.length);
      for (let i = 0; i < chunk.length; i += 1) numbers[i] = chunk.charCodeAt(i);
      slices.push(new Uint8Array(numbers));
    }
    bytes = slices;
  } catch (_) {
    return null;
  }
  return new Blob(bytes, { type: mime });
}

// Função nlFecharVisualizadorDocumento: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function nlFecharVisualizadorDocumento() {
  const viewer = document.getElementById('patientDocumentViewer');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!viewer) return;
  const objectUrl = viewer.dataset.objectUrl;
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (objectUrl) URL.revokeObjectURL(objectUrl);
  viewer.remove();
}

// Função nlAbrirVisualizadorDocumento: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function nlAbrirVisualizadorDocumento(doc) {
  const conteudo = nlNormalizarDocumentoBase64(doc);
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!conteudo) {
    mostrarToast('Arquivo sem conteúdo salvo. Reenvie o documento para liberar a visualização.', 'aviso');
    return;
  }

  const nome = doc?.nome_arquivo || doc?.nome || 'documento';
  const isImage = conteudo.startsWith('data:image/');
  const blob = nlDataUriToBlob(conteudo);
  const objectUrl = blob ? URL.createObjectURL(blob) : conteudo;

  nlFecharVisualizadorDocumento();
  const viewer = document.createElement('div');
  viewer.id = 'patientDocumentViewer';
  viewer.className = 'patient-document-viewer';
  viewer.dataset.objectUrl = blob ? objectUrl : '';
  viewer.innerHTML = `
    <div class="patient-document-viewer-card" role="dialog" aria-modal="true" aria-label="Visualizador de documento">
      <header class="patient-document-viewer-head">
        <div>
          <span>Documento do paciente</span>
          <strong>${nlSafeText(nome)}</strong>
        </div>
        <div class="patient-document-viewer-actions">
          <a class="btn btn-light btn-sm" href="${objectUrl}" download="${nlSafeText(nome)}" target="_blank" rel="noopener">Baixar</a>
          <button type="button" class="btn btn-primary btn-sm" onclick="nlFecharVisualizadorDocumento()">Fechar</button>
        </div>
      </header>
      <div class="patient-document-viewer-body">
        ${isImage ? `<img src="${objectUrl}" alt="${nlSafeText(nome)}">` : `<iframe src="${objectUrl}" title="${nlSafeText(nome)}"></iframe>`}
      </div>
    </div>
  `;
// Evento da interface: conecta uma ação do usuário com uma função do sistema.
  viewer.addEventListener('click', event => {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (event.target === viewer) nlFecharVisualizadorDocumento();
  });
  document.body.appendChild(viewer);
}
/* Removido: definição duplicada antiga de abrirDocumentoPaciente; mantida a versão final oficial no arquivo. */

/* Removido: definição duplicada antiga de salvarDocumentoLocalPaciente; mantida a versão final oficial no arquivo. */

/* Removido: definição duplicada antiga de uploadDocumentoPaciente; mantida a versão final oficial no arquivo. */

/* Removido: definição duplicada antiga de removerDocumentoPaciente; mantida a versão final oficial no arquivo. */


document.addEventListener('keydown', event => {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (event.key === 'Escape') nlFecharVisualizadorDocumento();
});
