/*
 * Arquivo: recursos/scripts/area-paciente/inicializacao.js
 * Objetivo: controlar comportamentos da interface do NeuroLab Center.
 * Como manter: mantenha funções pequenas, nomes claros e evite misturar páginas diferentes.
 * Observação: comentários explicam blocos, funções, validações e integração com o servidor.
 */

/*
 * NeuroLab Center - recursos/scripts/area-paciente/inicializacao.js
 * Responsabilidade: Comportamentos da Área do Paciente: painel, documentos, convênios e integração com portal.
 * Usado por: Páginas HTML em site/paginas/.
 * Manutenção: mantenha funções relacionadas juntas e evite misturar regras de páginas diferentes.
 */

/**
 * NeuroLab Center — Área do Paciente — 10-initializer.js
 * Origem reorganizada: recursos/scripts/paginas/plans-units-patient/initializer.js
 * Responsabilidade isolada para facilitar manutenção sem arquivos gigantes.
 */

/* NeuroLab page initializer: ativa automaticamente o módulo certo sem depender de chamadas manuais. */
document.addEventListener('DOMContentLoaded', () => {
  const pagina = typeof paginaArquivo === 'function' ? paginaArquivo() : (window.location.pathname.split('/').pop() || 'index.html').toLowerCase();
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (pagina === 'area-paciente.html') {
    initPortalPaciente();
    return;
  }
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (pagina === 'medicos.html' && typeof renderMedicosPage === 'function') renderMedicosPage();
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (pagina === 'unidades.html') {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (typeof renderUnidadesCompleta === 'function') renderUnidadesCompleta();
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (typeof aprimorarUnidadesMapas === 'function') aprimorarUnidadesMapas();
  }
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (pagina === 'convenios.html' && typeof renderConveniosMelhorados === 'function') renderConveniosMelhorados();
});
