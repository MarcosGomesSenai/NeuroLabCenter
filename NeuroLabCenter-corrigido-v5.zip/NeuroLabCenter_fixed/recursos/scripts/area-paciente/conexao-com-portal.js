/*
 * Arquivo: recursos/scripts/area-paciente/conexao-com-portal.js
 * Objetivo: controlar comportamentos da interface do NeuroLab Center.
 * Como manter: mantenha funções pequenas, nomes claros e evite misturar páginas diferentes.
 * Observação: comentários explicam blocos, funções, validações e integração com o servidor.
 */

/*
 * NeuroLab Center - recursos/scripts/area-paciente/conexao-com-portal.js
 * Responsabilidade: Comportamentos da Área do Paciente: painel, documentos, convênios e integração com portal.
 * Usado por: Páginas HTML em site/paginas/.
 * Manutenção: mantenha funções relacionadas juntas e evite misturar regras de páginas diferentes.
 */

/**
 * NeuroLab Center — Área do Paciente — 04-portal-api.js
 * Origem reorganizada: recursos/scripts/paginas/plans-units-patient/portal-api.js
 * Responsabilidade isolada para facilitar manutenção sem arquivos gigantes.
 */

let portalApiCache = null;

// Função carregarPortalApi: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
async function carregarPortalApi() {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (typeof getAuthToken !== 'function' || !getAuthToken()) return null;
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (typeof apiDisponivel !== 'function' || !(await apiDisponivel())) return null;
// Bloco protegido: tenta executar a ação e permite tratar falhas sem travar a página.
  try {
    portalApiCache = await apiPortalPainel(getPerfilAtivoCpf());
    return portalApiCache;
  } catch (erro) {
    mostrarToast(erro.message || 'Não foi possível carregar dados do banco.', 'aviso');
    return null;
  }
}

// Função initPortalPaciente: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
async function initPortalPaciente() {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (paginaArquivo() !== 'area-paciente.html') return;
  await carregarPortalApi();
  const grid = document.querySelector('.patient-app-shell, .dashboard-grid');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (grid) delete grid.dataset.patientEnhanced;
  renderPortalPacienteNovo();
}
/* Removido: definição duplicada antiga de renderPortalPacienteNovo; mantida a versão final oficial no arquivo. */

/* Removido: definição duplicada antiga de salvarFotoPerfilPaciente; mantida a versão final oficial no arquivo. */


async function trocarPerfilFamilia(cpf) {
  trocarPerfilFamiliaPorCpf(cpf);
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (typeof setPerfilAtivoCpf === 'function') setPerfilAtivoCpf(cpf);
  portalApiCache = null;
  await initPortalPaciente();
  const perfil = (portalApiCache?.perfis_familia || listarPerfisFamilia()).find(p => p.cpf === getPerfilAtivoCpf());
  mostrarToast(`Perfil ativo: ${perfil?.nome || 'Titular'}. Dados carregados do banco para este CPF.`, 'info');
}
/* Removido: definição duplicada antiga de documentoPacienteRef; mantida a versão final oficial no arquivo. */

/* Removido: definição duplicada antiga de documentoPacienteLocal; mantida a versão final oficial no arquivo. */

/* Removido: definição duplicada antiga de listaDocumentosLocais; mantida a versão final oficial no arquivo. */

/* Removido: definição duplicada antiga de salvarListaDocumentosLocais; mantida a versão final oficial no arquivo. */

/* Removido: definição duplicada antiga de preconsultaVazia; mantida a versão final oficial no arquivo. */

/* Removido: definição duplicada antiga de alternarPacienteSecao; mantida a versão final oficial no arquivo. */

/* Removido: definição duplicada antiga de atualizarPreferenciaPaciente; mantida a versão final oficial no arquivo. */

/* Removido: definição duplicada antiga de registrarCheckinPaciente; mantida a versão final oficial no arquivo. */

/* Removido: definição duplicada antiga de abrirDocumentoPaciente; mantida a versão final oficial no arquivo. */

/* Removido: definição duplicada antiga de salvarDocumentoLocalPaciente; mantida a versão final oficial no arquivo. */

/* Removido: definição duplicada antiga de uploadDocumentoPaciente; mantida a versão final oficial no arquivo. */

/* Removido: definição duplicada antiga de removerDocumentoPaciente; mantida a versão final oficial no arquivo. */

/* Removido: definição duplicada antiga de lerPreConsultaCampos; mantida a versão final oficial no arquivo. */

/* Removido: definição duplicada antiga de salvarRascunhoPreConsultaPaciente; mantida a versão final oficial no arquivo. */

/* Removido: definição duplicada antiga de salvarPreConsultaPaciente; mantida a versão final oficial no arquivo. */

/* Removido: definição duplicada antiga de removerPerfilFamilia; mantida a versão final oficial no arquivo. */
