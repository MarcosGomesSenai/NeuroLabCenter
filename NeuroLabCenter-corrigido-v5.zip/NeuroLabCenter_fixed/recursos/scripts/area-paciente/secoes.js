/*
 * Arquivo: recursos/scripts/area-paciente/secoes.js
 * Objetivo: controlar comportamentos da interface do NeuroLab Center.
 * Como manter: mantenha funções pequenas, nomes claros e evite misturar páginas diferentes.
 * Observação: comentários explicam blocos, funções, validações e integração com o servidor.
 */

/*
 * NeuroLab Center - recursos/scripts/area-paciente/secoes.js
 * Responsabilidade: Comportamentos da Área do Paciente: painel, documentos, convênios e integração com portal.
 * Usado por: Páginas HTML em site/paginas/.
 * Manutenção: mantenha funções relacionadas juntas e evite misturar regras de páginas diferentes.
 */

/**
 * NeuroLab Center — Área do Paciente — 07-dashboard-sections.js
 * Origem reorganizada: recursos/scripts/paginas/plans-units-patient/patient-dashboard-sections.js
 * Responsabilidade isolada para facilitar manutenção sem arquivos gigantes.
 */

function nlPacienteSelect(id, label, value, options) {
  return `<label class="patient-field"><span>${label}</span><select id="${id}">${options.map(([val, txt]) => `<option value="${nlSafeText(val)}" ${value === val ? 'selected' : ''}>${nlSafeText(txt)}</option>`).join('')}</select></label>`;
}


// Função nlPacienteCriarContexto: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function nlPacienteCriarContexto(painel) {
  const cpfPerfil = getPerfilAtivoCpf();
  const perfil = portalApiCache?.perfil_ativo || getPerfilAtivoUsuario() || getUsuarioLogado() || {};
  const usaApi = typeof getAuthToken === 'function' && getAuthToken();
  const agendamentos = portalApiCache?.agendamentos || agendamentosDoPerfil(cpfPerfil);
  const docs = portalApiCache?.documentos || listaDocumentosLocais(cpfPerfil);
  const prefs = portalApiCache?.preferencias || lerJson(chaveDadosPerfil('neurolab_paciente_preferencias', cpfPerfil), {
    whatsapp: true,
    email: true,
    sms: false
  });

  return { painel, cpfPerfil, perfil, usaApi, agendamentos, docs, prefs };
}

// Função nlPacienteMarcarAbaAtiva: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function nlPacienteMarcarAbaAtiva(secao, botao) {
  document.querySelectorAll('.patient-tabs button').forEach(item => item.classList.remove('active'));
  const ativo = botao || [...document.querySelectorAll('.patient-tabs button')]
    .find(item => item.getAttribute('onclick')?.includes(`'${secao}'`));
  ativo?.classList.add('active');
}


// Função nlRenderPacienteDados: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
async function nlRenderPacienteDados(ctx) {
  const dados = await nlCarregarFormularioPaciente('dados_cadastrais', nlDadosPacientePadrao(ctx.perfil));
  const menor = nlPacienteMenorAtual();

  ctx.painel.innerHTML = `
    <div class="patient-section-head patient-section-head-v3">
      <div><strong>Meus dados</strong><p>Campos salvos por CPF. O contato de emergência vira obrigatório para menores de 18 anos.</p></div>
      <span class="patient-save-pill" id="dadosStatus">${dados.atualizado_em ? 'Dados carregados' : 'Não enviado'}</span>
    </div>
    ${menor ? '<div class="patient-rule-alert">Paciente menor de 18 anos: informe nome e telefone do responsável/contato de emergência.</div>' : ''}
    <div class="patient-form-grid patient-form-grid-v3">
      ${nlPacienteFormInput('dadosEmail', 'E-mail de contato', dados.email, 'exemplo@email.com', 'email')}
      ${nlPacienteFormInput('dadosTelefone', 'Celular / WhatsApp', dados.telefone, '(11) 99999-9999')}
      ${nlPacienteFormInput('dadosEmergenciaNome', `Contato de emergência${menor ? ' *' : ''}`, dados.emergencia_nome, 'Nome do responsável/contato')}
      ${nlPacienteFormInput('dadosEmergenciaTelefone', `Telefone de emergência${menor ? ' *' : ''}`, dados.emergencia_telefone, '(11) 99999-9999')}
      ${nlPacienteFormInput('dadosConvenio', 'Convênio', dados.convenio, 'Particular, SUS ou nome do convênio')}
      ${nlPacienteFormInput('dadosCarteirinha', 'Número da carteirinha', dados.carteirinha, 'Opcional')}
      ${nlPacienteFormInput('dadosCep', 'CEP', dados.cep, '00000-000')}
      ${nlPacienteFormInput('dadosCidade', 'Cidade', dados.cidade, 'Santo André - SP')}
      ${nlPacienteFormTextarea('dadosEndereco', 'Endereço completo', dados.endereco, 'Rua, número, bairro e complemento')}
      ${nlPacienteFormTextarea('dadosObservacaoRecepcao', 'Observação para recepção', dados.observacao_recepcao, 'Acessibilidade, melhor forma de contato, preferências...')}
    </div>
    <div class="patient-form-actions patient-form-actions-v3">
      <button class="btn btn-primary" onclick="salvarDadosCadastraisPaciente()">Salvar dados</button>
      <small>Valida e-mail, telefone, CEP e responsável quando necessário.</small>
    </div>
  `;
}


// Função nlRenderPacienteDocumentos: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
async function nlRenderPacienteDocumentos(ctx) {
  const docsLocais = listaDocumentosLocais(ctx.cpfPerfil);
  let docs = ctx.docs;

// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (ctx.usaApi) {
// Bloco protegido: tenta executar a ação e permite tratar falhas sem travar a página.
    try {
      const docsApi = await apiPortalDocumentos(ctx.cpfPerfil);
      docs = [...(docsApi || []), ...docsLocais.filter(local => !local.sincronizado_mysql)];
    } catch (_) {
      docs = docsLocais;
    }
  } else {
    docs = docsLocais;
  }

  const metaDocs = lerJson(chaveDadosPerfil('neurolab_documentos_meta', ctx.cpfPerfil), {});
  docs = (docs || []).map(doc => ({ ...doc, ...(doc.id ? (metaDocs[doc.id] || {}) : {}) }));

  ctx.painel.innerHTML = `
    <div class="patient-section-head patient-section-head-v3">
      <div><strong>Documentos</strong><p>Envie arquivos por categoria. O sistema valida formato, tamanho e consentimento antes de salvar.</p></div>
      <span class="patient-save-pill">${(docs || []).length} arquivo(s)</span>
    </div>
    <div class="patient-doc-upload-v3">
      <div class="patient-doc-upload-main">
        <strong>Adicionar novo arquivo</strong>
        <p>Permitido: PDF, PNG, JPG ou WEBP até 5 MB.</p>
        <div class="patient-doc-controls">
          <select id="patientDocCategoria">
            <option value="documento_identidade">Documento de identidade</option>
            <option value="convenio">Carteirinha do convênio</option>
            <option value="encaminhamento">Encaminhamento médico</option>
            <option value="laudo">Laudo / exame anterior</option>
            <option value="consentimento">Termo / autorização</option>
            <option value="outros">Outros</option>
          </select>
          <label class="btn btn-primary mb-0">
            Selecionar arquivo
            <input type="file" id="patientDocInput" accept=".pdf,image/png,image/jpeg,image/webp" onchange="uploadDocumentoPaciente(this)" hidden>
          </label>
        </div>
        <label class="patient-consent-line"><input type="checkbox" id="patientDocConsent"> Confirmo que posso enviar este documento e autorizo o uso para atendimento.</label>
      </div>
    </div>
    <div class="patient-doc-list patient-doc-list-v3">
      ${(docs || []).map(doc => {
        const ref = documentoPacienteRef(doc);
        const nomeDoc = doc.nome_arquivo || doc.nome || 'Documento';
        const tipoDoc = doc.tipo_arquivo || doc.tipo || 'arquivo';
        const origem = doc.id || doc.id_mysql ? 'MySQL' : 'Não sincronizado';
        const temConteudo = doc.conteudo_base64 || doc.tem_conteudo;
        return `
          <article>
            <div class="patient-doc-icon">${String(tipoDoc).toLowerCase().includes('pdf') ? 'PDF' : 'IMG'}</div>
            <div class="patient-doc-info">
              <strong>${nlSafeText(nomeDoc)}</strong>
              <span>${nlSafeText(nlPacienteDocCategoriaLabel(doc.categoria))} · ${nlSafeText(tipoDoc)} · ${origem}${doc.tamanho_kb ? ` · ${doc.tamanho_kb} KB` : ''}</span>
              <small>${temConteudo ? 'Disponível para visualizar e apagar.' : 'Sem conteúdo salvo para visualização.'}</small>
            </div>
            <div class="patient-doc-actions">
              <button class="btn btn-light btn-sm" onclick="abrirDocumentoPaciente('${ref}')">Visualizar</button>
              <button class="btn btn-light btn-sm text-danger" onclick="removerDocumentoPaciente('${ref}')">Apagar</button>
            </div>
          </article>`;
      }).join('') || '<div class="patient-empty-state"><strong>Nenhum documento enviado</strong><p>Envie um documento real para liberar visualização e exclusão.</p></div>'}
    </div>
  `;
}


// Função nlRenderPacientePreconsulta: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
async function nlRenderPacientePreconsulta(ctx) {
  const localPreconsulta = portalApiCache?.preconsulta || {};
// Configuração ou referência reutilizada pelas funções deste arquivo.
  let anamnese = {
    sintomas: '', intensidade: '', inicio_sintomas: '', medicamentos: '', alergias: '',
    doencas_previas: '', exames_recentes: '', observacoes: '', sinais_alerta: [],
    consentimento_triagem: false, sem_queixas: false, ...localPreconsulta
  };

// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (ctx.usaApi) {
// Bloco protegido: tenta executar a ação e permite tratar falhas sem travar a página.
    try {
      const apiCore = await apiPortalPreconsulta(ctx.cpfPerfil);
      const apiCompleta = await nlCarregarFormularioPaciente('preconsulta_completa', {});
      anamnese = { ...anamnese, ...(apiCore || {}), ...(apiCompleta || {}) };
    } catch (_) {
      /* Mantém os dados locais quando MySQL/API não responder. */
    }
  }

  const sinais = Array.isArray(anamnese.sinais_alerta) ? anamnese.sinais_alerta : [];
  ctx.painel.innerHTML = `
    <div class="patient-section-head patient-section-head-v3">
      <div><strong>Pré-consulta / triagem</strong><p>Formulário mais completo para reduzir dúvidas no atendimento. Não substitui atendimento de urgência.</p></div>
      <span class="patient-save-pill" id="preconsultaStatus">${preconsultaVazia(anamnese) ? 'Ainda não preenchida' : 'Dados carregados'}</span>
    </div>
    <div class="patient-risk-banner">Caso exista piora rápida ou situação urgente, procure atendimento de emergência em vez de aguardar a consulta.</div>
    <div class="patient-form-grid patient-form-grid-v3 patient-preconsulta-v3">
      <label class="patient-consent-line patient-field-full"><input type="checkbox" id="preSemQueixas" ${anamnese.sem_queixas ? 'checked' : ''}> Não tenho queixas atuais, quero apenas atualizar meus dados.</label>
      ${nlPacienteFormTextarea('preSintomas', 'Sintomas principais', anamnese.sintomas, 'Descreva o que está sentindo, frequência e contexto')}
      ${nlPacienteSelect('preIntensidade', 'Intensidade do sintoma', anamnese.intensidade, [['', 'Selecione'], ['Leve', 'Leve'], ['Moderado', 'Moderado'], ['Forte', 'Forte'], ['Muito forte', 'Muito forte']])}
      ${nlPacienteFormInput('preInicioSintomas', 'Quando começou?', anamnese.inicio_sintomas, 'Ex.: há 2 semanas')}
      ${nlPacienteFormTextarea('preMedicamentos', 'Medicamentos em uso', anamnese.medicamentos, 'Nome, dosagem e frequência')}
      ${nlPacienteFormTextarea('preAlergias', 'Alergias', anamnese.alergias, 'Medicamentos, alimentos ou outras alergias')}
      ${nlPacienteFormTextarea('preDoencasPrevias', 'Histórico de saúde', anamnese.doencas_previas, 'Doenças prévias, cirurgias, acompanhamentos...')}
      ${nlPacienteFormTextarea('preExamesRecentes', 'Exames recentes', anamnese.exames_recentes, 'Laudos ou exames feitos recentemente')}
      ${nlPacienteFormTextarea('preObservacoes', 'Outras observações', anamnese.observacoes, 'Informações que o médico deve saber')}
      <div class="patient-field patient-field-full patient-alert-checks">
        <span>Sinais de atenção para triagem</span>
        ${[
          ['inicio_subito', 'Sintoma começou de repente'],
          ['desmaio_convulsao', 'Desmaio ou convulsão recente'],
          ['fraqueza_importante', 'Fraqueza importante ou alteração de fala'],
          ['febre_persistente', 'Febre persistente junto dos sintomas']
        ].map(([valor, texto]) => `<label><input type="checkbox" value="${valor}" ${sinais.includes(valor) ? 'checked' : ''}> ${texto}</label>`).join('')}
      </div>
      <label class="patient-consent-line patient-field-full"><input type="checkbox" id="preConsentimento" ${anamnese.consentimento_triagem ? 'checked' : ''}> Confirmo que as informações são verdadeiras e autorizo o uso para triagem do atendimento.</label>
    </div>
    <div class="patient-form-actions patient-form-actions-v3">
      <button class="btn btn-primary" onclick="salvarPreConsultaPaciente()">Enviar pré-consulta</button>
      <small>Sem rascunho local: o envio oficial é validado e salvo diretamente no MySQL.</small>
    </div>
  `;
}


// Função nlRenderPacienteExames: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
async function nlRenderPacienteExames(ctx) {
  let exames = portalApiCache?.exames;
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (ctx.usaApi) {
// Bloco protegido: tenta executar a ação e permite tratar falhas sem travar a página.
    try { exames = await apiPortalExames(ctx.cpfPerfil); } catch (_) {}
  }
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!exames?.length) exames = lerJson(chaveDadosPerfil('neurolab_exames_paciente', ctx.cpfPerfil), []);

  ctx.painel.innerHTML = `
    <div class="patient-section-head patient-section-head-v3"><div><strong>Exames</strong><p>Somente exames vinculados ao CPF ativo aparecem aqui.</p></div><span class="patient-save-pill">${exames.length || 0} registro(s)</span></div>
    ${exames.length ? `<div class="patient-exam-list patient-exam-list-v3">${exames.map(ex => `<article><div><strong>${nlSafeText(ex.nome)}</strong><span>${nlSafeText(ex.status)} · ${nlSafeText(ex.data_referencia || ex.data || '')}</span><small>Preparo: ${nlSafeText(ex.preparo || 'Orientação ainda não cadastrada.')}</small></div><button class="btn btn-light" onclick="gerarDocumentoPaciente('${String(ex.nome).replace(/'/g, "\\'")}')">Ver laudo</button></article>`).join('')}</div>` : `<div class="patient-empty-state"><strong>Nenhum exame disponível</strong><p>Quando um exame for solicitado ou um laudo for liberado, ele aparecerá aqui.</p><button class="btn btn-primary" onclick="abrirAgendamento()">Agendar exame</button></div>`}
  `;
}

// Função nlRenderPacienteFamilia: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
async function nlRenderPacienteFamilia(ctx) {
  let perfis = portalApiCache?.perfis_familia || listarPerfisFamilia();
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (ctx.usaApi) {
// Bloco protegido: tenta executar a ação e permite tratar falhas sem travar a página.
    try {
      const fam = await apiPortalFamilia();
      perfis = fam.perfis || perfis;
    } catch (_) {}
  }
  const titular = getUsuarioLogado();

  ctx.painel.innerHTML = `
    <div class="patient-section-head patient-section-head-v3"><div><strong>Conta família</strong><p>Vínculo familiar real: cada CPF tem documentos, pré-consulta e agendamentos próprios.</p></div><span class="patient-save-pill">${perfis.length} perfil(is)</span></div>
    <div class="patient-family-list patient-family-list-v3">
      ${perfis.length ? perfis.map(perfilItem => `<article><div><strong>${nlSafeText(perfilItem.papel)} — ${nlSafeText(perfilItem.nome)}</strong><span>${perfilItem.cpf === ctx.cpfPerfil ? 'Perfil ativo agora' : 'CPF ' + nlMascaraCpf(perfilItem.cpf)}</span></div><div class="patient-family-actions">${perfilItem.cpf !== ctx.cpfPerfil ? `<button class="btn btn-light btn-sm" onclick="trocarPerfilFamilia('${perfilItem.cpf}')">Usar perfil</button>` : '<span class="badge bg-success">Ativo</span>'}${perfilItem.cpf !== titular?.cpf ? `<button class="btn btn-light btn-sm" onclick="removerPerfilFamilia('${perfilItem.cpf}')">Desvincular</button>` : '<span class="badge bg-light text-dark">Titular</span>'}</div></article>`).join('') : '<div class="patient-empty-state"><strong>Nenhum familiar vinculado</strong><p>Cadastre familiares reais com CPF próprio.</p></div>'}
    </div>
    <div class="patient-family-register mt-4"><button class="btn btn-primary" onclick="abrirCadastroFamiliar()">Cadastrar familiar</button><p class="text-muted small mt-2 mb-0">Para filho, neto ou dependente: 0 a 17 anos deve ter responsável vinculado.</p></div>
  `;
}


// Função nlRenderPacientePreferencias: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
async function nlRenderPacientePreferencias(ctx) {
  const prefsExtra = await nlCarregarFormularioPaciente('preferencias_visuais', {
    unidade_preferida: '',
    horario_preferido: '',
    observacoes_lembretes: ''
  });

  ctx.painel.innerHTML = `
    <div class="patient-section-head patient-section-head-v3"><div><strong>Lembretes e preferências</strong><p>Controle os canais e preferências de atendimento sem misturar CPFs.</p></div><span class="patient-save-pill" id="prefsStatus">Preferências carregadas</span></div>
    <div class="patient-preference-grid patient-preference-grid-v3">
      ${[['whatsapp','WhatsApp','Confirmações e lembretes rápidos.'],['email','E-mail','Documentos, recibos e orientações.'],['sms','SMS','Alertas curtos quando necessário.']].map(([chave,titulo,texto]) => `<label><span><strong>${titulo}</strong><small>${texto}</small></span><input type="checkbox" ${ctx.prefs[chave] ? 'checked' : ''} onchange="atualizarPreferenciaPaciente('${chave}', this.checked)"></label>`).join('')}
    </div>
    <div class="patient-form-grid patient-form-grid-v3 mt-3">
      ${nlPacienteFormInput('prefUnidade', 'Unidade preferida', prefsExtra.unidade_preferida, 'Ex.: Santo André - Centro')}
      ${nlPacienteFormInput('prefHorario', 'Horário preferido', prefsExtra.horario_preferido, 'Ex.: manhã, tarde ou sábado')}
      ${nlPacienteFormTextarea('prefObs', 'Observações de lembrete', prefsExtra.observacoes_lembretes, 'Ex.: confirmar sempre pelo WhatsApp')}
    </div>
    <div class="patient-form-actions"><button class="btn btn-primary" onclick="salvarPreferenciasExtrasPaciente()">Salvar preferências</button></div>
  `;
}

// Função nlRenderPacienteResumo: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function nlRenderPacienteResumo(ctx) {
  const dados = nlFormularioLocal('dados_cadastrais', nlDadosPacientePadrao(ctx.perfil));
  const pre = portalApiCache?.preconsulta || {};
  const docsResumo = ctx.docs || [];
  const pendencias = nlPendenciasPaciente(dados, docsResumo, pre, ctx.agendamentos);

  ctx.painel.innerHTML = `
    <div class="patient-summary-v3">
      <div class="patient-pending-box ${pendencias.length ? '' : 'is-ok'}">
        <strong>${pendencias.length ? 'Pendências para deixar o atendimento pronto' : 'Painel sem pendências principais'}</strong>
        ${pendencias.length ? `<ul>${pendencias.map(item => `<li>${nlSafeText(item)}</li>`).join('')}</ul>` : '<p>Dados principais completos para o fluxo básico de atendimento.</p>'}
      </div>
      <div class="patient-summary-grid patient-summary-grid-v3">
        <article><span>Dados cadastrais</span><strong>${nlContarCamposPreenchidos(dados, ['telefone','email','emergencia_nome','emergencia_telefone','endereco'])}/5 campos</strong><small>${dados.emergencia_nome ? 'Contato de emergência informado.' : 'Contato de emergência pendente.'}</small></article>
        <article><span>Documentos</span><strong>${docsResumo.length ? `${docsResumo.length} arquivo(s)` : 'Nenhum enviado'}</strong><small>PDF/imagem até 5 MB, separados por CPF.</small></article>
        <article><span>Pré-consulta</span><strong>${preconsultaVazia(pre) ? 'Pendente' : 'Preenchida'}</strong><small>${pre.atualizado_em ? `Atualizada em ${new Date(pre.atualizado_em).toLocaleDateString('pt-BR')}` : 'Preencha antes do atendimento.'}</small></article>
        <article><span>Sincronização</span><strong>${nlStatusSincronizacao()}</strong><small>${ctx.usaApi ? 'Dados conectados à API.' : 'Abra a API Flask para gravar no MySQL.'}</small></article>
      </div>
    </div>
  `;
}


// Função alternarPacienteSecao: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
async function alternarPacienteSecao(secao = 'resumo', botao) {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (paginaArquivo() !== 'area-paciente.html') return;

  const painel = document.getElementById('patientDynamicPanel');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!painel) return;

  nlPacienteMarcarAbaAtiva(secao, botao);
  const ctx = nlPacienteCriarContexto(painel);

// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (secao === 'dados') return nlRenderPacienteDados(ctx);
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (secao === 'documentos') return nlRenderPacienteDocumentos(ctx);
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (secao === 'preconsulta') return nlRenderPacientePreconsulta(ctx);
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (secao === 'exames') return nlRenderPacienteExames(ctx);
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (secao === 'familia') return nlRenderPacienteFamilia(ctx);
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (secao === 'preferencias') return nlRenderPacientePreferencias(ctx);

  return nlRenderPacienteResumo(ctx);
}


// Função lerDadosCadastraisCampos: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function lerDadosCadastraisCampos() {
  return {
    email: document.getElementById('dadosEmail')?.value?.trim() || '',
    telefone: document.getElementById('dadosTelefone')?.value?.trim() || '',
    emergencia_nome: document.getElementById('dadosEmergenciaNome')?.value?.trim() || '',
    emergencia_telefone: document.getElementById('dadosEmergenciaTelefone')?.value?.trim() || '',
    convenio: document.getElementById('dadosConvenio')?.value?.trim() || '',
    carteirinha: document.getElementById('dadosCarteirinha')?.value?.trim() || '',
    cep: document.getElementById('dadosCep')?.value?.trim() || '',
    cidade: document.getElementById('dadosCidade')?.value?.trim() || '',
    endereco: document.getElementById('dadosEndereco')?.value?.trim() || '',
    observacao_recepcao: document.getElementById('dadosObservacaoRecepcao')?.value?.trim() || ''
  };
}
/* Removido: definição duplicada antiga de salvarDadosCadastraisPaciente; mantida a versão final oficial no arquivo. */


function lerPreConsultaCampos() {
  return {
    sem_queixas: Boolean(document.getElementById('preSemQueixas')?.checked),
    sintomas: document.getElementById('preSintomas')?.value?.trim() || '',
    intensidade: document.getElementById('preIntensidade')?.value?.trim() || '',
    inicio_sintomas: document.getElementById('preInicioSintomas')?.value?.trim() || '',
    medicamentos: document.getElementById('preMedicamentos')?.value?.trim() || '',
    alergias: document.getElementById('preAlergias')?.value?.trim() || '',
    doencas_previas: document.getElementById('preDoencasPrevias')?.value?.trim() || '',
    exames_recentes: document.getElementById('preExamesRecentes')?.value?.trim() || '',
    observacoes: document.getElementById('preObservacoes')?.value?.trim() || '',
    sinais_alerta: [...document.querySelectorAll('.patient-alert-checks input:checked')].map(item => item.value),
    consentimento_triagem: Boolean(document.getElementById('preConsentimento')?.checked),
    atualizado_em: new Date().toISOString()
  };
}

// Função preconsultaVazia: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function preconsultaVazia(dados) {
  return !dados?.sem_queixas && nlContarCamposPreenchidos(dados || {}, ['sintomas', 'medicamentos', 'observacoes', 'alergias', 'doencas_previas', 'exames_recentes']) === 0;
}
/* Removido: definição duplicada antiga de salvarPreConsultaPaciente; mantida a versão final oficial no arquivo. */

/* Removido: definição duplicada antiga de uploadDocumentoPaciente; mantida a versão final oficial no arquivo. */

/* Removido: definição duplicada antiga de salvarDocumentoLocalPaciente; mantida a versão final oficial no arquivo. */
