/*
 * Arquivo: recursos/scripts/area-paciente/acoes-no-banco.js
 * Objetivo: controlar comportamentos da interface do NeuroLab Center.
 * Como manter: mantenha funções pequenas, nomes claros e evite misturar páginas diferentes.
 * Observação: comentários explicam blocos, funções, validações e integração com o servidor.
 */

/*
 * NeuroLab Center - recursos/scripts/area-paciente/acoes-no-banco.js
 * Responsabilidade: Comportamentos da Área do Paciente: painel, documentos, convênios e integração com portal.
 * Usado por: Páginas HTML em site/paginas/.
 * Manutenção: mantenha funções relacionadas juntas e evite misturar regras de páginas diferentes.
 */

/**
 * NeuroLab Center — Área do Paciente — 09-mysql-actions.js
 * Origem reorganizada: recursos/scripts/paginas/plans-units-patient/patient-mysql-actions.js
 * Responsabilidade isolada para facilitar manutenção sem arquivos gigantes.
 */

/* ============================================================
   MYSQL ONLY — sem fallback de dados de negócio no localStorage
   ============================================================ */
// Função nlMySQLPronto: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
async function nlMySQLPronto(mensagem = true) {
  const okToken = typeof getAuthToken === 'function' && Boolean(getAuthToken());
  const okApi = typeof apiDisponivel === 'function' && await apiDisponivel();
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if ((!okToken || !okApi) && mensagem && typeof mostrarToast === 'function') {
    mostrarToast('MySQL/API indisponível ou usuário sem login. Os dados não serão salvos fora do MySQL.', 'aviso', 6500);
  }
  return okToken && okApi;
}

// Função nlStatusSincronizacao: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function nlStatusSincronizacao() {
  return (typeof getAuthToken === 'function' && getAuthToken()) ? 'MySQL obrigatório' : 'Login necessário';
}

// Função listaDocumentosLocais: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function listaDocumentosLocais() { return []; }
// Função salvarListaDocumentosLocais: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function salvarListaDocumentosLocais() { return false; }
// Função documentoPacienteLocal: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function documentoPacienteLocal() { return null; }
// Função salvarDocumentoLocalPaciente: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function salvarDocumentoLocalPaciente() {
  mostrarToast('Gravação fora do MySQL bloqueada. Ligue o MySQL/API para gravar documentos.', 'aviso', 6500);
  return null;
}

// Função nlFormularioLocal: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function nlFormularioLocal(tipo, fallback = {}) { return { ...(fallback || {}) }; }

// Função nlCarregarFormularioPaciente: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
async function nlCarregarFormularioPaciente(tipo, fallback = {}) {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!(await nlMySQLPronto(false)) || typeof apiPortalFormulario !== 'function') return { ...(fallback || {}) };
// Bloco protegido: tenta executar a ação e permite tratar falhas sem travar a página.
  try {
    const api = await apiPortalFormulario(getPerfilAtivoCpf(), tipo);
    return { ...(fallback || {}), ...(api?.dados || {}) };
  } catch (_) {
    return { ...(fallback || {}) };
  }
}

// Função nlSalvarFormularioPaciente: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
async function nlSalvarFormularioPaciente(tipo, dados, statusId) {
  const status = statusId ? document.getElementById(statusId) : null;
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!(await nlMySQLPronto(true)) || typeof apiPortalSalvarFormulario !== 'function') {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (status) status.textContent = 'Não salvo: MySQL offline';
    return false;
  }
// Bloco protegido: tenta executar a ação e permite tratar falhas sem travar a página.
  try {
    const cpf = getPerfilAtivoCpf();
// Configuração ou referência reutilizada pelas funções deste arquivo.
    const dadosComMeta = { ...(dados || {}), atualizado_em: new Date().toISOString() };
    await apiPortalSalvarFormulario(cpf, tipo, dadosComMeta);
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (status) status.textContent = 'Salvo no MySQL';
    portalApiCache = null;
    await carregarPortalApi();
    return true;
  } catch (erro) {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (status) status.textContent = 'Erro ao salvar no MySQL';
    mostrarToast(erro.message || 'Erro ao salvar no MySQL.', 'erro', 7000);
    return false;
  }
}

// Função salvarFotoPerfilPaciente: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
async function salvarFotoPerfilPaciente(input) {
  const arquivo = input?.files?.[0];
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!arquivo) return;
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!arquivo.type.startsWith('image/')) {
    input.value = '';
    return mostrarToast('Selecione uma imagem para a foto do perfil.', 'aviso');
  }
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!(await nlMySQLPronto(true))) { input.value = ''; return; }
  const leitor = new FileReader();
  leitor.onload = async () => {
// Bloco protegido: tenta executar a ação e permite tratar falhas sem travar a página.
    try {
      const foto = String(leitor.result || '');
      await apiPortalSalvarFoto(getPerfilAtivoCpf(), foto);
      portalApiCache = null;
      await carregarPortalApi();
      document.querySelectorAll('.patient-avatar-photo').forEach(avatar => {
        avatar.style.backgroundImage = `url('${foto}')`;
        avatar.textContent = '';
      });
      mostrarToast('Foto salva no MySQL.', 'sucesso');
    } catch (erro) {
      mostrarToast(erro.message || 'Não foi possível salvar a foto no MySQL.', 'erro', 7000);
    } finally {
      input.value = '';
    }
  };
  leitor.readAsDataURL(arquivo);
}

// Função atualizarPreferenciaPaciente: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
async function atualizarPreferenciaPaciente(chave, valor) {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!(await nlMySQLPronto(true))) return;
  const cpf = getPerfilAtivoCpf();
// Configuração ou referência reutilizada pelas funções deste arquivo.
  const prefs = { whatsapp: true, email: true, sms: false, ...(portalApiCache?.preferencias || {}) };
  prefs[chave] = Boolean(valor);
// Bloco protegido: tenta executar a ação e permite tratar falhas sem travar a página.
  try {
    const salvo = await apiPortalSalvarPreferencias(cpf, prefs);
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (portalApiCache) portalApiCache.preferencias = salvo;
    mostrarToast('Preferência salva no MySQL.', 'sucesso');
  } catch (erro) {
    mostrarToast(erro.message || 'Erro ao salvar preferência no MySQL.', 'erro', 7000);
  }
}


// Função salvarDadosCadastraisPaciente: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
async function salvarDadosCadastraisPaciente() {
  const dados = lerDadosCadastraisCampos();
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!dados.telefone && !dados.email) return mostrarToast('Informe pelo menos telefone ou e-mail.', 'aviso');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!nlEmailValido(dados.email)) return mostrarToast('E-mail inválido.', 'aviso');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!nlTelefoneValido(dados.telefone)) return mostrarToast('Celular deve ter 10 ou 11 dígitos.', 'aviso');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (dados.emergencia_telefone && !nlTelefoneValido(dados.emergencia_telefone)) return mostrarToast('Telefone de emergência deve ter 10 ou 11 dígitos.', 'aviso');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (Boolean(dados.emergencia_nome) !== Boolean(dados.emergencia_telefone)) return mostrarToast('Informe nome e telefone do contato de emergência.', 'aviso');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (dados.cep && nlSomenteDigitos(dados.cep).length !== 8) return mostrarToast('CEP deve ter 8 dígitos.', 'aviso');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (nlPacienteMenorAtual() && (!dados.emergencia_nome || !dados.emergencia_telefone)) return mostrarToast('Menor de idade precisa de contato de emergência.', 'aviso');

  const salvou = await nlSalvarFormularioPaciente('dados_cadastrais', dados, 'dadosStatus');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (salvou) {
    mostrarToast('Dados validados e salvos no MySQL.', 'sucesso');
    renderPortalPacienteNovo();
  }
}

// Função salvarPreConsultaPaciente: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
async function salvarPreConsultaPaciente() {
  const cpf = getPerfilAtivoCpf();
  const dados = lerPreConsultaCampos();
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!dados.sem_queixas && !dados.sintomas && !dados.observacoes && !dados.medicamentos) return mostrarToast('Descreva os sintomas ou marque “não tenho queixas atuais”.', 'aviso');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!dados.consentimento_triagem) return mostrarToast('Confirme o consentimento da pré-consulta.', 'aviso');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!(await nlMySQLPronto(true))) return;
// Bloco protegido: tenta executar a ação e permite tratar falhas sem travar a página.
  try {
    await apiPortalSalvarPreconsulta(cpf, {
      sintomas: dados.sem_queixas ? 'Paciente marcou sem queixas atuais.' : dados.sintomas,
      medicamentos: dados.medicamentos,
      observacoes: [
        dados.observacoes,
        dados.alergias ? `Alergias: ${dados.alergias}` : '',
        dados.doencas_previas ? `Histórico: ${dados.doencas_previas}` : '',
        dados.exames_recentes ? `Exames recentes: ${dados.exames_recentes}` : '',
        dados.intensidade ? `Intensidade: ${dados.intensidade}` : '',
        dados.inicio_sintomas ? `Início: ${dados.inicio_sintomas}` : '',
        dados.sinais_alerta?.length ? `Sinais de atenção: ${dados.sinais_alerta.join(', ')}` : '',
        dados.sem_queixas ? 'Sem queixas atuais: sim' : ''
      ].filter(Boolean).join('\n'),
      sem_queixas: dados.sem_queixas,
      consentimento_triagem: dados.consentimento_triagem
    });
    await apiPortalSalvarFormulario(cpf, 'preconsulta_completa', dados);
    portalApiCache = null;
    await carregarPortalApi();
    const status = document.getElementById('preconsultaStatus');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (status) status.textContent = 'Salva no MySQL';
    mostrarToast('Pré-consulta salva no MySQL.', 'sucesso');
    renderPortalPacienteNovo();
  } catch (erro) {
    mostrarToast(erro.message || 'Não foi possível salvar a pré-consulta no MySQL.', 'erro', 7000);
  }
}

// Função uploadDocumentoPaciente: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function uploadDocumentoPaciente(input) {
  const arquivo = input?.files?.[0];
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!arquivo) return;
  const categoria = document.getElementById('patientDocCategoria')?.value || 'outros';
  const consentiu = Boolean(document.getElementById('patientDocConsent')?.checked);
  const tiposPermitidos = ['application/pdf', 'image/png', 'image/jpeg', 'image/webp'];
  const limiteBytes = 5 * 1024 * 1024;
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!consentiu) { input.value = ''; return mostrarToast('Confirme a autorização para enviar o documento.', 'aviso'); }
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!tiposPermitidos.includes(arquivo.type)) { input.value = ''; return mostrarToast('Envie apenas PDF, PNG, JPG ou WEBP.', 'aviso'); }
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (arquivo.size > limiteBytes) { input.value = ''; return mostrarToast('Documento acima de 5 MB. Escolha um arquivo menor.', 'aviso'); }
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (arquivo.name.length > 180) { input.value = ''; return mostrarToast('Nome do arquivo muito longo.', 'aviso'); }

  const leitor = new FileReader();
  leitor.onload = async () => {
// Bloco protegido: tenta executar a ação e permite tratar falhas sem travar a página.
    try {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
      if (!(await nlMySQLPronto(true))) return;
      await apiPortalUploadDocumento(getPerfilAtivoCpf(), {
        nome_arquivo: arquivo.name,
        tipo_arquivo: arquivo.type.includes('pdf') ? 'PDF' : 'Imagem',
        categoria,
        consentimento_lgpd: true,
        consentimento: true,
        tamanho_kb: Math.ceil(arquivo.size / 1024),
        conteudo_base64: String(leitor.result || ''),
        status: 'enviado'
      });
      portalApiCache = null;
      await carregarPortalApi();
      const consent = document.getElementById('patientDocConsent');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
      if (consent) consent.checked = false;
      mostrarToast('Documento validado e salvo no MySQL.', 'sucesso');
      alternarPacienteSecao('documentos');
    } catch (erro) {
      mostrarToast(erro.message || 'Não foi possível salvar documento no MySQL.', 'erro', 7000);
    } finally {
      input.value = '';
    }
  };
  leitor.readAsDataURL(arquivo);
}

// Função abrirDocumentoPaciente: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
async function abrirDocumentoPaciente(docRef) {
  const ref = nlDocDecodeRef(docRef);
  const idMysql = /^\d+$/.test(ref) ? ref : null;
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!idMysql) return mostrarToast('Documento sem ID do MySQL. Reenvie o arquivo com a API ativa.', 'aviso');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!(await nlMySQLPronto(true))) return;
// Bloco protegido: tenta executar a ação e permite tratar falhas sem travar a página.
  try {
    const doc = await apiPortalObterDocumento(getPerfilAtivoCpf(), idMysql);
    nlAbrirVisualizadorDocumento(doc);
  } catch (erro) {
    mostrarToast(erro.message || 'Não foi possível abrir o documento no MySQL.', 'erro', 7000);
  }
}


// Função removerDocumentoPaciente: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
async function removerDocumentoPaciente(docRef) {
  const ref = nlDocDecodeRef(docRef);
  const idMysql = /^\d+$/.test(ref) ? ref : null;
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!idMysql) return mostrarToast('Documento sem ID do MySQL. Atualize a página e tente novamente.', 'aviso');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!confirm('Apagar este documento do MySQL?')) return;
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!(await nlMySQLPronto(true))) return;
// Bloco protegido: tenta executar a ação e permite tratar falhas sem travar a página.
  try {
    await apiPortalRemoverDocumento(getPerfilAtivoCpf(), idMysql);
    portalApiCache = null;
    await carregarPortalApi();
    mostrarToast('Documento apagado do MySQL.', 'sucesso');
    alternarPacienteSecao('documentos');
  } catch (erro) {
    mostrarToast(erro.message || 'Erro ao apagar documento do MySQL.', 'erro', 7000);
  }
}

// Função salvarPreferenciasExtrasPaciente: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
async function salvarPreferenciasExtrasPaciente() {
// Configuração ou referência reutilizada pelas funções deste arquivo.
  const dados = {
    unidade_preferida: document.getElementById('prefUnidade')?.value?.trim() || '',
    horario_preferido: document.getElementById('prefHorario')?.value?.trim() || '',
    observacoes_lembretes: document.getElementById('prefObs')?.value?.trim() || ''
  };
  const salvou = await nlSalvarFormularioPaciente('preferencias_visuais', dados, 'prefsStatus');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (salvou) mostrarToast('Preferências salvas no MySQL.', 'sucesso');
}

// Função registrarCheckinPaciente: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
async function registrarCheckinPaciente() {
// Configuração ou referência reutilizada pelas funções deste arquivo.
  const dados = { feito_em: new Date().toISOString(), status: 'QR Code liberado', cpf: getPerfilAtivoCpf() };
  const salvou = await nlSalvarFormularioPaciente('checkin', dados);
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!salvou) return;
  abrirModalPaciente('checkin');
  mostrarToast('Check-in salvo no MySQL para o CPF ativo.', 'sucesso');
}

// Função removerPerfilFamilia: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
async function removerPerfilFamilia(cpf) {
  const titular = getUsuarioLogado();
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!titular?.cpf || cpf === titular.cpf) return;
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!confirm('Desvincular este familiar da conta? A conta dele continua no MySQL, mas deixa de aparecer na sua família.')) return;
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!(await nlMySQLPronto(true))) return;
// Bloco protegido: tenta executar a ação e permite tratar falhas sem travar a página.
  try {
    await apiPortalDesvincularFamiliar(cpf);
    portalApiCache = null;
    await initPortalPaciente();
    alternarPacienteSecao('familia');
    mostrarToast('Familiar desvinculado no MySQL.', 'info');
  } catch (erro) {
    mostrarToast(erro.message || 'Erro ao desvincular familiar no MySQL.', 'erro', 7000);
  }
}


// Função gerarDocumentoPaciente: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function gerarDocumentoPaciente(nomeExame) {
  const nome = nlSafeText(nomeExame || 'Exame');
  let modal = document.getElementById('modalLaudoPaciente');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!modal) {
    modal = document.createElement('div');
    modal.className = 'modal-overlay';
    modal.id = 'modalLaudoPaciente';
    document.body.appendChild(modal);
  }
  modal.innerHTML = `
    <div class="modal-card modal-form-card">
      <button class="modal-close" onclick="fecharModal('modalLaudoPaciente')">×</button>
      <div class="modal-header-icon">📄</div>
      <h3>Laudo de ${nome}</h3>
      <p>O registro do exame foi carregado pela Área do Paciente. Quando o laudo completo for cadastrado no MySQL, ele aparecerá em Documentos.</p>
      <div class="patient-empty-state">
        <strong>Laudo ainda não anexado</strong>
        <p>Procure a aba <b>Documentos</b> para visualizar arquivos liberados pela clínica.</p>
      </div>
      <button class="btn btn-primary btn-full" onclick="fecharModal('modalLaudoPaciente'); alternarPacienteSecao('documentos')">Abrir documentos</button>
    </div>
  `;
  modal.classList.add('open');
  document.body.style.overflow = 'hidden';
}
