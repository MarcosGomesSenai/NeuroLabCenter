/*
 * Arquivo: recursos/scripts/area-paciente/resumo.js
 * Objetivo: controlar comportamentos da interface do NeuroLab Center.
 * Como manter: mantenha funções pequenas, nomes claros e evite misturar páginas diferentes.
 * Observação: comentários explicam blocos, funções, validações e integração com o servidor.
 */

/*
 * NeuroLab Center - recursos/scripts/area-paciente/resumo.js
 * Responsabilidade: Comportamentos da Área do Paciente: painel, documentos, convênios e integração com portal.
 * Usado por: Páginas HTML em site/paginas/.
 * Manutenção: mantenha funções relacionadas juntas e evite misturar regras de páginas diferentes.
 */

/**
 * NeuroLab Center — Área do Paciente — 06-dashboard-overview.js
 * Origem reorganizada: recursos/scripts/paginas/plans-units-patient/patient-dashboard-overview.js
 * Responsabilidade isolada para facilitar manutenção sem arquivos gigantes.
 */

/* === Área do Paciente 3.0 — regras de negócio + design premium === */
function nlSomenteDigitos(valor) {
  return String(valor || '').replace(/\D/g, '');
}

// Função nlTelefoneValido: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function nlTelefoneValido(valor) {
  const digitos = nlSomenteDigitos(valor);
  return !digitos || digitos.length === 10 || digitos.length === 11;
}

// Função nlEmailValido: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function nlEmailValido(valor) {
  const email = String(valor || '').trim();
  return !email || /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email);
}

// Função nlDataNascimentoPerfil: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function nlDataNascimentoPerfil() {
  const perfil = portalApiCache?.perfil_ativo || getPerfilAtivoUsuario?.() || getUsuarioLogado?.() || {};
  return perfil.data_nascimento || perfil.nascimento || perfil.dataNascimento || '';
}

// Função nlIdadePorData: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function nlIdadePorData(data) {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!data) return null;
  const nasc = new Date(String(data).slice(0, 10) + 'T00:00:00');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (Number.isNaN(nasc.getTime())) return null;
  const hoje = new Date();
  let idade = hoje.getFullYear() - nasc.getFullYear();
  const mes = hoje.getMonth() - nasc.getMonth();
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (mes < 0 || (mes === 0 && hoje.getDate() < nasc.getDate())) idade -= 1;
  return idade;
}

// Função nlPacienteMenorAtual: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function nlPacienteMenorAtual() {
  const idade = nlIdadePorData(nlDataNascimentoPerfil());
  return idade !== null && idade < 18;
}

// Função nlPacienteDocCategoriaLabel: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function nlPacienteDocCategoriaLabel(categoria) {
// Configuração ou referência reutilizada pelas funções deste arquivo.
  const mapa = {
    documento_identidade: 'Documento de identidade',
    convenio: 'Carteirinha do convênio',
    encaminhamento: 'Encaminhamento médico',
    laudo: 'Laudo / exame anterior',
    consentimento: 'Termo / autorização',
    outros: 'Outros'
  };
  return mapa[categoria] || 'Documento';
}

// Função nlPendenciasPaciente: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function nlPendenciasPaciente(dados, docs, pre, agendamentos) {
  const pendencias = [];
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!dados.telefone && !dados.email) pendencias.push('Informe telefone ou e-mail de contato.');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (nlPacienteMenorAtual() && (!dados.emergencia_nome || !dados.emergencia_telefone)) pendencias.push('Menor de idade: informe contato de emergência/responsável.');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!docs?.length) pendencias.push('Envie pelo menos um documento para agilizar a recepção.');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (preconsultaVazia(pre)) pendencias.push('Preencha a pré-consulta antes do atendimento.');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!agendamentos?.length) pendencias.push('Nenhum agendamento ativo para o CPF selecionado.');
  return pendencias;
}

// Função nlCalcularCompletudeArea: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function nlCalcularCompletudeArea(cpf, perfil, docs, agendamentos) {
  const dados = nlFormularioLocal('dados_cadastrais', nlDadosPacientePadrao(perfil));
  const pre = portalApiCache?.preconsulta || {};
  let pontos = 0;
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (cpf) pontos += 12;
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (perfil?.nome || getPerfilAtivoUsuario()?.nome || getUsuarioLogado()?.nome) pontos += 12;
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (dados.telefone || perfil?.telefone) pontos += 12;
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (dados.email || perfil?.email) pontos += 10;
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (dados.emergencia_nome && dados.emergencia_telefone) pontos += 14;
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if ((docs || []).length) pontos += 12;
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!preconsultaVazia(pre)) pontos += 18;
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if ((agendamentos || []).length) pontos += 10;
  return Math.min(100, pontos);
}

// Função nlPacienteCareCard: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function nlPacienteCareCard(titulo, texto, ok, acao, secao) {
  return `
    <article class="patient-care-card ${ok ? 'is-ok' : ''}">
      <span>${ok ? '✓' : '!'}</span>
      <div><strong>${titulo}</strong><small>${texto}</small></div>
      <button type="button" class="btn btn-light btn-sm" onclick="alternarPacienteSecao('${secao}')">${acao}</button>
    </article>
  `;
}


// Função renderPortalPacienteNovo: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function renderPortalPacienteNovo() {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (paginaArquivo() !== 'area-paciente.html') return;
  const grid = document.querySelector('.dashboard-grid, .patient-app-shell');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!grid) return;

  const api = portalApiCache;
  const usuario = getUsuarioLogado();
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!usuario?.cpf && !api?.perfil_ativo) {
    grid.className = 'patient-app-shell patient-app-shell-empty patient-area-v3';
    grid.innerHTML = `
      <section class="patient-login-empty patient-login-empty-v3">
        <div class="patient-login-icon">🔐</div>
        <span class="quick-access-label">Área segura</span>
        <h2>Entre com CPF para acessar dados reais.</h2>
        <p>Agendamentos, documentos, pré-consulta e conta família só aparecem quando existem no navegador ou no MySQL. Nada de dados falsos.</p>
        <div class="patient-empty-actions">
          <a class="btn btn-primary" href="index.html?modal=login">Entrar com CPF</a>
          <a class="btn btn-light" href="index.html?modal=cadastro">Criar conta</a>
        </div>
      </section>
    `;
    return;
  }

  const perfisFamilia = api?.perfis_familia || listarPerfisFamilia();
  const cpfPerfil = getPerfilAtivoCpf();
  const perfilDetalhe = perfisFamilia.find(p => p.cpf === cpfPerfil) || perfisFamilia[0] || {};
  const perfilApi = api?.perfil_ativo || {};
  const perfilUsuario = getPerfilAtivoUsuario() || {};
  const nomeCompleto = perfilApi.nome || perfilUsuario.nome || perfilDetalhe.nome || usuario.nome || 'Paciente';
  const nome = nomeCompleto.split(' ')[0];
  const agendamentos = api?.agendamentos || agendamentosDoPerfil(cpfPerfil);
  const proximo = agendamentos[0] || null;
  const docsLocais = listaDocumentosLocais(cpfPerfil);
  const docsPaciente = [...(api?.documentos || []), ...docsLocais.filter(doc => !doc.sincronizado_mysql)];
  const fotoPerfil = perfilApi.foto_perfil || '';
  const dados = nlFormularioLocal('dados_cadastrais', nlDadosPacientePadrao(perfilApi));
  const pre = portalApiCache?.preconsulta || {};
  const progresso = nlCalcularCompletudeArea(cpfPerfil, perfilApi, docsPaciente, agendamentos);
  const pendencias = nlPendenciasPaciente(dados, docsPaciente, pre, agendamentos);
  const perfilContexto = perfilDetalhe?.cpf === usuario?.cpf ? 'Titular da conta' : `${perfilDetalhe?.papel || 'Familiar'} vinculado`;
  const idade = nlIdadePorData(perfilApi.data_nascimento || perfilDetalhe.data_nascimento || perfilUsuario.data_nascimento);

  grid.className = 'patient-app-shell patient-app-shell-refined patient-area-v3';
  grid.innerHTML = `
    <aside class="patient-sidebar patient-sidebar-v3">
      <div class="patient-profile-card patient-profile-v3 text-center">
        <div class="patient-avatar patient-avatar-photo mx-auto" style="${fotoPerfil ? `background-image:url('${fotoPerfil}')` : ''}">${fotoPerfil ? '' : nlDoctorInitials(nome)}</div>
        <label class="btn btn-outline-secondary btn-sm mt-2 patient-photo-button">
          Trocar foto
          <input type="file" accept="image/*" class="d-none" onchange="salvarFotoPerfilPaciente(this)">
        </label>
        <strong class="d-block mt-2">${nlSafeText(nomeCompleto)}</strong>
        <span class="patient-context-label">${nlSafeText(perfilContexto)}</span>
        <small>CPF ${nlMascaraCpf(cpfPerfil)}${idade !== null ? ` · ${idade} anos` : ''}</small>
        <div class="patient-profile-progress patient-profile-progress-v3">
          <span>Perfil ${progresso}% completo</span>
          <div><i style="width:${progresso}%"></i></div>
        </div>
      </div>

      <div class="patient-side-block patient-family-switch">
        <label for="familiaPerfilSelect" class="form-label">Conta família</label>
        <select id="familiaPerfilSelect" class="form-select" onchange="trocarPerfilFamilia(this.value)">
          ${perfisFamilia.map(perfil => `<option value="${nlSafeText(perfil.cpf)}" ${perfil.cpf === cpfPerfil ? 'selected' : ''}>${nlSafeText(perfil.papel)} — ${nlSafeText(perfil.nome)}</option>`).join('')}
        </select>
        <small>Todos os módulos obedecem ao CPF ativo.</small>
      </div>

      <div class="patient-side-block patient-rule-box">
        <span>Regras ativas</span>
        <ul>
          <li>Dados isolados por CPF.</li>
          <li>Menor de 18 exige responsável.</li>
          <li>Documentos: PDF/imagem até 5 MB.</li>
          <li>Pré-consulta exige consentimento.</li>
        </ul>
      </div>

      <div class="patient-sidebar-actions">
        <button class="btn btn-primary" onclick="abrirAgendamento()">Novo agendamento</button>
        <button class="btn btn-light" onclick="alternarPacienteSecao('dados')">Completar cadastro</button>
      </div>
    </aside>

    <section class="patient-main-panel patient-main-v3">
      <div class="patient-welcome-card patient-welcome-v3">
        <div>
          <span class="quick-access-label">Painel do paciente</span>
          <h2>Olá, ${nlSafeText(nome)}.</h2>
          <p>Uma área mais limpa, com regras de negócio visíveis, pendências reais e salvamento por CPF.</p>
        </div>
        <div class="patient-status-stack patient-status-v3">
          <span>${nlStatusSincronizacao()}</span>
          <strong>${pendencias.length ? `${pendencias.length} pendência(s)` : 'Tudo pronto'}</strong>
        </div>
      </div>

      <div class="patient-kpis patient-kpis-v3">
        <div><strong>${agendamentos.length || 0}</strong><span>agendamentos</span></div>
        <div><strong>${docsPaciente.length}</strong><span>documentos</span></div>
        <div><strong>${perfisFamilia.length}</strong><span>perfis família</span></div>
        <div><strong>${progresso}%</strong><span>perfil completo</span></div>
      </div>

      <div class="patient-care-grid">
        ${nlPacienteCareCard('Dados cadastrais', dados.telefone || dados.email ? 'Contato informado' : 'Falta contato principal', dados.telefone || dados.email, 'Editar', 'dados')}
        ${nlPacienteCareCard('Documentos', docsPaciente.length ? `${docsPaciente.length} arquivo(s)` : 'Nenhum arquivo enviado', docsPaciente.length, 'Enviar', 'documentos')}
        ${nlPacienteCareCard('Pré-consulta', preconsultaVazia(pre) ? 'Pendente antes do atendimento' : 'Informações preenchidas', !preconsultaVazia(pre), 'Preencher', 'preconsulta')}
        ${nlPacienteCareCard('Agendamento', proximo ? 'Consulta encontrada' : 'Sem consulta ativa', Boolean(proximo), 'Agendar', 'resumo')}
      </div>

      <div class="patient-card-lg patient-next-card-v3">
        <div>
          <span class="quick-access-label">Próxima etapa</span>
          <h3>${proximo?.medico_nome || proximo?.medico || (pendencias[0] || 'Nenhum agendamento ativo')}</h3>
          <p>${proximo ? `${proximo.tipo_consulta || proximo.tipoNome || 'Consulta'} · ${proximo.data_consulta || proximo.dia || ''} ${proximo.hora_consulta || proximo.horario || ''} · ${nlSafeText(perfilDetalhe?.nome || nomeCompleto)}` : 'Complete cadastro, documentos e pré-consulta para reduzir etapas na recepção.'}</p>
        </div>
        <div class="patient-action-row">
          <button class="btn btn-light" onclick="alternarPacienteSecao('preconsulta')">Pré-consulta</button>
          <button class="btn btn-primary" onclick="abrirAgendamento()">${proximo ? 'Reagendar' : 'Agendar'}</button>
        </div>
      </div>

      <div class="patient-tabs patient-tabs-v3" role="tablist" aria-label="Área do Paciente">
        <button class="active" type="button" onclick="alternarPacienteSecao('resumo', this)">Resumo</button>
        <button type="button" onclick="alternarPacienteSecao('dados', this)">Meus dados</button>
        <button type="button" onclick="alternarPacienteSecao('documentos', this)">Documentos</button>
        <button type="button" onclick="alternarPacienteSecao('preconsulta', this)">Pré-consulta</button>
        <button type="button" onclick="alternarPacienteSecao('exames', this)">Exames</button>
        <button type="button" onclick="alternarPacienteSecao('familia', this)">Conta família</button>
        <button type="button" onclick="alternarPacienteSecao('preferencias', this)">Lembretes</button>
      </div>
      <div id="patientDynamicPanel" class="patient-dynamic-panel patient-panel-v3"></div>
    </section>
  `;
  alternarPacienteSecao('resumo');
}
