/*
 * Arquivo: recursos/scripts/api-do-servidor.js
 * Objetivo: controlar comportamentos da interface do NeuroLab Center.
 * Como manter: mantenha funções pequenas, nomes claros e evite misturar páginas diferentes.
 * Observação: comentários explicam blocos, funções, validações e integração com o servidor.
 */

/*
 * NeuroLab Center - recursos/scripts/api-do-servidor.js
 * Responsabilidade: Script principal de funcionalidade do site.
 * Usado por: Páginas HTML em site/paginas/.
 * Manutenção: mantenha funções relacionadas juntas e evite misturar regras de páginas diferentes.
 */

/**
 * NeuroLab Center — api.js
 * Arquivo consolidado para apresentação e manutenção.
 * Carregadores document.write e pastas part/section foram substituídos por código direto.
 */

// ============================================================================
// ============================================================================

const API_STORAGE = {
  token: 'neurolab_auth_token',
  perfilAtivo: 'neurolab_perfil_ativo_cpf'
};

// Função apiBaseUrl: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function apiBaseUrl() {
  const meta = document.querySelector('meta[name="neurolab-api"]')?.content?.trim();
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (meta) return meta.replace(/\/$/, '');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (window.NEUROLAB_API_URL) return String(window.NEUROLAB_API_URL).replace(/\/$/, '');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (location.protocol === 'file:') return 'http://127.0.0.1:5000/api';
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (location.hostname === 'localhost' || location.hostname === '127.0.0.1') {
    return `${location.protocol}//${location.hostname}:5000/api`;
  }
  return `${location.origin}/api`;
}

// Função getAuthToken: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function getAuthToken() {
  return localStorage.getItem(API_STORAGE.token) || '';
}

// Função setAuthToken: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function setAuthToken(token) {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (token) localStorage.setItem(API_STORAGE.token, token);
  else localStorage.removeItem(API_STORAGE.token);
}

// Função getPerfilAtivoCpf: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function getPerfilAtivoCpf() {
  const titular = lerJson(STORAGE_KEYS.usuarioAtual, null);
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!titular?.cpf) return null;
  const ativo = localStorage.getItem(API_STORAGE.perfilAtivo);
  return ativo || titular.cpf;
}

// Função setPerfilAtivoCpf: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function setPerfilAtivoCpf(cpf) {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (cpf) localStorage.setItem(API_STORAGE.perfilAtivo, cpf);
}

// Classe ApiError: agrupa dados e comportamentos relacionados ao mesmo recurso.
class ApiError extends Error {
  constructor(message, code, status) {
    super(message);
    this.code = code;
    this.status = status;
  }
}

// Função apiRequest: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
async function apiRequest(path, options = {}) {
// Configuração ou referência reutilizada pelas funções deste arquivo.
  const headers = {
    Accept: 'application/json',
    ...(options.headers || {})
  };
  const hasBody = options.body !== undefined && options.body !== null;
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (hasBody && !(options.body instanceof FormData)) {
    headers['Content-Type'] = 'application/json';
  }
  const token = getAuthToken();
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (token) headers.Authorization = `Bearer ${token}`;

  const response = await fetch(`${apiBaseUrl()}${path}`, {
    ...options,
    headers
  });

// Configuração ou referência reutilizada pelas funções deste arquivo.
  let data = {};
// Bloco protegido: tenta executar a ação e permite tratar falhas sem travar a página.
  try {
    data = await response.json();
  } catch (_) {
    data = {};
  }

// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!response.ok) {
    throw new ApiError(data.erro || 'Erro ao comunicar com o servidor.', data.codigo, response.status);
  }
  return data;
}

// Função apiDisponivel: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
async function apiDisponivel() {
// Bloco protegido: tenta executar a ação e permite tratar falhas sem travar a página.
  try {
    const res = await fetch(`${apiBaseUrl()}/health`, { method: 'GET' });
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (!res.ok) return false;
    const data = await res.json().catch(() => ({}));
    return data.status === 'online' || data.mysql === true;
  } catch (_) {
    return false;
  }
}

// Função apiLogin: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
async function apiLogin(cpf, senha) {
  const data = await apiRequest('/login', {
    method: 'POST',
    body: JSON.stringify({ cpf: somenteDigitos(cpf), senha })
  });
  setAuthToken(data.token);
  salvarJson(STORAGE_KEYS.usuarioAtual, {
    cpf: data.cpf,
    nome: data.nome,
    email: data.email,
    tipo_usuario: data.tipo_usuario
  });
  setPerfilAtivoCpf(data.cpf);
  return data;
}

// Função apiCadastro: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
async function apiCadastro(payload) {
  return apiRequest('/cadastro', {
    method: 'POST',
    body: JSON.stringify(payload)
  });
}

// Função apiUsuarioExiste: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
async function apiUsuarioExiste(cpf) {
  const cleanCpf = typeof somenteDigitos === 'function'
    ? somenteDigitos(cpf)
    : String(cpf || '').replace(/\D/g, '');
  return apiRequest(`/usuarios/${cleanCpf}/existe`);
}

// ============================================================================
// ============================================================================

/*
 * NeuroLab Center — módulo do cliente de API: portal.js
 *
 * Arquivo: recursos/scripts/compartilhado/api-client/portal.js
 *
 * Por que existe:
 * Este módulo foi separado para manter arquivos menores, facilitar leitura
 * na apresentação e isolar responsabilidades sem alterar o comportamento.
 */

function portalQuery(perfilCpf) {
  const cpf = perfilCpf || getPerfilAtivoCpf();
  return cpf ? `?perfil_cpf=${encodeURIComponent(cpf)}` : '';
}

// Função apiPortalPainel: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
async function apiPortalPainel(perfilCpf) {
  return apiRequest(`/portal/painel${portalQuery(perfilCpf)}`);
}

// Função apiPortalDocumentos: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
async function apiPortalDocumentos(perfilCpf) {
  return apiRequest(`/portal/documentos${portalQuery(perfilCpf)}`);
}

// Função apiPortalUploadDocumento: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
async function apiPortalUploadDocumento(perfilCpf, meta) {
  return apiRequest('/portal/documentos', {
    method: 'POST',
    body: JSON.stringify({ ...meta, perfil_cpf: perfilCpf || getPerfilAtivoCpf() })
  });
}

// Função apiPortalObterDocumento: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
async function apiPortalObterDocumento(perfilCpf, docId) {
  return apiRequest(`/portal/documentos/${docId}${portalQuery(perfilCpf)}`);
}

// Função apiPortalRemoverDocumento: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
async function apiPortalRemoverDocumento(perfilCpf, docId) {
  return apiRequest(`/portal/documentos/${docId}${portalQuery(perfilCpf)}`, { method: 'DELETE' });
}

// Função apiPortalPreconsulta: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
async function apiPortalPreconsulta(perfilCpf) {
  return apiRequest(`/portal/preconsulta${portalQuery(perfilCpf)}`);
}

// Função apiPortalSalvarPreconsulta: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
async function apiPortalSalvarPreconsulta(perfilCpf, dados) {
  return apiRequest('/portal/preconsulta', {
    method: 'PUT',
    body: JSON.stringify({ ...dados, perfil_cpf: perfilCpf || getPerfilAtivoCpf() })
  });
}

// Função apiPortalExames: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
async function apiPortalExames(perfilCpf) {
  return apiRequest(`/portal/exames${portalQuery(perfilCpf)}`);
}

// Função apiPortalPreferencias: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
async function apiPortalPreferencias(perfilCpf) {
  return apiRequest(`/portal/preferencias${portalQuery(perfilCpf)}`);
}

// Função apiPortalSalvarPreferencias: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
async function apiPortalSalvarPreferencias(perfilCpf, prefs) {
  return apiRequest('/portal/preferencias', {
    method: 'PUT',
    body: JSON.stringify({ ...prefs, perfil_cpf: perfilCpf || getPerfilAtivoCpf() })
  });
}

// Função apiPortalFamilia: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
async function apiPortalFamilia() {
  return apiRequest('/portal/familia');
}

async function apiPortalCadastrarFamiliar(dados) {
  return apiRequest('/portal/familia/membro', {
    method: 'POST',
    body: JSON.stringify({
      cpf: somenteDigitos(dados.cpf),
      nome: dados.nome,
      email: dados.email,
      telefone: dados.telefone || dados.celular,
      data_nascimento: dados.data_nascimento || dados.nascimento,
      senha: dados.senha,
      papel: dados.papel,
      cpf_responsavel: dados.cpf_responsavel || dados.cpfResponsavel || null
    })
  });
}

async function apiPortalDesvincularFamiliar(cpfMembro) {
  return apiRequest(`/portal/familia/${somenteDigitos(cpfMembro)}`, { method: 'DELETE' });
}

async function apiPortalSalvarFoto(perfilCpf, fotoBase64) {
  return apiRequest('/portal/foto', {
    method: 'PUT',
    body: JSON.stringify({
      perfil_cpf: perfilCpf || getPerfilAtivoCpf(),
      foto_base64: fotoBase64
    })
  });
}

async function apiPortalFormulario(perfilCpf, tipo) {
  return apiRequest(`/portal/formularios/${encodeURIComponent(tipo)}${portalQuery(perfilCpf)}`);
}

async function apiPortalSalvarFormulario(perfilCpf, tipo, dados) {
  return apiRequest(`/portal/formularios/${encodeURIComponent(tipo)}`, {
    method: 'PUT',
    body: JSON.stringify({
      perfil_cpf: perfilCpf || getPerfilAtivoCpf(),
      dados: dados || {}
    })
  });
}

/* ============================================================
   Persistencia oficial via API/banco — helpers para front-end
   ============================================================ */

// ============================================================================
// ============================================================================

/*
 * NeuroLab Center — módulo do cliente de API: catalog.js
 *
 * Arquivo: recursos/scripts/compartilhado/api-client/catalog.js
 *
 * Por que existe:
 * Este módulo foi separado para manter arquivos menores, facilitar leitura
 * na apresentação e isolar responsabilidades sem alterar o comportamento.
 */

const NL_API_CATALOG_CACHE = { unidades: null, medicos: null, convenios: null, exames: null };

function nlApiNormalize(texto) {
  return String(texto || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-zA-Z0-9]+/g, ' ')
    .trim()
    .toLowerCase();
}

function nlApiCrmClean(texto) {
  return String(texto || '').replace(/[^0-9]/g, '');
}

async function apiCatalogo(tipo) {
  if (NL_API_CATALOG_CACHE[tipo]) return NL_API_CATALOG_CACHE[tipo];
  const mapa = { unidades: '/unidades', medicos: '/medicos', convenios: '/convenios', exames: '/exames' };
  const data = await apiRequest(mapa[tipo]);
  NL_API_CATALOG_CACHE[tipo] = data[tipo] || [];
  return NL_API_CATALOG_CACHE[tipo];
}

function nlApiEscolherPorNome(lista, nome, aliases = {}) {
  const alvo = nlApiNormalize(nome);
  if (!alvo) return null;
  const aliasId = Object.entries(aliases).find(([chave]) => alvo.includes(chave));
  if (aliasId) {
    const encontrado = lista.find(item => Number(item.id) === Number(aliasId[1]));
    if (encontrado) return encontrado;
  }
  return lista.find(item => nlApiNormalize(item.nome) === alvo)
    || lista.find(item => alvo.includes(nlApiNormalize(item.nome)) || nlApiNormalize(item.nome).includes(alvo.split(' ')[0] || alvo));
}

function nlApiDataConsulta(dados) {
  if (dados?.dataISO) return dados.dataISO;
  const raw = String(dados?.dia || '').match(/(\d{1,2})\/(\d{1,2})/);
  if (raw) {
    const hoje = new Date();
    let ano = hoje.getFullYear();
    const data = new Date(ano, Number(raw[2]) - 1, Number(raw[1]));
    if (data < new Date(hoje.getFullYear(), hoje.getMonth(), hoje.getDate())) ano += 1;
    return `${ano}-${String(raw[2]).padStart(2, '0')}-${String(raw[1]).padStart(2, '0')}`;
  }
  const state = typeof nlBookingState === 'function' ? nlBookingState() : null;
  return state?.dataISO || new Date(Date.now() + 86400000).toISOString().slice(0, 10);
}

function nlApiTipoConsulta(dados) {
  const codigo = String(dados?.tipoCodigo || '').toUpperCase();
  const texto = nlApiNormalize(`${dados?.tipoNome || ''} ${dados?.tipo || ''}`);
  if (codigo === 'EXAM' || texto.includes('exame')) return 'exame';
  if (codigo === 'TELE' || texto.includes('tele') || texto.includes('online')) return 'teleconsulta';
  return 'consulta';
}

function nlApiTipoAtendimento(dados) {
  const texto = nlApiNormalize(`${dados?.cobertura || ''} ${dados?.convenio || ''}`);
  if (texto.includes('sus')) return 'sus';
  if (texto.includes('convenio') || dados?.convenio) return 'convenio';
  return 'particular';
}

// ============================================================================
// ============================================================================

/*
 * NeuroLab Center — resolução de entidades do agendamento
 * Por que existe: traduz nomes escolhidos no front para IDs reais do MySQL.
 */
async function apiResolverAgendamento(dados) {
  const [unidades, medicos, convenios, exames] = await Promise.all([
    apiCatalogo('unidades'), apiCatalogo('medicos'), apiCatalogo('convenios'), apiCatalogo('exames')
  ]);

  const tipoConsulta = nlApiTipoConsulta(dados);
  const tipoAtendimento = nlApiTipoAtendimento(dados);
  const unidadeNome = tipoConsulta === 'teleconsulta' ? 'Teleconsulta' : (dados.unidade || dados.unidadeNome || 'Santo André - Centro');
  const unidade = nlApiEscolherPorNome(unidades, unidadeNome, {
    'santo andre': 1,
    'sao bernardo': 2,
    'teleconsulta': 3,
    'vila pires': 4,
    'moema': 5,
    'tatuape': 6,
    'paulista': 7
  });

  const crm = nlApiCrmClean(dados.crm);
  const medico = (crm && medicos.find(item => nlApiCrmClean(item.crm) === crm))
    || nlApiEscolherPorNome(medicos, dados.medico || dados.medico_nome || 'Dra. Ana Beatriz Ferreira');

  let convenio = null;
  if (tipoAtendimento === 'convenio') {
    convenio = nlApiEscolherPorNome(convenios, dados.convenio || dados.cobertura || 'Unimed', {
      'unimed': 1,
      'bradesco': 2,
      'sulamerica': 3,
      'sul america': 3,
      'amil': 4
    });
  }

  let exame = null;
  if (tipoConsulta === 'exame') {
    exame = nlApiEscolherPorNome(exames, dados.exame || dados.tipoNome || 'Eletroencefalograma', {
      'eletroencefalograma': 1,
      'eeg': 1,
      'eletroneuromiografia': 2,
      'polissonografia': 3
    }) || exames[0];
  }

  if (!unidade?.id) throw new ApiError('Unidade não encontrada no banco para este agendamento.', 'unit_not_mapped', 400);
  if (!medico?.id) throw new ApiError('Médico não encontrado no banco para este agendamento.', 'doctor_not_mapped', 400);
  if (tipoAtendimento === 'convenio' && !convenio?.id) throw new ApiError('Convênio não encontrado no banco.', 'plan_not_mapped', 400);
  if (tipoConsulta === 'exame' && !exame?.id) throw new ApiError('Exame não encontrado no banco.', 'exam_not_mapped', 400);

  return { unidade, medico, convenio, exame, tipoConsulta, tipoAtendimento };
}


/*
 * NeuroLab Center — criação de agendamento no MySQL
 * Por que existe: mantém a montagem do payload separada da listagem e cancelamento.
 */
async function apiCriarAgendamentoMySQL(dados) {
  if (!(await apiDisponivel())) {
    throw new ApiError('Back-end indisponível. Ligue o Flask antes de agendar.', 'backend_unavailable', 503);
  }
  const paciente = typeof obterPacienteParaAgendamento === 'function' ? obterPacienteParaAgendamento() : {};
  const cpfCliente = somenteDigitos(paciente.pacienteCpf || getPerfilAtivoCpf() || '');
  if (!cpfCliente || cpfCliente === 'visitante') {
    throw new ApiError('Entre na Área do Paciente antes de criar agendamento.', 'login_required', 401);
  }

  const resolvido = await apiResolverAgendamento(dados || {});
  const payload = {
    cpf_cliente: cpfCliente,
    cpf_responsavel: paciente.agendadoPorCpf || null,
    id_medico: resolvido.medico.id,
    id_unidade: resolvido.unidade.id,
    id_convenio: resolvido.convenio?.id || null,
    id_exame: resolvido.exame?.id || null,
    data_consulta: nlApiDataConsulta(dados || {}),
    hora_consulta: String((dados || {}).horario || (dados || {}).hora_consulta || '').slice(0, 5),
    tipo_consulta: resolvido.tipoConsulta,
    tipo_atendimento: resolvido.tipoAtendimento,
    observacao: `Criado pelo front-end NeuroLab. Médico: ${(dados || {}).medico || resolvido.medico.nome}. Unidade: ${(dados || {}).unidade || resolvido.unidade.nome}.`
  };
  if (!payload.hora_consulta) throw new ApiError('Horário obrigatório para agendamento.', 'missing_time', 400);

  const salvo = await apiRequest('/agendamentos', { method: 'POST', body: JSON.stringify(payload) });
  return {
    ...salvo,
    ...dados,
    id: salvo.id,
    status: salvo.status || 'confirmado',
    pacienteCpf: cpfCliente,
    pacienteNome: paciente.pacienteNome,
    data_consulta: payload.data_consulta,
    hora_consulta: payload.hora_consulta,
    tipo_consulta: payload.tipo_consulta,
    tipo_atendimento: payload.tipo_atendimento,
    id_medico: payload.id_medico,
    id_unidade: payload.id_unidade,
    id_convenio: payload.id_convenio,
    id_exame: payload.id_exame
  };
}


/*
 * NeuroLab Center — listagem, cancelamento e disponibilidade
 * Por que existe: agrupa operações de consulta que não criam avaliações.
 */
async function apiListarAgendamentosPaciente(cpf) {
  const cleanCpf = somenteDigitos(cpf || getPerfilAtivoCpf() || '');
  if (!cleanCpf) return [];
  const data = await apiRequest(`/agendamentos?cpf=${encodeURIComponent(cleanCpf)}`);
  return data.agendamentos || [];
}

async function apiCancelarAgendamentoMySQL(id, motivo = '') {
  const cleanId = String(id || '').replace(/[^0-9]/g, '');
  if (!cleanId) throw new ApiError('ID do agendamento inválido.', 'invalid_appointment_id', 400);
  return apiRequest(`/agendamentos/${cleanId}`, {
    method: 'DELETE',
    body: JSON.stringify({ cpf_cliente: getPerfilAtivoCpf(), motivo })
  });
}

async function apiConsultarDisponibilidadeMySQL(dados = {}) {
  const resolvido = await apiResolverAgendamento(dados || {});
  const dataConsulta = dados.dataISO || nlApiDataConsulta(dados || {});
  const params = new URLSearchParams({
    id_medico: resolvido.medico.id,
    id_unidade: resolvido.unidade.id,
    data: dataConsulta
  });
  const data = await apiRequest(`/agendamentos/disponibilidade?${params.toString()}`);
  return data.disponibilidade || {};
}

async function apiEntrarFilaEsperaMySQL(dados = {}) {
  if (!(await apiDisponivel())) {
    throw new ApiError('Back-end indisponível. Ligue o Flask antes de entrar na fila.', 'backend_unavailable', 503);
  }
  const resolvido = await apiResolverAgendamento(dados || {});
  const payload = {
    cpf_cliente: somenteDigitos(getPerfilAtivoCpf() || ''),
    id_medico: resolvido.medico.id,
    id_unidade: resolvido.unidade.id,
    data_preferida: dados.dataISO || nlApiDataConsulta(dados || {}),
    hora_preferida: String(dados.horario || dados.hora_consulta || '').slice(0, 5) || null,
    whatsapp: dados.whatsapp,
    observacao: dados.observacao || `Fila criada pelo front-end NeuroLab para ${dados.medico || resolvido.medico.nome}.`
  };
  return apiRequest('/fila-espera', { method: 'POST', body: JSON.stringify(payload) });
}


/*
 * NeuroLab Center — envio de avaliação geral
 * Por que existe: separa feedback do paciente das operações de agendamento.
 */
async function apiEnviarAvaliacaoGeralMySQL(dados = {}) {
  const payload = {
    cpf_cliente: somenteDigitos(getPerfilAtivoCpf() || ''),
    nota_medico: Number(dados.medico),
    nota_recepcao: Number(dados.recepcao),
    nota_agendamento: Number(dados.agendamento),
    nps: Number(dados.nps),
    comentario: dados.comentario || '',
    publicar: Boolean(dados.publicar)
  };
  return apiRequest('/feedback/geral', { method: 'POST', body: JSON.stringify(payload) });
}
