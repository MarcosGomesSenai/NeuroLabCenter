/*
 * Arquivo: recursos/scripts/formularios.js
 * Objetivo: controlar comportamentos da interface do NeuroLab Center.
 * Como manter: mantenha funções pequenas, nomes claros e evite misturar páginas diferentes.
 * Observação: comentários explicam blocos, funções, validações e integração com o servidor.
 */

/*
 * NeuroLab Center - recursos/scripts/formularios.js
 * Responsabilidade: Script principal de funcionalidade do site.
 * Usado por: Páginas HTML em site/paginas/.
 * Manutenção: mantenha funções relacionadas juntas e evite misturar regras de páginas diferentes.
 */

/**
 * NeuroLab Center — forms.js
 * Arquivo consolidado para apresentação e manutenção.
 * Carregadores document.write e pastas part/section foram substituídos por código direto.
 */

// ============================================================================
// ============================================================================

/**
 * NeuroLab Center — documentação do arquivo
 *
 * Arquivo: recursos/scripts/app/forms-auth.js
 *
 * Por que este arquivo existe:
 * Este script fica separado para manter uma responsabilidade clara no site
 * ou no microserviço Node.js. Isso evita que a apresentação dependa de um único
 * arquivo gigante e facilita encontrar erros de caminho, import ou regra visual.
 */

function mascararCpf(input) {
  let valor = somenteDigitos(input.value).slice(0, 11);
  valor = valor.replace(/(\d{3})(\d)/, '$1.$2');
  valor = valor.replace(/(\d{3})(\d)/, '$1.$2');
  valor = valor.replace(/(\d{3})(\d{1,2})$/, '$1-$2');
  input.value = valor;
}

// Função mascararTelefone: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function mascararTelefone(input) {
  let valor = somenteDigitos(input.value).slice(0, 11);
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (valor.length > 10) {
    valor = valor.replace(/^(\d{2})(\d{5})(\d{1,4})$/, '($1) $2-$3');
  } else if (valor.length > 6) {
    valor = valor.replace(/^(\d{2})(\d{4})(\d{1,4})$/, '($1) $2-$3');
  } else if (valor.length > 2) {
    valor = valor.replace(/^(\d{2})(\d{1,5})$/, '($1) $2');
  }
  input.value = valor;
}

// Função cpfValido: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function cpfValido(cpfEntrada) {
  const cpf = somenteDigitos(cpfEntrada);
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (cpf.length !== 11 || /^(\d)\1+$/.test(cpf)) return false;

  const calcularDigito = (base) => {
    let soma = 0;
    for (let i = 0; i < base.length; i++) soma += Number(base[i]) * (base.length + 1 - i);
    const resto = (soma * 10) % 11;
    return resto === 10 ? 0 : resto;
  };

  return calcularDigito(cpf.slice(0, 9)) === Number(cpf[9]) &&
    calcularDigito(cpf.slice(0, 10)) === Number(cpf[10]);
}

// Função idadeEmAnos: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function idadeEmAnos(dataIso) {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!dataIso) return null;
  const nascimento = new Date(`${dataIso}T00:00:00`);
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (Number.isNaN(nascimento.getTime())) return null;
  const hoje = new Date();
  let idade = hoje.getFullYear() - nascimento.getFullYear();
  const mes = hoje.getMonth() - nascimento.getMonth();
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (mes < 0 || (mes === 0 && hoje.getDate() < nascimento.getDate())) idade--;
  return idade;
}

// Função senhaValida: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function senhaValida(senha) {
  return /[A-Za-z]/.test(senha) && /\d/.test(senha) && String(senha).length >= 8;
}

// Função nomeCompletoValido: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function nomeCompletoValido(nome) {
  return String(nome || '').trim().split(/\s+/).length >= 2;
}

// Função setHint: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function setHint(id, mensagem, tipo = 'info') {
  const el = $(id);
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!el) return;
  el.textContent = mensagem;
  el.className = `field-hint ${tipo}`;
}


// Função preencherCpfLogin: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function preencherCpfLogin(cpf) {
  const campo = $('loginCpf');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!campo) return;
  campo.value = cpf;
  mascararCpf(campo);
  loginEtapa = 'cpf';
  $('loginSenhaGroup')?.classList.add('hidden');
  const btn = $('btnLoginProximo');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (btn) btn.textContent = 'Continuar';
  setTimeout(() => campo.focus(), 80);
}


// Função mostrarCpfDuplicadoCadastro: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function mostrarCpfDuplicadoCadastro(campoId, hintId) {
  const campo = $(campoId);
  const hint = $(hintId);
  const cpf = somenteDigitos(campo?.value || '');
  const alertId = `${hintId}-dup-alert`;
  document.getElementById(alertId)?.remove();

// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (campo) {
    campo.classList.remove('cpf-valido');
    campo.classList.add('cpf-invalido', 'is-invalid');
    campo.focus();
  }

// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (hint) {
    hint.textContent = '';
    hint.className = 'field-hint error';
  }

  const alvo = campo?.closest('.form-group') || hint?.parentElement;
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!alvo) return;
  alvo.insertAdjacentHTML('beforeend', `
    <div class="cpf-duplicate-alert cpf-duplicate-alert-strong" id="${alertId}" role="alert">
      <div class="dup-alert-content">
        <span class="dup-alert-icon">⚠️</span>
        <div>
          <strong>CPF já utilizado no sistema</strong>
          <p>Esse CPF já possui uma conta. Por segurança, use login ou recuperação de senha em vez de criar outro cadastro.</p>
        </div>
      </div>
      <button type="button" class="btn btn-light btn-sm btn-dup-login" onclick="fecharModal('modalCadastro'); abrirModalLogin(); preencherCpfLogin('${cpf}');">Fazer login com este CPF</button>
    </div>
  `);
}

// Função switchCadastro: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function switchCadastro(tipo) {
  cadastroTipoAtual = tipo;
  $('formAdulto')?.style.setProperty('display', tipo === 'adulto' ? 'block' : 'none');
  $('formAdolescente')?.style.setProperty('display', tipo === 'adolescente' ? 'block' : 'none');
  $('tabAdulto')?.classList.toggle('active', tipo === 'adulto');
  $('tabAdolescente')?.classList.toggle('active', tipo === 'adolescente');
  setHint('cadGeralHint', '');
}


function limparRascunhoCadastro() {
  localStorage.removeItem('neurolab_cadastro_rascunho');
}


// Função realizarCadastro: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
async function realizarCadastro() {
  const termos = $('cadTermos')?.checked;
  const isAdulto = cadastroTipoAtual === 'adulto';
  const dados = isAdulto
    ? {
        cpf: $('cadCpf')?.value,
        nascimento: $('cadNascimento')?.value,
        nome: $('cadNome')?.value,
        celular: $('cadCelular')?.value,
        email: $('cadEmail')?.value,
        senha: $('cadSenha')?.value,
        senhaConfirm: $('cadSenhaConfirm')?.value,
        tipo: 'adulto'
      }
    : {
        cpf: $('cadCpfAdol')?.value,
        nascimento: $('cadNascAdol')?.value,
        nome: $('cadNomeAdol')?.value,
        celular: $('cadCelAdol')?.value,
        cpfResponsavel: $('cadCpfResp')?.value,
        senha: $('cadSenhaAdol')?.value,
        senhaConfirm: $('cadSenhaAdolConfirm')?.value,
        tipo: 'adolescente'
      };

  const modoFamilia = window.NLUX?.cadastroFamilia;
  const usuarioLogado = getUsuarioLogado();
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (modoFamilia && !isAdulto && usuarioLogado && usuarioLogado.cpf) {
    dados.cpfResponsavel = usuarioLogado.cpf;
  }

  const cpf = somenteDigitos(dados.cpf);
  const idade = idadeEmAnos(dados.nascimento);
  const apiOnline = typeof apiDisponivel === 'function' && (await apiDisponivel());

// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!cpfValido(cpf)) return setHint('cadGeralHint', 'CPF inválido. Verifique os números digitados.', 'error');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!nomeCompletoValido(dados.nome)) return setHint('cadGeralHint', 'Informe o nome completo com pelo menos duas palavras.', 'error');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (idade === null) return setHint('cadGeralHint', 'Informe uma data de nascimento válida.', 'error');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (isAdulto && idade < 18) return setHint('cadGeralHint', 'Use a aba Menor de idade para pacientes de 0 a 17 anos.', 'error');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!isAdulto && (idade < 0 || idade > 17)) return setHint('cadGeralHint', 'A conta de menor de idade é permitida apenas para 0 a 17 anos.', 'error');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!isAdulto && !cpfValido(dados.cpfResponsavel)) return setHint('cadGeralHint', 'Informe um CPF de responsável válido.', 'error');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (somenteDigitos(dados.celular).length < 10) return setHint('cadGeralHint', 'Informe um celular válido com DDD.', 'error');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!senhaValida(dados.senha)) return setHint('cadGeralHint', 'A senha precisa ter 8 caracteres, uma letra e um número.', 'error');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (dados.senha !== dados.senhaConfirm) return setHint('cadGeralHint', 'As senhas não conferem.', 'error');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!termos) return setHint('cadGeralHint', 'Aceite os Termos de Uso e Política de Privacidade para criar a conta.', 'error');

  const papel = $('cadFamiliaPapel')?.value?.trim() || '';
  const email = (dados.email || '').trim().toLowerCase();

// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (modoFamilia && !papel) {
    return setHint('cadGeralHint', 'Informe o parentesco do familiar (Filho, Mãe, etc.).', 'error');
  }
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (apiOnline && isAdulto && !email) {
    return setHint('cadGeralHint', 'E-mail é obrigatório para salvar no banco de dados.', 'error');
  }

// Configuração ou referência reutilizada pelas funções deste arquivo.
  const apiPayload = {
    cpf,
    nome: dados.nome.trim(),
    email: email || `paciente.${cpf}@neurolab.local`,
    telefone: dados.celular,
    data_nascimento: dados.nascimento,
    senha: dados.senha,
    tipo_usuario: 'paciente',
    cpf_responsavel: isAdulto ? undefined : somenteDigitos(dados.cpfResponsavel)
  };

// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (apiOnline) {
// Bloco protegido: tenta executar a ação e permite tratar falhas sem travar a página.
    try {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
      if (modoFamilia) {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
        if (!getAuthToken?.()) {
          return setHint('cadGeralHint', 'Entre na sua conta para cadastrar um familiar.', 'error');
        }
        const familiarCriado = await apiPortalCadastrarFamiliar({ ...apiPayload, papel });
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
        if (familiarCriado?.cpf && typeof setPerfilAtivoCpf === 'function') setPerfilAtivoCpf(familiarCriado.cpf);
        window.NLUX.cadastroFamilia = false;
        document.getElementById('cadFamiliaExtra')?.classList.add('hidden');
        limparRascunhoCadastro();
        setHint('cadGeralHint', 'Familiar cadastrado no banco e vinculado à conta família.', 'success');
        setTimeout(() => {
          fecharModal('modalCadastro');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
          if (paginaArquivo() === 'area-paciente.html' && typeof initPortalPaciente === 'function') {
            initPortalPaciente();
          } else {
            const destino = typeof nlConsumirRetornoAuth === 'function'
              ? nlConsumirRetornoAuth('area-paciente.html')
              : 'area-paciente.html';
            navegarPara(destino);
          }
        }, 700);
        return;
      }

      await apiCadastro(apiPayload);
      await apiLogin(cpf, dados.senha);
      limparRascunhoCadastro();
      setHint('cadGeralHint', 'Conta salva no banco. Login realizado.', 'success');
      setTimeout(() => {
        fecharModal('modalCadastro');
        const destino = typeof nlConsumirRetornoAuth === 'function'
          ? nlConsumirRetornoAuth('area-paciente.html')
          : 'area-paciente.html';
        navegarPara(destino);
      }, 700);
      return;
    } catch (erro) {
      const msg = erro?.message || 'Não foi possível salvar no servidor.';
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
      if (erro?.code === 'cpf_already_exists') {
        mostrarCpfDuplicadoCadastro(isAdulto ? 'cadCpf' : 'cadCpfAdol', isAdulto ? 'cadCpfHint' : 'cadCpfAdolHint');
        return setHint('cadGeralHint', 'CPF já cadastrado. Faça login ou recupere sua senha.', 'error');
      }
      return setHint('cadGeralHint', msg, 'error');
    }
  }

  return setHint(
    'cadGeralHint',
    'Back-end indisponível. Inicie o Flask e tente novamente para salvar no banco.',
    'error'
  );
}


// Função avancarLogin: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
async function avancarLogin() {
  const cpf = somenteDigitos($('loginCpf')?.value);

// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!cpfValido(cpf)) return setHint('loginCpfHint', 'CPF inválido. Verifique os números digitados.', 'error');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (typeof apiDisponivel !== 'function' || !(await apiDisponivel())) {
    return setHint('loginCpfHint', 'Back-end indisponível. Inicie o Flask para entrar.', 'error');
  }

// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (loginEtapa === 'cpf') {
// Bloco protegido: tenta executar a ação e permite tratar falhas sem travar a página.
    try {
      const consulta = typeof apiUsuarioExiste === 'function'
        ? await apiUsuarioExiste(cpf)
        : await apiRequest(`/usuarios/${cpf}`);
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
      if (!consulta?.existe && !consulta?.cpf) {
        return setHint('loginCpfHint', 'CPF não encontrado no banco. Crie uma conta.', 'error');
      }
    } catch (_) {
      return setHint('loginCpfHint', 'CPF não encontrado no banco. Crie uma conta.', 'error');
    }

    $('loginSenhaGroup')?.classList.remove('hidden');
    $('btnLoginProximo').textContent = 'Entrar';
    setHint('loginCpfHint', 'CPF encontrado no banco. Digite sua senha.', 'success');
    loginEtapa = 'senha';
    $('loginSenha')?.focus();
    return;
  }

  const senha = $('loginSenha')?.value || '';
// Bloco protegido: tenta executar a ação e permite tratar falhas sem travar a página.
  try {
    await apiLogin(cpf, senha);
    setHint('loginSenhaHint', 'Login realizado com sucesso pelo banco.', 'success');
    setTimeout(() => {
      fecharModal('modalLogin');
      const destino = typeof nlConsumirRetornoAuth === 'function'
        ? nlConsumirRetornoAuth('area-paciente.html')
        : 'area-paciente.html';
      navegarPara(destino);
    }, 500);
  } catch (erro) {
    setHint('loginSenhaHint', erro.message || 'Senha incorreta.', 'error');
  }
}

// Função enviarRecuperacao: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
async function enviarRecuperacao() {
  const cpf = somenteDigitos($('recCpf')?.value);
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!cpfValido(cpf)) return setHint('recHint', 'CPF inválido. Verifique os números digitados.', 'error');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (typeof apiDisponivel !== 'function' || !(await apiDisponivel())) {
    return setHint('recHint', 'Back-end indisponível. Inicie o Flask para recuperar a senha.', 'error');
  }

// Bloco protegido: tenta executar a ação e permite tratar falhas sem travar a página.
  try {
    const resposta = await apiRequest('/esqueci-senha', {
      method: 'POST',
      body: JSON.stringify({ cpf })
    });
    const token = resposta?.token_recuperacao ? ` Token local de teste: ${resposta.token_recuperacao}` : '';
    setHint('recHint', `${resposta?.mensagem || 'Solicitação registrada no banco.'}${token}`, 'success');
  } catch (erro) {
    setHint('recHint', erro.message || 'Não foi possível solicitar recuperação de senha.', 'error');
  }
}
