/*
 * Arquivo: recursos/scripts/chatbot.js
 * Objetivo: controlar comportamentos da interface do NeuroLab Center.
 * Como manter: mantenha funções pequenas, nomes claros e evite misturar páginas diferentes.
 * Observação: comentários explicam blocos, funções, validações e integração com o servidor.
 */

/*
 * NeuroLab Center - recursos/scripts/chatbot.js
 * Responsabilidade: Script principal de funcionalidade do site.
 * Usado por: Páginas HTML em site/paginas/.
 * Manutenção: mantenha funções relacionadas juntas e evite misturar regras de páginas diferentes.
 */

/**
 * NeuroLab Center — chatbot.js
 * Arquivo consolidado para apresentação e manutenção.
 * Carregadores document.write e pastas part/section foram substituídos por código direto.
 */

// ============================================================================
// ============================================================================

function abrirAgendamentoOnline() {
  window.location.href = 'agendamento.html?modo=online';
}

// Função esconderAgendamentoOnline: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function esconderAgendamentoOnline(esconderTudo = true) {
  const agenda = document.getElementById('agendamentoOnlineCard');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (agenda && esconderTudo) agenda.classList.add('hidden');
}

// Função confirmarConsultaOnline: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function confirmarConsultaOnline() {
  const nomeInput = document.getElementById('agendaNome');
  const especialidadeInput = document.getElementById('agendaEspecialidade');
  const dataInput = document.getElementById('agendaData');
  const horarioInput = document.getElementById('agendaHorario');
  const confirmacao = document.getElementById('agendaConfirmacao');
  const resumo = document.getElementById('agendaResumo');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!nomeInput || !especialidadeInput || !dataInput || !horarioInput || !confirmacao || !resumo) {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (typeof mostrarToast === 'function') mostrarToast('Abra o formulario de teleconsulta antes de confirmar.', 'aviso');
    return;
  }
  const nome = nomeInput.value.trim();
  const especialidade = especialidadeInput.value;
  const data = dataInput.value;
  const horario = horarioInput.value;

// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!especialidade) {
    mostrarToast('Escolha a especialidade para agendar.', 'aviso');
    return;
  }

// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!nome || !data || !horario) {
    mostrarToast('Preencha nome, data e horário para agendar.', 'aviso');
    return;
  }

  const dataFormatada = new Date(data + 'T00:00:00').toLocaleDateString('pt-BR');
  resumo.textContent = `${nome}, sua consulta de ${especialidade} ficou marcada para ${dataFormatada} às ${horario}. No horário marcado, clique em “Ir em ligação com médico”.`;
  confirmacao.classList.remove('hidden');
  confirmacao.scrollIntoView({ behavior: 'smooth', block: 'center' });
}

// Função entrarLigacaoMedico: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
async function entrarLigacaoMedico() {
  const sala = document.getElementById('salaConsulta');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!sala) {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (typeof mostrarToast === 'function') mostrarToast('Sala virtual indisponivel nesta pagina.', 'aviso');
    return;
  }
  sala.classList.remove('hidden');
  sala.scrollIntoView({ behavior: 'smooth', block: 'center' });
  await liberarCameraPaciente();
}

// Função liberarCameraPaciente: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
async function liberarCameraPaciente() {
  const video = document.getElementById('videoPaciente');
  const placeholder = document.getElementById('cameraPlaceholder');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!video || !placeholder) return;

// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
    placeholder.innerHTML = '<span>⚠️</span><h3>Câmera indisponível</h3><p>Seu navegador não liberou acesso à câmera.</p>';
    return;
  }

// Bloco protegido: tenta executar a ação e permite tratar falhas sem travar a página.
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
    video.srcObject = stream;
    video.style.display = 'block';
    placeholder.style.display = 'none';
  } catch (erro) {
    placeholder.innerHTML = '<span>🚫</span><h3>Câmera bloqueada</h3><p>Permita o acesso à câmera no navegador para aparecer na ligação.</p>';
  }
}

// Função abrirSalaConsulta: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function abrirSalaConsulta() {
  abrirAgendamentoOnline();
}

// Função esconderSalaConsulta: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function esconderSalaConsulta() {
  const sala = document.getElementById('salaConsulta');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (sala) sala.classList.add('hidden');
}

// Função enviarMensagemSala: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function enviarMensagemSala() {
  const input = document.getElementById('salaMensagem');
  const body = document.getElementById('salaChatBody');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!input || !body) return;
  const texto = input.value.trim();
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!texto) return;

  const msg = document.createElement('div');
  msg.className = 'msg user';
  msg.textContent = texto;
  body.appendChild(msg);
  input.value = '';

  setTimeout(() => {
    const bot = document.createElement('div');
    bot.className = 'msg bot';
    bot.textContent = 'Mensagem enviada. O médico responderá aqui durante a consulta online.';
    body.appendChild(bot);
    body.scrollTop = body.scrollHeight;
  }, 500);

  body.scrollTop = body.scrollHeight;
}

// Função enviarSalaComEnter: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function enviarSalaComEnter(event) {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (event.key === 'Enter') enviarMensagemSala();
}

// ============================================================================
// ============================================================================

// CHAT DE DÚVIDAS COM IA LOCAL
// URL: meta neurolab-chat-api, window.NEUROLAB_CHAT_API, ou mesma origem /api/chat (senão localhost:3001 em dev)
// Regras de segurança: o chat tira dúvidas, mas não prescreve remédio, dose ou diagnóstico.
function abrirTriagemChat() {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (typeof esconderSalaConsulta === 'function') esconderSalaConsulta();
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (typeof esconderAgendamentoOnline === 'function') esconderAgendamentoOnline(false);
  const triagem = document.getElementById('triagemCard');
  const chat = document.getElementById('chatCard');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!triagem || !chat) {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (typeof mostrarToast === 'function') mostrarToast('Abra a pagina de teleconsulta para iniciar o chat.', 'aviso');
    return;
  }
  triagem.classList.remove('hidden');
  chat.classList.add('hidden');
  triagem.scrollIntoView({ behavior: 'smooth', block: 'center' });
}

// Função selecionarTriagem: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function selecionarTriagem(texto) {
  const chat = document.getElementById('chatCard');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!chat || !document.getElementById('chatBody')) return;
  chat.classList.remove('hidden');
  adicionarMensagem('user', texto);
  document.getElementById('chatMensagem')?.focus();
  responderComIA(texto);
}

// Função enviarMensagemChat: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
async function enviarMensagemChat() {
  const input = document.getElementById('chatMensagem');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!input) return;
  const texto = input.value.trim();

// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!texto) return;

  adicionarMensagem('user', texto);
  input.value = '';
  await responderComIA(texto);
}

// Função resolverUrlChatApi: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function resolverUrlChatApi() {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (typeof window.NEUROLAB_CHAT_API === 'string' && window.NEUROLAB_CHAT_API.trim()) {
    const base = window.NEUROLAB_CHAT_API.trim().replace(/\/$/, '');
    return base.endsWith('/api/chat') ? base : `${base}/api/chat`;
  }
  const meta = document.querySelector('meta[name="neurolab-chat-api"]');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (meta?.content?.trim()) {
    const base = meta.content.trim().replace(/\/$/, '');
    return base.endsWith('/api/chat') ? base : `${base}/api/chat`;
  }
  const prot = typeof location !== 'undefined' ? location.protocol : '';
  const host = typeof location !== 'undefined' ? location.hostname : '';
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (prot === 'file:' || host === 'localhost' || host === '127.0.0.1') {
    const devHost = host === '127.0.0.1' ? '127.0.0.1' : 'localhost';
    return `http://${devHost}:3001/api/chat`;
  }
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (prot && prot !== 'file:' && location.origin && location.origin !== 'null') {
    return `${location.origin}/api/chat`;
  }
  return 'http://localhost:3001/api/chat';
}

// Função responderComIA: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
async function responderComIA(texto) {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!document.getElementById('chatBody')) return;
  adicionarMensagem('bot', 'Analisando sua dúvida com segurança...');

// Bloco protegido: tenta executar a ação e permite tratar falhas sem travar a página.
  try {
    const resposta = await fetch(resolverUrlChatApi(), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: texto })
    });

// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (!resposta.ok) throw new Error('API local indisponível');

    const dados = await resposta.json();
    removerUltimaMensagemBotTemporaria();
    adicionarMensagem('bot', dados.answer || respostaBasicaHospital(texto));
  } catch (erro) {
    removerUltimaMensagemBotTemporaria();
    adicionarMensagem('bot', respostaBasicaHospital(texto));
  }
}

// Função respostaBasicaHospital: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function respostaBasicaHospital(texto) {
  const t = normalizarTexto(texto);

// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (t.includes('remedio') || t.includes('medicamento') || t.includes('tomar') || t.includes('dose')) {
    return 'Por segurança, eu não posso indicar remédio, dose ou tratamento específico. Posso explicar cuidados gerais e ajudar você a agendar uma consulta. Se a dor for forte, súbita ou vier com sinais de alerta, procure emergência.';
  }

// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (t.includes('dor de cabeca') || t.includes('enxaqueca')) {
    return 'Dor de cabeça pode ter várias causas. Como orientação geral: descanse em local tranquilo, hidrate-se e observe a evolução. Procure urgência se a dor for súbita e muito forte, vier com febre, desmaio, confusão, fraqueza, alteração na fala, convulsão ou alteração visual. Não indico remédios pelo chat.';
  }

// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (t.includes('tontura')) {
    return 'Para tontura, sente-se ou deite-se para evitar queda e observe se há desmaio, falta de ar, dor no peito, fraqueza ou fala enrolada. Se for intenso, recorrente ou vier com sinais neurológicos, procure atendimento médico.';
  }

// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (t.includes('formigamento') || t.includes('dormencia')) {
    return 'Formigamento pode ter várias causas. Se ocorrer em um lado do corpo, junto com boca torta, fala enrolada, perda de força, confusão ou dor no peito, procure emergência. Se for leve e repetitivo, agende avaliação neurológica.';
  }

// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (t.includes('exame') || t.includes('consulta') || t.includes('agendar')) {
    return 'Posso ajudar com informações de agendamento, consulta presencial, consulta online e exames como EEG, eletroneuromiografia, polissonografia e Doppler. Para confirmar diagnóstico ou tratamento, é necessário atendimento médico.';
  }

  return 'Entendi sua dúvida. Posso orientar de forma geral, mas não faço diagnóstico e não indico remédios. Me diga o sintoma, há quanto tempo começou e se existe algum sinal de alerta como febre alta, desmaio, convulsão, fraqueza, fala alterada ou dor muito forte.';
}

// Função removerUltimaMensagemBotTemporaria: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function removerUltimaMensagemBotTemporaria() {
  const chatBody = document.getElementById('chatBody');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!chatBody) return;
  const mensagens = chatBody.querySelectorAll('.msg.bot');
  const ultima = mensagens[mensagens.length - 1];
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (ultima && ultima.textContent === 'Analisando sua dúvida com segurança...') ultima.remove();
}

// Função enviarComEnter: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function enviarComEnter(event) {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (event.key === 'Enter') enviarMensagemChat();
}

// Função adicionarMensagem: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function adicionarMensagem(tipo, texto) {
  const chatBody = document.getElementById('chatBody');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!chatBody) return;
  const msg = document.createElement('div');
  msg.className = `msg ${tipo}`;
  msg.textContent = texto;
  chatBody.appendChild(msg);
  chatBody.scrollTop = chatBody.scrollHeight;
}

// ============================================================================
// ============================================================================

// ── NeuroBot — Chatbot usando API local do projeto (Node/Express) ──────────────────────
(() => {
  const conversationHistory = [];

  // Usa a mesma função global de URL para manter consistência com o chatbot da página de ajuda.
  function _chatUrl() {
    return typeof resolverUrlChatApi === 'function'
      ? resolverUrlChatApi()
      : 'http://127.0.0.1:3001/api/chat';
  }

// Função enviarMensagemBot: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
  async function enviarMensagemBot() {
    const input = document.getElementById('botInput');
    const btn = document.getElementById('botSendBtn');
    const msg = input?.value.trim();
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (!msg) return;

    input.value = '';
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (btn) btn.disabled = true;
    ajudaAdicionarMensagem(msg, 'user');
    conversationHistory.push({ role: 'user', content: msg });

    const typingId = 'typing-' + Date.now();
    const typingEl = document.createElement('div');
    typingEl.className = 'chatbot-msg bot loading';
    typingEl.id = typingId;
    typingEl.innerHTML = '<div class="chatbot-typing"><span></span><span></span><span></span></div>';
    document.getElementById('botMessages')?.appendChild(typingEl);
    scrollBot();

// Bloco protegido: tenta executar a ação e permite tratar falhas sem travar a página.
    try {
      const response = await fetch(_chatUrl(), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: msg, history: conversationHistory.slice(-8) })
      });
      const data = await response.json().catch(() => ({}));
      const reply = data.answer || 'Desculpe, não consegui processar sua mensagem. Ligue (11) 4002-8922.';
      document.getElementById(typingId)?.remove();
      conversationHistory.push({ role: 'assistant', content: reply });
      ajudaAdicionarMensagem(reply, 'bot');
    } catch (err) {
      document.getElementById(typingId)?.remove();
      ajudaAdicionarMensagem('Não consegui conectar na API local do chat. Rode `cd api-do-chatbot`, `npm install` e `npm start`, ou fale pelo WhatsApp: (11) 4002-8922. 😊', 'bot');
    }

// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (btn) btn.disabled = false;
    input?.focus();
  }

// Função enviarRapido: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
  function enviarRapido(texto) {
    const input = document.getElementById('botInput');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (input) input.value = texto;
    enviarMensagemBot();
  }

// Função ajudaAdicionarMensagem: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
  function ajudaAdicionarMensagem(texto, tipo) {
    const div = document.createElement('div');
    div.className = `chatbot-msg ${tipo}`;
    div.innerHTML = String(texto)
      .replace(/[<>&]/g, ch => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;' }[ch]))
      .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
      .replace(/\n/g, '<br>');
    document.getElementById('botMessages')?.appendChild(div);
    scrollBot();
  }

// Função scrollBot: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
  function scrollBot() {
    const msgs = document.getElementById('botMessages');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (msgs) msgs.scrollTop = msgs.scrollHeight;
  }

// Evento da interface: conecta uma ação do usuário com uma função do sistema.
  document.addEventListener('DOMContentLoaded', () => {
// Evento da interface: conecta uma ação do usuário com uma função do sistema.
    document.getElementById('botInput')?.addEventListener('keydown', e => {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
      if (e.key === 'Enter') enviarMensagemBot();
    });
    window.enviarMensagemBot = enviarMensagemBot;
    window.enviarRapido = enviarRapido;
  });
})();

// ============================================================================
// ============================================================================

function renderTeleconsultaProfissional() {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (paginaArquivo() !== 'teleconsulta.html') return;
  const root = document.querySelector('.consulta-grid-full');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!root || root.dataset.teleEnhanced === 'true') return;
  root.dataset.teleEnhanced = 'true';

  root.innerHTML = `
    <div class="telemedicine-layout">
      <div class="telemedicine-copy">
        <span class="quick-access-label">Teleconsulta NeuroLab</span>
        <h1>Consulta neurológica online com acesso simples e seguro.</h1>
        <p>Agende, receba o link automaticamente e entre pela Área do Paciente. O botão da sala libera 15 minutos antes do horário, com teste de câmera e microfone.</p>
        <div class="tele-alert">Teleconsulta disponível apenas nas modalidades <strong>Particular</strong> e <strong>Convênio</strong>. Não disponível pelo SUS.</div>
        <div class="page-actions">
          <button class="btn btn-primary btn-big" onclick="abrirAgendamentoOnline()">Agendar teleconsulta</button>
          <button class="btn btn-light btn-big" onclick="abrirTriagemChat()">Tirar dúvida</button>
        </div>
      </div>
      <div class="telemedicine-card">
        <strong>Fluxo da consulta</strong>
        <ol>
          <li>Escolha especialidade, médico e horário.</li>
          <li>Confirme a cobertura Particular ou Convênio.</li>
          <li>Receba o link e teste câmera/microfone.</li>
          <li>Entre na sala virtual 15 minutos antes.</li>
        </ol>
      </div>
    </div>
    <div class="telemedicine-grid">
      <article><strong>Receita digital.</strong><span>Quando aplicável, a prescrição ou o atestado é enviado ao paciente após a consulta.</span></article>
      <article><strong>Ideal para retorno.</strong><span>Acompanhe tratamentos, revise exames e receba orientação clínica sem deslocamento.</span></article>
      <article><strong>Área do Paciente.</strong><span>Acesse histórico, link da sala, documentos e notificações em um só lugar.</span></article>
    </div>
    <div class="triagem-card hidden" id="triagemCard">
      <h3>Antes de abrir o chat, escolha uma opção:</h3>
      <p class="safe-note">O chat é apenas para dúvidas e orientação inicial. Não indica remédios, doses ou diagnóstico.</p>
      <div class="triagem-options">
        <button onclick="selecionarTriagem('Estou com dor de cabeça')">Dor de cabeça</button>
        <button onclick="selecionarTriagem('Estou com tontura')">Tontura</button>
        <button onclick="selecionarTriagem('Estou com formigamento')">Formigamento</button>
        <button onclick="selecionarTriagem('Tenho uma dúvida sobre consulta ou exame')">Dúvida</button>
      </div>
    </div>
    <div class="chat-card hidden" id="chatCard">
      <div class="chat-header"><strong>NeuroLab Dúvidas</strong><span>Seguro · Sem prescrição</span></div>
      <div class="chat-body" id="chatBody"><div class="msg bot">Olá! Posso responder dúvidas gerais sobre sintomas, exames e agendamento. Em emergências, procure atendimento imediatamente.</div></div>
      <div class="chat-input"><input id="chatMensagem" placeholder="Digite sua dúvida..." onkeydown="enviarComEnter(event)" aria-label="Mensagem do chat" /><button onclick="enviarMensagemChat()">Enviar</button></div>
    </div>
    <div class="agendamento-online-card hidden" id="agendamentoOnlineCard">
      <h3>Agendar teleconsulta</h3>
      <p class="safe-note">Somente Particular e Convênio.</p>
      <div class="agenda-form">
        <div class="field"><label>Nome do paciente</label><input id="agendaNome" placeholder="Seu nome completo" /></div>
        <div class="field"><label>Cobertura</label><select id="agendaCobertura"><option>Particular</option><option>Convênio</option></select></div>
        <div class="field"><label>Especialidade</label><select id="agendaEspecialidade"><option value="">Escolha a especialidade</option><option>Neurologia geral</option><option>Enxaqueca e cefaleia</option><option>Memória e cognição</option><option>Distúrbios do sono</option></select></div>
        <div class="field"><label>Data</label><input id="agendaData" type="date" /></div>
        <div class="field"><label>Horário</label><select id="agendaHorario"><option>09:00</option><option>10:30</option><option>14:00</option><option>15:30</option><option>17:00</option></select></div>
        <button class="btn btn-primary" onclick="confirmarConsultaOnline()">Confirmar</button>
      </div>
      <div class="agenda-confirmacao hidden" id="agendaConfirmacao"><strong>Teleconsulta confirmada</strong><p id="agendaResumo"></p><button class="btn btn-light" onclick="entrarLigacaoMedico()">Entrar na sala virtual</button></div>
    </div>
    <div class="video-consulta hidden" id="salaConsulta">
      <div class="video-topbar"><strong>Sala virtual NeuroLab</strong><span>Médico ainda não entrou</span></div>
      <div class="video-grid">
        <div class="video-box medico"><span>MD</span><h3>Médico</h3><p>Aguardando o médico entrar na chamada</p></div>
        <div class="video-box paciente" id="pacienteVideoBox"><video id="videoPaciente" autoplay muted playsinline></video><div class="camera-placeholder" id="cameraPlaceholder"><span>Paciente</span><h3>Câmera</h3><p>Clique em Permitir para liberar sua câmera</p></div></div>
      </div>
      <div class="chat-card mini-chat"><div class="chat-header"><strong>Chat da consulta</strong><span>Texto com o médico</span></div><div class="chat-body" id="salaChatBody"><div class="msg bot">Você entrou na sala. Aguarde o médico iniciar o atendimento.</div></div><div class="chat-input"><input id="salaMensagem" placeholder="Mensagem para o médico..." onkeydown="enviarSalaComEnter(event)" aria-label="Mensagem da sala" /><button onclick="enviarMensagemSala()">Enviar</button></div></div>
    </div>
  `;
}

// ============================================================================
// ============================================================================

// ── Teleconsulta: seleção de médico e horários adaptativos ──
    const TELE_SLOTS = {
      'AB': { 1:['08:00','09:00','10:00','14:00','15:00'], 3:['08:30','09:30','14:30','16:00'], 5:['09:00','10:30','14:00'] },
      'CE': { 2:['08:00','10:00','13:00','15:00','16:30'], 4:['09:00','11:00','14:00','15:30'], 1:['08:30','14:30'] },
      'RM': { 1:['09:00','10:30','14:30'], 2:['08:30','14:00','16:00'], 3:['09:30','11:00','15:00'], 5:['08:00','13:00','14:30'] }
    };

    let teleMedicoSelecionado = null;

// Função selecionarTeleMedico: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
    function selecionarTeleMedico(nome, sigla, especialidade, el) {
      document.querySelectorAll('.tele-medico-card').forEach(c => c.classList.remove('selecionado'));
      el.classList.add('selecionado');
      teleMedicoSelecionado = sigla;
      document.getElementById('agendaMedicoNome').value = nome + ' — ' + especialidade;
      document.getElementById('teleStepForm').style.display = 'block';
      document.getElementById('agendaData').value = '';
      document.getElementById('agendaHorario').innerHTML = '<option value="">-- Selecione uma data --</option>';
    }

// Evento da interface: conecta uma ação do usuário com uma função do sistema.
    document.addEventListener('DOMContentLoaded', () => {
      const dataInput = document.getElementById('agendaData');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
      if (dataInput) {
        // Set min date to tomorrow
        const tomorrow = new Date();
        tomorrow.setDate(tomorrow.getDate() + 1);
        dataInput.min = tomorrow.toISOString().split('T')[0];

// Evento da interface: conecta uma ação do usuário com uma função do sistema.
        dataInput.addEventListener('change', function() {
          const d = new Date(this.value + 'T12:00:00');
          const dow = d.getDay(); // 0=Sun, 1=Mon...
          const sigla = teleMedicoSelecionado || 'AB';
          const slots = TELE_SLOTS[sigla]?.[dow] || ['09:00','10:30','14:00','15:30'];
          const sel = document.getElementById('agendaHorario');
          sel.innerHTML = '<option value="">-- Selecione o horário --</option>';
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
          if (dow === 0 || dow === 6) {
            sel.innerHTML = '<option value="">Médico não atende neste dia</option>';
          } else {
            slots.forEach(h => {
              const opt = document.createElement('option');
              opt.value = h; opt.textContent = h;
              sel.appendChild(opt);
            });
          }
        });
      }
    });
