/*
 * Arquivo: recursos/scripts/comum/funcoes-gerais.js
 * Objetivo: controlar comportamentos da interface do NeuroLab Center.
 * Como manter: mantenha funções pequenas, nomes claros e evite misturar páginas diferentes.
 * Observação: comentários explicam blocos, funções, validações e integração com o servidor.
 */

/*
 * NeuroLab Center - recursos/scripts/comum/funcoes-gerais.js
 * Responsabilidade: Funções compartilhadas por várias páginas, como avisos, busca, exames e regras.
 * Usado por: Páginas HTML em site/paginas/.
 * Manutenção: mantenha funções relacionadas juntas e evite misturar regras de páginas diferentes.
 */

/**
 * NeuroLab Center — global-utils.js
 * Objetos globais e utilidades mínimas compartilhadas.
 * Separado do antigo utils.js para facilitar manutenção.
 */

// ============================================================================

// Utilitários globais mínimos do NeuroLab.
// Este arquivo centraliza objetos/funções usados por várias páginas para evitar duplicação global.
(function () {
// Configuração ou referência reutilizada pelas funções deste arquivo.
  const defaults = {
    cadastroFamilia: false,
    calendarOffset: 0,
    selectedDateISO: '',
    selectedSlot: '',
    portalTab: 'historico'
  };

  window.NLUX = {
    ...defaults,
    ...(window.NLUX || {})
  };

  window.nlSafeText = function (valor) {
    return String(valor ?? '').replace(/[&<>"']/g, (char) => ({
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      '"': '&quot;',
      "'": '&#039;'
    }[char]));
  };
})();

// ============================================================================
