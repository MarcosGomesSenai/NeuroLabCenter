/*
 * Arquivo: recursos/scripts/comum/avisos.js
 * Objetivo: controlar comportamentos da interface do NeuroLab Center.
 * Como manter: mantenha funções pequenas, nomes claros e evite misturar páginas diferentes.
 * Observação: comentários explicam blocos, funções, validações e integração com o servidor.
 */

/*
 * NeuroLab Center - recursos/scripts/comum/avisos.js
 * Responsabilidade: Funções compartilhadas por várias páginas, como avisos, busca, exames e regras.
 * Usado por: Páginas HTML em site/paginas/.
 * Manutenção: mantenha funções relacionadas juntas e evite misturar regras de páginas diferentes.
 */

/**
 * NeuroLab Center — toast.js
 * Sistema visual de mensagens/toasts.
 * Separado do antigo utils.js para facilitar manutenção.
 */

// ============================================================================

// ============================================================
// TOAST NOTIFICATION SYSTEM (Componente 1)
// Substitui todos os alert() por notificações visuais
// ============================================================
(function criarToastContainer() {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (document.querySelector('.toast-container')) return;
  const container = document.createElement('div');
  container.className = 'toast-container';
  container.id = 'toastContainer';
  document.body.appendChild(container);
})();

// Função mostrarToast: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function mostrarToast(mensagem, tipo = 'info', duracao = 4000) {
  let container = document.getElementById('toastContainer');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!container) {
    container = document.createElement('div');
    container.className = 'toast-container';
    container.id = 'toastContainer';
    document.body.appendChild(container);
  }

// Configuração ou referência reutilizada pelas funções deste arquivo.
  const icones = { sucesso: '✅', erro: '❌', info: 'ℹ️', aviso: '⚠️' };
  const toast = document.createElement('div');
  toast.className = `toast toast-${tipo}`;
  toast.innerHTML = `
    <span class="toast-icone">${icones[tipo] || 'ℹ️'}</span>
    <span>${mensagem}</span>
    <button class="toast-fechar" onclick="this.parentElement.remove()">×</button>
  `;
  container.appendChild(toast);

  setTimeout(() => {
    toast.classList.add('saindo');
    setTimeout(() => toast.remove(), 300);
  }, duracao);
}

// ============================================================================
