/*
 * Arquivo: recursos/scripts/comum/regras-de-agendamento.js
 * Objetivo: controlar comportamentos da interface do NeuroLab Center.
 * Como manter: mantenha funções pequenas, nomes claros e evite misturar páginas diferentes.
 * Observação: comentários explicam blocos, funções, validações e integração com o servidor.
 */

/*
 * NeuroLab Center - recursos/scripts/comum/regras-de-agendamento.js
 * Responsabilidade: Funções compartilhadas por várias páginas, como avisos, busca, exames e regras.
 * Usado por: Páginas HTML em site/paginas/.
 * Manutenção: mantenha funções relacionadas juntas e evite misturar regras de páginas diferentes.
 */

/**
 * NeuroLab Center — appointment-rules.js
 * Regras de cancelamento, reagendamento e faltas.
 * Separado do antigo utils.js para facilitar manutenção.
 */

// ============================================================================

// ============================================================
// REGRAS DE NEGÓCIO AVANÇADAS
// Fonte oficial: MySQL via API Flask
// ============================================================

async function carregarAgendamentosPacienteMySQL(cpf) {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (typeof apiListarAgendamentosPaciente !== 'function') return [];
  return apiListarAgendamentosPaciente(cpf || getPerfilAtivoCpf());
}

// RB-012: Max 3 consultas por CPF em 30 dias
async function verificarLimiteConsultas(cpf) {
  const agendamentos = await carregarAgendamentosPacienteMySQL(cpf);
  const agora = Date.now();
  const trintaDias = 30 * 24 * 60 * 60 * 1000;
  const recentes = agendamentos.filter(ag =>
    String(ag.status || '').toLowerCase() === 'confirmado' &&
    ag.criado_em &&
    (agora - new Date(ag.criado_em).getTime()) < trintaDias
  );
  return recentes.length < 3;
}

// RB-032: Max 2 reagendamentos por CPF em 30 dias
async function verificarLimiteReagendamentos(cpf) {
  const agendamentos = await carregarAgendamentosPacienteMySQL(cpf);
  const agora = Date.now();
  const trintaDias = 30 * 24 * 60 * 60 * 1000;
  const reagendamentos = agendamentos.filter(ag =>
    Number(ag.reagendamentos_count || 0) > 0 &&
    ag.ultimo_reagendamento_em &&
    (agora - new Date(ag.ultimo_reagendamento_em).getTime()) < trintaDias
  );
  return reagendamentos.length < 2;
}

// RB-031: Cancelamento com prazo real usando data/hora da consulta do MySQL
function podeCancelar(agendamento) {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!agendamento) return false;
  const data = agendamento.data_consulta || agendamento.dataISO;
  const hora = String(agendamento.hora_consulta || agendamento.horario || '').slice(0, 5);
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!data || !hora) return false;
  const tipo = String(agendamento.tipo_consulta || agendamento.tipoCodigo || '').toLowerCase();
  const prazoMs = tipo.includes('exame') || tipo === 'exam' ? 1 * 60 * 60 * 1000 : 24 * 60 * 60 * 1000;
  const dataConsulta = new Date(`${data}T${hora}:00`).getTime();
  return (dataConsulta - Date.now()) > prazoMs;
}

// RB-031b: Contagem de faltas/no-show em 90 dias
async function verificarNoShows(cpf) {
  const agendamentos = await carregarAgendamentosPacienteMySQL(cpf);
  const agora = Date.now();
  const noventaDias = 90 * 24 * 60 * 60 * 1000;
  const noShows = agendamentos.filter(ag =>
    ['falta', 'no-show'].includes(String(ag.status || '').toLowerCase()) &&
    ag.cancelado_em &&
    (agora - new Date(ag.cancelado_em).getTime()) < noventaDias
  );
  return noShows.length >= 3;
}

// Cancelar agendamento buscando o registro oficial no MySQL antes de abrir o modal
async function cancelarAgendamento(agendamentoId) {
  const id = String(agendamentoId || '').replace(/[^0-9]/g, '');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!id) { mostrarToast('ID do agendamento inválido.', 'erro'); return; }

// Bloco protegido: tenta executar a ação e permite tratar falhas sem travar a página.
  try {
    const lista = await carregarAgendamentosPacienteMySQL(getPerfilAtivoCpf());
    const ag = lista.find(item => String(item.id) === id);
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (!ag) { mostrarToast('Agendamento não encontrado no MySQL.', 'erro'); return; }

// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (!podeCancelar(ag)) {
      mostrarToast('Prazo de cancelamento encerrado. Em caso de dúvidas, ligue para a clínica.', 'aviso', 5000);
      return;
    }

    abrirModalCancelamento(ag);
  } catch (erro) {
    mostrarToast(erro.message || 'Não foi possível consultar o agendamento no MySQL.', 'erro', 7000);
  }
}

// Função abrirModalCancelamento: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function abrirModalCancelamento(agendamento) {
  let modal = document.getElementById('modalCancelar');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!modal) {
    modal = document.createElement('div');
    modal.className = 'modal-overlay modal-cancel-overlay';
    modal.id = 'modalCancelar';
    document.body.appendChild(modal);
  }

  const dataBR = agendamento.data_consulta ? new Date(`${agendamento.data_consulta}T00:00:00`).toLocaleDateString('pt-BR') : (agendamento.dia || '-');
  const hora = String(agendamento.hora_consulta || agendamento.horario || '-').slice(0, 5);
  const medico = agendamento.medico_nome || agendamento.medico || '-';
  const unidade = agendamento.unidade_nome || agendamento.unidade || '-';

  modal.innerHTML = `
    <div class="modal-card modal-form-card">
      <button class="modal-close" onclick="fecharModal('modalCancelar')">×</button>
      <div class="modal-header-icon">⚠️</div>
      <h3>Cancelar agendamento</h3>
      <p>Tem certeza que deseja cancelar este agendamento? O horário será liberado para outros pacientes.</p>
      <div class="resumo-agendamento" style="margin:16px 0;">
        <div class="resumo-row"><span class="resumo-label">Médico</span><span class="resumo-val">${medico}</span></div>
        <div class="resumo-row"><span class="resumo-label">Data</span><span class="resumo-val">${dataBR} às ${hora}</span></div>
        <div class="resumo-row"><span class="resumo-label">Unidade</span><span class="resumo-val">${unidade}</span></div>
      </div>
      <div class="cancel-actions">
        <button class="btn-cancel-voltar" onclick="fecharModal('modalCancelar')">← Voltar, manter agendamento</button>
        <button class="btn-cancel-confirmar" onclick="confirmarCancelamento('${agendamento.id}')">Confirmar cancelamento</button>
      </div>
    </div>
  `;
  modal.classList.add('open');
  document.body.style.overflow = 'hidden';
}

// Função confirmarCancelamento: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
async function confirmarCancelamento(agendamentoId) {
// Bloco protegido: tenta executar a ação e permite tratar falhas sem travar a página.
  try {
    await apiCancelarAgendamentoMySQL(agendamentoId, 'Cancelado pelo paciente no portal');
    fecharModal('modalCancelar');
    mostrarToast('Agendamento cancelado no MySQL.', 'sucesso');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (typeof initPortalPaciente === 'function') initPortalPaciente();
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (typeof renderDashboardAgendamentos === 'function') renderDashboardAgendamentos();
  } catch (erro) {
    mostrarToast(erro.message || 'Não foi possível cancelar no MySQL.', 'erro', 7000);
  }
}
