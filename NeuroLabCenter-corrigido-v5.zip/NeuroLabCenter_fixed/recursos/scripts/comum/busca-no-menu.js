/*
 * Arquivo: recursos/scripts/comum/busca-no-menu.js
 * Objetivo: controlar comportamentos da interface do NeuroLab Center.
 * Como manter: mantenha funções pequenas, nomes claros e evite misturar páginas diferentes.
 * Observação: comentários explicam blocos, funções, validações e integração com o servidor.
 */

/*
 * NeuroLab Center - recursos/scripts/comum/busca-no-menu.js
 * Responsabilidade: Funções compartilhadas por várias páginas, como avisos, busca, exames e regras.
 * Usado por: Páginas HTML em site/paginas/.
 * Manutenção: mantenha funções relacionadas juntas e evite misturar regras de páginas diferentes.
 */

/**
 * NeuroLab Center — navigation-search.js
 * Busca rápida, FAQ e atalhos simples de navegação.
 * Separado do antigo utils.js para facilitar manutenção.
 */

// ============================================================================

// FAQ Accordion toggle
function toggleFaq(elemento) {
  const item = elemento.closest('.faq-item');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (item) item.classList.toggle('aberto');
}

// Função buscaRapida: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function buscaRapida(texto) {
  const input = document.getElementById('busca');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (input) input.value = texto;
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (typeof buscarSite === 'function') buscarSite();
}

// As funções globais abrirMenu() e buscarSite() ficam centralizadas em
function confirmarAgendamento() {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (typeof abrirAgendamento === 'function') abrirAgendamento();
}

// Função abrirCadastro: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function abrirCadastro() {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (typeof abrirModalCadastro === 'function') abrirModalCadastro();
}

// Função abrirLogin: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function abrirLogin() {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (typeof abrirModalLogin === 'function') abrirModalLogin();
}

// Função abrirResultadoExames: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function abrirResultadoExames() {
  window.location.href = 'area-paciente.html';
}

// ============================================================================
