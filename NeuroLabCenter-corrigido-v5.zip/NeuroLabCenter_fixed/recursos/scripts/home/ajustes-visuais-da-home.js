/*
 * Arquivo: recursos/scripts/home/ajustes-visuais-da-home.js
 * Objetivo: controlar comportamentos da interface do NeuroLab Center.
 * Como manter: mantenha funções pequenas, nomes claros e evite misturar páginas diferentes.
 * Observação: comentários explicam blocos, funções, validações e integração com o servidor.
 */

/*
 * NeuroLab Center - recursos/scripts/home/ajustes-visuais-da-home.js
 * Responsabilidade: Comportamentos da página inicial: layout, busca de comandos e feedback dos formulários.
 * Usado por: Páginas HTML em site/paginas/.
 * Manutenção: mantenha funções relacionadas juntas e evite misturar regras de páginas diferentes.
 */

/**
 * NeuroLab Center — visual-polish.js
 * Polimento visual, menu responsivo e ajustes de Bootstrap.
 * Separado do antigo main.js para manter cada arquivo abaixo de 500 linhas.
 */

function aplicarIdentidadeVisualLegada() {
  const pagina = paginaArquivo();
// Configuração ou referência reutilizada pelas funções deste arquivo.
  const classesPorPagina = {
    'index.html': 'page-home',
    'sobre.html': 'page-sobre',
    'especialidades.html': 'page-especialidades',
    'medicos.html': 'page-medicos',
    'exames.html': 'page-exames',
    'unidades.html': 'page-unidades',
    'convenios.html': 'page-convenios',
    'teleconsulta.html': 'page-teleconsulta',
    'area-paciente.html': 'page-paciente',
    'agendamento.html': 'page-agendamento',
    'termos-de-uso.html': 'page-legal',
    'politica-privacidade.html': 'page-legal'
  };

  document.body.classList.remove('nl-redesign');
  document.body.classList.add('nl-legacy', classesPorPagina[pagina] || 'page-interna');
  document.body.dataset.page = pagina.replace('.html', '') || 'home';
}


// Função prepararMenuResponsivo: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function prepararMenuResponsivo() {
  const menu = document.getElementById('menu');
  const botao = document.querySelector('.menu-btn');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!menu || !botao || menu.dataset.enhanced === 'true') return;

  menu.dataset.enhanced = 'true';
  menu.id = menu.id || 'menu';
  botao.setAttribute('aria-controls', menu.id);
  botao.setAttribute('aria-expanded', String(menu.classList.contains('open')));

// Evento da interface: conecta uma ação do usuário com uma função do sistema.
  menu.addEventListener('click', (event) => {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (event.target.closest('a')) {
      menu.classList.remove('open');
      botao.setAttribute('aria-expanded', 'false');
    }
  });

// Evento da interface: conecta uma ação do usuário com uma função do sistema.
  document.addEventListener('keydown', (event) => {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (event.key !== 'Escape') return;
    menu.classList.remove('open');
    botao.setAttribute('aria-expanded', 'false');
  });

// Evento da interface: conecta uma ação do usuário com uma função do sistema.
  document.addEventListener('click', (event) => {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (!menu.classList.contains('open')) return;
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (event.target.closest('nav')) return;
    menu.classList.remove('open');
    botao.setAttribute('aria-expanded', 'false');
  });
}

// Função prepararNavbarFixa: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function prepararNavbarFixa() {
  const topbar = document.querySelector('.topbar');
  const header = document.querySelector('header');
  const navbar = document.querySelector('.navbar');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!header || header.dataset.fixedReady === 'true') return;
  header.dataset.fixedReady = 'true';

  const calcularAlturas = () => {
    const topbarVisivel = topbar && getComputedStyle(topbar).display !== 'none';
    const topbarAltura = topbarVisivel ? Math.ceil(topbar.getBoundingClientRect().height || 36) : 0;
    const headerAltura = Math.ceil((navbar || header).getBoundingClientRect().height || 78);
    const offset = topbarAltura + headerAltura;

    document.documentElement.style.setProperty('--nl-topbar-height', `${topbarAltura}px`);
    document.documentElement.style.setProperty('--nl-header-height', `${headerAltura}px`);
    document.documentElement.style.setProperty('--nl-fixed-offset', `${offset}px`);
    document.body.style.paddingTop = `${offset}px`;
    document.body.classList.add('nl-navbar-fixed-ready');
  };

  const atualizarSombra = () => {
    header.classList.toggle('navbar-scrolled', window.scrollY > 8);
  };

  calcularAlturas();
  atualizarSombra();
  setTimeout(calcularAlturas, 80);
// Evento da interface: conecta uma ação do usuário com uma função do sistema.
  window.addEventListener('resize', calcularAlturas, { passive: true });
// Evento da interface: conecta uma ação do usuário com uma função do sistema.
  window.addEventListener('scroll', atualizarSombra, { passive: true });
}

// Função aplicarAjustesBootstrapLegado: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function aplicarAjustesBootstrapLegado() {
  document.querySelectorAll('.modal-card, .card, .quick-btn, .unidade-rica, .dashboard-section, .consulta-option-card, .exam-info-panel').forEach((elemento) => {
    elemento.classList.add('shadow-sm');
  });

  document.querySelectorAll('input, select, textarea').forEach((campo) => {
    const tipo = String(campo.getAttribute('type') || '').toLowerCase();
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (['checkbox', 'radio', 'hidden', 'file', 'button', 'submit'].includes(tipo)) return;
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (!campo.classList.contains('form-control') && !campo.classList.contains('form-select')) {
      campo.classList.add(campo.tagName === 'SELECT' ? 'form-select' : 'form-control');
    }
  });

  document.querySelectorAll('.page-hero, .hero').forEach((hero) => {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (!hero.dataset.enhanced) {
      hero.dataset.enhanced = 'true';
      hero.insertAdjacentHTML('beforeend', '<div class="page-ambient-line" aria-hidden="true"></div>');
    }
  });
}
