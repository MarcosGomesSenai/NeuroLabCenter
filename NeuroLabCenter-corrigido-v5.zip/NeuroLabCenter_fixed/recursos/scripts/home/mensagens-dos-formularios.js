/*
 * Arquivo: recursos/scripts/home/mensagens-dos-formularios.js
 * Objetivo: controlar comportamentos da interface do NeuroLab Center.
 * Como manter: mantenha funções pequenas, nomes claros e evite misturar páginas diferentes.
 * Observação: comentários explicam blocos, funções, validações e integração com o servidor.
 */

/*
 * NeuroLab Center - recursos/scripts/home/mensagens-dos-formularios.js
 * Responsabilidade: Comportamentos da página inicial: layout, busca de comandos e feedback dos formulários.
 * Usado por: Páginas HTML em site/paginas/.
 * Manutenção: mantenha funções relacionadas juntas e evite misturar regras de páginas diferentes.
 */

/**
 * NeuroLab Center — form-feedback.js
 * Validação visual, botão voltar ao topo e força de senha.
 * Separado do antigo main.js para manter cada arquivo abaixo de 500 linhas.
 */

// ============================================================================

/*
 * NeuroLab Center — botão voltar ao topo
 * Por que existe: separa comportamento de rolagem da validação de formulários.
 */
function prepararBotaoVoltarTopo() {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (document.getElementById('nlBackTop')) return;
  const botao = document.createElement('button');
  botao.id = 'nlBackTop';
  botao.className = 'nl-back-top';
  botao.type = 'button';
  botao.setAttribute('aria-label', 'Voltar ao topo');
  botao.setAttribute('data-bs-toggle', 'tooltip');
  botao.setAttribute('data-bs-title', 'Voltar ao topo');
  botao.textContent = '↑';
// Evento da interface: conecta uma ação do usuário com uma função do sistema.
  botao.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));
  document.body.appendChild(botao);

  const alternar = () => botao.classList.toggle('show', window.scrollY > 520);
  alternar();
// Evento da interface: conecta uma ação do usuário com uma função do sistema.
  window.addEventListener('scroll', alternar, { passive: true });
}


/*
 * NeuroLab Center — validação visual Bootstrap
 * Por que existe: mantém regras de formulário isoladas dos recursos de senha.
 */
function prepararValidacaoBootstrap() {
  const grupos = document.querySelectorAll('.form-group');
  grupos.forEach((grupo) => {
    const label = grupo.querySelector('label');
    const campo = grupo.querySelector('input, select, textarea');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (!campo || campo.type === 'checkbox' || campo.type === 'file') return;
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (label?.textContent.includes('*')) campo.required = true;
    campo.classList.add(campo.tagName === 'SELECT' ? 'form-select' : 'form-control');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (!grupo.querySelector('.invalid-feedback')) {
      campo.insertAdjacentHTML('afterend', '<div class="invalid-feedback">Confira este campo antes de continuar.</div>');
    }
    const validar = () => validarCampoBootstrap(campo);
// Evento da interface: conecta uma ação do usuário com uma função do sistema.
    campo.addEventListener('blur', () => {
      campo.dataset.touched = 'true';
      validar();
    });
// Evento da interface: conecta uma ação do usuário com uma função do sistema.
    campo.addEventListener('input', () => {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
      if (campo.dataset.touched === 'true' || campo.value.length > 2) validar();
      atualizarBotaoCadastro();
    });
  });

  document.querySelectorAll('.checkbox-group input[type="checkbox"]').forEach((checkbox) => {
    checkbox.classList.add('form-check-input');
// Evento da interface: conecta uma ação do usuário com uma função do sistema.
    checkbox.addEventListener('change', atualizarBotaoCadastro);
  });
  atualizarBotaoCadastro();
}

// Função validarCampoBootstrap: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function validarCampoBootstrap(campo) {
  const valor = String(campo.value || '').trim();
  let valido = true;
  let mensagem = 'Confira este campo antes de continuar.';

// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (campo.required && !valor) {
    valido = false;
    mensagem = 'Campo obrigatório.';
  } else if (campo.type === 'email' && valor && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(valor)) {
    valido = false;
    mensagem = 'Informe um e-mail válido.';
  } else if (/cpf/i.test(campo.id) && valor && !cpfValido(valor)) {
    valido = false;
    mensagem = 'CPF inválido.';
  } else if (/senha/i.test(campo.id) && !/confirm/i.test(campo.id) && valor && !senhaValida(valor)) {
    valido = false;
    mensagem = 'Use ao menos 8 caracteres, uma letra e um número.';
  } else if (campo.id === 'cadSenhaConfirm' || campo.id === 'cadSenhaAdolConfirm') {
    const senhaId = campo.id === 'cadSenhaAdolConfirm' ? 'cadSenhaAdol' : 'cadSenha';
    const senha = document.getElementById(senhaId)?.value || '';
    valido = valor === senha;
    mensagem = 'As senhas precisam ser iguais.';
  }

  campo.classList.toggle('is-invalid', !valido);
  campo.classList.toggle('is-valid', valido && Boolean(valor));
  const feedback = campo.parentElement?.querySelector('.invalid-feedback');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (feedback) feedback.textContent = mensagem;
  return valido;
}

// Função atualizarBotaoCadastro: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function atualizarBotaoCadastro() {
  const modal = document.getElementById('modalCadastro');
  const botao = modal?.querySelector('button.btn-primary.btn-full');
  const termos = document.getElementById('cadTermos');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!botao || !termos) return;
  botao.disabled = !termos.checked;
  botao.classList.toggle('disabled', !termos.checked);
  botao.title = termos.checked ? '' : 'Aceite os Termos de Uso e a Política de Privacidade.';
}


/*
 * NeuroLab Center — mostrar/ocultar senha
 * Por que existe: separa acessibilidade do campo de senha da regra de força.
 */
function prepararToggleSenha() {
  document.querySelectorAll('input[type="password"], input[type="text"][data-password-toggle="true"]').forEach((campo) => {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (campo.closest('.nl-password-wrap')) return;
    const parent = campo.parentNode;
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (!parent) return;

    campo.dataset.passwordToggle = 'true';
    const wrap = document.createElement('div');
    wrap.className = 'nl-password-wrap';
    parent.insertBefore(wrap, campo);
    wrap.appendChild(campo);

    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'nl-password-toggle';
    btn.setAttribute('aria-label', 'Mostrar senha');
    btn.setAttribute('aria-pressed', 'false');
    btn.innerHTML = '&#128065;';
// Evento da interface: conecta uma ação do usuário com uma função do sistema.
    btn.addEventListener('click', () => {
      const visivel = campo.type === 'text';
      campo.type = visivel ? 'password' : 'text';
      btn.setAttribute('aria-pressed', String(!visivel));
      btn.setAttribute('aria-label', visivel ? 'Mostrar senha' : 'Ocultar senha');
      btn.innerHTML = visivel ? '&#128065;' : '&#128584;';
    });
    wrap.appendChild(btn);
  });
}


/*
 * NeuroLab Center — força da senha
 * Por que existe: deixa a regra de pontuação da senha em um arquivo próprio.
 */
function prepararForcaSenha() {
  document.querySelectorAll('#cadSenha, #cadSenhaAdol, #loginSenha').forEach((campo) => {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (campo.dataset.strengthReady === 'true') return;
    campo.dataset.strengthReady = 'true';
    const destino = campo.closest('.nl-password-wrap') || campo.parentElement;
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (!destino?.querySelector('.nl-password-strength')) {
      destino.insertAdjacentHTML('beforeend', '<div class="nl-password-strength"><span></span><small>Força da senha</small></div>');
    }
// Evento da interface: conecta uma ação do usuário com uma função do sistema.
    campo.addEventListener('input', () => atualizarForcaSenha(campo));
    atualizarForcaSenha(campo);
  });
}

// Função atualizarForcaSenha: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function atualizarForcaSenha(campo) {
  const wrap = campo.closest('.nl-password-wrap');
  const grupo = campo.closest('.form-group') || campo.parentElement;
  const box = wrap?.querySelector('.nl-password-strength') || grupo?.querySelector('.nl-password-strength');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!box) return;

  const senha = campo.value || '';
  let score = 0;
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (senha.length >= 8) score += 1;
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (/[A-Z]/.test(senha)) score += 1;
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (/\d/.test(senha)) score += 1;
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (/[^A-Za-z0-9]/.test(senha)) score += 1;
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (senha.length >= 12 && score >= 3) score += 1;

  const niveis = [
    { label: 'Muito fraca', cls: 'weak', width: '18%' },
    { label: 'Fraca', cls: 'weak', width: '35%' },
    { label: 'Boa', cls: 'medium', width: '62%' },
    { label: 'Forte', cls: 'strong', width: '82%' },
    { label: 'Muito forte', cls: 'strong', width: '100%' },
    { label: 'Excelente', cls: 'strong', width: '100%' }
  ];
  const nivel = niveis[Math.min(score, niveis.length - 1)];
  box.className = `nl-password-strength ${nivel.cls}`;
  box.style.setProperty('--strength-width', senha ? nivel.width : '0%');
  const label = box.querySelector('small');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (label) label.textContent = senha ? `Força da senha: ${nivel.label}` : 'Força da senha';
}

// ============================================================================
