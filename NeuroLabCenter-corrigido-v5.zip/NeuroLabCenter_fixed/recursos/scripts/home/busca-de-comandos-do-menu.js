/*
 * Arquivo: recursos/scripts/home/busca-de-comandos-do-menu.js
 * Objetivo: controlar comportamentos da interface do NeuroLab Center.
 * Como manter: mantenha funções pequenas, nomes claros e evite misturar páginas diferentes.
 * Observação: comentários explicam blocos, funções, validações e integração com o servidor.
 */

/*
 * NeuroLab Center - recursos/scripts/home/busca-de-comandos-do-menu.js
 * Responsabilidade: Comportamentos da página inicial: layout, busca de comandos e feedback dos formulários.
 * Usado por: Páginas HTML em site/paginas/.
 * Manutenção: mantenha funções relacionadas juntas e evite misturar regras de páginas diferentes.
 */

/**
 * NeuroLab Center — command-search.js
 * Busca rápida e painel de comando do site.
 * Separado do antigo main.js para manter cada arquivo abaixo de 500 linhas.
 */


// ============================================================================
// ============================================================================

/*
 * NeuroLab Center — dados e sugestões da busca rápida
 * Por que existe: deixa a lista de atalhos separada da interface do comando.
 */
const NL_ACOES_RAPIDAS = [
  { titulo: 'Agendar consulta', detalhe: 'Abrir fluxo de agendamento em 6 passos', href: 'agendamento.html', termos: 'agendar consulta horario medico unidade' },
  { titulo: 'Teleconsulta', detalhe: 'Consulta online particular ou convenio', href: 'teleconsulta.html', termos: 'online teleconsulta video' },
  { titulo: 'Area do Paciente', detalhe: 'Historico, exames, documentos e familia', href: 'area-paciente.html', termos: 'paciente historico exames documentos familia' },
  { titulo: 'Medicos', detalhe: 'Ver profissionais por especialidade', href: 'medicos.html', termos: 'medicos especialistas neurologia' },
  { titulo: 'Exames', detalhe: 'EEG, ENMG, polissonografia e preparo', href: 'exames.html', termos: 'exames eeg enmg polissonografia preparo' },
  { titulo: 'Unidades', detalhe: 'Enderecos, mapas e estrutura', href: 'unidades.html', termos: 'unidades mapa endereco unidade' },
  { titulo: 'Convenios', detalhe: 'Planos aceitos e cobertura', href: 'convenios.html', termos: 'convenios planos cobertura' },
  { titulo: 'Termos e privacidade', detalhe: 'LGPD, termos de uso e politica de privacidade', href: 'politica-privacidade.html', termos: 'termos privacidade lgpd dados' }
];

// Função prepararSugestoesBusca: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function prepararSugestoesBusca() {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (document.getElementById('nlBuscaSugestoes')) return;
  const datalist = document.createElement('datalist');
  datalist.id = 'nlBuscaSugestoes';
  datalist.innerHTML = ['Agendar consulta', 'Teleconsulta', 'EEG', 'Eletroneuromiografia', 'Polissonografia', 'Enxaqueca', 'Memoria', 'Unimed', 'Bradesco Saude', 'Area do Paciente']
    .map(item => `<option value="${item}"></option>`).join('');
  document.body.appendChild(datalist);
  document.querySelectorAll('#busca, #drEspecialidadeBusca, input[type="search"]').forEach(input => {
    input.setAttribute('list', 'nlBuscaSugestoes');
    input.setAttribute('autocomplete', 'off');
  });
}

// Função registrarBuscaRecente: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function registrarBuscaRecente(valor) {
  const texto = String(valor || '').trim();
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!texto) return;
  const recentes = lerJson('neurolab_buscas_recentes', []);
  const atualizados = [texto, ...recentes.filter(item => normalizarTexto(item) !== normalizarTexto(texto))].slice(0, 6);
  salvarJson('neurolab_buscas_recentes', atualizados);
}


/*
 * NeuroLab Center — janela da busca rápida
 * Por que existe: concentra abertura, fechamento e filtro da paleta de comandos.
 */
function abrirComandoRapido() {
  let palette = document.getElementById('nlCommandPalette');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!palette) {
    palette = document.createElement('div');
    palette.id = 'nlCommandPalette';
    palette.className = 'nl-command-palette';
    palette.innerHTML = `
      <div class="nl-command-card">
        <button class="nl-command-close" onclick="fecharComandoRapido()" aria-label="Fechar">x</button>
        <label for="nlCommandInput">Busca rapida</label>
        <input id="nlCommandInput" class="form-control" placeholder="Digite: agendar, exame, unidade, convenio..." oninput="filtrarComandoRapido(this.value)" onkeydown="executarComandoRapido(event)">
        <div class="nl-command-list" id="nlCommandList"></div>
      </div>
    `;
    document.body.appendChild(palette);
  }
  palette.classList.add('open');
  document.body.style.overflow = 'hidden';
  filtrarComandoRapido('');
  setTimeout(() => document.getElementById('nlCommandInput')?.focus(), 40);
}

// Função fecharComandoRapido: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function fecharComandoRapido() {
  document.getElementById('nlCommandPalette')?.classList.remove('open');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!document.querySelector('.modal-overlay.open')) document.body.style.overflow = '';
}

// Função filtrarComandoRapido: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function filtrarComandoRapido(valor = '') {
  const termo = normalizarTexto(valor);
  const lista = document.getElementById('nlCommandList');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!lista) return;
  const recentes = lerJson('neurolab_buscas_recentes', []);
  const itens = NL_ACOES_RAPIDAS.filter(item => normalizarTexto(`${item.titulo} ${item.detalhe} ${item.termos}`).includes(termo));
  const htmlRecentes = !termo && recentes.length
    ? `<div class="nl-command-section">Recentes</div>${recentes.map(item => `<button class="nl-command-item compact" onclick="rebuscarComandoRapido('${encodeURIComponent(item)}')"><strong>${nlSafeText(item)}</strong><span>Buscar novamente</span></button>`).join('')}`
    : '';
  const htmlAcoes = itens.map((item, index) => `
    <button class="nl-command-item ${index === 0 ? 'active' : ''}" onclick="navegarPara('${item.href}')">
      <strong>${nlSafeText(item.titulo)}</strong>
      <span>${nlSafeText(item.detalhe)}</span>
    </button>
  `).join('');
  lista.innerHTML = `${htmlRecentes}${htmlAcoes}` || '<div class="safe-note">Nada encontrado. Tente buscar por consulta, exame, unidade ou convenio.</div>';
}

// Função rebuscarComandoRapido: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function rebuscarComandoRapido(valorCodificado) {
  const valor = decodeURIComponent(valorCodificado || '');
  const input = document.getElementById('nlCommandInput');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (input) {
    input.value = valor;
    filtrarComandoRapido(valor);
    input.focus();
    return;
  }
  registrarBuscaRecente(valor);
  const busca = document.getElementById('busca');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (busca) {
    busca.value = valor;
    buscarSite();
  }
}


/*
 * NeuroLab Center — atalhos de teclado
 * Por que existe: mantém Ctrl+K, / e Escape separados da renderização da paleta.
 */
function executarComandoRapido(event) {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (event.key === 'Escape') {
    fecharComandoRapido();
    return;
  }
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (event.key !== 'Enter') return;
  registrarBuscaRecente(document.getElementById('nlCommandInput')?.value || '');
  const ativo = document.querySelector('#nlCommandList .nl-command-item.active') || document.querySelector('#nlCommandList .nl-command-item');
  ativo?.click();
}

// Função prepararAtalhosGlobais: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function prepararAtalhosGlobais() {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (document.body.dataset.shortcutsReady === 'true') return;
  document.body.dataset.shortcutsReady = 'true';

// Evento da interface: conecta uma ação do usuário com uma função do sistema.
  document.addEventListener('keydown', (event) => {
    const alvo = event.target;
    const digitando = alvo && ['INPUT', 'TEXTAREA', 'SELECT'].includes(alvo.tagName);
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k') {
      event.preventDefault();
      abrirComandoRapido();
      return;
    }
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (event.key === '/' && !digitando && !document.querySelector('.modal-overlay.open')) {
      event.preventDefault();
      abrirComandoRapido();
      return;
    }
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (event.key === 'Escape') fecharComandoRapido();
  });
}

// ============================================================================
