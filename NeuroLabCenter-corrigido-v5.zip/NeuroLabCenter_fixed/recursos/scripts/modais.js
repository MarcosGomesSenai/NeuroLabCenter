/*
 * Arquivo: recursos/scripts/modais.js
 * Objetivo: controlar comportamentos da interface do NeuroLab Center.
 * Como manter: mantenha funções pequenas, nomes claros e evite misturar páginas diferentes.
 * Observação: comentários explicam blocos, funções, validações e integração com o servidor.
 */

/*
 * NeuroLab Center - recursos/scripts/modais.js
 * Responsabilidade: Script principal de funcionalidade do site.
 * Usado por: Páginas HTML em site/paginas/.
 * Manutenção: mantenha funções relacionadas juntas e evite misturar regras de páginas diferentes.
 */

/**
 * NeuroLab Center — modals.js
 * Arquivo consolidado para apresentação e manutenção.
 * Carregadores document.write e pastas part/section foram substituídos por código direto.
 */

// ============================================================================
// ============================================================================

function abrirMenu() {
  const menu = $('menu');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (menu) menu.classList.toggle('open');
}

// Função navegarPara: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function navegarPara(arquivo) {
  window.location.href = arquivo;
}

// Função buscarSite: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function buscarSite() {
  const input = $('busca');
  const termo = normalizarTexto(input?.value || '');

// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!termo) {
    mostrarToast('Digite algo para buscar. Ex: enxaqueca, EEG, unidade ou consultas.', 'aviso');
    return;
  }

// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (termo.includes('online') || termo.includes('chat') || termo.includes('teleconsulta')) {
    navegarPara('teleconsulta.html');
  } else if (termo.includes('eletro') || termo.includes('exame') || termo.includes('polissonografia') || termo.includes('eeg')) {
    navegarPara('exames.html');
  } else if (termo.includes('unidade') || termo.includes('endereco') || termo.includes('cidade') || termo.includes('cep')) {
    navegarPara('unidades.html');
  } else {
    navegarPara('especialidades.html');
  }
}

// Função abrirModal: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function abrirModal(id) {
  const modal = $(id);
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!modal) return false;
  modal.classList.add('open');
  document.body.style.overflow = 'hidden';
  return true;
}

// Função fecharModal: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function fecharModal(id) {
  const modal = $(id);
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (modal) modal.classList.remove('open');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!document.querySelector('.modal-overlay.open')) document.body.style.overflow = '';
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (id === 'modalAgendamento') liberarHold(false);
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (id === 'modalCadastro') {
    const ux = window.NLUX;
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (ux) ux.cadastroFamilia = false;
    document.getElementById('cadFamiliaExtra')?.classList.add('hidden');
  }
}

// Função abrirCadastroFamiliar: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function abrirCadastroFamiliar() {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!getAuthToken?.()) {
    mostrarToast('Entre na sua conta antes de cadastrar um familiar.', 'aviso');
    abrirModalLogin();
    return;
  }
  const ux = window.NLUX;
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (ux) ux.cadastroFamilia = true;
  const extra = document.getElementById('cadFamiliaExtra');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (extra) extra.classList.remove('hidden');
  const titulo = document.querySelector('#modalCadastro h3');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (titulo) titulo.textContent = 'Cadastrar familiar';
  switchCadastro('adulto');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (paginaAtual() === 'index.html') {
    abrirModalCadastro();
  } else {
    navegarPara('index.html?modal=cadastro&familia=1');
  }
}

// Função abrirModalCadastro: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function abrirModalCadastro() {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (abrirModal('modalCadastro')) return;
  navegarPara('index.html?modal=cadastro');
}

// Função abrirModalLogin: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function abrirModalLogin() {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (abrirModal('modalLogin')) return;
  navegarPara('index.html?modal=login');
}

// Função abrirRecuperarSenha: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function abrirRecuperarSenha() {
  fecharModal('modalLogin');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (abrirModal('modalRecuperarSenha')) return;
  navegarPara('index.html?modal=recuperar');
}

// Função abrirModalAvaliacao: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function abrirModalAvaliacao() {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (abrirModal('modalAvaliacao')) return;
  navegarPara('index.html?modal=avaliacao');
}

// Função abrirAgendamento: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function abrirAgendamento() {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!verificarAuthParaAgendamento()) return;

  const titular = typeof getUsuarioLogado === 'function' ? getUsuarioLogado() : null;
  const cpfAtivo = typeof getPerfilAtivoCpf === 'function' ? getPerfilAtivoCpf() : titular?.cpf;
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (titular?.cpf && cpfAtivo && cpfAtivo !== titular.cpf) {
    const perfil = typeof listarPerfisFamilia === 'function'
      ? listarPerfisFamilia().find(p => p.cpf === cpfAtivo)
      : null;
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (perfil) {
      mostrarToast(`Agendando para ${perfil.nome} (${perfil.papel}).`, 'info');
    }
  }

// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (paginaAtual() !== 'agendamento.html') {
    navegarPara('agendamento.html');
    return;
  }

  window.scrollTo({ top: 0, behavior: 'smooth' });
}
