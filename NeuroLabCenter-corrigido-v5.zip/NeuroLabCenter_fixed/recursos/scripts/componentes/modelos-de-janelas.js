/*
 * Arquivo: recursos/scripts/componentes/modelos-de-janelas.js
 * Objetivo: controlar comportamentos da interface do NeuroLab Center.
 * Como manter: mantenha funções pequenas, nomes claros e evite misturar páginas diferentes.
 * Observação: comentários explicam blocos, funções, validações e integração com o servidor.
 */

/*
 * NeuroLab Center - recursos/scripts/componentes/modelos-de-janelas.js
 * Responsabilidade: Modelos e componentes JavaScript reutilizáveis, como janelas e modais.
 * Usado por: Páginas HTML em site/paginas/.
 * Manutenção: mantenha funções relacionadas juntas e evite misturar regras de páginas diferentes.
 */

/**
 * NeuroLab Center — componentes de modais da Home
 *
 * Este arquivo mantém o index.html abaixo do limite de 500 linhas.
 * A marcação continua separada, nomeada e fácil de achar:
 * - login
 * - cadastro
 * - recuperação de senha
 * - agendamento em 6 passos
 * - fila de espera
 * - avaliação
 */
(function carregarModaisDaHome() {
  const root = document.getElementById('modalRoot');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!root) return;

  root.innerHTML = String.raw`
  <!-- MODAL LOGIN -->
  <div class="modal-overlay" id="modalLogin">
    <div class="modal-card modal-form-card">
      <button class="modal-close" onclick="fecharModal('modalLogin')">×</button>
      <div class="modal-header-icon">🔐</div>
      <h3>Entrar na sua conta</h3>
      <p>Autenticação em duas etapas: CPF depois senha (RB-020).</p>
      <div class="form-group">
        <label>CPF</label>
        <input id="loginCpf" type="text" placeholder="000.000.000-00" maxlength="14" oninput="mascararCpf(this)" />
        <span class="field-hint" id="loginCpfHint"></span>
      </div>
      <div class="form-group hidden" id="loginSenhaGroup">
        <label>Senha</label>
        <input id="loginSenha" type="password" placeholder="Sua senha" />
        <span class="field-hint" id="loginSenhaHint"></span>
      </div>
      <div id="loginBloqueio" class="alerta-bloqueio hidden"></div>
      <button class="btn btn-primary btn-full" id="btnLoginProximo" onclick="avancarLogin()">Continuar</button>
      <div class="modal-links">
        <a href="#" onclick="abrirRecuperarSenha(); return false;">Esqueci minha senha</a>
        <span>·</span>
        <a href="#" onclick="fecharModal('modalLogin'); abrirModalCadastro(); return false;">Criar conta</a>
      </div>
    </div>
  </div>
  <!-- MODAL CADASTRO -->
  <div class="modal-overlay" id="modalCadastro">
    <div class="modal-card modal-form-card modal-lg">
      <button class="modal-close" onclick="fecharModal('modalCadastro')">×</button>
      <div class="modal-header-icon">🧠</div>
      <h3>Criar conta</h3>
      <p>Campos com * são obrigatórios. CPF é o identificador único (RB-001).</p>
      <div class="cadastro-tabs">
        <button class="cadastro-tab active" id="tabAdulto" onclick="switchCadastro('adulto')">Adulto (18+)</button>
        <button class="cadastro-tab" id="tabAdolescente" onclick="switchCadastro('adolescente')">Menor de idade (0–17)</button>
      </div>
      <div id="formAdulto">
        <div class="form-row">
          <div class="form-group">
            <label>CPF *</label>
            <input id="cadCpf" type="text" placeholder="000.000.000-00" maxlength="14" oninput="mascararCpf(this)" />
            <span class="field-hint" id="cadCpfHint"></span>
          </div>
          <div class="form-group">
            <label>Data de nascimento *</label>
            <input id="cadNascimento" type="date" />
          </div>
        </div>
        <div class="form-group">
          <label>Nome completo *</label>
          <input id="cadNome" type="text" placeholder="Mínimo 2 nomes" />
        </div>
        <div class="form-row">
          <div class="form-group">
            <label>Celular (WhatsApp) *</label>
            <input id="cadCelular" type="text" placeholder="(11) 99999-9999" maxlength="15"
              oninput="mascararTelefone(this)" />
          </div>
          <div class="form-group">
            <label>E-mail <small>(opcional)</small></label>
            <input id="cadEmail" type="email" placeholder="seu@email.com" />
          </div>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label>Senha *</label>
            <input id="cadSenha" type="password" placeholder="Mín. 8 chars, 1 letra e 1 número" />
          </div>
          <div class="form-group">
            <label>Confirmar senha *</label>
            <input id="cadSenhaConfirm" type="password" placeholder="Repita a senha" />
          </div>
        </div>
        <span class="field-hint" id="cadSenhaHint"></span>
      </div>
      <div id="cadFamiliaExtra" class="form-group hidden">
        <label>Parentesco do familiar *</label>
        <input id="cadFamiliaPapel" type="text" placeholder="Ex.: Filho, Neto, Sobrinho, Mãe, Pai, Cônjuge" />
        <small class="text-muted">O familiar terá conta completa no banco (CPF próprio) e ficará vinculado à sua conta família.</small>
      </div>
      <div id="formAdolescente" class="view-style-050">
        <p class="safe-note view-style-051">Filhos, netos e dependentes de 0 a 17 anos podem ter conta própria. Um CPF de
          responsável cadastrado é obrigatório como contato e responsável legal.</p>
        <div class="form-row">
          <div class="form-group">
            <label>CPF *</label>
            <input id="cadCpfAdol" type="text" placeholder="000.000.000-00" maxlength="14" oninput="mascararCpf(this)" />
            <span class="field-hint" id="cadCpfAdolHint"></span>
          </div>
          <div class="form-group"><label>Data de nascimento *</label><input id="cadNascAdol" type="date" /></div>
        </div>
        <div class="form-group"><label>Nome completo *</label><input id="cadNomeAdol" type="text"
            placeholder="Mínimo 2 nomes" /></div>
        <div class="form-row">
          <div class="form-group"><label>Celular *</label><input id="cadCelAdol" type="text"
              placeholder="(11) 99999-9999" maxlength="15" oninput="mascararTelefone(this)" /></div>
          <div class="form-group">
            <label>CPF do responsável *</label>
            <input id="cadCpfResp" type="text" placeholder="000.000.000-00" maxlength="14"
              oninput="mascararCpf(this)" />
            <small class="view-style-052">Responsável cadastrado</small>
          </div>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label>Senha *</label>
            <input id="cadSenhaAdol" type="password" placeholder="Mín. 8 chars, 1 letra e 1 número" />
          </div>
          <div class="form-group">
            <label>Confirmar senha *</label>
            <input id="cadSenhaAdolConfirm" type="password" placeholder="Repita a senha" />
          </div>
        </div>
      </div>
      <div class="form-group checkbox-group">
        <label class="checkbox-label">
          <input type="checkbox" id="cadTermos" />
          <span>Aceito os <a href="termos-de-uso.html" target="_blank" class="view-style-053">Termos de Uso</a> e a <a href="politica-privacidade.html" target="_blank" class="view-style-053">Política de Privacidade</a> *
            (desmarcado por padrão — RB-003)</span>
        </label>
      </div>
      <div class="form-group checkbox-group">
        <label class="checkbox-label">
          <input type="checkbox" id="cadWhatsapp" />
          <span>Aceito receber lembretes por WhatsApp (opcional — RB-004)</span>
        </label>
      </div>
      <span class="field-hint" id="cadGeralHint"></span>
      <button class="btn btn-primary btn-full" onclick="realizarCadastro()">Criar conta</button>
      <div class="modal-links">
        <a href="#" onclick="fecharModal('modalCadastro'); abrirModalLogin(); return false;">Já tenho conta → Entrar</a>
      </div>
    </div>
  </div>
  <!-- MODAL RECUPERAR SENHA -->
  <div class="modal-overlay" id="modalRecuperarSenha">
    <div class="modal-card modal-form-card">
      <button class="modal-close" onclick="fecharModal('modalRecuperarSenha')">×</button>
      <div class="modal-header-icon">🔑</div>
      <h3>Recuperar senha</h3>
      <p>Informe seu CPF. Enviaremos um link por WhatsApp, SMS ou e-mail. O link expira em <strong>2 horas</strong> e é
        de uso único (RB-032/033). Máximo 3 solicitações por hora (RB-035).</p>
      <div class="form-group">
        <label>CPF</label>
        <input id="recCpf" type="text" placeholder="000.000.000-00" maxlength="14" oninput="mascararCpf(this)" />
      </div>
      <span class="field-hint" id="recHint"></span>
      <button class="btn btn-primary btn-full" onclick="enviarRecuperacao()">Enviar link de recuperação</button>
    </div>
  </div>
  <!-- MODAL AGENDAMENTO 6 PASSOS -->
  <div class="modal-overlay modal-fullscreen" id="modalAgendamento">
    <div class="modal-card modal-agendamento-card">
      <button class="modal-close" onclick="fecharModal('modalAgendamento')">×</button>
      <div class="agendamento-progress">
        <div class="progress-steps" id="progressSteps">
          <div class="progress-step active" data-step="1">1. Tipo</div>
          <div class="progress-step" data-step="2">2. Cobertura</div>
          <div class="progress-step" data-step="3">3. Unidade</div>
          <div class="progress-step" data-step="4">4. Médico</div>
          <div class="progress-step" data-step="5">5. Horário</div>
          <div class="progress-step" data-step="6">6. Confirmar</div>
        </div>
        <div class="progress-bar">
          <div class="progress-fill" id="progressFill"></div>
        </div>
      </div>
      <!-- PASSO 1 -->
      <div class="ag-step" id="agStep1">
        <h3>Passo 1 — Tipo de atendimento</h3>
        <p>Selecione o tipo. Teleconsulta não está disponível no SUS (RB-122).</p>
        <div class="tipo-buttons">
          <button class="tipo-btn" onclick="selecionarTipo('Consulta Neurológica Adulto', 'CONS-ADULT')">
            <span>🧠</span><strong>Consulta Neurológica</strong><small>Adulto (18+)</small>
          </button>
          <button class="tipo-btn" onclick="selecionarTipo('Consulta Neurológica Infantil', 'CONS-INF')">
            <span>👶</span><strong>Consulta Infantil</strong><small>Até 15 anos</small>
          </button>
          <button class="tipo-btn" onclick="selecionarTipo('Teleconsulta', 'TELE')">
            <span>💻</span><strong>Teleconsulta</strong><small>Particular ou Convênio</small>
          </button>
          <button class="tipo-btn" onclick="selecionarTipo('Exame Diagnóstico', 'EXAM')">
            <span>🔬</span><strong>Exame Diagnóstico</strong><small>EEG, ENMG, Polissonografia...</small>
          </button>
        </div>
      </div>
      <!-- PASSO 2 -->
      <div class="ag-step hidden" id="agStep2">
        <h3>Passo 2 — Cobertura</h3>
        <p>Como será coberto o atendimento?</p>
        <div id="avisoTeleSus" class="safe-note hidden view-style-003">⚠ Teleconsulta não está disponível
          pelo SUS (RB-122/176). Escolha Particular ou Convênio.</div>
        <div class="tipo-buttons">
          <button class="tipo-btn" onclick="selecionarCobertura('Particular')">
            <span>💳</span><strong>Particular</strong><small>Sem convênio</small>
          </button>
          <button class="tipo-btn" id="btnConvenio" onclick="selecionarCobertura('Convênio')">
            <span>🏥</span><strong>Convênio</strong><small>Plano de saúde</small>
          </button>
          <button class="tipo-btn" id="btnSUS" onclick="selecionarCobertura('SUS')">
            <span>🇧🇷</span><strong>SUS</strong><small>Sistema Único de Saúde</small>
          </button>
        </div>
        <div id="convenioSelect" class="hidden view-style-004">
          <label><strong>Selecione seu convênio:</strong></label>
          <select id="convenioNome" class="view-style-005">
            <option value="">-- Selecione --</option>
            <option>Unimed</option>
            <option>Bradesco Saúde</option>
            <option>SulAmérica</option>
            <option>Amil</option>
            <option>Porto Seguro Saúde</option>
            <option>NotreDame Intermédica</option>
          </select>
          <button class="btn btn-primary view-style-006" onclick="confirmarConvenio()">Confirmar convênio e
            continuar</button>
        </div>
        <div class="ag-nav">
          <button class="btn btn-light" onclick="voltarPasso()">← Voltar</button>
        </div>
      </div>
      <!-- PASSO 3 -->
      <div class="ag-step hidden" id="agStep3">
        <h3>Passo 3 — Localização e unidade</h3>
        <p>Digite seu CEP para encontrar unidades disponíveis.</p>
        <div class="form-group">
          <label>CEP</label>
          <div class="view-style-007">
            <input id="agCep" type="text" placeholder="00000-000" maxlength="9" oninput="mascararCep(this)" class="view-style-008" />
            <button class="btn btn-primary" onclick="buscarUnidadePorCep()">Buscar</button>
          </div>
        </div>
        <div id="unidadesDisponiveis" class="unidades-grid hidden">
          <div class="unidade-card" onclick="selecionarUnidade('Santo André — Centro', 'R. Amazonas, 48')">
            <strong>Santo André — Centro</strong>
            <small>R. Amazonas, 48 — 2,1 km</small>
            <div class="tags view-style-009"><span class="tag">Convênio</span><span class="tag">SUS</span><span
                class="tag">Teleconsulta</span></div>
          </div>
          <div class="unidade-card" onclick="selecionarUnidade('São Bernardo — Jardim do Mar', 'Av. Kennedy, 303')">
            <strong>São Bernardo — Jardim do Mar</strong>
            <small>Av. Kennedy, 303 — 8,4 km</small>
            <div class="tags view-style-009"><span class="tag">Convênio</span><span
                class="tag">Teleconsulta</span></div>
          </div>
        </div>
        <div class="ag-nav">
          <button class="btn btn-light" onclick="voltarPasso()">← Voltar</button>
        </div>
      </div>
      <!-- PASSO 4 -->
      <div class="ag-step hidden" id="agStep4">
        <h3>Passo 4 — Escolha do médico</h3>
        <p>Médicos disponíveis: <span id="ag4Label" class="view-style-010"></span></p>
        <div class="medicos-grid">
          <div class="medico-card"
            onclick="selecionarMedico('Dra. Ana Beatriz Ferreira','CRM/SP 84.201','Neurologia Geral e Epilepsia',4.9,127)">
            <div class="medico-avatar">AB</div>
            <div class="medico-info">
              <strong>Dra. Ana Beatriz Ferreira</strong>
              <small>CRM/SP 84.201 · Neurologia Geral e Epilepsia</small>
              <div class="medico-rating">⭐ 4.9 <span>(127 avaliações)</span></div>
              <div class="tags"><span class="tag">Particular</span><span class="tag">Convênio</span><span
                  class="tag">SUS</span></div>
            </div>
          </div>
          <div class="medico-card"
            onclick="selecionarMedico('Dr. Carlos Eduardo Moura','CRM/SP 67.453','Neurologia e Distúrbios do Sono',4.7,89)">
            <div class="medico-avatar">CE</div>
            <div class="medico-info">
              <strong>Dr. Carlos Eduardo Moura</strong>
              <small>CRM/SP 67.453 · Neurologia e Distúrbios do Sono</small>
              <div class="medico-rating">⭐ 4.7 <span>(89 avaliações)</span></div>
              <div class="tags"><span class="tag">Particular</span><span class="tag">Convênio</span><span
                  class="tag">Teleconsulta</span></div>
            </div>
          </div>
          <div class="medico-card"
            onclick="selecionarMedico('Dra. Fernanda Lima Costa','CRM/SP 91.077','Neuropediatria',4.8,203)">
            <div class="medico-avatar">FL</div>
            <div class="medico-info">
              <strong>Dra. Fernanda Lima Costa</strong>
              <small>CRM/SP 91.077 · Neuropediatria</small>
              <div class="medico-rating">⭐ 4.8 <span>(203 avaliações)</span></div>
              <div class="tags"><span class="tag">Particular</span><span class="tag">Convênio</span></div>
            </div>
          </div>
        </div>
        <div class="ag-nav">
          <button class="btn btn-light" onclick="voltarPasso()">← Voltar</button>
        </div>
      </div>
      <!-- PASSO 5 -->
      <div class="ag-step hidden" id="agStep5">
        <h3>Passo 5 — Calendário e horário</h3>
        <p>Selecione um slot. Ao selecionar, o horário é reservado por <strong>10 minutos</strong> (RB-210).</p>
        <div class="calendario-grid">
          <div class="horario-grupo">
            <div class="horario-dia">Seg, 05 Mai</div>
            <div class="horarios">
              <button class="horario-btn" onclick="selecionarHorarioHome('Seg 05/Mai','08:00',this)">08:00</button>
              <button class="horario-btn" onclick="selecionarHorarioHome('Seg 05/Mai','09:30',this)">09:30</button>
              <button class="horario-btn ocupado" disabled title="Horário ocupado">11:00</button>
              <button class="horario-btn" onclick="selecionarHorarioHome('Seg 05/Mai','14:00',this)">14:00</button>
            </div>
          </div>
          <div class="horario-grupo">
            <div class="horario-dia">Ter, 06 Mai</div>
            <div class="horarios">
              <button class="horario-btn" onclick="selecionarHorarioHome('Ter 06/Mai','08:30',this)">08:30</button>
              <button class="horario-btn ocupado" disabled title="Horário ocupado">10:00</button>
              <button class="horario-btn" onclick="selecionarHorarioHome('Ter 06/Mai','13:00',this)">13:00</button>
              <button class="horario-btn" onclick="selecionarHorarioHome('Ter 06/Mai','16:30',this)">16:30</button>
            </div>
          </div>
          <div class="horario-grupo">
            <div class="horario-dia">Qua, 07 Mai</div>
            <div class="horarios">
              <button class="horario-btn" onclick="selecionarHorarioHome('Qua 07/Mai','09:00',this)">09:00</button>
              <button class="horario-btn" onclick="selecionarHorarioHome('Qua 07/Mai','11:30',this)">11:30</button>
              <button class="horario-btn ocupado" disabled title="Horário ocupado">14:30</button>
              <button class="horario-btn" onclick="selecionarHorarioHome('Qua 07/Mai','17:00',this)">17:00</button>
            </div>
          </div>
        </div>
        <div class="hold-timer hidden" id="holdTimer">
          <div class="hold-info">
            <span>🔒 Horário reservado:</span>
            <strong id="holdHorarioLabel"></strong>
          </div>
          <div class="hold-countdown">
            <span>Tempo para confirmar:</span>
            <strong id="holdCountdown" class="hold-time">10:00</strong>
          </div>
        </div>
        <div class="fila-espera-cta" id="filaEsperaCta">
          <p>Não encontrou o horário ideal?</p>
          <button class="btn btn-light" onclick="abrirFilaEspera()">🔔 Avise-me quando surgir uma desistência</button>
        </div>
        <div class="ag-nav">
          <button class="btn btn-light" onclick="voltarPassoComHold()">← Voltar (libera reserva)</button>
          <button class="btn btn-primary hidden" id="btnAvancarPasso6" onclick="avancarParaConfirmacao()">Continuar
            →</button>
        </div>
      </div>
      <!-- PASSO 6 -->
      <div class="ag-step hidden" id="agStep6">
        <h3>Passo 6 — Confirmação final</h3>
        <div class="resumo-agendamento" id="resumoAgendamento"></div>
        <div id="prepExameBox" class="exam-prep hidden view-style-011">
          <strong>⚠ Instruções de preparo:</strong>
          <ul id="prepExameLista"></ul>
        </div>
        <div class="confirmacao-aviso">
          <p>✅ Você receberá confirmação por <strong>WhatsApp e e-mail</strong> (RB-411).</p>
          <p>📅 Lembretes <strong>24h e 2h</strong> antes da consulta (RB-420).</p>
          <p>🔒 Dados protegidos conforme a <strong>LGPD</strong>.</p>
        </div>
        <div class="ag-nav">
          <button class="btn btn-light" onclick="voltarPassoComHold()">← Voltar (libera reserva)</button>
          <button class="btn btn-primary btn-big" onclick="confirmarAgendamentoFinal()">✅ Confirmar agendamento</button>
        </div>
      </div>
      <!-- SUCESSO -->
      <div class="ag-step hidden" id="agStepSucesso">
        <div class="agendamento-sucesso">
          <div class="sucesso-icon">✅</div>
          <h3>Agendamento confirmado!</h3>
          <div id="sucessoResumo" class="resumo-agendamento"></div>
          <p>Confirmação enviada por WhatsApp. O agendamento aparece no histórico da <strong>Área do Paciente</strong>.
          </p>
          <div class="sucesso-actions">
            <button class="btn btn-primary" onclick="fecharModal('modalAgendamento')">Fechar</button>
            <button class="btn btn-light" onclick="novoAgendamento()">Novo agendamento</button>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- MODAL FILA DE ESPERA -->
  <div class="modal-overlay" id="modalFilaEspera">
    <div class="modal-card modal-form-card">
      <button class="modal-close" onclick="fecharModal('modalFilaEspera')">×</button>
      <div class="modal-header-icon">⏳</div>
      <h3>Entrar na fila de espera</h3>
      <p>Quando surgir uma desistência, você será notificado por <strong>WhatsApp + SMS</strong> e terá <strong>30
          minutos</strong> para confirmar (RB-242/243).</p>
      <div id="filaResumo" class="resumo-agendamento view-style-011"></div>
      <div class="form-group">
        <label>Seu WhatsApp para notificação *</label>
        <input id="filaWhatsapp" type="text" placeholder="(11) 99999-9999" maxlength="15"
          oninput="mascararTelefone(this)" />
      </div>
      <button class="btn btn-primary btn-full" onclick="confirmarFilaEspera()">🔔 Entrar na fila</button>
    </div>
  </div>
  <!-- MODAL AVALIAÇÃO -->
  <div class="modal-overlay" id="modalAvaliacao">
    <div class="modal-card modal-form-card">
      <button class="modal-close" onclick="fecharModal('modalAvaliacao')">×</button>
      <div class="modal-header-icon">⭐</div>
      <h3>Avaliar consulta</h3>
      <p>Avaliação anônima. A nota numérica é sempre salva; o comentário só é publicado com seu consentimento
        (RB-472/473).</p>
      <div class="avaliacao-item">
        <label>Nota do médico *</label>
        <div class="estrelas" id="estrelasMedico" data-campo="medico"></div>
      </div>
      <div class="avaliacao-item">
        <label>Nota da recepção/unidade *</label>
        <div class="estrelas" id="estrelasRecepcao" data-campo="recepcao"></div>
      </div>
      <div class="avaliacao-item">
        <label>Nota do agendamento online *</label>
        <div class="estrelas" id="estrelasAgendamento" data-campo="agendamento"></div>
      </div>
      <div class="avaliacao-item">
        <label>NPS: Você indicaria a NeuroLab? * <small class="view-style-054">(0–10 — interno, não publicado —
            RB-493)</small></label>
        <div class="nps-scale" id="npsScale"></div>
      </div>
      <div class="form-group">
        <label>Comentário <small>(opcional, máx. 500 caracteres)</small></label>
        <textarea id="avaliacaoComentario" rows="3" maxlength="500" placeholder="Conte como foi sua experiência..."
          oninput="atualizarCharCount()"></textarea>
        <small id="charCount">0 / 500</small>
      </div>
      <div class="form-group checkbox-group">
        <label class="checkbox-label">
          <input type="checkbox" id="consentimentoPublicacao" onchange="verificarAvaliacao()" />
          <span>Autorizo a publicação anônima do meu comentário no perfil do médico e/ou da unidade.</span>
        </label>
        <small class="view-style-052">Desmarcado por padrão (LGPD — RB-471). Moderação em até 48h antes da
          publicação (RB-611).</small>
      </div>
      <span class="field-hint" id="avaliacaoHint"></span>
      <button class="btn btn-primary btn-full" id="btnEnviarAvaliacao" onclick="enviarAvaliacao()" disabled>Enviar
        avaliação</button>
    </div>
  </div>
  `;
})();
