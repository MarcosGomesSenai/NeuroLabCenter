# Relatório de testes dos fluxos — NeuroLab Center

Este relatório registra a validação feita antes da apresentação.

## Testes executados

- Abertura de todas as páginas HTML do site.
- Verificação de caminhos internos de CSS, JavaScript e imagens.
- Verificação de `@import` e `url(...)` nos arquivos CSS.
- Verificação de sintaxe de todos os JavaScripts com `node --check`.
- Verificação de sintaxe/importação Python com `compileall` e importação do Flask app.
- Listagem das rotas Flask registradas.
- Execução dos testes automatizados do servidor com `pytest`.
- Execução dos testes do microserviço do chatbot com `npm test`.
- Teste visual automatizado dos principais fluxos do front-end com Playwright, usando API simulada.

## Fluxos de interface validados

- Home carregando sem erro de JavaScript.
- Modal de login abrindo corretamente.
- Fluxo de login em duas etapas: CPF e senha.
- Modal de cadastro abrindo corretamente.
- Cadastro adulto com campos obrigatórios.
- Modal de recuperação de senha.
- Página de agendamento carregando sem erro.
- Etapas do agendamento: tipo, cobertura, unidade, médico, horário, confirmação e sucesso.
- Área do Paciente carregando sem erro de JavaScript.
- Renderização do painel do paciente.
- Página de teleconsulta carregando sem erro.
- Chatbot/triagem iniciando sem erro.
- Navegação interna entre páginas.

## Correções aplicadas durante os testes

1. Corrigido import quebrado no backend:
   - Antes: `servidor.servicos.auth`
   - Depois: `servidor.servicos.autenticacao`

2. Corrigida compatibilidade de funções internas usadas por avaliações:
   - `_get_appointment`
   - `_insert_event`
   - `_to_time`
   - `_validate_owner_or_responsible`

3. Corrigido teste de caminhos dos arquivos locais no Pytest.
   - O teste usava `urljoin` de forma inadequada para caminhos relativos como `../../recursos/...`.
   - Agora resolve corretamente a partir da pasta do HTML.

## Resultado final

- JavaScript: sem erro de sintaxe.
- Python: sem erro de sintaxe.
- Flask app: importa corretamente.
- Rotas Flask: registradas corretamente.
- Caminhos locais: sem arquivos quebrados.
- Testes Pytest: 1 passou e 2 foram pulados apenas porque o ambiente de teste não possui MySQL ligado.
- Testes do chatbot: 3 passaram.
- Testes visuais simulados: passaram.

## Observação importante

Os dois testes completos do backend que usam banco foram pulados porque o ambiente de teste não possui MySQL/XAMPP rodando. Isso não significa erro no código. No computador de apresentação, com o MySQL ligado e o banco criado, rode:

```bash
python -m servidor.banco_de_dados.criar_banco
python -m pytest -q servidor/testes/testes_fluxos_principais.py servidor/testes/test_banco_e_apresentacao.py
```

Para o chatbot, rode:

```bash
cd api-do-chatbot
npm install
npm test
```


## Revisão adicional de banco e apresentação

Correções aplicadas nesta revisão:

- `site/paginas/agendamento.html` agora carrega `recursos/scripts/area-paciente/avaliacoes.js`, necessário para os botões da fila de espera.
- `scripts/run-tests.ps1` foi atualizado para a estrutura atual em PT-BR: `servidor`, `servidor\testes` e `api-do-chatbot`.
- `servidor/banco_de_dados/dados_iniciais.sql` agora cria uma conta administrativa de teste para apresentação.
- `servidor/banco_de_dados/criar_banco.py` passou a validar mais colunas reais usadas pelo backend.
- Foram adicionadas garantias de compatibilidade para bancos MySQL antigos que ainda não possuem todas as colunas de `agendamentos`.

Conta administrativa de teste:

- CPF: `90000000094`
- E-mail: `admin@neurolabcenter.com.br`
- Senha: `Senha123`

Observação: para testar fluxos reais de banco, o MySQL/XAMPP precisa estar ligado e o comando `python -m servidor.banco_de_dados.criar_banco` deve ser executado antes do Flask.


## Resultado da revisão de banco

Nesta revisão adicional foram executados testes estáticos do banco e dos fluxos de apresentação.

Resultado local:

- Pytest: 5 testes passaram e 2 foram pulados por falta de MySQL no ambiente.
- Seed do banco: nenhuma coluna inexistente encontrada nos INSERTs.
- Schema principal: 22 tabelas identificadas.
- Conta admin de apresentação: validada no arquivo de dados iniciais.
- Script de testes: atualizado para a estrutura atual do projeto.

Comando recomendado para validação no computador da apresentação:

```bash
python -m pytest -q servidor/testes/testes_fluxos_principais.py servidor/testes/test_banco_e_apresentacao.py
```
