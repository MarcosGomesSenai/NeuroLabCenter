# API do projeto

A API principal fica em `servidor/` e usa Flask + MySQL.

## Rotas principais

```text
servidor/routes/auth.py
servidor/routes/agendamentos.py
servidor/routes/catalog.py
servidor/routes/pacientes.py
servidor/routes/portal.py
servidor/routes/feedback.py
servidor/routes/fila.py
servidor/routes/usuarios.py
```

## Fluxo básico

```text
HTML -> recursos/scripts/api-do-servidor.js -> backend Flask -> MySQL
```

## Chat IA opcional

A pasta `api-do-chatbot/` contém um microserviço Node.js separado. Ele foi mantido fora do backend Flask porque o chat é complementar e não deve confundir a API clínica principal.
