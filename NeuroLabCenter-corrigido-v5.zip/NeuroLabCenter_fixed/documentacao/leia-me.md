# Documentação

Documentação central do NeuroLab Center.

Arquivos principais:

- `INSTALACAO.md`: como instalar e rodar.
- `ESTRUTURA.md`: explicação das pastas.
- `BANCO_DE_DADOS.md`: explicação do MySQL.
- `API.md`: rotas e integração.
- `GUIA_DE_APRESENTACAO.md`: roteiro para apresentar.
- `MANUTENCAO.md`: onde mexer no projeto.
- `RELATORIO_DE_REORGANIZACAO.md`: mudanças feitas na limpeza.
