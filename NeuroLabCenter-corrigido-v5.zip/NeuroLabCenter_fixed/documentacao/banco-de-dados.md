# Banco de dados

O banco principal do projeto é MySQL.

Arquivos principais:

```text
servidor/banco_de_dados/estrutura.sql
servidor/banco_de_dados/dados_iniciais.sql
servidor/database/connection.py
servidor/banco_de_dados/criar_banco.py
```

## Responsabilidade dos arquivos

- `estrutura.sql`: cria o banco e todas as tabelas principais.
- `dados_iniciais.sql`: insere dados de teste para apresentação.
- `connection.py`: centraliza a conexão com MySQL.
- `init_db.py`: executa o schema e o seed automaticamente.

## Tabelas principais

- `usuarios`
- `pacientes`
- `medicos`
- `agendamentos`
- `unidades`
- `convenios`
- `exames`
- `documentos_paciente`
- `feedback_geral`
- `fila_espera`
- `notificacoes`

## Credenciais de teste

Senha padrão dos usuários do seed: `Senha123`.

CPFs úteis:

- Responsável: `12345678909`
- Paciente dependente: `98765432100`
- Médica: `11144477735`
