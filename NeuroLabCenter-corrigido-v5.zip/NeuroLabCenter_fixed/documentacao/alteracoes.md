# Changelog

## Versão reorganizada para manutenção

- Projeto renomeado internamente para `NeuroLabCenter`.
- CSS dividido em pastas por responsabilidade: `core`, `layout`, `components`, `paginas`, `responsive` e `overrides`.
- Área do Paciente separada em módulos menores dentro de `recursos/scripts/paginas/paciente/`.
- Mantido `recursos/estilos/estilos-do-site.css` como entrada única para simplificar o HTML.
- Removidos arquivos gigantes gerados pela consolidação anterior.
- Criado `documentacao/MANUTENCAO.md` com orientação de manutenção.
