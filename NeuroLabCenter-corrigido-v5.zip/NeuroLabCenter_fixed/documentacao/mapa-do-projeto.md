# Mapa do projeto

Este arquivo serve para você abrir o VS Code e entender onde mexer sem ficar perdido.

## Pastas principais

```text
site/paginas/             -> telas HTML abertas no navegador
recursos/estilos/         -> visual do site
recursos/scripts/         -> funcionamento do front-end
recursos/imagens/         -> imagens usadas no site
servidor/                 -> API Flask e banco MySQL
api-do-chatbot/           -> API Node do chatbot
documentacao/             -> explicações do projeto
```

## Onde mexer no visual

```text
recursos/estilos/base/                -> cores, reset, fontes e utilitários
recursos/estilos/componentes/         -> botões, cards, formulários, modais e menu
recursos/estilos/layout/              -> cabeçalho, layout geral e seções da home
recursos/estilos/paginas/             -> páginas públicas, catálogos e área do paciente
recursos/estilos/paginas/agendamento/ -> tela de agendamento
recursos/estilos/responsivo/          -> adaptação para celular e telas menores
recursos/estilos/correcoes-visuais/   -> ajustes finais de aparência
```

O arquivo `recursos/estilos/estilos-do-site.css` é só a entrada dos estilos. Ele não deve receber regras grandes; ele apenas importa os outros arquivos.

## Onde mexer no JavaScript

```text
recursos/scripts/configuracoes.js       -> configurações usadas no front-end
recursos/scripts/api-do-servidor.js     -> chamadas para a API Flask
recursos/scripts/autenticacao.js        -> login, cadastro e sessão
recursos/scripts/agendamento.js         -> fluxo de agendamento
recursos/scripts/chatbot.js             -> integração com chatbot
recursos/scripts/comum/                 -> funções reaproveitadas em várias páginas
recursos/scripts/home/                  -> comportamentos da página inicial
recursos/scripts/area-paciente/         -> painel e dados da área do paciente
```

## Onde mexer no servidor

```text
servidor/app.py                         -> entrada da API Flask
servidor/configuracao.py                -> configurações gerais
servidor/rotas/                         -> endpoints HTTP
servidor/servicos/                      -> regras de negócio
servidor/banco_de_dados/                -> conexão, estrutura e dados iniciais MySQL
servidor/utilitarios/                   -> validações, CPF, datas, segurança e respostas
```

## Regra de nomes

Os nomes foram deixados em português e sem prefixos como `01-`, `02-`, `part-01` ou `section-01`. A ideia é que o nome do arquivo já explique sua função.
