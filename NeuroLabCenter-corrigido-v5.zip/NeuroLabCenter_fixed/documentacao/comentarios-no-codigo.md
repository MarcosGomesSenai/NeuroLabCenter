# Comentários no código

Esta versão recebeu comentários extras nos arquivos de código para facilitar leitura, apresentação e manutenção.

## Como os comentários foram distribuídos

- **HTML:** comentários em cabeçalho, corpo, seções, formulários, scripts, imagens e links de estilos.
- **CSS:** comentários em imports, seletores, media queries e blocos visuais importantes.
- **JavaScript:** comentários em funções, classes, eventos, validações, blocos protegidos e configurações.
- **Python/Flask:** comentários em funções, classes, decisões, retornos, tratamento de erros e laços.
- **SQL:** comentários em criação de tabelas, inserts e alterações estruturais.
- **PowerShell:** comentários em etapas de execução do script.

## Regra de manutenção

Ao alterar um arquivo, mantenha os comentários que explicam o objetivo do bloco. Se o código mudar de responsabilidade, atualize também o comentário para não deixar informação falsa.

## Observação importante

Arquivos JSON, como `package.json`, não receberam comentários porque JSON puro não aceita comentários. Colocar comentários neles quebraria o projeto.
