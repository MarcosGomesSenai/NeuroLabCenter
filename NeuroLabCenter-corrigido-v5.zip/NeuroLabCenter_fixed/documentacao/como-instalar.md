# Como instalar e rodar

## 1. Instalar dependências Python

```bash
python -m pip install -r servidor/requirements.txt
```

## 2. Criar banco MySQL

Ligue o MySQL pelo XAMPP ou MySQL Workbench e execute:

```bash
python -m servidor.banco_de_dados.criar_banco
```

## 3. Rodar API Flask

```bash
python -m servidor.app
```

A API deve iniciar em:

```text
http://localhost:5000
```

## 4. Abrir o site

Abra o arquivo:

```text
index.html
```

Ele redireciona para `site/paginas/index.html`.
