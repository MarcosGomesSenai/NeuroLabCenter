# Guia de manutenção

## Regras principais

1. Mantenha cada arquivo com até 500 linhas sempre que possível.
2. O limite máximo tolerado é 550 linhas.
3. Não crie arquivos com nomes genéricos como `parte1`, `teste`, `novo`, `final` ou `ajuste2`.
4. Use nomes que expliquem a função do arquivo.
5. Antes de remover um arquivo, pesquise se ele aparece em HTML, CSS, JS ou Python.

## Como testar depois de mexer

```bash
python -m compileall servidor
```

Para o JavaScript, rode dentro do projeto:

```bash
node --check recursos/scripts/api-do-servidor.js
```

Para testar todos os scripts JS, você pode repetir o comando nos arquivos de `recursos/scripts/`.

## Como saber onde mexer

- Mudou aparência? Procure em `recursos/estilos/`.
- Mudou botão, card ou modal? Procure em `recursos/estilos/componentes/`.
- Mudou agendamento? Procure em `recursos/scripts/agendamento.js` e `recursos/estilos/paginas/agendamento/`.
- Mudou área do paciente? Procure em `recursos/scripts/area-paciente/`.
- Mudou banco/API? Procure em `servidor/`.
