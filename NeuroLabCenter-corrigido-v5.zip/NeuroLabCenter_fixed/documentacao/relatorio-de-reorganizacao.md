# Relatório de reorganização

## Objetivo

Deixar o projeto mais fácil de entender no VS Code, com nomes em português, comentários úteis e sem arquivos gigantes.

## Mudanças principais

- A pasta antiga do servidor foi renomeada para `servidor/`.
- `database/` virou `banco_de_dados/`.
- `routes/` virou `rotas/`.
- `services/` virou `servicos/`.
- `utils/` virou `utilitarios/`.
- A pasta do chatbot virou `api-do-chatbot/`.
- A pasta de scripts compartilhados virou `recursos/scripts/comum/`.
- A pasta da área do paciente virou `recursos/scripts/area-paciente/`.
- Os nomes genéricos e numéricos foram removidos.
- Os arquivos principais receberam comentários explicando responsabilidade, uso e manutenção.

## Validação

```json
{
  "arquivos_totais": 166,
  "contagem_por_extensao": {
    ".css": 39,
    ".example": 1,
    ".html": 14,
    ".jpg": 3,
    ".js": 40,
    ".json": 2,
    ".md": 10,
    ".png": 1,
    ".ps1": 1,
    ".py": 47,
    ".sql": 2,
    ".txt": 3,
    ".webp": 1,
    "[sem_extensao]": 2
  },
  "limite_linhas": "todos os arquivos de texto <= 550 linhas",
  "python_compileall": true,
  "javascript_node_check": true,
  "referencias_html_css_imagens": "ok",
  "sem_prefixos_numericos": true,
  "sem_referencias_antigas": true,
  "erros": []
}
```

## Como rodar

```bash
python -m pip install -r servidor/requirements.txt
python -m servidor.banco_de_dados.criar_banco
python -m servidor.app
```
