# Roteiro de apresentação

## 1. Apresentação do problema

O NeuroLab Center simula uma clínica neurológica com agendamento online, área do paciente, exames, unidades, feedback e integração com MySQL.

## 2. Estrutura do projeto

Mostre rapidamente:

- `site/paginas/`: telas do sistema.
- `recursos/estilos/`: visual do site.
- `recursos/scripts/`: comportamento e integração com API.
- `servidor/`: API Flask.
- `servidor/database/`: banco MySQL.
- `documentacao/`: documentação final.

## 3. Funcionalidades principais

- Cadastro e login.
- Agendamento de consulta.
- Área do paciente.
- Consulta de unidades, médicos, exames e convênios.
- Feedback e fila de espera.
- Dados armazenados no MySQL.

## 4. Pontos técnicos para destacar

- Projeto separado em site, backend e banco.
- MySQL como banco principal.
- CSS e JS consolidados para facilitar manutenção.
- Documentação reduzida e objetiva.

## 5. Fechamento

Explique que a reorganização removeu excesso de arquivos pequenos e documentação repetida, deixando o projeto mais simples de defender na apresentação.
