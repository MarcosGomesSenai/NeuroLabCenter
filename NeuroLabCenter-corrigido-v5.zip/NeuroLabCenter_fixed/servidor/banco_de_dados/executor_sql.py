"""
Arquivo: servidor/banco_de_dados/executor_sql.py

Objetivo:
    Implementar uma parte do servidor Flask do NeuroLab Center.

Como manter:
    Leia os comentários antes de alterar regras de negócio, rotas ou acesso ao banco.
    Preserve nomes em português e imports do pacote servidor.

Observação:
    Comentários foram adicionados para facilitar apresentação e manutenção.
"""

"""
NeuroLab Center - servidor/banco_de_dados/executor_sql.py

Responsabilidade:
    Banco de dados MySQL: conexão, criação do schema e execução de consultas.

Usado por:
    servidor/app.py ou outros módulos do pacote servidor.

Manutenção:
    Este comentário foi adicionado para facilitar leitura em apresentação e manutenção.
    Preserve os imports atualizados para o pacote `servidor`.
"""

from servidor.banco_de_dados.conexao import db_cursor


# Função query_one: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def query_one(query, params=None):
    with db_cursor() as cursor:
        cursor.execute(query, params or ())
        # Retorno padronizado para quem chamou esta função.
        return cursor.fetchone()


# Função query_all: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def query_all(query, params=None):
    with db_cursor() as cursor:
        cursor.execute(query, params or ())
        # Retorno padronizado para quem chamou esta função.
        return cursor.fetchall()


# Função execute_query: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def execute_query(query, params=None):
    with db_cursor(commit=True) as cursor:
        cursor.execute(query, params or ())
        # Retorno padronizado para quem chamou esta função.
        return cursor.lastrowid


# Função execute_many: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def execute_many(query, values):
    with db_cursor(commit=True) as cursor:
        cursor.executemany(query, values)
        # Retorno padronizado para quem chamou esta função.
        return cursor.rowcount
