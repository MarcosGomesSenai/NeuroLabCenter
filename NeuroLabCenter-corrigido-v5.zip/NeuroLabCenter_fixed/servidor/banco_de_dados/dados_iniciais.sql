-- ============================================================================
-- Arquivo: servidor/banco_de_dados/dados_iniciais.sql
-- Objetivo: comandos SQL usados pelo banco de dados MySQL do NeuroLab Center.
-- Como manter: altere tabelas e dados iniciais com cuidado para não quebrar o backend.
-- ============================================================================

-- NeuroLab Center - servidor/banco_de_dados/dados_iniciais.sql
-- Responsabilidade: Banco de dados MySQL: conexão, criação do schema e execução de consultas.
-- Manutenção: execute pelo MySQL Workbench ou por python -m servidor.banco_de_dados.criar_banco.

-- NeuroLab Center — documentação do script SQL
--
-- Arquivo: servidor/banco_de_dados/dados_iniciais.sql
--
-- Por que este arquivo existe:
-- Este script mantém a estrutura ou os dados do MySQL versionados junto do projeto,
-- evitando depender de criação manual sem registro durante a apresentação.

USE neurolabcenter;

INSERT IGNORE INTO usuarios (cpf, nome, telefone, email, senha_hash, tipo_usuario)
VALUES
('12345678909', 'Marcos Silva', '11912345678', 'marcos@exemplo.com', '$2b$12$TvJ9PKJzKNAtixMmgh8VwemlrTWUN93oMHX9WEGnq2ZWDc2a35KnO', 'responsavel'),
('98765432100', 'Pedro Silva', '11912345679', 'pedro@exemplo.com', '$2b$12$TvJ9PKJzKNAtixMmgh8VwemlrTWUN93oMHX9WEGnq2ZWDc2a35KnO', 'paciente'),
('11144477735', 'Dra. Ana Beatriz Ferreira', '(11) 4002-8922', 'ana@neurolabcenter.com.br', '$2b$12$TvJ9PKJzKNAtixMmgh8VwemlrTWUN93oMHX9WEGnq2ZWDc2a35KnO', 'medico'),
('52998224725', 'Dr. Carlos Eduardo Moura', '(11) 4002-8922', 'carlos@neurolabcenter.com.br', '$2b$12$TvJ9PKJzKNAtixMmgh8VwemlrTWUN93oMHX9WEGnq2ZWDc2a35KnO', 'medico');


-- Conta administrativa de teste para a apresentação.
-- Senha padrão: Senha123
INSERT IGNORE INTO usuarios (cpf, nome, telefone, email, senha_hash, tipo_usuario)
VALUES
('90000000094', 'Administrador NeuroLab', '(11) 4002-8922', 'admin@neurolabcenter.com.br', '$2b$12$TvJ9PKJzKNAtixMmgh8VwemlrTWUN93oMHX9WEGnq2ZWDc2a35KnO', 'admin');

INSERT IGNORE INTO pacientes (cpf, nome, data_nascimento, cpf_responsavel)
VALUES
('12345678909', 'Marcos Silva', '1988-06-10', NULL),
('98765432100', 'Pedro Silva', '2017-03-14', '12345678909');

INSERT IGNORE INTO unidades (id, nome, endereco, cidade, cep, telefone, horario_ini, horario_fim, aceita_sus, ativo)
VALUES
(1, 'NeuroLabCenter Santo Andre', 'R. Amazonas, 48 - Centro', 'Santo Andre', '09000000', '(11) 4002-8922', '07:00:00', '19:00:00', TRUE, TRUE),
(2, 'NeuroLabCenter Sao Bernardo', 'Av. Kennedy, 303 - Jardim do Mar', 'Sao Bernardo do Campo', '09726000', '(11) 4002-8923', '08:00:00', '18:00:00', FALSE, TRUE),
(3, 'Teleconsulta NeuroLab', 'Atendimento online', 'Online', '00000000', '(11) 4002-8922', '07:00:00', '21:00:00', FALSE, TRUE);

INSERT IGNORE INTO convenios (id, nome, ativo)
VALUES
(1, 'Unimed', TRUE),
(2, 'Bradesco Saude', TRUE),
(3, 'SulAmerica', TRUE),
(4, 'Amil', TRUE);

INSERT IGNORE INTO unidades_convenios (id_unidade, id_convenio)
VALUES
(1, 1), (1, 2), (1, 3), (1, 4),
(2, 1), (2, 2),
(3, 1), (3, 2), (3, 3), (3, 4);

INSERT IGNORE INTO exames (id, nome, descricao, preparo_recomendado, duracao_minutos, ativo)
VALUES
(1, 'Eletroencefalograma', 'Exame EEG para avaliacao de atividade cerebral.', 'Cabelos limpos e secos, sem gel ou creme.', 40, TRUE),
(2, 'Eletroneuromiografia', 'Avaliacao neurofisiologica de nervos e musculos.', 'Evitar cremes na pele no dia do exame.', 60, TRUE),
(3, 'Polissonografia', 'Exame do sono.', 'Seguir rotina habitual de sono e levar itens pessoais.', 480, TRUE);

INSERT IGNORE INTO medicos (id, id_usuario, crm, especialidade)
SELECT 1, id, 'CRM/SP 84201', 'Neurologia Geral e Epilepsia'
  FROM usuarios
 WHERE cpf = '11144477735';

INSERT IGNORE INTO medicos (id, id_usuario, crm, especialidade)
SELECT 2, id, 'CRM/SP 67453', 'Sono e Cognicao'
  FROM usuarios
 WHERE cpf = '52998224725';

INSERT IGNORE INTO medicos_unidades (id_medico, id_unidade, aceita_particular, aceita_convenio, aceita_sus, aceita_teleconsulta, ativo)
VALUES
-- Medicos 1 e 2 (Ana Beatriz e Carlos Eduardo) — unidades iniciais
(1, 1, TRUE, TRUE, TRUE,  TRUE,  TRUE),
(1, 3, TRUE, TRUE, FALSE, TRUE,  TRUE),
(2, 1, TRUE, TRUE, FALSE, TRUE,  TRUE),
(2, 2, TRUE, TRUE, FALSE, FALSE, TRUE),
(2, 3, TRUE, TRUE, FALSE, TRUE,  TRUE);

INSERT IGNORE INTO agendamentos (
    id, id_paciente, id_medico, id_unidade, id_convenio, id_exame,
    data_consulta, hora_consulta, tipo_consulta, tipo_atendimento,
    status, observacao, cpf_responsavel_confirmacao, confirmado_em
)
SELECT
    1, p.id, 1, 1, NULL, NULL,
    DATE_SUB(CURDATE(), INTERVAL 7 DAY), '10:00:00', 'consulta', 'particular',
    'confirmado', 'Consulta confirmada para exemplo de feedback.', p.cpf_responsavel, DATE_SUB(NOW(), INTERVAL 7 DAY)
  FROM pacientes p
 WHERE p.cpf = '98765432100';

INSERT IGNORE INTO agendamentos (
    id, id_paciente, id_medico, id_unidade, id_convenio, id_exame,
    data_consulta, hora_consulta, tipo_consulta, tipo_atendimento,
    status, observacao, cpf_responsavel_confirmacao, confirmacao_token, confirmacao_expira_em
)
SELECT
    2, p.id, 1, 1, NULL, 1,
    DATE_ADD(CURDATE(), INTERVAL 7 DAY), '11:00:00', 'exame', 'particular',
    'pendente', 'Exame pendente aguardando confirmacao do responsavel.', p.cpf_responsavel,
    '00000000-0000-0000-0000-000000000001', DATE_ADD(NOW(), INTERVAL 12 HOUR)
  FROM pacientes p
 WHERE p.cpf = '98765432100';

INSERT IGNORE INTO agendamento_eventos (id, id_agendamento, tipo_evento, cpf_autor, detalhe)
VALUES
(1, 1, 'criado', '98765432100', 'status=confirmado'),
(2, 1, 'confirmado', '12345678909', 'confirmado pelo responsavel'),
(3, 2, 'criado', '98765432100', 'status=pendente');

INSERT IGNORE INTO feedback (id_agendamento, nota, comentario)
VALUES
(1, 5, 'Otimo atendimento.');

INSERT IGNORE INTO agendamento_eventos (id, id_agendamento, tipo_evento, cpf_autor, detalhe)
VALUES
(4, 1, 'feedback', '98765432100', 'nota=5');

-- Sincronizacao do catalogo do front-end com o MySQL oficial
UPDATE unidades SET nome = 'Santo André - Centro', endereco = 'R. Amazonas, 48 - Centro, Santo André - SP', cidade = 'Santo André', cep = '09000000' WHERE id = 1;
UPDATE unidades SET nome = 'São Bernardo - Jardim do Mar', endereco = 'Av. Kennedy, 303 - Jardim do Mar, São Bernardo do Campo - SP', cidade = 'São Bernardo do Campo', cep = '09726000' WHERE id = 2;
UPDATE unidades SET nome = 'Teleconsulta NeuroLab', endereco = 'Atendimento online', cidade = 'Online', cep = '00000000' WHERE id = 3;

INSERT IGNORE INTO unidades (id, nome, endereco, cidade, cep, telefone, horario_ini, horario_fim, aceita_sus, ativo)
VALUES
(4, 'Santo André - Vila Pires', 'R. Senador Fláquer, 512 - Vila Pires, Santo André - SP', 'Santo André', '09195000', '(11) 4002-8924', '08:00:00', '18:00:00', FALSE, TRUE),
(5, 'Moema - Neurodiagnóstico', 'Av. Ibirapuera, 2120 - Moema, São Paulo - SP', 'São Paulo', '04028001', '(11) 4002-8925', '07:00:00', '19:00:00', FALSE, TRUE),
(6, 'Tatuapé - Neuropediatria', 'R. Itapura, 986 - Tatuapé, São Paulo - SP', 'São Paulo', '03310000', '(11) 4002-8926', '08:00:00', '18:00:00', FALSE, TRUE),
(7, 'Paulista - Sono e Cognição', 'Av. Paulista, 171 - Bela Vista, São Paulo - SP', 'São Paulo', '01311000', '(11) 4002-8927', '07:00:00', '19:00:00', FALSE, TRUE);

UPDATE convenios SET nome = 'Bradesco Saúde' WHERE id = 2;
UPDATE convenios SET nome = 'SulAmérica' WHERE id = 3;
INSERT IGNORE INTO convenios (id, nome, ativo)
VALUES
(5, 'Porto Seguro Saúde', TRUE),
(6, 'NotreDame Intermédica', TRUE),
(7, 'Care Plus', TRUE),
(8, 'Omint', TRUE),
(9, 'Golden Cross', TRUE),
(10, 'Alice', TRUE),
(11, 'Prevent Senior', TRUE),
(12, 'Sompo Saúde', TRUE),
(13, 'Mediservice', TRUE),
(14, 'Cassi', TRUE);

INSERT IGNORE INTO unidades_convenios (id_unidade, id_convenio)
VALUES
(4,1),(4,2),(4,3),(4,4),(4,5),
(5,1),(5,2),(5,3),(5,4),(5,5),(5,8),(5,12),(5,14),
(6,1),(6,4),(6,6),(6,7),(6,10),
(7,2),(7,3),(7,7),(7,8),(7,9),(7,11),
-- Convênios extras para unidades 1, 2 e 3 (só podem ser inseridos após convenios 5-14 serem criados)
(1,5),(1,9),(1,11),(1,12),(1,14),
(2,4),(2,6),(2,13),
(3,5),(3,6),(3,7),(3,8),(3,9),(3,10),(3,11),(3,12),(3,13),(3,14);

INSERT IGNORE INTO usuarios (cpf, nome, telefone, email, senha_hash, tipo_usuario)
VALUES
('70000000078', 'Dra. Fernanda Lima Costa', '(11) 4002-8922', 'fernanda@neurolabcenter.com.br', '$2b$12$TvJ9PKJzKNAtixMmgh8VwemlrTWUN93oMHX9WEGnq2ZWDc2a35KnO', 'medico'),
('70000000159', 'Dr. Rafael Nogueira', '(11) 4002-8922', 'rafael@neurolabcenter.com.br', '$2b$12$TvJ9PKJzKNAtixMmgh8VwemlrTWUN93oMHX9WEGnq2ZWDc2a35KnO', 'medico'),
('70000000230', 'Dra. Marina Azevedo Prado', '(11) 4002-8922', 'marina@neurolabcenter.com.br', '$2b$12$TvJ9PKJzKNAtixMmgh8VwemlrTWUN93oMHX9WEGnq2ZWDc2a35KnO', 'medico'),
('70000000310', 'Dr. Henrique Vidal Ramos', '(11) 4002-8922', 'henrique@neurolabcenter.com.br', '$2b$12$TvJ9PKJzKNAtixMmgh8VwemlrTWUN93oMHX9WEGnq2ZWDc2a35KnO', 'medico'),
('70000000400', 'Dra. Laura Martins Sato', '(11) 4002-8922', 'laura@neurolabcenter.com.br', '$2b$12$TvJ9PKJzKNAtixMmgh8VwemlrTWUN93oMHX9WEGnq2ZWDc2a35KnO', 'medico'),
('70000000582', 'Dr. Bruno Paiva Leal', '(11) 4002-8922', 'bruno@neurolabcenter.com.br', '$2b$12$TvJ9PKJzKNAtixMmgh8VwemlrTWUN93oMHX9WEGnq2ZWDc2a35KnO', 'medico');

INSERT IGNORE INTO medicos (id, id_usuario, crm, especialidade)
SELECT 3, id, 'CRM/SP 91077', 'Neuropediatria e desenvolvimento' FROM usuarios WHERE cpf = '70000000078';
INSERT IGNORE INTO medicos (id, id_usuario, crm, especialidade)
SELECT 4, id, 'CRM/SP 76118', 'Exames neurofisiológicos' FROM usuarios WHERE cpf = '70000000159';
INSERT IGNORE INTO medicos (id, id_usuario, crm, especialidade)
SELECT 5, id, 'CRM/SP 102884', 'Cefaleia, enxaqueca e dor neuropática' FROM usuarios WHERE cpf = '70000000230';
INSERT IGNORE INTO medicos (id, id_usuario, crm, especialidade)
SELECT 6, id, 'CRM/SP 73904', 'Memória, cognição e Alzheimer' FROM usuarios WHERE cpf = '70000000310';
INSERT IGNORE INTO medicos (id, id_usuario, crm, especialidade)
SELECT 7, id, 'CRM/SP 88612', 'Neuropediatria e desenvolvimento infantil' FROM usuarios WHERE cpf = '70000000400';
INSERT IGNORE INTO medicos (id, id_usuario, crm, especialidade)
SELECT 8, id, 'CRM/SP 69450', 'Distúrbios do movimento e Parkinson' FROM usuarios WHERE cpf = '70000000582';

INSERT IGNORE INTO medicos_unidades (id_medico, id_unidade, aceita_particular, aceita_convenio, aceita_sus, aceita_teleconsulta, ativo)
VALUES
-- Todos os medicos e suas unidades (INSERT IGNORE evita duplicatas ao re-executar)
(1, 1, TRUE, TRUE, TRUE,  TRUE,  TRUE),
(1, 3, TRUE, TRUE, FALSE, TRUE,  TRUE),
(2, 1, TRUE, TRUE, FALSE, TRUE,  TRUE),
(2, 2, TRUE, TRUE, FALSE, FALSE, TRUE),
(2, 3, TRUE, TRUE, FALSE, TRUE,  TRUE),
(3, 1, TRUE, TRUE, FALSE, FALSE, TRUE),
(3, 2, TRUE, TRUE, FALSE, FALSE, TRUE),
(4, 1, TRUE, TRUE, TRUE,  FALSE, TRUE),
(4, 4, TRUE, TRUE, FALSE, FALSE, TRUE),
(5, 5, TRUE, TRUE, FALSE, TRUE,  TRUE),
(6, 7, TRUE, TRUE, FALSE, TRUE,  TRUE),
(7, 6, TRUE, TRUE, FALSE, FALSE, TRUE),
(7, 1, TRUE, TRUE, FALSE, FALSE, TRUE),
(8, 1, TRUE, TRUE, TRUE,  FALSE, TRUE),
(8, 7, TRUE, TRUE, FALSE, FALSE, TRUE);
