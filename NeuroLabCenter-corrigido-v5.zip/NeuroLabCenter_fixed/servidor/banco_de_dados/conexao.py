"""
Arquivo: servidor/banco_de_dados/conexao.py

Objetivo:
    Implementar uma parte do servidor Flask do NeuroLab Center.

Como manter:
    Leia os comentários antes de alterar regras de negócio, rotas ou acesso ao banco.
    Preserve nomes em português e imports do pacote servidor.

Observação:
    Comentários foram adicionados para facilitar apresentação e manutenção.
"""

"""
NeuroLab Center - servidor/banco_de_dados/conexao.py

Responsabilidade:
    Banco de dados MySQL: conexão, criação do schema e execução de consultas.

Usado por:
    servidor/app.py ou outros módulos do pacote servidor.

Manutenção:
    Este comentário foi adicionado para facilitar leitura em apresentação e manutenção.
    Preserve os imports atualizados para o pacote `servidor`.
"""

from contextlib import contextmanager

import mysql.connector
from mysql.connector import pooling

from servidor.configuracao import Config

_pool = None


# Função database_driver: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def database_driver():
    """Retorna o banco oficial em uso no projeto."""
    return "mysql"


# Função get_pool: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def get_pool():
    global _pool
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if _pool is None:
        # O Flask debug reloader inicializa o processo duas vezes.
        # Se o pool já existir com esse nome, tenta com sufixo único para evitar conflito.
        _pool_name = Config.MYSQL_POOL_NAME
        for tentativa in range(2):
            try:
                _pool = pooling.MySQLConnectionPool(
                    pool_name=_pool_name,
                    pool_size=Config.MYSQL_POOL_SIZE,
                    host=Config.MYSQL_HOST,
                    port=Config.MYSQL_PORT,
                    user=Config.MYSQL_USER,
                    password=Config.MYSQL_PASSWORD,
                    database=Config.MYSQL_DATABASE,
                    autocommit=False,
                )
                break
            except mysql.connector.errors.PoolError as pool_error:
                if "already exists" in str(pool_error).lower() and tentativa == 0:
                    # Pool criado pelo processo pai do reloader — usa nome alternativo.
                    _pool_name = Config.MYSQL_POOL_NAME + "_r"
                else:
                    raise
    # Retorno padronizado para quem chamou esta função.
    return _pool


# Função get_connection: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def get_connection():
    # A conexão é criada por chamada para evitar conexão global presa no processo.
    # Isso deixa o projeto mais previsível em testes, recarregamentos do Flask e uso com MySQL local.
    """Abre conexao MySQL.

    O projeto deve usar somente MySQL. Se o MySQL estiver desligado,
    mal configurado ou sem o banco criado, o erro sobe para a API retornar
    falha em vez de cair silenciosamente para SQLite.
    """
    try:
        # Retorno padronizado para quem chamou esta função.
        return get_pool().get_connection()
    except mysql.connector.Error as error:
        raise RuntimeError(
            "Nao foi possivel conectar ao MySQL. "
            "Verifique se o MySQL/XAMPP esta ligado, se o banco existe e se o .env esta correto. "
            f"Banco configurado: {Config.MYSQL_DATABASE}. Erro original: {error}"
        ) from error


@contextmanager
# Função db_cursor: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def db_cursor(commit=False):
    connection = get_connection()
    cursor = connection.cursor(dictionary=True)
    # Bloco protegido: captura erros previsíveis sem derrubar a API.
    try:
        yield cursor
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if commit:
            connection.commit()
    except Exception:
        connection.rollback()
        raise
    finally:
        cursor.close()
        connection.close()


# Função fetch_one: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def fetch_one(query, params=None):
    with db_cursor() as cursor:
        cursor.execute(query, params or ())
        # Retorno padronizado para quem chamou esta função.
        return cursor.fetchone()


# Função fetch_all: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def fetch_all(query, params=None):
    with db_cursor() as cursor:
        cursor.execute(query, params or ())
        # Retorno padronizado para quem chamou esta função.
        return cursor.fetchall()


# Função execute: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def execute(query, params=None):
    with db_cursor(commit=True) as cursor:
        cursor.execute(query, params or ())
        # Retorno padronizado para quem chamou esta função.
        return cursor.lastrowid
