"""
Arquivo: servidor/banco_de_dados/criar_banco.py

Objetivo:
    Implementar uma parte do servidor Flask do NeuroLab Center.

Como manter:
    Leia os comentários antes de alterar regras de negócio, rotas ou acesso ao banco.
    Preserve nomes em português e imports do pacote servidor.

Observação:
    Comentários foram adicionados para facilitar apresentação e manutenção.
"""

"""
NeuroLab Center - servidor/banco_de_dados/criar_banco.py

Responsabilidade:
    Banco de dados MySQL: conexão, criação do schema e execução de consultas.

Usado por:
    servidor/app.py ou outros módulos do pacote servidor.

Manutenção:
    Este comentário foi adicionado para facilitar leitura em apresentação e manutenção.
    Preserve os imports atualizados para o pacote `servidor`.
"""

# ============================================================================
# Seção consolidada
# ============================================================================
"""
NeuroLab Center — organização modular avançada
Origem: servidor/banco_de_dados/criar_banco.py
Parte 01: executada pelo wrapper para manter compatibilidade de imports.
"""

"""NeuroLab Center — documentação do arquivo

Arquivo: servidor/banco_de_dados/criar_banco.py

Por que este arquivo existe:
    Este módulo foi mantido separado para reduzir acoplamento e facilitar
    a apresentação do projeto. A separação também ajuda a testar e alterar
    uma responsabilidade sem mexer em toda a aplicação.
"""

from pathlib import Path
import re
import sys

# Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
if __package__ in {None, ""}:
    sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import mysql.connector

from servidor.configuracao import Config


# Função _quote_identifier: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def _quote_identifier(identifier):
    """Escapa nomes de banco/tabela usados em comandos DDL.

    MySQL nao aceita parametros bind para identificadores. Por isso, antes de
    interpolar o nome do banco vindo do .env, validamos o formato para evitar
    SQL injection e problemas de sintaxe.
    """
    value = str(identifier or "").strip()
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if not re.fullmatch(r"[A-Za-z0-9_]+", value):
        raise ValueError("MYSQL_DATABASE deve conter apenas letras, numeros e underscore.")
    # Retorno padronizado para quem chamou esta função.
    return f"`{value}`"


# Função _render_sql: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def _render_sql(sql):
    """Aplica o nome do banco configurado no .env aos arquivos SQL.

    Os arquivos .sql continuam executaveis diretamente no MySQL Workbench com o
    banco padrao neurolabcenter, mas o init_db.py respeita MYSQL_DATABASE quando
    o professor/aluno decidir usar outro nome no .env.
    """
    db = _quote_identifier(Config.MYSQL_DATABASE)
    sql = re.sub(r"CREATE\s+DATABASE\s+IF\s+NOT\s+EXISTS\s+`?neurolabcenter`?",
                 f"CREATE DATABASE IF NOT EXISTS {db}", sql, flags=re.IGNORECASE)
    sql = re.sub(r"USE\s+`?neurolabcenter`?\s*;", f"USE {db};", sql, flags=re.IGNORECASE)
    # Retorno padronizado para quem chamou esta função.
    return sql


# Função _run_sql_file: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def _run_sql_file(cursor, path):
    sql = _render_sql(Path(path).read_text(encoding="utf-8"))
    # Laço de repetição: percorre registros ou dados recebidos do sistema.
    for statement in sql.split(";"):
        statement = statement.strip()
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if statement:
            cursor.execute(statement)




# Função _table_exists: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def _table_exists(cursor, table):
    cursor.execute(
        """
        SELECT COUNT(*) AS total
          FROM information_schema.TABLES
         WHERE TABLE_SCHEMA = %s
           AND TABLE_NAME = %s
        """,
        (Config.MYSQL_DATABASE, table),
    )
    row = cursor.fetchone()
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if isinstance(row, dict):
        # Retorno padronizado para quem chamou esta função.
        return bool(row.get("total"))
    # Retorno padronizado para quem chamou esta função.
    return bool(row[0])


# Função _assert_required_schema: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def _assert_required_schema(cursor):
    required = {
        "usuarios": {"id", "cpf", "nome", "telefone", "email", "senha_hash", "tipo_usuario", "data_cadastro", "ativo", "tentativas_login", "bloqueado_ate"},
        "senha_recuperacao_tokens": {"id", "cpf", "token_hash", "criado_em", "expira_em", "usado_em", "ip_solicitante", "user_agent", "ativo"},
        "pacientes": {"id", "cpf", "nome", "foto_perfil", "data_nascimento", "cpf_responsavel", "criado_em", "atualizado_em"},
        "unidades": {"id", "nome", "endereco", "cidade", "cep", "telefone", "horario_ini", "horario_fim", "aceita_sus", "ativo"},
        "convenios": {"id", "nome", "ativo"},
        "unidades_convenios": {"id_unidade", "id_convenio"},
        "exames": {"id", "nome", "descricao", "preparo_recomendado", "duracao_minutos", "ativo"},
        "medicos": {"id", "id_usuario", "crm", "especialidade", "ativo"},
        "medicos_unidades": {"id_medico", "id_unidade", "aceita_particular", "aceita_convenio", "aceita_sus", "aceita_teleconsulta", "ativo"},
        "agendamentos": {"id", "id_paciente", "id_medico", "id_unidade", "id_convenio", "id_exame", "data_consulta", "hora_consulta", "tipo_consulta", "tipo_atendimento", "status", "observacao", "cpf_responsavel_confirmacao", "confirmacao_token", "confirmacao_expira_em", "confirmado_em", "cancelado_em", "reagendamentos_count", "ultimo_reagendamento_em", "criado_em", "atualizado_em", "slot_ativo"},
        "agendamento_eventos": {"id", "id_agendamento", "tipo_evento", "cpf_autor", "detalhe", "criado_em"},
        "feedback": {"id", "id_agendamento", "nota", "comentario", "data_feedback"},
        "conta_familia_vinculos": {"id", "cpf_titular", "cpf_membro", "papel", "criado_em"},
        "documentos_paciente": {"id", "cpf_paciente", "nome_arquivo", "tipo_arquivo", "categoria", "tamanho_kb", "consentimento_lgpd", "status", "conteudo_base64", "criado_em"},
        "preconsulta_paciente": {"cpf_paciente", "sintomas", "medicamentos", "observacoes", "sem_queixas", "consentimento_triagem", "atualizado_em"},
        "formularios_paciente": {"cpf_paciente", "tipo_formulario", "dados_json", "criado_em", "atualizado_em"},
        "preferencias_paciente": {"cpf_paciente", "whatsapp", "email", "sms", "atualizado_em"},
        "exames_paciente": {"id", "cpf_paciente", "nome", "status", "preparo", "data_referencia", "criado_em", "atualizado_em"},
        "feedback_geral": {"id", "cpf_paciente", "nota_medico", "nota_recepcao", "nota_agendamento", "nps", "comentario", "publicar", "moderado", "criado_em"},
        "fila_espera": {"id", "cpf_paciente", "id_medico", "id_unidade", "data_preferida", "hora_preferida", "whatsapp", "observacao", "status", "criado_em", "atualizado_em"},
    }
    missing = []
    # Laço de repetição: percorre registros ou dados recebidos do sistema.
    for table, columns in required.items():
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if not _table_exists(cursor, table):
            missing.append(f"tabela {table}")
            continue
        # Laço de repetição: percorre registros ou dados recebidos do sistema.
        for column in sorted(columns):
            # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
            if not _column_exists(cursor, table, column):
                missing.append(f"{table}.{column}")
    required_indexes = {
        "usuarios": {"uk_usuarios_cpf", "uk_usuarios_email"},
        "agendamentos": {"uk_agendamento"},
        "conta_familia_vinculos": {"uk_familia_titular_membro"},
        "senha_recuperacao_tokens": {"uk_senha_recuperacao_token_hash"},
    }
    # Laço de repetição: percorre registros ou dados recebidos do sistema.
    for table, indexes in required_indexes.items():
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if not _table_exists(cursor, table):
            continue
        # Laço de repetição: percorre registros ou dados recebidos do sistema.
        for index_name in sorted(indexes):
            # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
            if not _index_exists(cursor, table, index_name):
                missing.append(f"indice {table}.{index_name}")

    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if missing:
        raise RuntimeError(
            "Schema MySQL incompleto. Execute servidor/banco_de_dados/criar_banco.py novamente. Faltando: "
            + ", ".join(missing)
        )

# ============================================================================
# Seção consolidada
# ============================================================================
"""
NeuroLab Center — organização modular avançada
Origem: servidor/banco_de_dados/criar_banco.py
Parte 02: executada pelo wrapper para manter compatibilidade de imports.
"""

def _column_exists(cursor, table, column):
    cursor.execute(
        """
        SELECT COUNT(*) AS total
          FROM information_schema.COLUMNS
         WHERE TABLE_SCHEMA = %s
           AND TABLE_NAME = %s
           AND COLUMN_NAME = %s
        """,
        (Config.MYSQL_DATABASE, table, column),
    )
    row = cursor.fetchone()
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if isinstance(row, dict):
        # Retorno padronizado para quem chamou esta função.
        return bool(row.get("total"))
    # Retorno padronizado para quem chamou esta função.
    return bool(row[0])


# Função _add_column_if_missing: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def _add_column_if_missing(cursor, table, column, ddl):
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if not _column_exists(cursor, table, column):
        cursor.execute(f"ALTER TABLE {table} ADD COLUMN {ddl}")


# Função _index_exists: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def _index_exists(cursor, table, index_name):
    cursor.execute(
        """
        SELECT COUNT(*) AS total
          FROM information_schema.STATISTICS
         WHERE TABLE_SCHEMA = %s
           AND TABLE_NAME = %s
           AND INDEX_NAME = %s
        """,
        (Config.MYSQL_DATABASE, table, index_name),
    )
    row = cursor.fetchone()
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if isinstance(row, dict):
        # Retorno padronizado para quem chamou esta função.
        return bool(row.get("total"))
    # Retorno padronizado para quem chamou esta função.
    return bool(row[0])


# Função _add_index_if_missing: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def _add_index_if_missing(cursor, table, index_name, ddl):
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if not _index_exists(cursor, table, index_name):
        cursor.execute(f"ALTER TABLE {table} ADD INDEX {index_name} {ddl}")


# Função _add_unique_index_if_missing: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def _add_unique_index_if_missing(cursor, table, index_name, ddl):
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if not _index_exists(cursor, table, index_name):
        cursor.execute(f"ALTER TABLE {table} ADD UNIQUE KEY {index_name} {ddl}")


# Função _ensure_incremental_columns: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def _ensure_incremental_columns(cursor):
    """Garante colunas novas mesmo se o banco ja existia de uma versao antiga."""
    cursor.execute(f"USE {_quote_identifier(Config.MYSQL_DATABASE)}")

    _add_column_if_missing(cursor, "pacientes", "foto_perfil", "foto_perfil LONGTEXT NULL AFTER nome")

    _add_column_if_missing(
        cursor,
        "documentos_paciente",
        "categoria",
        "categoria VARCHAR(80) NOT NULL DEFAULT 'outros' AFTER tipo_arquivo",
    )
    _add_column_if_missing(
        cursor,
        "documentos_paciente",
        "tamanho_kb",
        "tamanho_kb INT NULL AFTER categoria",
    )
    _add_column_if_missing(
        cursor,
        "documentos_paciente",
        "consentimento_lgpd",
        "consentimento_lgpd BOOLEAN NOT NULL DEFAULT FALSE AFTER tamanho_kb",
    )
    _add_column_if_missing(
        cursor,
        "documentos_paciente",
        "conteudo_base64",
        "conteudo_base64 LONGTEXT NULL AFTER status",
    )
    _add_column_if_missing(
        cursor,
        "documentos_paciente",
        "criado_em",
        "criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP",
    )
    _add_index_if_missing(cursor, "documentos_paciente", "idx_documentos_paciente_cpf", "(cpf_paciente)")
    _add_index_if_missing(cursor, "documentos_paciente", "idx_documentos_paciente_categoria", "(categoria)")

    _add_column_if_missing(
        cursor,
        "preconsulta_paciente",
        "sem_queixas",
        "sem_queixas BOOLEAN NOT NULL DEFAULT FALSE AFTER observacoes",
    )
    _add_column_if_missing(
        cursor,
        "preconsulta_paciente",
        "consentimento_triagem",
        "consentimento_triagem BOOLEAN NOT NULL DEFAULT FALSE AFTER sem_queixas",
    )
    _add_column_if_missing(
        cursor,
        "preconsulta_paciente",
        "atualizado_em",
        "atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP",
    )

    _add_column_if_missing(cursor, "usuarios", "tentativas_login", "tentativas_login INT NOT NULL DEFAULT 0")
    _add_column_if_missing(cursor, "usuarios", "bloqueado_ate", "bloqueado_ate DATETIME NULL")
    _add_index_if_missing(cursor, "usuarios", "idx_usuarios_bloqueado_ate", "(bloqueado_ate)")
    _add_unique_index_if_missing(cursor, "usuarios", "uk_usuarios_email", "(email)")

    # Agendamentos antigos de versões anteriores podem não ter todos os campos usados
    # pelas rotas atuais. Estas colunas mantêm compatibilidade quando o banco já existia.
    _add_column_if_missing(cursor, "agendamentos", "id_convenio", "id_convenio INT NULL AFTER id_unidade")
    _add_column_if_missing(cursor, "agendamentos", "id_exame", "id_exame INT NULL AFTER id_convenio")
    _add_column_if_missing(cursor, "agendamentos", "observacao", "observacao TEXT NULL AFTER status")
    _add_column_if_missing(cursor, "agendamentos", "cpf_responsavel_confirmacao", "cpf_responsavel_confirmacao VARCHAR(11) NULL AFTER observacao")
    _add_column_if_missing(cursor, "agendamentos", "confirmacao_token", "confirmacao_token CHAR(36) NULL AFTER cpf_responsavel_confirmacao")
    _add_column_if_missing(cursor, "agendamentos", "confirmacao_expira_em", "confirmacao_expira_em DATETIME NULL AFTER confirmacao_token")
    _add_column_if_missing(cursor, "agendamentos", "confirmado_em", "confirmado_em DATETIME NULL AFTER confirmacao_expira_em")
    _add_column_if_missing(cursor, "agendamentos", "cancelado_em", "cancelado_em DATETIME NULL AFTER confirmado_em")
    _add_column_if_missing(cursor, "agendamentos", "reagendamentos_count", "reagendamentos_count INT NOT NULL DEFAULT 0 AFTER cancelado_em")
    _add_column_if_missing(cursor, "agendamentos", "ultimo_reagendamento_em", "ultimo_reagendamento_em DATETIME NULL AFTER reagendamentos_count")
    _add_column_if_missing(cursor, "agendamentos", "atualizado_em", "atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    _add_column_if_missing(cursor, "agendamentos", "slot_ativo", "slot_ativo VARCHAR(190) GENERATED ALWAYS AS (CASE WHEN status IN ('pendente', 'confirmado') THEN CONCAT(id_unidade, '-', id_medico, '-', CAST(data_consulta AS CHAR), '-', CAST(hora_consulta AS CHAR)) ELSE NULL END) STORED")
    _add_unique_index_if_missing(cursor, "agendamentos", "uk_agendamento", "(slot_ativo)")
    _add_index_if_missing(cursor, "agendamentos", "idx_agendamentos_confirmacao", "(cpf_responsavel_confirmacao, confirmacao_token)")

# ============================================================================
# Seção consolidada
# ============================================================================
"""
NeuroLab Center — organização modular avançada
Origem: servidor/banco_de_dados/criar_banco.py
Parte 03: executada pelo wrapper para manter compatibilidade de imports.
"""

def init_database(with_seed=True):
    connection = mysql.connector.connect(
        host=Config.MYSQL_HOST,
        port=Config.MYSQL_PORT,
        user=Config.MYSQL_USER,
        password=Config.MYSQL_PASSWORD,
        autocommit=False,
    )
    cursor = connection.cursor(dictionary=True)
    base_dir = Path(__file__).resolve().parent
    # Bloco protegido: captura erros previsíveis sem derrubar a API.
    try:
        # O schema cria a base inicial; migrations aplicam incrementos documentados.
        # Manter essa ordem evita que tabelas novas tentem referenciar tabelas que ainda não existem.
        _run_sql_file(cursor, base_dir / "estrutura.sql")
        _ensure_incremental_columns(cursor)
        _assert_required_schema(cursor)
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if with_seed:
            _run_sql_file(cursor, base_dir / "dados_iniciais.sql")
        connection.commit()
    except Exception:
        connection.rollback()
        raise
    finally:
        cursor.close()
        connection.close()


# Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
if __name__ == "__main__":
    init_database(with_seed=True)
    print("Banco NeuroLab Center inicializado e regras de negocio verificadas.")
