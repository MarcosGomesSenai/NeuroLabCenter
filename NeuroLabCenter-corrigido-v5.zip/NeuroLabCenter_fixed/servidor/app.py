"""
Arquivo: servidor/app.py

Objetivo:
    Implementar uma parte do servidor Flask do NeuroLab Center.

Como manter:
    Leia os comentários antes de alterar regras de negócio, rotas ou acesso ao banco.
    Preserve nomes em português e imports do pacote servidor.

Observação:
    Comentários foram adicionados para facilitar apresentação e manutenção.
"""

"""
NeuroLab Center - servidor/app.py

Responsabilidade:
    Entrada da API Flask. Cria o app, registra rotas e expõe health check.

Usado por:
    servidor/app.py ou outros módulos do pacote servidor.

Manutenção:
    Este comentário foi adicionado para facilitar leitura em apresentação e manutenção.
    Preserve os imports atualizados para o pacote `servidor`.
"""

from pathlib import Path
import sys

# Permite executar com `python servidor/app.py` e também com `python -m servidor.app`.
# Sem este ajuste, imports absolutos podem falhar dependendo de onde o terminal foi aberto.
if __package__ in {None, ""}:
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from flask import Flask, jsonify

from servidor.configuracao import Config
from servidor.rotas import register_routes
from servidor.banco_de_dados.conexao import database_driver, fetch_one
from servidor.utilitarios.erros import BusinessRuleError, NotFoundError, UnauthorizedError


# Função create_app: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def create_app():
    # Factory pattern: centraliza a criação do Flask para facilitar testes.
    # Os testes conseguem importar `app` sem duplicar configuração manual.
    app = Flask(__name__)
    app.config.from_object(Config)

    # As rotas ficam em servidor/routes para que app.py não vire um arquivo gigante.
    register_routes(app, Config.API_PREFIX)

    @app.get("/")
    # Função index: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
    def index():
        # Retorno padronizado para quem chamou esta função.
        return jsonify(
            {
                "name": Config.APP_NAME,
                "status": "online",
                "api_prefix": Config.API_PREFIX,
            }
        )

    @app.get(f"{Config.API_PREFIX}/health")
    # Função health: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
    def health():
        # Health check valida API e banco ao mesmo tempo.
        # Isso ajuda na apresentação: se falhar, o problema provavelmente está no MySQL/configuração.
        try:
            fetch_one("SELECT 1 AS ok")
            driver = database_driver()
            # Retorno padronizado para quem chamou esta função.
            return jsonify({"status": "online", "database": driver, "mysql": driver == "mysql"}), 200
        except Exception as error:
            status = {"status": "degraded", "database": database_driver(), "mysql": False}
            # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
            if app.config.get("DEBUG"):
                status["erro"] = str(error)
            # Retorno padronizado para quem chamou esta função.
            return jsonify(status), 503

    @app.errorhandler(BusinessRuleError)
    # Função handle_business_error: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
    def handle_business_error(error):
        # Regras de negócio geram resposta previsível para o site exibir mensagens claras.
        return jsonify({"erro": str(error), "codigo": error.code}), error.status_code

    @app.errorhandler(NotFoundError)
    # Função handle_not_found: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
    def handle_not_found(error):
        # Retorno padronizado para quem chamou esta função.
        return jsonify({"erro": str(error), "codigo": error.code}), 404

    @app.errorhandler(UnauthorizedError)
    # Função handle_unauthorized: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
    def handle_unauthorized(error):
        # Retorno padronizado para quem chamou esta função.
        return jsonify({"erro": str(error), "codigo": error.code}), error.status_code

    @app.errorhandler(Exception)
    # Função handle_unexpected: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
    def handle_unexpected(error):
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if app.config.get("DEBUG"):
            # Retorno padronizado para quem chamou esta função.
            return jsonify({"erro": str(error), "tipo": error.__class__.__name__}), 500
        # Retorno padronizado para quem chamou esta função.
        return jsonify({"erro": "Erro interno no servidor."}), 500

    # Retorno padronizado para quem chamou esta função.
    return app


app = create_app()


# Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=Config.DEBUG)
