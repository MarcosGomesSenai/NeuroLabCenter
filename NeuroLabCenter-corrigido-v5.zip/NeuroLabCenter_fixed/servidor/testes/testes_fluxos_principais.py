"""
Arquivo: servidor/testes/testes_fluxos_principais.py

Objetivo:
    Implementar uma parte do servidor Flask do NeuroLab Center.

Como manter:
    Leia os comentários antes de alterar regras de negócio, rotas ou acesso ao banco.
    Preserve nomes em português e imports do pacote servidor.

Observação:
    Comentários foram adicionados para facilitar apresentação e manutenção.
"""

"""
NeuroLab Center - servidor/testes/testes_fluxos_principais.py

Responsabilidade:
    Testes automatizados dos fluxos principais do sistema.

Usado por:
    servidor/app.py ou outros módulos do pacote servidor.

Manutenção:
    Este comentário foi adicionado para facilitar leitura em apresentação e manutenção.
    Preserve os imports atualizados para o pacote `servidor`.
"""

# ============================================================================
# Seção consolidada
# ============================================================================
"""
NeuroLab Center — organização modular avançada
Origem: servidor/tests/test_functional_flows.py
Parte 01: executada pelo wrapper para manter compatibilidade de imports.
"""

"""NeuroLab Center — documentação do arquivo

Arquivo: servidor/tests/test_functional_flows.py

Por que este arquivo existe:
    Este módulo foi mantido separado para reduzir acoplamento e facilitar
    a apresentação do projeto. A separação também ajuda a testar e alterar
    uma responsabilidade sem mexer em toda a aplicação.
"""

import base64
import random
import sys
from datetime import date, timedelta
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import urlparse

import mysql.connector
import pytest

ROOT = Path(__file__).resolve().parents[2]
# Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from servidor.app import app  # noqa: E402
from servidor.configuracao import Config  # noqa: E402

PASSWORD = "Senha123"
_mysql_checked = False


# Função ensure_mysql_available: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def ensure_mysql_available():
    global _mysql_checked
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if _mysql_checked:
        return
    # Bloco protegido: captura erros previsíveis sem derrubar a API.
    try:
        connection = mysql.connector.connect(
            host=Config.MYSQL_HOST,
            port=Config.MYSQL_PORT,
            user=Config.MYSQL_USER,
            password=Config.MYSQL_PASSWORD,
            database=Config.MYSQL_DATABASE,
        )
        connection.close()
    except mysql.connector.Error as error:
        pytest.skip(
            "MySQL nao esta disponivel/configurado para os testes. "
            "Ligue o MySQL, execute python -m servidor.banco_de_dados.criar_banco, "
            f"e confira o .env. Erro: {error}"
        )
    _mysql_checked = True


# Função cpf_digit: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def cpf_digit(numbers):
    total = sum(number * weight for number, weight in zip(numbers, range(len(numbers) + 1, 1, -1)))
    remainder = total % 11
    # Retorno padronizado para quem chamou esta função.
    return 0 if remainder < 2 else 11 - remainder


# Função make_cpf: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def make_cpf():
    # Laço de repetição: percorre registros ou dados recebidos do sistema.
    while True:
        numbers = [random.randint(0, 9) for _ in range(9)]
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if len(set(numbers)) == 1:
            continue
        numbers.append(cpf_digit(numbers))
        numbers.append(cpf_digit(numbers))
        # Retorno padronizado para quem chamou esta função.
        return "".join(map(str, numbers))


# Função json: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def json(response):
    # Retorno padronizado para quem chamou esta função.
    return response.get_json(silent=True) or {}


# Função auth_headers: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def auth_headers(token):
    # Retorno padronizado para quem chamou esta função.
    return {"Authorization": f"Bearer {token}"}


# Função test_health_and_catalogs_are_available: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def test_health_and_catalogs_are_available():
    ensure_mysql_available()
    client = app.test_client()

    health = client.get("/api/health")
    assert health.status_code == 200
    assert json(health)["status"] == "online"
    assert json(health)["database"] == "mysql"
    assert json(health)["mysql"] is True

    expected_keys = {
        "/api/unidades": "unidades",
        "/api/medicos": "medicos",
        "/api/convenios": "convenios",
        "/api/exames": "exames",
    }
    # Laço de repetição: percorre registros ou dados recebidos do sistema.
    for path, key in expected_keys.items():
        response = client.get(path)
        assert response.status_code == 200
        assert json(response)[key]

# ============================================================================
# Seção consolidada
# ============================================================================
"""
NeuroLab Center — organização modular avançada
Origem: servidor/tests/test_functional_flows.py
Parte 02: executada pelo wrapper para manter compatibilidade de imports.
"""

def test_full_patient_portal_document_family_and_appointment_journey():
    ensure_mysql_available()
    client = app.test_client()
    suffix = random.randint(100000, 999999)
    adult_cpf = make_cpf()
    child_cpf = make_cpf()
    adult_email = f"pytest.adulto.{suffix}@exemplo.com"
    child_email = f"pytest.filho.{suffix}@exemplo.com"

    created = client.post(
        "/api/cadastro",
        json={
            "cpf": adult_cpf,
            "nome": "Pytest Adulto Funcional",
            "email": adult_email,
            "telefone": "11988887777",
            "data_nascimento": "1991-05-21",
            "senha": PASSWORD,
            "tipo_usuario": "paciente",
        },
    )
    assert created.status_code == 201
    assert json(created)["cpf"] == adult_cpf

    login = client.post("/api/login", json={"cpf": adult_cpf, "senha": PASSWORD})
    assert login.status_code == 200
    token = json(login)["token"]
    headers = auth_headers(token)

    panel = client.get("/api/portal/painel", headers=headers)
    assert panel.status_code == 200
    assert json(panel)["perfil_ativo"]["cpf"] == adult_cpf

    updated_email = f"pytest.atualizado.{suffix}@exemplo.com"
    form = client.put(
        "/api/portal/formularios/dados_cadastrais",
        headers=headers,
        json={
            "email": updated_email,
            "telefone": "11977776666",
            "cep": "09000000",
            "emergencia_nome": "Contato Emergencia",
            "emergencia_telefone": "11966665555",
        },
    )
    assert form.status_code == 200
    assert json(form)["tipo_formulario"] == "dados_cadastrais"

    user = client.get(f"/api/usuarios/{adult_cpf}", headers=headers)
    assert user.status_code == 200
    assert json(user)["email"] == updated_email
    assert json(user)["telefone"] == "11977776666"

    preferences = client.put(
        "/api/portal/preferencias",
        headers=headers,
        json={"whatsapp": False, "email": True, "sms": True},
    )
    assert preferences.status_code == 200
    assert json(preferences)["whatsapp"] is False
    assert json(preferences)["sms"] is True

    preconsultation = client.put(
        "/api/portal/preconsulta",
        headers=headers,
        json={
            "sintomas": "Cefaleia leve ha dois dias",
            "medicamentos": "Nenhum",
            "observacoes": "Teste funcional automatizado",
            "sem_queixas": False,
            "consentimento_triagem": True,
        },
    )
    assert preconsultation.status_code == 200
    assert "Cefaleia" in json(preconsultation)["sintomas"]

    document_payload = "data:application/pdf;base64," + base64.b64encode(
        b"%PDF-1.4\n% neuro lab test\n"
    ).decode("ascii")
    document = client.post(
        "/api/portal/documentos",
        headers=headers,
        json={
            "nome_arquivo": "pedido-pytest.pdf",
            "tipo_arquivo": "pdf",
            "categoria": "pedido_medico",
            "consentimento_lgpd": True,
            "conteudo_base64": document_payload,
        },
    )
    assert document.status_code == 201
    document_id = json(document)["id"]

    documents = client.get("/api/portal/documentos", headers=headers)
    assert documents.status_code == 200
    assert any(item["id"] == document_id for item in json(documents))

    loaded_document = client.get(f"/api/portal/documentos/{document_id}", headers=headers)
    assert loaded_document.status_code == 200
    assert json(loaded_document)["conteudo_base64"]

    removed_document = client.delete(f"/api/portal/documentos/{document_id}", headers=headers)
    assert removed_document.status_code == 200
    assert json(removed_document)["removido"] is True

    family_member = client.post(
        "/api/portal/familia/membro",
        headers=headers,
        json={
            "cpf": child_cpf,
            "nome": "Pytest Filho Funcional",
            "email": child_email,
            "telefone": "11955554444",
            "data_nascimento": "2018-03-10",
            "senha": PASSWORD,
            "papel": "Filho",
        },
    )
    assert family_member.status_code == 201
    assert json(family_member)["cpf"] == child_cpf
    assert json(family_member)["vinculado"] is True

    family = client.get("/api/portal/familia", headers=headers)
    assert family.status_code == 200
    assert any(profile["cpf"] == child_cpf for profile in json(family)["perfis"])

    unlinked = client.delete(f"/api/portal/familia/{child_cpf}", headers=headers)
    assert unlinked.status_code == 200
    assert json(unlinked)["cpf_membro"] == child_cpf

    appointment_date = (date.today() + timedelta(days=23)).isoformat()
    new_appointment_date = (date.today() + timedelta(days=24)).isoformat()
    appointment = client.post(
        "/api/agendamentos",
        headers=headers,
        json={
            "cpf_cliente": adult_cpf,
            "tipo_consulta": "consulta",
            "tipo_atendimento": "particular",
            "id_medico": 2,
            "id_unidade": 1,
            "data_consulta": appointment_date,
            "hora_consulta": "16:10",
            "observacao": "Agendamento Pytest",
        },
    )
    assert appointment.status_code == 201
    appointment_id = json(appointment)["id"]
    assert json(appointment)["status"] == "confirmado"

    availability = client.get(
        f"/api/agendamentos/disponibilidade?id_medico=2&id_unidade=1&data={appointment_date}"
    )
    assert availability.status_code == 200
    assert "16:10" in json(availability)["disponibilidade"]["horarios_ocupados"]

    rescheduled = client.put(
        f"/api/agendamentos/{appointment_id}",
        headers=headers,
        json={
            "cpf_cliente": adult_cpf,
            "id_medico": 2,
            "id_unidade": 1,
            "data_consulta": new_appointment_date,
            "hora_consulta": "16:20",
        },
    )
    assert rescheduled.status_code == 200
    assert json(rescheduled)["data_consulta"] == new_appointment_date

    canceled = client.delete(
        f"/api/agendamentos/{appointment_id}",
        headers=headers,
        json={"cpf_cliente": adult_cpf, "motivo": "Teste Pytest cancela"},
    )
    assert canceled.status_code == 200
    assert json(canceled)["status"] == "cancelado"

# ============================================================================
# Seção consolidada
# ============================================================================
"""
NeuroLab Center — organização modular avançada
Origem: servidor/tests/test_functional_flows.py
Parte 03: executada pelo wrapper para manter compatibilidade de imports.
"""

class SrcParser(HTMLParser):
    # Função __init__: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
    def __init__(self):
        super().__init__()
        self.refs = []

    # Função handle_starttag: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if tag == "script" and attrs.get("src"):
            self.refs.append(attrs["src"])
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if tag == "link" and attrs.get("href") and attrs.get("rel") in {"stylesheet", "preload"}:
            self.refs.append(attrs["href"])
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if tag == "img" and attrs.get("src"):
            self.refs.append(attrs["src"])


# Função test_local_asset_paths_exist: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def test_local_asset_paths_exist():
    html_files = list((ROOT / "site" / "paginas").glob("*.html")) + [ROOT / "index.html"]
    # Laço de repetição: percorre registros ou dados recebidos do sistema.
    for html in html_files:
        parser = SrcParser()
        parser.feed(html.read_text(encoding="utf-8"))
        base = html.parent
        # Laço de repetição: percorre registros ou dados recebidos do sistema.
        for ref in parser.refs:
            parsed = urlparse(ref)
            # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
            if parsed.scheme or ref.startswith("//") or ref.startswith("data:") or ref.startswith("#"):
                continue
            target = (base / parsed.path).resolve()
            assert target.exists(), f"{html.relative_to(ROOT)} referencia arquivo inexistente: {ref}"
