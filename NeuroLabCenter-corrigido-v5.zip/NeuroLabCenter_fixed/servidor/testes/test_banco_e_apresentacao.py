"""
Testes estáticos do banco e da apresentação.

Eles não substituem os testes reais com MySQL ligado, mas ajudam a pegar erros
que atrapalham a apresentação antes mesmo de abrir o navegador ou o XAMPP.
"""

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def _create_tables(sql):
    """Lê CREATE TABLE com parênteses balanceados e devolve colunas por tabela."""
    tables = {}
    for match in re.finditer(r"CREATE\s+TABLE\s+IF\s+NOT\s+EXISTS\s+`?(\w+)`?\s*\(", sql, re.I):
        table = match.group(1)
        start = match.end()
        depth = 1
        quote = None
        end = start
        while end < len(sql):
            char = sql[end]
            if quote:
                if char == quote:
                    quote = None
                elif char == "\\":
                    end += 1
            else:
                if char in "'\"`":
                    quote = char
                elif char == "(":
                    depth += 1
                elif char == ")":
                    depth -= 1
                    if depth == 0:
                        break
            end += 1
        tables[table] = _columns_from_body(sql[start:end])
    return tables


def _split_top_level(text):
    """Separa itens por vírgula ignorando vírgulas dentro de parênteses/strings."""
    items = []
    current = ""
    depth = 0
    quote = None
    index = 0
    while index < len(text):
        char = text[index]
        if quote:
            current += char
            if char == quote:
                quote = None
            elif char == "\\" and index + 1 < len(text):
                index += 1
                current += text[index]
        else:
            if char in "'\"`":
                quote = char
                current += char
            elif char == "(":
                depth += 1
                current += char
            elif char == ")":
                depth -= 1
                current += char
            elif char == "," and depth == 0:
                items.append(current.strip())
                current = ""
            else:
                current += char
        index += 1
    if current.strip():
        items.append(current.strip())
    return items


def _columns_from_body(body):
    columns = set()
    for item in _split_top_level(body):
        match = re.match(r"`?(\w+)`?\s+(.+)", item, re.S)
        if not match:
            continue
        name = match.group(1)
        if name.upper() in {"PRIMARY", "UNIQUE", "INDEX", "KEY", "CONSTRAINT", "CHECK", "FOREIGN"}:
            continue
        columns.add(name)
    return columns


def test_seed_nao_insere_colunas_inexistentes():
    schema = (ROOT / "servidor/banco_de_dados/estrutura.sql").read_text(encoding="utf-8")
    seed = (ROOT / "servidor/banco_de_dados/dados_iniciais.sql").read_text(encoding="utf-8")
    tables = _create_tables(schema)
    problemas = []
    for match in re.finditer(r"INSERT\s+IGNORE\s+INTO\s+`?(\w+)`?\s*\((.*?)\)", seed, re.I | re.S):
        table = match.group(1)
        columns = [item.strip().strip("`") for item in match.group(2).replace("\n", " ").split(",")]
        if table not in tables:
            problemas.append(f"Tabela inexistente no seed: {table}")
            continue
        for column in columns:
            if column not in tables[table]:
                problemas.append(f"Coluna inexistente no seed: {table}.{column}")
    assert not problemas, "\n".join(problemas)


def test_seed_tem_admin_de_apresentacao():
    seed = (ROOT / "servidor/banco_de_dados/dados_iniciais.sql").read_text(encoding="utf-8")
    assert "admin@neurolabcenter.com.br" in seed
    assert "90000000094" in seed
    assert "admin" in seed


def test_agendamento_carrega_script_da_fila_de_espera():
    html = (ROOT / "site/paginas/agendamento.html").read_text(encoding="utf-8")
    assert "recursos/scripts/area-paciente/avaliacoes.js" in html
    assert html.index("area-paciente/avaliacoes.js") < html.index("recursos/scripts/agendamento.js")


def test_script_de_testes_aponta_para_pastas_atuais():
    script = (ROOT / "scripts/run-tests.ps1").read_text(encoding="utf-8")
    assert "compileall -q servidor" in script
    assert "servidor\\testes" in script
    assert "api-do-chatbot" in script
    assert "compileall -q backend" not in script
    assert "servidor\\tests" not in script
    assert "Join-Path $root \"apis\"" not in script


def test_cadastro_publico_nao_permite_perfil_privilegiado():
    import sys

    if str(ROOT) not in sys.path:
        sys.path.insert(0, str(ROOT))

    from servidor.app import app

    response = app.test_client().post(
        "/api/cadastro",
        json={
            "cpf": "90000000094",
            "nome": "Admin Indevido",
            "email": "admin.indevido@example.com",
            "telefone": "11999998888",
            "data_nascimento": "1990-01-01",
            "senha": "Senha123",
            "tipo_usuario": "admin",
        },
    )

    assert response.status_code == 403
    assert response.get_json()["codigo"] == "privileged_user_type_not_allowed"
