"""
Arquivo: servidor/servicos/login_e_cadastro.py

Objetivo:
    Implementar uma parte do servidor Flask do NeuroLab Center.

Como manter:
    Leia os comentários antes de alterar regras de negócio, rotas ou acesso ao banco.
    Preserve nomes em português e imports do pacote servidor.

Observação:
    Comentários foram adicionados para facilitar apresentação e manutenção.
"""

"""
NeuroLab Center - servidor/servicos/login_e_cadastro.py

Responsabilidade:
    Camada de serviços: regras de negócio e operações com pacientes, usuários e agendamentos.

Usado por:
    servidor/app.py ou outros módulos do pacote servidor.

Manutenção:
    Este comentário foi adicionado para facilitar leitura em apresentação e manutenção.
    Preserve os imports atualizados para o pacote `servidor`.
"""

from servidor.servicos.autenticacao import (
    PASSWORD_RESET_MESSAGE,
    authenticate_user,
    create_user,
    redefinir_senha_por_token,
    solicitar_recuperacao_senha,
)

__all__ = [
    "PASSWORD_RESET_MESSAGE",
    "authenticate_user",
    "create_user",
    "redefinir_senha_por_token",
    "solicitar_recuperacao_senha",
]
