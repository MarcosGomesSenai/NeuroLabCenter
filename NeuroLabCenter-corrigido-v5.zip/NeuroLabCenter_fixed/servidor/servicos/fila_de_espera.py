"""
Arquivo: servidor/servicos/fila_de_espera.py

Objetivo:
    Implementar uma parte do servidor Flask do NeuroLab Center.

Como manter:
    Leia os comentários antes de alterar regras de negócio, rotas ou acesso ao banco.
    Preserve nomes em português e imports do pacote servidor.

Observação:
    Comentários foram adicionados para facilitar apresentação e manutenção.
"""

"""
NeuroLab Center - servidor/servicos/fila_de_espera.py

Responsabilidade:
    Camada de serviços: regras de negócio e operações com pacientes, usuários e agendamentos.

Usado por:
    servidor/app.py ou outros módulos do pacote servidor.

Manutenção:
    Este comentário foi adicionado para facilitar leitura em apresentação e manutenção.
    Preserve os imports atualizados para o pacote `servidor`.
"""

from servidor.banco_de_dados.conexao import db_cursor
from servidor.utilitarios.cpf import normalize_cpf
from servidor.utilitarios.datas import parse_date, parse_time
from servidor.utilitarios.erros import BusinessRuleError
from servidor.utilitarios.validacoes import positive_int


# Função criar_entrada_fila: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def criar_entrada_fila(data):
    cpf = normalize_cpf(data.get("cpf_cliente"), "cpf_cliente")
    doctor_id = positive_int(data.get("id_medico"), "id_medico")
    unit_id = positive_int(data.get("id_unidade"), "id_unidade")
    whatsapp = "".join(ch for ch in str(data.get("whatsapp") or "") if ch.isdigit())
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if len(whatsapp) < 10:
        raise BusinessRuleError("WhatsApp invalido para fila de espera.", code="invalid_whatsapp")

    date_value = data.get("data_preferida")
    time_value = data.get("hora_preferida")
    preferred_date = parse_date(date_value, "data_preferida") if date_value else None
    preferred_time = parse_time(time_value) if time_value else None
    observation = (data.get("observacao") or "").strip()[:500] or None

    with db_cursor(commit=True) as cursor:
        cursor.execute("SELECT cpf FROM pacientes WHERE cpf = %s", (cpf,))
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if not cursor.fetchone():
            raise BusinessRuleError("Paciente nao encontrado para entrar na fila.", code="patient_not_found", status_code=404)
        cursor.execute("SELECT id FROM medicos WHERE id = %s AND ativo = TRUE", (doctor_id,))
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if not cursor.fetchone():
            raise BusinessRuleError("Medico nao encontrado para fila.", code="doctor_not_found", status_code=404)
        cursor.execute("SELECT id FROM unidades WHERE id = %s AND ativo = TRUE", (unit_id,))
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if not cursor.fetchone():
            raise BusinessRuleError("Unidade nao encontrada para fila.", code="unit_not_found", status_code=404)
        cursor.execute(
            """
            INSERT INTO fila_espera
              (cpf_paciente, id_medico, id_unidade, data_preferida, hora_preferida, whatsapp, observacao)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
            """,
            (cpf, doctor_id, unit_id, preferred_date, preferred_time, whatsapp, observation),
        )
        waitlist_id = cursor.lastrowid
    # Retorno padronizado para quem chamou esta função.
    return {"id": waitlist_id, "cpf_paciente": cpf, "status": "ativa"}
