"""
Arquivo: servidor/servicos/catalogos.py

Objetivo:
    Implementar uma parte do servidor Flask do NeuroLab Center.

Como manter:
    Leia os comentários antes de alterar regras de negócio, rotas ou acesso ao banco.
    Preserve nomes em português e imports do pacote servidor.

Observação:
    Comentários foram adicionados para facilitar apresentação e manutenção.
"""

"""
NeuroLab Center - servidor/servicos/catalogos.py

Responsabilidade:
    Camada de serviços: regras de negócio e operações com pacientes, usuários e agendamentos.

Usado por:
    servidor/app.py ou outros módulos do pacote servidor.

Manutenção:
    Este comentário foi adicionado para facilitar leitura em apresentação e manutenção.
    Preserve os imports atualizados para o pacote `servidor`.
"""

from servidor.banco_de_dados.conexao import fetch_all, fetch_one
from servidor.utilitarios.erros import BusinessRuleError


# Função list_units: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def list_units():
    # Retorno padronizado para quem chamou esta função.
    return fetch_all("SELECT * FROM unidades WHERE ativo = TRUE ORDER BY nome")


# Função list_doctors: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def list_doctors():
    # Retorno padronizado para quem chamou esta função.
    return fetch_all(
        """
        SELECT m.id, m.crm, m.especialidade, u.nome, u.cpf
          FROM medicos m
          JOIN usuarios u ON u.id = m.id_usuario
         WHERE m.ativo = TRUE AND u.ativo = TRUE
         ORDER BY u.nome
        """
    )


# Função list_health_plans: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def list_health_plans():
    # Retorno padronizado para quem chamou esta função.
    return fetch_all("SELECT * FROM convenios WHERE ativo = TRUE ORDER BY nome")


# Função list_exams: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def list_exams():
    # Retorno padronizado para quem chamou esta função.
    return fetch_all("SELECT * FROM exames WHERE ativo = TRUE ORDER BY nome")


# Função get_unit_by_zip_code: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def get_unit_by_zip_code(cep):
    digits = "".join(char for char in str(cep or "") if char.isdigit())
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if len(digits) < 5:
        raise BusinessRuleError("CEP invalido.", code="invalid_zip_code")
    unit = fetch_one(
        """
        SELECT *
          FROM unidades
         WHERE ativo = TRUE
         ORDER BY
           CASE
             WHEN cep = %s THEN 0
             WHEN LEFT(cep, 5) = LEFT(%s, 5) THEN 1
             WHEN LEFT(cep, 3) = LEFT(%s, 3) THEN 2
             ELSE 3
           END,
           nome
         LIMIT 1
        """,
        (digits[:8], digits[:8], digits[:8]),
    )
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if not unit:
        raise BusinessRuleError("Nenhuma unidade ativa encontrada para o CEP.", code="unit_not_found_by_zip")
    # Retorno padronizado para quem chamou esta função.
    return unit
