"""
Arquivo: servidor/servicos/familia.py

Objetivo:
    Implementar uma parte do servidor Flask do NeuroLab Center.

Como manter:
    Leia os comentários antes de alterar regras de negócio, rotas ou acesso ao banco.
    Preserve nomes em português e imports do pacote servidor.

Observação:
    Comentários foram adicionados para facilitar apresentação e manutenção.
"""

"""
NeuroLab Center - servidor/servicos/familia.py

Responsabilidade:
    Camada de serviços: regras de negócio e operações com pacientes, usuários e agendamentos.

Usado por:
    servidor/app.py ou outros módulos do pacote servidor.

Manutenção:
    Este comentário foi adicionado para facilitar leitura em apresentação e manutenção.
    Preserve os imports atualizados para o pacote `servidor`.
"""

# ============================================================================
# Seção consolidada
# ============================================================================
"""
NeuroLab Center — organização modular avançada
Origem: servidor/services/familia_service.py
Parte 01: executada pelo wrapper para manter compatibilidade de imports.
"""

"""NeuroLab Center — documentação do arquivo

Arquivo: servidor/services/familia_service.py

Por que este arquivo existe:
    Este módulo foi mantido separado para reduzir acoplamento e facilitar
    a apresentação do projeto. A separação também ajuda a testar e alterar
    uma responsabilidade sem mexer em toda a aplicação.
"""

import unicodedata

from mysql.connector import IntegrityError

from servidor.configuracao import Config
from servidor.banco_de_dados.conexao import db_cursor, fetch_all, fetch_one
from servidor.servicos.login_e_cadastro import create_user
from servidor.utilitarios.cpf import normalize_cpf
from servidor.utilitarios.datas import age_from_birthdate, parse_date
from servidor.utilitarios.erros import BusinessRuleError, NotFoundError

PAPEIS_MENORES = {"filho", "filha", "neto", "neta", "dependente", "menor"}
PAPEIS_ADULTOS = {"mae", "pai", "avo", "conjuge", "responsavel"}
PAPEIS_PERMITIDOS = PAPEIS_MENORES | {
    "mae", "mãe", "pai", "avo", "avó", "avô", "conjuge", "cônjuge", "irmao", "irmão", "irma", "irmã", "outro", "responsavel", "responsável"
}


# Função _normalizar_papel: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def _normalizar_papel(papel):
    papel_limpo = str(papel or "").strip().lower()
    papel_sem_acento = "".join(
        char for char in unicodedata.normalize("NFD", papel_limpo)
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if unicodedata.category(char) != "Mn"
    )
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if not papel_sem_acento:
        raise BusinessRuleError("Informe o parentesco.", code="missing_papel")
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if len(papel_limpo) > 40:
        raise BusinessRuleError("Parentesco muito longo.", code="papel_too_long")
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if papel_limpo not in PAPEIS_PERMITIDOS and papel_sem_acento not in PAPEIS_PERMITIDOS:
        raise BusinessRuleError(
            "Parentesco invalido. Use filho, filha, neto, neta, pai, mae, conjuge, irmao, responsavel ou outro.",
            code="invalid_family_role",
        )
    # Retorno padronizado para quem chamou esta função.
    return papel_limpo.title(), papel_sem_acento


# Função _idade_por_cpf: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def _idade_por_cpf(cpf):
    row = fetch_one("SELECT data_nascimento FROM pacientes WHERE cpf = %s", (cpf,))
    nascimento = row.get("data_nascimento") if row else None
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if not nascimento:
        # Retorno padronizado para quem chamou esta função.
        return None
    # Retorno padronizado para quem chamou esta função.
    return age_from_birthdate(nascimento)


# Função _assert_titular_existe_e_pode_gerenciar: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def _assert_titular_existe_e_pode_gerenciar(titular):
    titular_user = fetch_one(
        "SELECT cpf, nome, ativo FROM usuarios WHERE cpf = %s",
        (titular,),
    )
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if not titular_user or not titular_user["ativo"]:
        raise NotFoundError("Usuario titular nao encontrado.", code="titular_not_found")
    idade = _idade_por_cpf(titular)
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if idade is not None and idade < Config.MINOR_CONFIRMATION_AGE:
        raise BusinessRuleError(
            "Menor de idade nao pode gerenciar conta familia.",
            code="minor_cannot_manage_family",
            status_code=403,
        )
    # Retorno padronizado para quem chamou esta função.
    return titular_user


# Função _validar_regra_idade_familiar: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def _validar_regra_idade_familiar(titular, membro, papel_normalizado):
    idade = _idade_por_cpf(membro)
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if idade is None:
        return
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if papel_normalizado in PAPEIS_MENORES and idade >= Config.MINOR_CONFIRMATION_AGE:
        raise BusinessRuleError(
            "Contas de filho, filha, neto, neta ou dependente devem ter de 0 a 17 anos.",
            code="minor_family_role_requires_minor",
        )
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if papel_normalizado in PAPEIS_ADULTOS and idade < Config.MINOR_CONFIRMATION_AGE:
        raise BusinessRuleError(
            "Papel de mae, pai, avo, conjuge ou responsavel exige familiar maior de idade.",
            code="adult_family_role_requires_adult",
        )
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if idade < Config.MINOR_CONFIRMATION_AGE:
        paciente = fetch_one("SELECT cpf_responsavel FROM pacientes WHERE cpf = %s", (membro,))
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if not paciente or paciente.get("cpf_responsavel") != titular:
            raise BusinessRuleError(
                "Menor de idade so pode ser vinculado quando o titular for o responsavel legal.",
                code="minor_family_member_requires_holder_responsible",
                status_code=403,
            )

# ============================================================================
# Seção consolidada
# ============================================================================
"""
NeuroLab Center — organização modular avançada
Origem: servidor/services/familia_service.py
Parte 02: executada pelo wrapper para manter compatibilidade de imports.
"""

def listar_perfis_acessiveis(cpf_titular):
    titular = normalize_cpf(cpf_titular)
    titular_user = fetch_one(
        "SELECT cpf, nome FROM usuarios WHERE cpf = %s AND ativo = TRUE",
        (titular,),
    )
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if not titular_user:
        raise NotFoundError("Usuario titular nao encontrado.", code="titular_not_found")

    perfis = [
        {
            "cpf": titular_user["cpf"],
            "nome": titular_user["nome"],
            "papel": "Eu",
            "tipo_vinculo": "titular",
        }
    ]

    vinculos = fetch_all(
        """
        SELECT v.cpf_membro AS cpf, v.papel, u.nome, p.data_nascimento
          FROM conta_familia_vinculos v
          JOIN usuarios u ON u.cpf = v.cpf_membro
          JOIN pacientes p ON p.cpf = v.cpf_membro
         WHERE v.cpf_titular = %s AND u.ativo = TRUE
         ORDER BY v.papel, u.nome
        """,
        (titular,),
    )
    # Laço de repetição: percorre registros ou dados recebidos do sistema.
    for item in vinculos:
        perfis.append(
            {
                "cpf": item["cpf"],
                "nome": item["nome"],
                "papel": item["papel"],
                "tipo_vinculo": "familia",
                "data_nascimento": item.get("data_nascimento"),
            }
        )

    dependentes_guardiao = fetch_all(
        """
        SELECT p.cpf, p.nome, p.data_nascimento
          FROM pacientes p
          JOIN usuarios u ON u.cpf = p.cpf
         WHERE p.cpf_responsavel = %s AND u.ativo = TRUE
           AND p.cpf NOT IN (
               SELECT cpf_membro FROM conta_familia_vinculos WHERE cpf_titular = %s
           )
        """,
        (titular, titular),
    )
    # Laço de repetição: percorre registros ou dados recebidos do sistema.
    for item in dependentes_guardiao:
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if not any(perfil["cpf"] == item["cpf"] for perfil in perfis):
            perfis.append(
                {
                    "cpf": item["cpf"],
                    "nome": item["nome"],
                    "papel": "Dependente",
                    "tipo_vinculo": "responsavel_legal",
                    "data_nascimento": item.get("data_nascimento"),
                }
            )

    # Retorno padronizado para quem chamou esta função.
    return perfis


# Função pode_acessar_perfil: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def pode_acessar_perfil(cpf_titular, cpf_perfil):
    titular = normalize_cpf(cpf_titular)
    perfil = normalize_cpf(cpf_perfil, "cpf_perfil")
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if titular == perfil:
        # Retorno padronizado para quem chamou esta função.
        return True

    vinculo = fetch_one(
        """
        SELECT 1 AS ok FROM conta_familia_vinculos
         WHERE cpf_titular = %s AND cpf_membro = %s
        """,
        (titular, perfil),
    )
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if vinculo:
        # Retorno padronizado para quem chamou esta função.
        return True

    guardiao = fetch_one(
        "SELECT 1 AS ok FROM pacientes WHERE cpf = %s AND cpf_responsavel = %s",
        (perfil, titular),
    )
    # Retorno padronizado para quem chamou esta função.
    return bool(guardiao)


# Função assert_acesso_perfil: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def assert_acesso_perfil(cpf_titular, cpf_perfil):
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if not pode_acessar_perfil(cpf_titular, cpf_perfil):
        raise BusinessRuleError(
            "Sem permissao para acessar dados deste perfil.",
            code="profile_access_denied",
            status_code=403,
        )

# ============================================================================
# Seção consolidada
# ============================================================================
"""
NeuroLab Center — organização modular avançada
Origem: servidor/services/familia_service.py
Parte 03: executada pelo wrapper para manter compatibilidade de imports.
"""

def vincular_membro_existente(cpf_titular, cpf_membro, papel):
    titular = normalize_cpf(cpf_titular)
    membro = normalize_cpf(cpf_membro, "cpf_membro")
    papel_limpo, papel_normalizado = _normalizar_papel(papel)
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if titular == membro:
        raise BusinessRuleError("O familiar precisa ter CPF diferente do titular.", code="family_member_must_differ")

    _assert_titular_existe_e_pode_gerenciar(titular)

    membro_user = fetch_one(
        "SELECT cpf, ativo FROM usuarios WHERE cpf = %s",
        (membro,),
    )
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if not membro_user or not membro_user["ativo"]:
        raise BusinessRuleError("CPF do familiar precisa estar cadastrado.", code="member_not_found")

    _validar_regra_idade_familiar(titular, membro, papel_normalizado)

    # Bloco protegido: captura erros previsíveis sem derrubar a API.
    try:
        with db_cursor(commit=True) as cursor:
            cursor.execute(
                """
                INSERT INTO conta_familia_vinculos (cpf_titular, cpf_membro, papel)
                VALUES (%s, %s, %s)
                """,
                (titular, membro, papel_limpo),
            )
    except IntegrityError as error:
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if error.errno == 1062:
            raise BusinessRuleError("Familiar ja vinculado.", code="already_linked")
        raise

    # Retorno padronizado para quem chamou esta função.
    return {"cpf_membro": membro, "papel": papel_limpo, "mensagem": "Familiar vinculado."}


# Função cadastrar_e_vincular_familiar: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def cadastrar_e_vincular_familiar(cpf_titular, data):
    """Cadastro normal (usuarios + pacientes) + vinculo na conta familia, com regras de idade."""
    titular = normalize_cpf(cpf_titular)
    _assert_titular_existe_e_pode_gerenciar(titular)

    papel_limpo, papel_normalizado = _normalizar_papel(data.get("papel") or data.get("parentesco"))
    nascimento = data.get("data_nascimento") or data.get("nascimento")
    idade = age_from_birthdate(parse_date(nascimento, "data_nascimento"))
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if idade < 0:
        raise BusinessRuleError("Data de nascimento nao pode ser futura.", code="birthdate_in_future")
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if idade > 120:
        raise BusinessRuleError("Data de nascimento invalida.", code="invalid_birthdate")

    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if papel_normalizado in PAPEIS_MENORES and idade >= Config.MINOR_CONFIRMATION_AGE:
        raise BusinessRuleError(
            "Contas de filho, filha, neto, neta ou dependente devem ter de 0 a 17 anos.",
            code="minor_family_role_requires_minor",
        )
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if papel_normalizado in PAPEIS_ADULTOS and idade < Config.MINOR_CONFIRMATION_AGE:
        raise BusinessRuleError(
            "Papel de mae, pai, avo, conjuge ou responsavel exige familiar maior de idade.",
            code="adult_family_role_requires_adult",
        )

    cpf_responsavel = data.get("cpf_responsavel") or (titular if idade < Config.MINOR_CONFIRMATION_AGE else None)

    payload = {
        "cpf": data.get("cpf"),
        "nome": data.get("nome"),
        "email": data.get("email"),
        "telefone": data.get("telefone") or data.get("celular"),
        "data_nascimento": nascimento,
        "senha": data.get("senha"),
        "tipo_usuario": "paciente",
        "cpf_responsavel": cpf_responsavel,
    }

    created = create_user(payload)
    vincular_membro_existente(titular, created["cpf"], papel_limpo)

    # Retorno padronizado para quem chamou esta função.
    return {
        **created,
        "papel": papel_limpo,
        "vinculado": True,
        "mensagem": "Conta criada e vinculada a conta familia.",
    }


# Função desvincular_familiar: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def desvincular_familiar(cpf_titular, cpf_membro):
    titular = normalize_cpf(cpf_titular)
    membro = normalize_cpf(cpf_membro, "cpf_membro")
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if titular == membro:
        raise BusinessRuleError("Nao e possivel desvincular o titular.", code="cannot_unlink_self")
    _assert_titular_existe_e_pode_gerenciar(titular)

    with db_cursor(commit=True) as cursor:
        cursor.execute(
            "DELETE FROM conta_familia_vinculos WHERE cpf_titular = %s AND cpf_membro = %s",
            (titular, membro),
        )
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if cursor.rowcount == 0:
            raise NotFoundError("Vinculo familiar nao encontrado.", code="link_not_found")

    # Retorno padronizado para quem chamou esta função.
    return {"cpf_membro": membro, "mensagem": "Familiar desvinculado."}
