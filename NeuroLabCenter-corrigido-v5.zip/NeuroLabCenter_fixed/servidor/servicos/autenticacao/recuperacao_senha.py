"""
Arquivo: servidor/servicos/autenticacao/recuperacao_senha.py

Objetivo:
    Implementar uma parte do servidor Flask do NeuroLab Center.

Como manter:
    Leia os comentários antes de alterar regras de negócio, rotas ou acesso ao banco.
    Preserve nomes em português e imports do pacote servidor.

Observação:
    Comentários foram adicionados para facilitar apresentação e manutenção.
"""

"""
NeuroLab Center - servidor/servicos/autenticacao/recuperacao_senha.py

Responsabilidade:
    Camada de serviços: regras de negócio e operações com pacientes, usuários e agendamentos.

Usado por:
    servidor/app.py ou outros módulos do pacote servidor.

Manutenção:
    Este comentário foi adicionado para facilitar leitura em apresentação e manutenção.
    Preserve os imports atualizados para o pacote `servidor`.
"""

# ============================================================================
# Seção consolidada
# ============================================================================
"""
NeuroLab Center — organização modular avançada
Origem: servidor/services/auth/password_reset.py
Parte 01: executada pelo wrapper para manter compatibilidade de imports.
"""

"""NeuroLab Center — recuperação de senha

Arquivo: servidor/services/auth/password_reset.py

Por que existe:
    Este arquivo foi separado para reduzir tamanho dos módulos, deixar a
    navegação mais simples durante a apresentação e diminuir risco de mexer
    em uma responsabilidade e quebrar outra.
"""

from datetime import datetime, timedelta

from servidor.configuracao import Config
from servidor.banco_de_dados.conexao import db_cursor, fetch_one
from servidor.utilitarios.cpf import normalize_cpf
from servidor.utilitarios.erros import BusinessRuleError
from servidor.utilitarios.seguranca import (
    generate_password_reset_token,
    hash_password,
    hash_password_reset_token,
    verify_password,
)
from servidor.utilitarios.validacoes import validate_email


VALID_USER_TYPES = {"paciente", "responsavel", "medico", "recepcionista", "admin"}
RESPONSIBLE_USER_TYPES = {"responsavel", "paciente"}

PASSWORD_RESET_MESSAGE = (
    "Se os dados estiverem corretos, as instrucoes para redefinir a senha foram geradas."
)

# Função _now: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def _now():
    # Retorno padronizado para quem chamou esta função.
    return datetime.now()


# Função _buscar_usuario_para_recuperacao: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def _buscar_usuario_para_recuperacao(data):
    cpf = data.get("cpf")
    email = data.get("email")

    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if cpf:
        normalized = normalize_cpf(cpf)
        # Retorno padronizado para quem chamou esta função.
        return fetch_one(
            """
            SELECT id, cpf, nome, email, senha_hash, tipo_usuario, ativo
              FROM usuarios
             WHERE cpf = %s
             LIMIT 1
            """,
            (normalized,),
        )

    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if email:
        normalized_email = validate_email(email, required=True)
        # Retorno padronizado para quem chamou esta função.
        return fetch_one(
            """
            SELECT id, cpf, nome, email, senha_hash, tipo_usuario, ativo
              FROM usuarios
             WHERE email = %s
             LIMIT 1
            """,
            (normalized_email,),
        )

    raise BusinessRuleError(
        "Informe CPF ou e-mail para recuperar a senha.",
        code="password_reset_identifier_required",
    )


# Função _validar_limite_recuperacao: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def _validar_limite_recuperacao(cpf):
    row = fetch_one(
        """
        SELECT COUNT(*) AS total
          FROM senha_recuperacao_tokens
         WHERE cpf = %s
           AND criado_em >= DATE_SUB(NOW(), INTERVAL %s MINUTE)
        """,
        (cpf, Config.PASSWORD_RESET_RATE_LIMIT_MINUTES),
    )
    total = int((row or {}).get("total") or 0)
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if total >= Config.PASSWORD_RESET_MAX_REQUESTS:
        raise BusinessRuleError(
            "Muitas solicitacoes de recuperacao. Aguarde alguns minutos e tente novamente.",
            code="password_reset_rate_limited",
            status_code=429,
        )

# ============================================================================
# Seção consolidada
# ============================================================================
"""
NeuroLab Center — organização modular avançada
Origem: servidor/services/auth/password_reset.py
Parte 02: executada pelo wrapper para manter compatibilidade de imports.
"""

def solicitar_recuperacao_senha(data, ip=None, user_agent=None):
    user = _buscar_usuario_para_recuperacao(data)

    # Resposta generica evita expor se um CPF/e-mail existe no sistema.
    if not user or not user.get("ativo"):
        # Retorno padronizado para quem chamou esta função.
        return {"mensagem": PASSWORD_RESET_MESSAGE}

    _validar_limite_recuperacao(user["cpf"])

    token = generate_password_reset_token()
    token_hash = hash_password_reset_token(token)
    expira_em = _now() + timedelta(minutes=Config.PASSWORD_RESET_EXPIRES_MINUTES)
    safe_agent = (user_agent or "")[:255]

    with db_cursor(commit=True) as cursor:
        cursor.execute(
            """
            UPDATE senha_recuperacao_tokens
               SET ativo = FALSE
             WHERE cpf = %s
               AND usado_em IS NULL
               AND ativo = TRUE
            """,
            (user["cpf"],),
        )
        cursor.execute(
            """
            INSERT INTO senha_recuperacao_tokens
                (cpf, token_hash, expira_em, ip_solicitante, user_agent)
            VALUES (%s, %s, %s, %s, %s)
            """,
            (user["cpf"], token_hash, expira_em, ip, safe_agent),
        )

    response = {
        "mensagem": PASSWORD_RESET_MESSAGE,
        "expira_em_minutos": Config.PASSWORD_RESET_EXPIRES_MINUTES,
    }
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if Config.PASSWORD_RESET_EXPOSE_TOKEN:
        response["token_recuperacao"] = token
        response["aviso"] = (
            "Token exposto porque PASSWORD_RESET_EXPOSE_TOKEN=true. "
            "Use apenas em ambiente local/escolar."
        )
    # Retorno padronizado para quem chamou esta função.
    return response


# Função redefinir_senha_por_token: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def redefinir_senha_por_token(data):
    token = str(data.get("token") or data.get("token_recuperacao") or "").strip()
    nova_senha = data.get("nova_senha") or data.get("senha") or data.get("new_password")
    confirmacao = data.get("confirmar_senha") or data.get("confirmacao_senha") or data.get("confirm_password")

    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if not token:
        raise BusinessRuleError("Token de recuperacao obrigatorio.", code="password_reset_token_required")
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if confirmacao is not None and str(nova_senha or "") != str(confirmacao):
        raise BusinessRuleError(
            "Confirmacao de senha diferente da nova senha.",
            code="password_confirmation_mismatch",
        )

    token_hash = hash_password_reset_token(token)
    reset = fetch_one(
        """
        SELECT s.id, s.cpf, s.expira_em, s.usado_em, s.ativo,
               u.senha_hash, u.ativo AS usuario_ativo
          FROM senha_recuperacao_tokens s
          JOIN usuarios u ON u.cpf = s.cpf
         WHERE s.token_hash = %s
         LIMIT 1
        """,
        (token_hash,),
    )

    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if (
        not reset
        or not reset.get("ativo")
        or reset.get("usado_em") is not None
        or not reset.get("usuario_ativo")
        or reset.get("expira_em") < _now()
    ):
        raise BusinessRuleError(
            "Token de recuperacao invalido ou expirado.",
            code="password_reset_token_invalid",
        )

    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if verify_password(nova_senha, reset.get("senha_hash")):
        raise BusinessRuleError(
            "A nova senha deve ser diferente da senha atual.",
            code="password_must_change",
        )

    nova_hash = hash_password(nova_senha)

    with db_cursor(commit=True) as cursor:
        cursor.execute(
            """
            UPDATE usuarios
               SET senha_hash = %s,
                   tentativas_login = 0,
                   bloqueado_ate = NULL
             WHERE cpf = %s
            """,
            (nova_hash, reset["cpf"]),
        )
        cursor.execute(
            """
            UPDATE senha_recuperacao_tokens
               SET usado_em = NOW(),
                   ativo = FALSE
             WHERE id = %s
            """,
            (reset["id"],),
        )
        cursor.execute(
            """
            UPDATE senha_recuperacao_tokens
               SET ativo = FALSE
             WHERE cpf = %s
               AND id <> %s
               AND usado_em IS NULL
            """,
            (reset["cpf"], reset["id"]),
        )

    # Retorno padronizado para quem chamou esta função.
    return {"mensagem": "Senha redefinida com sucesso. Faca login com a nova senha."}
