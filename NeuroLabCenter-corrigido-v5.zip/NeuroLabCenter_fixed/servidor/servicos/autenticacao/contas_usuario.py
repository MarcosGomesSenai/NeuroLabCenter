"""
Arquivo: servidor/servicos/autenticacao/contas_usuario.py

Objetivo:
    Implementar uma parte do servidor Flask do NeuroLab Center.

Como manter:
    Leia os comentários antes de alterar regras de negócio, rotas ou acesso ao banco.
    Preserve nomes em português e imports do pacote servidor.

Observação:
    Comentários foram adicionados para facilitar apresentação e manutenção.
"""

"""
NeuroLab Center - servidor/servicos/autenticacao/contas_usuario.py

Responsabilidade:
    Camada de serviços: regras de negócio e operações com pacientes, usuários e agendamentos.

Usado por:
    servidor/app.py ou outros módulos do pacote servidor.

Manutenção:
    Este comentário foi adicionado para facilitar leitura em apresentação e manutenção.
    Preserve os imports atualizados para o pacote `servidor`.
"""

# ============================================================================
# Seção consolidada
# ============================================================================
"""
NeuroLab Center — organização modular avançada
Origem: servidor/services/auth/user_accounts.py
Parte 01: executada pelo wrapper para manter compatibilidade de imports.
"""

"""NeuroLab Center — login e cadastro de usuários

Arquivo: servidor/services/auth/user_accounts.py

Por que existe:
    Este arquivo foi separado para reduzir tamanho dos módulos, deixar a
    navegação mais simples durante a apresentação e diminuir risco de mexer
    em uma responsabilidade e quebrar outra.
"""

from datetime import datetime, timedelta

from mysql.connector import IntegrityError

from servidor.configuracao import Config
from servidor.banco_de_dados.conexao import db_cursor, fetch_one
from servidor.utilitarios.cpf import normalize_cpf
from servidor.utilitarios.datas import age_from_birthdate, parse_date
from servidor.utilitarios.erros import BusinessRuleError, UnauthorizedError
from servidor.utilitarios.seguranca import (
    create_token,
    hash_password,
    verify_password,
)
from servidor.utilitarios.validacoes import validate_email, validate_phone


VALID_USER_TYPES = {"paciente", "responsavel", "medico", "recepcionista", "admin"}
RESPONSIBLE_USER_TYPES = {"responsavel", "paciente"}

PASSWORD_RESET_MESSAGE = (
    "Se os dados estiverem corretos, as instrucoes para redefinir a senha foram geradas."
)

# Função _validar_idade_cadastro: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def _validar_idade_cadastro(idade):
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if idade < 0:
        raise BusinessRuleError("Data de nascimento nao pode ser futura.", code="birthdate_in_future")
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if idade > 120:
        raise BusinessRuleError("Data de nascimento invalida.", code="invalid_birthdate")


# Função _responsavel_e_adulto: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def _responsavel_e_adulto(responsible_cpf):
    patient = fetch_one(
        "SELECT data_nascimento FROM pacientes WHERE cpf = %s",
        (responsible_cpf,),
    )
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if not patient or not patient.get("data_nascimento"):
        raise BusinessRuleError(
            "CPF do responsavel precisa possuir cadastro de paciente/responsavel.",
            code="responsible_patient_record_required",
        )
    idade = age_from_birthdate(patient["data_nascimento"])
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if idade < Config.MINOR_CONFIRMATION_AGE:
        raise BusinessRuleError(
            "CPF do responsavel precisa ser de uma pessoa maior de idade.",
            code="responsible_must_be_adult",
        )


# Função _registrar_falha_login: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def _registrar_falha_login(user):
    tentativas = int(user.get("tentativas_login") or 0) + 1
    bloqueado_ate = None
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if tentativas >= Config.LOGIN_MAX_ATTEMPTS:
        bloqueado_ate = datetime.now() + timedelta(minutes=Config.LOGIN_BLOCK_MINUTES)
    with db_cursor(commit=True) as cursor:
        cursor.execute(
            """
            UPDATE usuarios
               SET tentativas_login = %s,
                   bloqueado_ate = %s
             WHERE cpf = %s
            """,
            (tentativas, bloqueado_ate, user["cpf"]),
        )
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if bloqueado_ate:
        raise UnauthorizedError(
            f"Conta bloqueada por {Config.LOGIN_BLOCK_MINUTES} minutos apos muitas tentativas.",
            code="account_locked",
            status_code=423,
        )


# Função _registrar_login_sucesso: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def _registrar_login_sucesso(cpf):
    with db_cursor(commit=True) as cursor:
        cursor.execute(
            "UPDATE usuarios SET tentativas_login = 0, bloqueado_ate = NULL WHERE cpf = %s",
            (cpf,),
        )


# Função authenticate_user: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def authenticate_user(cpf, password):
    normalized = normalize_cpf(cpf)
    user = fetch_one(
        """
        SELECT id, cpf, nome, email, senha_hash, tipo_usuario, ativo,
               tentativas_login, bloqueado_ate
          FROM usuarios
         WHERE cpf = %s
        """,
        (normalized,),
    )
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if not user or not user["ativo"]:
        raise UnauthorizedError("CPF ou senha invalidos.", code="invalid_credentials")

    bloqueado_ate = user.get("bloqueado_ate")
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if bloqueado_ate and bloqueado_ate > datetime.now():
        raise UnauthorizedError(
            "Conta temporariamente bloqueada por excesso de tentativas.",
            code="account_locked",
            status_code=423,
        )

    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if not verify_password(password, user["senha_hash"]):
        _registrar_falha_login(user)
        raise UnauthorizedError("CPF ou senha invalidos.", code="invalid_credentials")

    _registrar_login_sucesso(user["cpf"])
    token = create_token(user)
    # Retorno padronizado para quem chamou esta função.
    return {
        "id": user["id"],
        "cpf": user["cpf"],
        "nome": user["nome"],
        "email": user["email"],
        "tipo_usuario": user["tipo_usuario"],
        "token": token,
    }

# ============================================================================
# Seção consolidada
# ============================================================================
"""
NeuroLab Center — organização modular avançada
Origem: servidor/services/auth/user_accounts.py
Parte 02: executada pelo wrapper para manter compatibilidade de imports.
"""

def create_user(data, allow_privileged_types=False):
    cpf = normalize_cpf(data.get("cpf"))
    name = (data.get("nome") or "").strip()
    email = validate_email(data.get("email"), required=True)
    phone = validate_phone(data.get("telefone"), required=False)
    birthdate = parse_date(data.get("data_nascimento"), "data_nascimento")
    user_type = data.get("tipo_usuario") or "paciente"
    responsible_cpf = data.get("cpf_responsavel")

    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if not name:
        raise BusinessRuleError("Nome e obrigatorio.", code="missing_name")
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if len(name) > 120:
        raise BusinessRuleError("Nome muito longo.", code="name_too_long")
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if user_type not in VALID_USER_TYPES:
        raise BusinessRuleError("Tipo de usuario invalido.", code="invalid_user_type")
    if not allow_privileged_types and user_type not in RESPONSIBLE_USER_TYPES:
        raise BusinessRuleError(
            "Cadastro publico permite apenas paciente ou responsavel.",
            code="privileged_user_type_not_allowed",
            status_code=403,
        )

    patient_age = age_from_birthdate(birthdate)
    _validar_idade_cadastro(patient_age)

    normalized_responsible = None
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if patient_age < Config.MINOR_CONFIRMATION_AGE:
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if user_type == "responsavel":
            raise BusinessRuleError("Menor de 18 anos nao pode ser cadastrado como responsavel.", code="minor_cannot_be_responsible")
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if not responsible_cpf:
            raise BusinessRuleError(
                "Menor de 18 anos precisa de CPF de responsavel.",
                code="minor_requires_responsible",
            )
        normalized_responsible = normalize_cpf(responsible_cpf, "cpf_responsavel")
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if normalized_responsible == cpf:
            raise BusinessRuleError("CPF do responsavel deve ser diferente do CPF do paciente.", code="responsible_must_differ")
    elif responsible_cpf:
        normalized_responsible = normalize_cpf(responsible_cpf, "cpf_responsavel")
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if normalized_responsible == cpf:
            raise BusinessRuleError("CPF do responsavel deve ser diferente do CPF do paciente.", code="responsible_must_differ")

    existing_email = fetch_one(
        "SELECT cpf FROM usuarios WHERE email = %s AND ativo = TRUE AND cpf <> %s LIMIT 1",
        (email, cpf),
    )
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if existing_email:
        raise BusinessRuleError("E-mail ja cadastrado em outra conta.", code="email_already_exists")

    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if normalized_responsible:
        responsible = fetch_one(
            "SELECT cpf, tipo_usuario, ativo FROM usuarios WHERE cpf = %s",
            (normalized_responsible,),
        )
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if not responsible or not responsible["ativo"]:
            raise BusinessRuleError(
                "CPF do responsavel precisa estar cadastrado e ativo.",
                code="responsible_must_exist",
            )
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if responsible["tipo_usuario"] not in RESPONSIBLE_USER_TYPES:
            raise BusinessRuleError(
                "CPF do responsavel precisa ser de um usuario do tipo responsavel ou paciente.",
                code="responsible_must_have_responsible_type",
            )
        _responsavel_e_adulto(normalized_responsible)

    password_hash = hash_password(data.get("senha"))

    # Bloco protegido: captura erros previsíveis sem derrubar a API.
    try:
        with db_cursor(commit=True) as cursor:
            cursor.execute(
                """
                INSERT INTO usuarios (cpf, nome, telefone, email, senha_hash, tipo_usuario)
                VALUES (%s, %s, %s, %s, %s, %s)
                """,
                (cpf, name, phone, email, password_hash, user_type),
            )
            user_id = cursor.lastrowid

            # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
            if user_type in {"paciente", "responsavel"}:
                cursor.execute(
                    """
                    INSERT INTO pacientes (cpf, nome, data_nascimento, cpf_responsavel)
                    VALUES (%s, %s, %s, %s)
                    """,
                    (cpf, name, birthdate, normalized_responsible),
                )
                patient_id = cursor.lastrowid
            else:
                patient_id = None
    except IntegrityError as error:
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if error.errno == 1062:
            message = str(error).lower()
            # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
            if "email" in message or "uk_usuarios_email" in message:
                raise BusinessRuleError("E-mail ja cadastrado em outra conta.", code="email_already_exists")
            raise BusinessRuleError("CPF ja cadastrado. Faca login.", code="cpf_already_exists")
        raise

    # Retorno padronizado para quem chamou esta função.
    return {
        "id": user_id,
        "id_paciente": patient_id,
        "cpf": cpf,
        "nome": name,
        "menor": patient_age < Config.MINOR_CONFIRMATION_AGE,
    }
