"""
Arquivo: servidor/servicos/agendamento/apoio.py

Objetivo:
    Implementar uma parte do servidor Flask do NeuroLab Center.

Como manter:
    Leia os comentários antes de alterar regras de negócio, rotas ou acesso ao banco.
    Preserve nomes em português e imports do pacote servidor.

Observação:
    Comentários foram adicionados para facilitar apresentação e manutenção.
"""

"""
NeuroLab Center - servidor/servicos/agendamento/apoio.py

Responsabilidade:
    Camada de serviços: regras de negócio e operações com pacientes, usuários e agendamentos.

Usado por:
    servidor/app.py ou outros módulos do pacote servidor.

Manutenção:
    Este comentário foi adicionado para facilitar leitura em apresentação e manutenção.
    Preserve os imports atualizados para o pacote `servidor`.
"""

# ============================================================================
# Seção consolidada
# ============================================================================
"""
NeuroLab Center — organização modular avançada
Origem: servidor/services/agendamento/helpers.py
Parte 01: executada pelo wrapper para manter compatibilidade de imports.
"""

"""NeuroLab Center — helpers de agendamento

Arquivo: servidor/services/agendamento/helpers.py

Por que existe:
    Este arquivo foi separado para reduzir tamanho dos módulos, deixar a
    navegação mais simples durante a apresentação e diminuir risco de mexer
    em uma responsabilidade e quebrar outra.
"""

import unicodedata
from datetime import date, time, timedelta

from servidor.configuracao import Config

from servidor.utilitarios.cpf import normalize_cpf
from servidor.utilitarios.datas import combine_date_time, hours_until, parse_date, parse_time
from servidor.utilitarios.erros import BusinessRuleError, NotFoundError


ACTIVE_SLOT_STATUS = ("pendente", "confirmado")


# Função _seconds: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def _seconds(value):
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if hasattr(value, "total_seconds"):
        # Retorno padronizado para quem chamou esta função.
        return int(value.total_seconds())
    # Retorno padronizado para quem chamou esta função.
    return value.hour * 3600 + value.minute * 60 + value.second


# Função _to_time: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def _to_time(value):
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if isinstance(value, time):
        # Retorno padronizado para quem chamou esta função.
        return value
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if hasattr(value, "total_seconds"):
        total = int(value.total_seconds())
        # Retorno padronizado para quem chamou esta função.
        return time(total // 3600, (total % 3600) // 60, total % 60)
    # Retorno padronizado para quem chamou esta função.
    return parse_time(value)


# Função _normalize_attendance: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def _normalize_attendance(value):
    normalized = str(value or "").strip().lower()
    normalized = "".join(
        char for char in unicodedata.normalize("NFD", normalized)
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if unicodedata.category(char) != "Mn"
    )
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if normalized not in {"convenio", "particular", "sus"}:
        raise BusinessRuleError("Tipo de atendimento invalido.", code="invalid_attendance_type")
    # Retorno padronizado para quem chamou esta função.
    return normalized


# Função _normalize_consultation_type: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def _normalize_consultation_type(value):
    normalized = str(value or "").strip().lower()
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if normalized not in {"consulta", "exame", "teleconsulta"}:
        raise BusinessRuleError("Tipo de consulta invalido.", code="invalid_consultation_type")
    # Retorno padronizado para quem chamou esta função.
    return normalized


# Função _min_hours_for_type: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def _min_hours_for_type(consultation_type):
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if consultation_type == "exame":
        # Retorno padronizado para quem chamou esta função.
        return Config.EXAM_MIN_HOURS
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if consultation_type == "teleconsulta":
        # Retorno padronizado para quem chamou esta função.
        return Config.TELECONSULTATION_MIN_HOURS
    # Retorno padronizado para quem chamou esta função.
    return Config.CONSULTATION_MIN_HOURS


# Função _cancel_min_hours_for_type: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def _cancel_min_hours_for_type(consultation_type):
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if consultation_type == "exame":
        # Retorno padronizado para quem chamou esta função.
        return Config.EXAM_CANCEL_MIN_HOURS
    # Retorno padronizado para quem chamou esta função.
    return Config.CONSULTATION_CANCEL_MIN_HOURS


# Função _get_unit: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def _get_unit(cursor, unit_id):
    cursor.execute("SELECT * FROM unidades WHERE id = %s AND ativo = TRUE", (unit_id,))
    unit = cursor.fetchone()
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if not unit:
        raise NotFoundError("Unidade nao encontrada ou inativa.", code="unit_not_found")
    # Retorno padronizado para quem chamou esta função.
    return unit


# Função _get_doctor_unit: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def _get_doctor_unit(cursor, doctor_id, unit_id):
    cursor.execute(
        """
        SELECT mu.*, m.ativo AS medico_ativo
          FROM medicos_unidades mu
          JOIN medicos m ON m.id = mu.id_medico
         WHERE mu.id_medico = %s AND mu.id_unidade = %s AND mu.ativo = TRUE
        """,
        (doctor_id, unit_id),
    )
    relation = cursor.fetchone()
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if not relation or not relation["medico_ativo"]:
        raise BusinessRuleError(
            "Medico nao atende nesta unidade.",
            code="doctor_not_available_at_unit",
        )
    # Retorno padronizado para quem chamou esta função.
    return relation


# Função _validate_unit_schedule: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def _validate_unit_schedule(unit, appointment_time):
    start = _seconds(unit["horario_ini"])
    end = _seconds(unit["horario_fim"])
    selected = _seconds(appointment_time)
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if selected < start or selected >= end:
        raise BusinessRuleError(
            "Horario fora do funcionamento da unidade.",
            code="outside_unit_hours",
        )

# ============================================================================
# Seção consolidada
# ============================================================================
"""
NeuroLab Center — organização modular avançada
Origem: servidor/services/agendamento/helpers.py
Parte 02: executada pelo wrapper para manter compatibilidade de imports.
"""

def _validate_attendance(cursor, unit, relation, attendance_type, consultation_type, health_plan_id):
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if attendance_type == "sus":
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if not unit["aceita_sus"] or not relation["aceita_sus"]:
            raise BusinessRuleError(
                "Atendimento SUS indisponivel para esta unidade ou medico.",
                code="sus_not_available",
            )
    elif attendance_type == "convenio":
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if not relation["aceita_convenio"]:
            raise BusinessRuleError(
                "Este medico nao atende convenio nesta unidade.",
                code="plan_not_available_for_doctor",
            )
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if not health_plan_id:
            raise BusinessRuleError("Informe o convenio.", code="health_plan_required")
        cursor.execute(
            """
            SELECT 1
              FROM unidades_convenios
             WHERE id_unidade = %s AND id_convenio = %s
            """,
            (unit["id"], health_plan_id),
        )
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if not cursor.fetchone():
            raise BusinessRuleError(
                "Convenio nao aceito nesta unidade.",
                code="health_plan_not_available_at_unit",
            )
    elif attendance_type == "particular" and not relation["aceita_particular"]:
        raise BusinessRuleError(
            "Atendimento particular indisponivel para este medico/unidade.",
            code="private_not_available",
        )

    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if consultation_type == "teleconsulta" and not relation["aceita_teleconsulta"]:
        raise BusinessRuleError(
            "Teleconsulta indisponivel para este medico/unidade.",
            code="teleconsultation_not_available",
        )



# Função _validate_exam_rules: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def _validate_exam_rules(cursor, consultation_type, exam_id):
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if consultation_type == "exame" and not exam_id:
        raise BusinessRuleError("Informe o exame para agendamento do tipo exame.", code="exam_required")
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if consultation_type != "exame" and exam_id:
        raise BusinessRuleError("Exame so pode ser informado quando o tipo for exame.", code="exam_not_allowed")
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if exam_id:
        cursor.execute("SELECT id, ativo FROM exames WHERE id = %s", (exam_id,))
        exam = cursor.fetchone()
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if not exam or not exam["ativo"]:
            raise BusinessRuleError("Exame nao encontrado ou inativo.", code="exam_not_available")


# Função _validate_health_plan_active: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def _validate_health_plan_active(cursor, attendance_type, health_plan_id):
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if attendance_type != "convenio" or not health_plan_id:
        return
    cursor.execute("SELECT id, ativo FROM convenios WHERE id = %s", (health_plan_id,))
    plan = cursor.fetchone()
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if not plan or not plan["ativo"]:
        raise BusinessRuleError("Convenio nao encontrado ou inativo.", code="health_plan_inactive")

# Função _validate_appointment_datetime: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def _validate_appointment_datetime(date_value, time_value, consultation_type):
    appointment_date = parse_date(date_value, "data_consulta")
    appointment_time = parse_time(time_value, "hora_consulta")
    appointment_moment = combine_date_time(date_value, time_value)
    min_hours = _min_hours_for_type(consultation_type)
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if hours_until(appointment_moment) < min_hours:
        raise BusinessRuleError(
            f"Agendamento precisa de antecedencia minima de {min_hours} hora(s).",
            code="minimum_notice_not_met",
        )
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if appointment_date > date.today() + timedelta(days=Config.APPOINTMENT_MAX_DAYS_AHEAD):
        raise BusinessRuleError(
            f"Agendamento so pode ser feito com ate {Config.APPOINTMENT_MAX_DAYS_AHEAD} dias de antecedencia.",
            code="maximum_notice_exceeded",
        )
    # Retorno padronizado para quem chamou esta função.
    return appointment_date, appointment_time


# Função _resolve_unit_id_by_cep: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def _resolve_unit_id_by_cep(cursor, cep):
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if not cep:
        # Retorno padronizado para quem chamou esta função.
        return None
    digits = "".join(char for char in str(cep) if char.isdigit())
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if len(digits) < 5:
        raise BusinessRuleError("CEP invalido para busca de unidade.", code="invalid_zip_code")
    cursor.execute(
        """
        SELECT id
          FROM unidades
         WHERE ativo = TRUE
         ORDER BY
           CASE
             WHEN cep = %s THEN 0
             WHEN LEFT(cep, 5) = LEFT(%s, 5) THEN 1
             WHEN LEFT(cep, 3) = LEFT(%s, 3) THEN 2
             ELSE 3
           END,
           nome
         LIMIT 1
        """,
        (digits[:8], digits[:8], digits[:8]),
    )
    unit = cursor.fetchone()
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if not unit:
        raise BusinessRuleError("Nenhuma unidade ativa encontrada para o CEP informado.", code="unit_not_found_by_zip")
    # Retorno padronizado para quem chamou esta função.
    return unit["id"]


# Função _ensure_slot_available: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def _ensure_slot_available(cursor, doctor_id, unit_id, appointment_date, appointment_time, ignore_id=None):
    params = [unit_id, doctor_id, appointment_date, appointment_time]
    query = """
        SELECT id
          FROM agendamentos
         WHERE id_unidade = %s
           AND id_medico = %s
           AND data_consulta = %s
           AND hora_consulta = %s
           AND status IN ('pendente', 'confirmado')
    """
    if ignore_id:
        query += " AND id <> %s"
        params.append(ignore_id)
    cursor.execute(query, tuple(params))
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if cursor.fetchone():
        raise BusinessRuleError("Horario ja ocupado.", code="slot_unavailable")

# ============================================================================
# Seção consolidada
# ============================================================================
"""
NeuroLab Center — organização modular avançada
Origem: servidor/services/agendamento/helpers.py
Parte 03: executada pelo wrapper para manter compatibilidade de imports.
"""

def _insert_event(cursor, appointment_id, event_type, cpf_author=None, detail=None):
    cursor.execute(
        """
        INSERT INTO agendamento_eventos (id_agendamento, tipo_evento, cpf_autor, detalhe)
        VALUES (%s, %s, %s, %s)
        """,
        (appointment_id, event_type, cpf_author, detail),
    )


# Função _get_appointment: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def _get_appointment(cursor, appointment_id):
    cursor.execute(
        """
        SELECT a.*, p.cpf AS cpf_paciente, p.cpf_responsavel, p.data_nascimento
          FROM agendamentos a
          JOIN pacientes p ON p.id = a.id_paciente
         WHERE a.id = %s
        """,
        (appointment_id,),
    )
    appointment = cursor.fetchone()
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if not appointment:
        raise NotFoundError("Agendamento nao encontrado.", code="appointment_not_found")
    # Retorno padronizado para quem chamou esta função.
    return appointment


# Função _validate_owner_or_responsible: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def _validate_owner_or_responsible(appointment, cpf_client, cpf_responsible=None):
    client = normalize_cpf(cpf_client, "cpf_cliente")
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if appointment["cpf_paciente"] == client:
        # Retorno padronizado para quem chamou esta função.
        return client

    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if cpf_responsible:
        responsible = normalize_cpf(cpf_responsible, "cpf_responsavel")
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if appointment["cpf_responsavel"] == responsible:
            # Retorno padronizado para quem chamou esta função.
            return responsible

    raise BusinessRuleError(
        "Agendamento nao pertence a este CPF.",
        code="appointment_owner_mismatch",
        status_code=403,
    )
