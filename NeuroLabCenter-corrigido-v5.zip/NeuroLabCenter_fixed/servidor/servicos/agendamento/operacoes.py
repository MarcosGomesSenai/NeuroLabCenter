"""
Arquivo: servidor/servicos/agendamento/operacoes.py

Objetivo:
    Implementar uma parte do servidor Flask do NeuroLab Center.

Como manter:
    Leia os comentários antes de alterar regras de negócio, rotas ou acesso ao banco.
    Preserve nomes em português e imports do pacote servidor.

Observação:
    Comentários foram adicionados para facilitar apresentação e manutenção.
"""

"""
NeuroLab Center - servidor/servicos/agendamento/operacoes.py

Responsabilidade:
    Camada de serviços: regras de negócio e operações com pacientes, usuários e agendamentos.

Usado por:
    servidor/app.py ou outros módulos do pacote servidor.

Manutenção:
    Este comentário foi adicionado para facilitar leitura em apresentação e manutenção.
    Preserve os imports atualizados para o pacote `servidor`.
"""

# ============================================================================
# Seção consolidada
# ============================================================================
"""
NeuroLab Center — organização modular avançada
Origem: servidor/services/agendamento/operations.py
Parte 01: executada pelo wrapper para manter compatibilidade de imports.
"""

"""NeuroLab Center — operações públicas de agendamento

Arquivo: servidor/services/agendamento/operations.py

Por que existe:
    Este arquivo foi separado para reduzir tamanho dos módulos, deixar a
    navegação mais simples durante a apresentação e diminuir risco de mexer
    em uma responsabilidade e quebrar outra.
"""

from datetime import datetime, timedelta
from uuid import uuid4

from mysql.connector import IntegrityError

from servidor.configuracao import Config
from servidor.banco_de_dados.conexao import db_cursor, fetch_all
from servidor.servicos.agendamento.apoio import (
    _cancel_min_hours_for_type,
    _ensure_slot_available,
    _get_doctor_unit,
    _get_appointment,
    _get_unit,
    _insert_event,
    _normalize_attendance,
    _normalize_consultation_type,
    _resolve_unit_id_by_cep,
    _to_time,
    _validate_appointment_datetime,
    _validate_attendance,
    _validate_exam_rules,
    _validate_health_plan_active,
    _validate_owner_or_responsible,
    _validate_unit_schedule,
)
from servidor.servicos.pacientes import (
    buscar_paciente_por_cpf,
    paciente_menor_de_idade,
    validar_vinculo_responsavel,
)
from servidor.utilitarios.cpf import normalize_cpf
from servidor.utilitarios.datas import hours_until, parse_date
from servidor.utilitarios.erros import BusinessRuleError
from servidor.utilitarios.validacoes import positive_int

# ============================================================================
# Seção consolidada
# ============================================================================
"""
NeuroLab Center — organização modular avançada
Origem: servidor/services/agendamento/operations.py
Parte 02: executada pelo wrapper para manter compatibilidade de imports.
"""

def criar_agendamento(data):
    patient = buscar_paciente_por_cpf(data.get("cpf_cliente"))
    consultation_type = _normalize_consultation_type(data.get("tipo_consulta"))
    attendance_type = _normalize_attendance(data.get("tipo_atendimento"))
    doctor_id = positive_int(data.get("id_medico"), "id_medico")
    unit_id = positive_int(data.get("id_unidade"), "id_unidade", required=False)
    health_plan_id = positive_int(data.get("id_convenio"), "id_convenio", required=False)
    exam_id = positive_int(data.get("id_exame"), "id_exame", required=False)
    observation = data.get("observacao")

    responsible = None
    pending_confirmation = paciente_menor_de_idade(patient)
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if pending_confirmation:
        responsible = validar_vinculo_responsavel(patient, data.get("cpf_responsavel"))

    appointment_date, appointment_time = _validate_appointment_datetime(
        data.get("data_consulta"),
        data.get("hora_consulta"),
        consultation_type,
    )

    token = str(uuid4()) if pending_confirmation else None
    expires_at = (
        datetime.now() + timedelta(hours=Config.RESPONSIBLE_CONFIRMATION_EXPIRES_HOURS)
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if pending_confirmation
        else None
    )
    status = "pendente" if pending_confirmation else "confirmado"

    # Bloco protegido: captura erros previsíveis sem derrubar a API.
    try:
        with db_cursor(commit=True) as cursor:
            # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
            if not unit_id and data.get("cep"):
                unit_id = _resolve_unit_id_by_cep(cursor, data.get("cep"))
            # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
            if not unit_id:
                raise BusinessRuleError("Unidade e obrigatoria quando o CEP nao for informado.", code="unit_or_zip_required")
            unit = _get_unit(cursor, unit_id)
            relation = _get_doctor_unit(cursor, doctor_id, unit_id)
            _validate_unit_schedule(unit, appointment_time)
            _validate_health_plan_active(cursor, attendance_type, health_plan_id)
            _validate_attendance(cursor, unit, relation, attendance_type, consultation_type, health_plan_id)
            _validate_exam_rules(cursor, consultation_type, exam_id)
            _ensure_slot_available(cursor, doctor_id, unit_id, appointment_date, appointment_time)

            cursor.execute(
                """
                INSERT INTO agendamentos (
                    id_paciente, id_medico, id_unidade, id_convenio, id_exame,
                    data_consulta, hora_consulta, tipo_consulta, tipo_atendimento,
                    status, observacao, cpf_responsavel_confirmacao,
                    confirmacao_token, confirmacao_expira_em, confirmado_em
                )
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                """,
                (
                    patient["id"],
                    doctor_id,
                    unit_id,
                    health_plan_id,
                    exam_id,
                    appointment_date,
                    appointment_time,
                    consultation_type,
                    attendance_type,
                    status,
                    observation,
                    responsible["cpf"] if responsible else None,
                    token,
                    expires_at,
                    datetime.now() if status == "confirmado" else None,
                ),
            )
            appointment_id = cursor.lastrowid
            _insert_event(cursor, appointment_id, "criado", patient["cpf"], f"status={status}")
    except IntegrityError as error:
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if error.errno == 1062:
            raise BusinessRuleError("Horario ja ocupado.", code="slot_unavailable")
        raise

    # Retorno padronizado para quem chamou esta função.
    return {
        "id": appointment_id,
        "status": status,
        "precisa_confirmacao_responsavel": pending_confirmation,
        "confirmacao_token": token,
        "confirmacao_expira_em": expires_at.isoformat() if expires_at else None,
    }


# Função confirmar_agendamento_responsavel: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def confirmar_agendamento_responsavel(appointment_id, data):
    responsible_cpf = normalize_cpf(data.get("cpf_responsavel"), "cpf_responsavel")
    token = data.get("confirmacao_token")
    expired = False

    with db_cursor(commit=True) as cursor:
        appointment = _get_appointment(cursor, appointment_id)
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if appointment["status"] != "pendente":
            raise BusinessRuleError("Agendamento nao esta pendente.", code="appointment_not_pending")
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if appointment["confirmacao_expira_em"] and appointment["confirmacao_expira_em"] < datetime.now():
            cursor.execute("UPDATE agendamentos SET status = 'expirado', atualizado_em = NOW() WHERE id = %s", (appointment_id,))
            _insert_event(cursor, appointment_id, "expirado", responsible_cpf, "confirmacao expirada")
            expired = True
        else:
            # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
            if appointment["confirmacao_token"] and token != appointment["confirmacao_token"]:
                raise BusinessRuleError("Token de confirmacao obrigatorio ou invalido.", code="invalid_confirmation_token", status_code=403)
            # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
            if appointment["cpf_responsavel_confirmacao"] != responsible_cpf:
                raise BusinessRuleError("CPF nao autorizado para confirmar.", code="responsible_not_authorized", status_code=403)

            cursor.execute(
                """
                UPDATE agendamentos
                   SET status = 'confirmado', confirmado_em = NOW(), atualizado_em = NOW()
                 WHERE id = %s
                """,
                (appointment_id,),
            )
            _insert_event(cursor, appointment_id, "confirmado", responsible_cpf, "confirmado pelo responsavel")

    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if expired:
        raise BusinessRuleError("Confirmacao expirada.", code="confirmation_expired")

    # Retorno padronizado para quem chamou esta função.
    return {"id": appointment_id, "status": "confirmado"}

# ============================================================================
# Seção consolidada
# ============================================================================
"""
NeuroLab Center — organização modular avançada
Origem: servidor/services/agendamento/operations.py
Parte 03: executada pelo wrapper para manter compatibilidade de imports.
"""

def consultar_confirmacao_agendamento(appointment_id, data):
    responsible_cpf = normalize_cpf(data.get("cpf_responsavel"), "cpf_responsavel")
    token = data.get("confirmacao_token")

    # Leitura inicial sem commit — evita lock desnecessário em consultas puras.
    with db_cursor() as cursor:
        appointment = _get_appointment(cursor, appointment_id)
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if appointment["cpf_responsavel_confirmacao"] != responsible_cpf:
            raise BusinessRuleError("CPF nao autorizado para este link.", code="responsible_not_authorized", status_code=403)
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if appointment["confirmacao_token"] and token != appointment["confirmacao_token"]:
            raise BusinessRuleError("Token de confirmacao obrigatorio ou invalido.", code="invalid_confirmation_token", status_code=403)

        expired = bool(
            appointment["status"] == "pendente"
            and appointment["confirmacao_expira_em"]
            and appointment["confirmacao_expira_em"] < datetime.now()
        )

    # Commit apenas quando há atualização real (caso de expiração).
    if expired:
        with db_cursor(commit=True) as cursor:
            cursor.execute("UPDATE agendamentos SET status = 'expirado', atualizado_em = NOW() WHERE id = %s", (appointment_id,))
            _insert_event(cursor, appointment_id, "expirado", responsible_cpf, "confirmacao expirada por validacao do link")

    # Retorno padronizado para quem chamou esta função.
    return {
        "id": appointment_id,
        "status": "expirado" if expired else appointment["status"],
        "cpf_responsavel": responsible_cpf,
        "pode_confirmar": appointment["status"] == "pendente" and not expired,
        "confirmacao_expira_em": appointment["confirmacao_expira_em"],
    }


# Função reagendar_agendamento: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def reagendar_agendamento(appointment_id, data):
    with db_cursor(commit=True) as cursor:
        appointment = _get_appointment(cursor, appointment_id)
        consultation_type = _normalize_consultation_type(appointment["tipo_consulta"])
        new_date, new_time = _validate_appointment_datetime(
            data.get("data_consulta"),
            data.get("hora_consulta"),
            consultation_type,
        )
        author_cpf = _validate_owner_or_responsible(
            appointment,
            data.get("cpf_cliente"),
            data.get("cpf_responsavel"),
        )
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if appointment["status"] not in {"confirmado", "pendente"}:
            raise BusinessRuleError("Apenas agendamentos ativos podem ser reagendados.", code="inactive_appointment")

        attendance_type = appointment["tipo_atendimento"]
        limit = Config.SUS_RESCHEDULE_LIMIT_30_DAYS if attendance_type == "sus" else Config.RESCHEDULE_LIMIT_30_DAYS
        cursor.execute(
            """
            SELECT COUNT(*) AS total
              FROM agendamento_eventos
             WHERE cpf_autor = %s
               AND tipo_evento = 'reagendado'
               AND criado_em >= DATE_SUB(NOW(), INTERVAL 30 DAY)
            """,
            (author_cpf,),
        )
        total = cursor.fetchone()["total"]
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if total >= limit:
            cursor.execute(
                "UPDATE agendamentos SET status = 'aprovacao_manual', atualizado_em = NOW() WHERE id = %s",
                (appointment_id,),
            )
            _insert_event(cursor, appointment_id, "reagendado", author_cpf, "limite excedido; aprovacao manual")
            # Retorno padronizado para quem chamou esta função.
            return {"id": appointment_id, "status": "aprovacao_manual", "motivo": "limite_reagendamento"}

        doctor_id = positive_int(data.get("id_medico") or appointment["id_medico"], "id_medico")
        unit_id = positive_int(data.get("id_unidade") or appointment["id_unidade"], "id_unidade")
        unit = _get_unit(cursor, unit_id)
        relation = _get_doctor_unit(cursor, doctor_id, unit_id)
        _validate_unit_schedule(unit, new_time)
        _validate_health_plan_active(cursor, attendance_type, appointment["id_convenio"])
        _validate_attendance(
            cursor,
            unit,
            relation,
            attendance_type,
            appointment["tipo_consulta"],
            appointment["id_convenio"],
        )
        _validate_exam_rules(cursor, appointment["tipo_consulta"], appointment["id_exame"])
        _ensure_slot_available(cursor, doctor_id, unit_id, new_date, new_time, ignore_id=appointment_id)

        cursor.execute(
            """
            UPDATE agendamentos
               SET id_medico = %s,
                   id_unidade = %s,
                   data_consulta = %s,
                   hora_consulta = %s,
                   reagendamentos_count = reagendamentos_count + 1,
                   ultimo_reagendamento_em = NOW(),
                   atualizado_em = NOW()
             WHERE id = %s
            """,
            (doctor_id, unit_id, new_date, new_time, appointment_id),
        )
        _insert_event(cursor, appointment_id, "reagendado", author_cpf, f"{new_date} {new_time}")

    # Retorno padronizado para quem chamou esta função.
    return {
        "id": appointment_id,
        "status": appointment["status"],
        "data_consulta": str(new_date),
        "hora_consulta": str(new_time),
    }

# ============================================================================
# Seção consolidada
# ============================================================================
"""
NeuroLab Center — organização modular avançada
Origem: servidor/services/agendamento/operations.py
Parte 04: executada pelo wrapper para manter compatibilidade de imports.
"""

def cancelar_agendamento(appointment_id, data):
    with db_cursor(commit=True) as cursor:
        appointment = _get_appointment(cursor, appointment_id)
        author_cpf = _validate_owner_or_responsible(
            appointment,
            data.get("cpf_cliente"),
            data.get("cpf_responsavel"),
        )
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if appointment["status"] not in {"confirmado", "pendente"}:
            raise BusinessRuleError("Agendamento nao pode ser cancelado neste status.", code="cannot_cancel")

        appointment_moment = datetime.combine(appointment["data_consulta"], _to_time(appointment["hora_consulta"]))
        min_hours = _cancel_min_hours_for_type(appointment["tipo_consulta"])
        new_status = "cancelado" if hours_until(appointment_moment) >= min_hours else "falta"
        event = "cancelado" if new_status == "cancelado" else "falta"

        cursor.execute(
            """
            UPDATE agendamentos
               SET status = %s, cancelado_em = NOW(), atualizado_em = NOW()
             WHERE id = %s
            """,
            (new_status, appointment_id),
        )
        _insert_event(cursor, appointment_id, event, author_cpf, data.get("motivo"))

    # Retorno padronizado para quem chamou esta função.
    return {"id": appointment_id, "status": new_status}


# Função listar_agendamentos_por_paciente: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def listar_agendamentos_por_paciente(cpf):
    normalized = normalize_cpf(cpf, "cpf_cliente")
    # Retorno padronizado para quem chamou esta função.
    return fetch_all(
        """
        SELECT a.*, p.nome AS paciente_nome, m.crm, u.nome AS unidade_nome, uu.nome AS medico_nome
          FROM agendamentos a
          JOIN pacientes p ON p.id = a.id_paciente
          JOIN medicos m ON m.id = a.id_medico
          JOIN usuarios uu ON uu.id = m.id_usuario
          JOIN unidades u ON u.id = a.id_unidade
         WHERE p.cpf = %s OR p.cpf_responsavel = %s
         ORDER BY a.data_consulta DESC, a.hora_consulta DESC
        """,
        (normalized, normalized),
    )


# Função listar_agendamentos_por_data: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def listar_agendamentos_por_data(date_value):
    appointment_date = parse_date(date_value, "data")
    # Retorno padronizado para quem chamou esta função.
    return fetch_all(
        """
        SELECT a.*, p.nome AS paciente_nome, m.crm, u.nome AS unidade_nome, uu.nome AS medico_nome
          FROM agendamentos a
          JOIN pacientes p ON p.id = a.id_paciente
          JOIN medicos m ON m.id = a.id_medico
          JOIN usuarios uu ON uu.id = m.id_usuario
          JOIN unidades u ON u.id = a.id_unidade
         WHERE a.data_consulta = %s
         ORDER BY a.hora_consulta
        """,
        (appointment_date,),
    )


# Função listar_horarios_ocupados: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def listar_horarios_ocupados(data):
    doctor_id = positive_int(data.get("id_medico"), "id_medico")
    unit_id = positive_int(data.get("id_unidade"), "id_unidade")
    appointment_date = parse_date(data.get("data"), "data")

    with db_cursor() as cursor:
        unit = _get_unit(cursor, unit_id)
        _get_doctor_unit(cursor, doctor_id, unit_id)
        cursor.execute(
            """
            SELECT hora_consulta
              FROM agendamentos
             WHERE id_medico = %s
               AND id_unidade = %s
               AND data_consulta = %s
               AND status IN ('pendente', 'confirmado')
             ORDER BY hora_consulta
            """,
            (doctor_id, unit_id, appointment_date),
        )
        occupied = [str(_to_time(row["hora_consulta"]))[:5] for row in cursor.fetchall()]

    # Retorno padronizado para quem chamou esta função.
    return {
        "id_medico": doctor_id,
        "id_unidade": unit_id,
        "data": str(appointment_date),
        "horario_ini": str(_to_time(unit["horario_ini"]))[:5],
        "horario_fim": str(_to_time(unit["horario_fim"]))[:5],
        "horarios_ocupados": occupied,
    }


create_appointment = criar_agendamento
confirm_responsible = confirmar_agendamento_responsavel
get_confirmation_status = consultar_confirmacao_agendamento
reschedule_appointment = reagendar_agendamento
cancel_appointment = cancelar_agendamento
list_by_client = listar_agendamentos_por_paciente
list_by_date = listar_agendamentos_por_data
list_unavailable_slots = listar_horarios_ocupados
