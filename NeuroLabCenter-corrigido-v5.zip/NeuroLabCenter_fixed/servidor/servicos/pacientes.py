"""
Arquivo: servidor/servicos/pacientes.py

Objetivo:
    Implementar uma parte do servidor Flask do NeuroLab Center.

Como manter:
    Leia os comentários antes de alterar regras de negócio, rotas ou acesso ao banco.
    Preserve nomes em português e imports do pacote servidor.

Observação:
    Comentários foram adicionados para facilitar apresentação e manutenção.
"""

"""
NeuroLab Center - servidor/servicos/pacientes.py

Responsabilidade:
    Camada de serviços: regras de negócio e operações com pacientes, usuários e agendamentos.

Usado por:
    servidor/app.py ou outros módulos do pacote servidor.

Manutenção:
    Este comentário foi adicionado para facilitar leitura em apresentação e manutenção.
    Preserve os imports atualizados para o pacote `servidor`.
"""

from servidor.configuracao import Config
from servidor.utilitarios.datas import age_from_birthdate
from servidor.banco_de_dados.conexao import db_cursor, fetch_one
from servidor.utilitarios.cpf import normalize_cpf
from servidor.utilitarios.erros import BusinessRuleError, NotFoundError
from servidor.utilitarios.seguranca import verify_password


# Função buscar_paciente_por_cpf: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def buscar_paciente_por_cpf(cpf):
    normalized = normalize_cpf(cpf, "cpf_paciente")
    patient = fetch_one(
        """
        SELECT p.*, u.email, u.telefone, u.ativo
          FROM pacientes p
          JOIN usuarios u ON u.cpf = p.cpf
         WHERE p.cpf = %s
        """,
        (normalized,),
    )
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if not patient:
        raise NotFoundError("Paciente nao encontrado.", code="patient_not_found")
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if not patient["ativo"]:
        raise BusinessRuleError("Paciente inativo.", code="inactive_patient")
    # Retorno padronizado para quem chamou esta função.
    return patient


# Função paciente_menor_de_idade: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def paciente_menor_de_idade(patient):
    # Retorno padronizado para quem chamou esta função.
    return age_from_birthdate(patient["data_nascimento"]) < Config.MINOR_CONFIRMATION_AGE



# Função _validar_responsavel_adulto: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def _validar_responsavel_adulto(cpf_responsavel):
    row = fetch_one("SELECT data_nascimento FROM pacientes WHERE cpf = %s", (cpf_responsavel,))
    nascimento = row.get("data_nascimento") if row else None
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if nascimento and age_from_birthdate(nascimento) < Config.MINOR_CONFIRMATION_AGE:
        raise BusinessRuleError(
            "Responsavel legal precisa ser maior de idade.",
            code="responsible_must_be_adult",
        )

# Função validar_vinculo_responsavel: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def validar_vinculo_responsavel(patient, responsible_cpf):
    responsible = normalize_cpf(responsible_cpf, "cpf_responsavel")
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if patient.get("cpf_responsavel") != responsible:
        raise BusinessRuleError(
            "CPF do responsavel nao esta vinculado a este paciente.",
            code="responsible_not_linked",
            status_code=403,
        )

    responsible_user = fetch_one(
        "SELECT id, cpf, nome, tipo_usuario, ativo FROM usuarios WHERE cpf = %s",
        (responsible,),
    )
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if not responsible_user or not responsible_user["ativo"]:
        raise BusinessRuleError("Responsavel nao cadastrado ou inativo.", code="invalid_responsible")
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if responsible_user["tipo_usuario"] not in {"responsavel", "paciente"}:
        raise BusinessRuleError(
            "CPF informado nao pertence a um usuario do tipo responsavel ou paciente.",
            code="responsible_must_have_responsible_type",
        )
    _validar_responsavel_adulto(responsible)
    # Retorno padronizado para quem chamou esta função.
    return responsible_user


# Função atualizar_responsavel_paciente: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def atualizar_responsavel_paciente(patient_cpf, data):
    patient = buscar_paciente_por_cpf(patient_cpf)
    new_responsible_cpf = normalize_cpf(data.get("novo_cpf_responsavel"), "novo_cpf_responsavel")
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if new_responsible_cpf == patient["cpf"]:
        raise BusinessRuleError(
            "Responsavel legal precisa ter CPF diferente do paciente.",
            code="responsible_must_differ",
        )

    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if patient.get("cpf_responsavel"):
        current_responsible_cpf = normalize_cpf(
            data.get("cpf_responsavel_atual"),
            "cpf_responsavel_atual",
        )
        current_password = data.get("senha_responsavel_atual")
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if patient["cpf_responsavel"] != current_responsible_cpf:
            raise BusinessRuleError(
                "CPF do responsavel atual nao confere.",
                code="current_responsible_mismatch",
                status_code=403,
            )

        current_user = fetch_one(
            "SELECT cpf, senha_hash, ativo FROM usuarios WHERE cpf = %s",
            (current_responsible_cpf,),
        )
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if not current_user or not current_user["ativo"] or not verify_password(current_password, current_user["senha_hash"]):
            raise BusinessRuleError(
                "Nova autenticacao do responsavel atual falhou.",
                code="current_responsible_auth_failed",
                status_code=403,
            )

    new_user = fetch_one(
        "SELECT cpf, tipo_usuario, ativo FROM usuarios WHERE cpf = %s",
        (new_responsible_cpf,),
    )
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if not new_user or not new_user["ativo"]:
        raise BusinessRuleError("Novo responsavel nao cadastrado ou inativo.", code="new_responsible_not_found")
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if new_user["tipo_usuario"] not in {"responsavel", "paciente"}:
        raise BusinessRuleError(
            "Novo CPF precisa ser de um usuario do tipo responsavel ou paciente.",
            code="new_responsible_must_have_responsible_type",
        )
    _validar_responsavel_adulto(new_responsible_cpf)

    with db_cursor(commit=True) as cursor:
        cursor.execute(
            """
            UPDATE pacientes
               SET cpf_responsavel = %s, atualizado_em = NOW()
             WHERE cpf = %s
            """,
            (new_responsible_cpf, patient["cpf"]),
        )

    # Retorno padronizado para quem chamou esta função.
    return {
        "cpf_paciente": patient["cpf"],
        "cpf_responsavel": new_responsible_cpf,
        "mensagem": "Responsavel atualizado com sucesso.",
    }


get_patient_by_cpf = buscar_paciente_por_cpf
is_minor = paciente_menor_de_idade
validate_responsible_link = validar_vinculo_responsavel
update_patient_responsible = atualizar_responsavel_paciente
