"""
Arquivo: servidor/servicos/avaliacoes.py

Objetivo:
    Implementar uma parte do servidor Flask do NeuroLab Center.

Como manter:
    Leia os comentários antes de alterar regras de negócio, rotas ou acesso ao banco.
    Preserve nomes em português e imports do pacote servidor.

Observação:
    Comentários foram adicionados para facilitar apresentação e manutenção.
"""

"""
NeuroLab Center - servidor/servicos/avaliacoes.py

Responsabilidade:
    Camada de serviços: regras de negócio e operações com pacientes, usuários e agendamentos.

Usado por:
    servidor/app.py ou outros módulos do pacote servidor.

Manutenção:
    Este comentário foi adicionado para facilitar leitura em apresentação e manutenção.
    Preserve os imports atualizados para o pacote `servidor`.
"""

from datetime import datetime

from mysql.connector import IntegrityError

from servidor.banco_de_dados.conexao import db_cursor, fetch_all
from servidor.servicos.agendamentos import _get_appointment, _insert_event, _to_time, _validate_owner_or_responsible
from servidor.utilitarios.erros import BusinessRuleError
from servidor.utilitarios.validacoes import positive_int


# Função create_feedback: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def create_feedback(data):
    appointment_id = positive_int(data.get("id_agendamento"), "id_agendamento")
    note = positive_int(data.get("nota"), "nota")
    comment = (data.get("comentario") or "").strip() or None
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if comment and len(comment) > 1000:
        raise BusinessRuleError("Comentario deve ter ate 1000 caracteres.", code="feedback_comment_too_long")

    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if note < 1 or note > 5:
        raise BusinessRuleError("Nota deve estar entre 1 e 5.", code="invalid_feedback_note")

    # Bloco protegido: captura erros previsíveis sem derrubar a API.
    try:
        with db_cursor(commit=True) as cursor:
            appointment = _get_appointment(cursor, appointment_id)
            author_cpf = _validate_owner_or_responsible(
                appointment,
                data.get("cpf_cliente"),
                data.get("cpf_responsavel"),
            )
            appointment_moment = datetime.combine(
                appointment["data_consulta"],
                _to_time(appointment["hora_consulta"]),
            )
            # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
            if appointment["status"] != "confirmado" or appointment_moment >= datetime.now():
                raise BusinessRuleError(
                    "Feedback so pode ser enviado apos atendimento confirmado e com data passada.",
                    code="feedback_not_available_yet",
                )

            cursor.execute(
                """
                INSERT INTO feedback (id_agendamento, nota, comentario)
                VALUES (%s, %s, %s)
                """,
                (appointment_id, note, comment),
            )
            feedback_id = cursor.lastrowid
            _insert_event(cursor, appointment_id, "feedback", author_cpf, f"nota={note}")
    except IntegrityError as error:
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if error.errno == 1062:
            raise BusinessRuleError(
                "Voce ja avaliou este agendamento.",
                code="feedback_already_exists",
            )
        raise

    # Retorno padronizado para quem chamou esta função.
    return {"id": feedback_id, "id_agendamento": appointment_id, "nota": note}


# Função doctor_average: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def doctor_average(doctor_id):
    # Retorno padronizado para quem chamou esta função.
    return fetch_all(
        """
        SELECT m.id AS id_medico,
               AVG(f.nota) AS media,
               COUNT(f.id) AS total_feedbacks
          FROM medicos m
          LEFT JOIN agendamentos a ON a.id_medico = m.id
          LEFT JOIN feedback f ON f.id_agendamento = a.id
         WHERE m.id = %s
         GROUP BY m.id
        """,
        (doctor_id,),
    )


# Função unit_average: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def unit_average(unit_id):
    # Retorno padronizado para quem chamou esta função.
    return fetch_all(
        """
        SELECT u.id AS id_unidade,
               AVG(f.nota) AS media,
               COUNT(f.id) AS total_feedbacks
          FROM unidades u
          LEFT JOIN agendamentos a ON a.id_unidade = u.id
          LEFT JOIN feedback f ON f.id_agendamento = a.id
         WHERE u.id = %s
         GROUP BY u.id
        """,
        (unit_id,),
    )


# Função doctor_comments: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def doctor_comments(doctor_id):
    # Retorno padronizado para quem chamou esta função.
    return fetch_all(
        """
        SELECT f.nota, f.comentario, f.data_feedback, p.nome AS paciente_nome
          FROM feedback f
          JOIN agendamentos a ON a.id = f.id_agendamento
          JOIN pacientes p ON p.id = a.id_paciente
         WHERE a.id_medico = %s
           AND f.comentario IS NOT NULL
           AND f.comentario <> ''
         ORDER BY f.data_feedback DESC
        """,
        (doctor_id,),
    )


# Função unit_comments: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def unit_comments(unit_id):
    # Retorno padronizado para quem chamou esta função.
    return fetch_all(
        """
        SELECT f.nota, f.comentario, f.data_feedback, p.nome AS paciente_nome
          FROM feedback f
          JOIN agendamentos a ON a.id = f.id_agendamento
          JOIN pacientes p ON p.id = a.id_paciente
         WHERE a.id_unidade = %s
           AND f.comentario IS NOT NULL
           AND f.comentario <> ''
         ORDER BY f.data_feedback DESC
        """,
        (unit_id,),
    )



# Função _validate_score: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def _validate_score(value, field_name, min_value=1, max_value=5):
    score = positive_int(value, field_name)
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if score < min_value or score > max_value:
        raise BusinessRuleError(f"{field_name} deve estar entre {min_value} e {max_value}.", code="invalid_score")
    # Retorno padronizado para quem chamou esta função.
    return score


# Função create_general_feedback: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def create_general_feedback(data):
    from servidor.utilitarios.cpf import normalize_cpf

    cpf = normalize_cpf(data.get("cpf_cliente"), "cpf_cliente")
    nota_medico = _validate_score(data.get("nota_medico"), "nota_medico")
    nota_recepcao = _validate_score(data.get("nota_recepcao"), "nota_recepcao")
    nota_agendamento = _validate_score(data.get("nota_agendamento"), "nota_agendamento")
    nps = _validate_score(data.get("nps"), "nps", 0, 10)
    comentario = (data.get("comentario") or "").strip() or None
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if comentario and len(comentario) > 1000:
        raise BusinessRuleError("Comentario deve ter ate 1000 caracteres.", code="feedback_comment_too_long")

    with db_cursor(commit=True) as cursor:
        cursor.execute("SELECT cpf FROM pacientes WHERE cpf = %s", (cpf,))
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if not cursor.fetchone():
            raise BusinessRuleError("Paciente nao encontrado para salvar avaliacao.", code="patient_not_found", status_code=404)
        cursor.execute(
            """
            INSERT INTO feedback_geral
              (cpf_paciente, nota_medico, nota_recepcao, nota_agendamento, nps, comentario, publicar)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
            """,
            (cpf, nota_medico, nota_recepcao, nota_agendamento, nps, comentario, bool(data.get("publicar"))),
        )
        feedback_id = cursor.lastrowid

    # Retorno padronizado para quem chamou esta função.
    return {"id": feedback_id, "cpf_paciente": cpf, "status": "salvo"}
