"""
Arquivo: servidor/servicos/agendamentos.py

Objetivo:
    Implementar uma parte do servidor Flask do NeuroLab Center.

Como manter:
    Leia os comentários antes de alterar regras de negócio, rotas ou acesso ao banco.
    Preserve nomes em português e imports do pacote servidor.

Observação:
    Comentários foram adicionados para facilitar apresentação e manutenção.
"""

"""
NeuroLab Center - servidor/servicos/agendamentos.py

Responsabilidade:
    Camada de serviços: regras de negócio e operações com pacientes, usuários e agendamentos.

Usado por:
    servidor/app.py ou outros módulos do pacote servidor.

Manutenção:
    Este comentário foi adicionado para facilitar leitura em apresentação e manutenção.
    Preserve os imports atualizados para o pacote `servidor`.
"""

from servidor.servicos.agendamento import (
    cancel_appointment,
    cancelar_agendamento,
    confirm_responsible,
    confirmar_agendamento_responsavel,
    consultar_confirmacao_agendamento,
    create_appointment,
    criar_agendamento,
    get_confirmation_status,
    list_by_client,
    list_by_date,
    list_unavailable_slots,
    listar_agendamentos_por_data,
    listar_agendamentos_por_paciente,
    listar_horarios_ocupados,
    reagendar_agendamento,
    reschedule_appointment,
)


# Compatibilidade: alguns serviços reutilizam funções internas de apoio do agendamento.
from servidor.servicos.agendamento.apoio import (
    _get_appointment,
    _insert_event,
    _to_time,
    _validate_owner_or_responsible,
)

__all__ = [
    "cancel_appointment",
    "cancelar_agendamento",
    "confirm_responsible",
    "confirmar_agendamento_responsavel",
    "consultar_confirmacao_agendamento",
    "create_appointment",
    "criar_agendamento",
    "get_confirmation_status",
    "list_by_client",
    "list_by_date",
    "list_unavailable_slots",
    "listar_agendamentos_por_data",
    "listar_agendamentos_por_paciente",
    "listar_horarios_ocupados",
    "reagendar_agendamento",
    "reschedule_appointment",
    "_get_appointment",
    "_insert_event",
    "_to_time",
    "_validate_owner_or_responsible",
]
