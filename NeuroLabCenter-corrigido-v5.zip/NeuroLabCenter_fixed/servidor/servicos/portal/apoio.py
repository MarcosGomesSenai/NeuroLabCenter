"""
Arquivo: servidor/servicos/portal/apoio.py

Objetivo:
    Implementar uma parte do servidor Flask do NeuroLab Center.

Como manter:
    Leia os comentários antes de alterar regras de negócio, rotas ou acesso ao banco.
    Preserve nomes em português e imports do pacote servidor.

Observação:
    Comentários foram adicionados para facilitar apresentação e manutenção.
"""

"""
NeuroLab Center - servidor/servicos/portal/apoio.py

Responsabilidade:
    Camada de serviços: regras de negócio e operações com pacientes, usuários e agendamentos.

Usado por:
    servidor/app.py ou outros módulos do pacote servidor.

Manutenção:
    Este comentário foi adicionado para facilitar leitura em apresentação e manutenção.
    Preserve os imports atualizados para o pacote `servidor`.
"""

import json

from servidor.banco_de_dados.conexao import fetch_one
from servidor.servicos.familia import assert_acesso_perfil
from servidor.utilitarios.cpf import normalize_cpf
from servidor.utilitarios.datas import age_from_birthdate
from servidor.utilitarios.erros import BusinessRuleError
from servidor.utilitarios.validacoes import (
    parse_bool,
    validate_cep,
    validate_email,
    validate_phone,
)

DATA_URI_PREFIXOS_DOCUMENTO = (
    "data:application/pdf;base64,",
    "data:image/png;base64,",
    "data:image/jpeg;base64,",
    "data:image/jpg;base64,",
    "data:image/webp;base64,",
)
DATA_URI_PREFIXOS_IMAGEM = (
    "data:image/png;base64,",
    "data:image/jpeg;base64,",
    "data:image/jpg;base64,",
    "data:image/webp;base64,",
)
CATEGORIAS_DOCUMENTO = {"documento_identidade", "pedido_medico", "encaminhamento", "exame", "laudo", "consentimento", "convenio", "outros"}
STATUS_DOCUMENTO = {"enviado", "validacao_pendente", "revisado", "salvo localmente"}
STATUS_EXAME = {"agendado", "realizado", "pendente", "cancelado", "em analise", "em análise"}
FORMULARIOS_PERMITIDOS = {"dados_cadastrais", "preconsulta_completa", "checkin", "preferencias_visuais"}
MAX_DOCUMENTO_BYTES = 5 * 1024 * 1024
MAX_FOTO_BYTES = 2 * 1024 * 1024


# Função _primeiro_valor_presente: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def _primeiro_valor_presente(dados, *chaves):
    """Retorna o primeiro campo realmente enviado, preservando False/0/"false".

    Usar ``a or b`` em booleanos causa erro de regra de negócio, porque
    ``False`` pode ser trocado por outro campo verdadeiro.
    """
    for chave in chaves:
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if isinstance(dados, dict) and chave in dados:
            # Retorno padronizado para quem chamou esta função.
            return dados.get(chave)
    # Retorno padronizado para quem chamou esta função.
    return None

# Função _resolver_perfil_cpf: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def _resolver_perfil_cpf(cpf_titular, perfil_cpf=None):
    alvo = normalize_cpf(perfil_cpf or cpf_titular, "cpf_perfil")
    assert_acesso_perfil(cpf_titular, alvo)
    # Retorno padronizado para quem chamou esta função.
    return alvo


# Função _valor_texto: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def _valor_texto(dados, chave, limite=3000):
    # Retorno padronizado para quem chamou esta função.
    return str((dados or {}).get(chave) or "").strip()[:limite]


# Função _validar_tipo_formulario: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def _validar_tipo_formulario(tipo):
    tipo_normalizado = (tipo or "").strip().lower().replace("-", "_")
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if tipo_normalizado not in FORMULARIOS_PERMITIDOS:
        raise BusinessRuleError("Tipo de formulario invalido.", code="invalid_form_type")
    # Retorno padronizado para quem chamou esta função.
    return tipo_normalizado


# Função _idade_paciente: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def _idade_paciente(cpf):
    row = fetch_one("SELECT data_nascimento FROM pacientes WHERE cpf = %s", (cpf,))
    nascimento = row.get("data_nascimento") if row else None
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if not nascimento:
        # Retorno padronizado para quem chamou esta função.
        return None
    # Retorno padronizado para quem chamou esta função.
    return age_from_birthdate(nascimento)


# Função _paciente_menor: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def _paciente_menor(cpf):
    idade = _idade_paciente(cpf)
    # Retorno padronizado para quem chamou esta função.
    return idade is not None and idade < 18


# Função _limpar_json_formulario: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def _limpar_json_formulario(dados):
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if not isinstance(dados, dict):
        raise BusinessRuleError("Dados do formulario precisam ser um objeto.", code="invalid_form_payload")
    dados_limpos = {}
    # Laço de repetição: percorre registros ou dados recebidos do sistema.
    for chave, valor in dados.items():
        chave_limpa = str(chave).strip()[:80]
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if not chave_limpa:
            continue
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if isinstance(valor, str):
            dados_limpos[chave_limpa] = valor.strip()[:3000]
        elif isinstance(valor, (bool, int, float)) or valor is None:
            dados_limpos[chave_limpa] = valor
        elif isinstance(valor, list):
            dados_limpos[chave_limpa] = [str(item)[:300] for item in valor[:30]]
        else:
            dados_limpos[chave_limpa] = str(valor)[:3000]
    # Retorno padronizado para quem chamou esta função.
    return dados_limpos


# Função _salvar_json_formulario: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def _salvar_json_formulario(cursor, cpf, tipo_formulario, dados_limpos):
    cursor.execute(
        """
        INSERT INTO formularios_paciente (cpf_paciente, tipo_formulario, dados_json)
        VALUES (%s, %s, %s)
        ON DUPLICATE KEY UPDATE
            dados_json = VALUES(dados_json),
            atualizado_em = NOW()
        """,
        (cpf, tipo_formulario, json.dumps(dados_limpos, ensure_ascii=False)),
    )


# Função _validar_dados_formulario: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def _validar_dados_formulario(cpf, tipo_formulario, dados):
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if tipo_formulario == "dados_cadastrais":
        email = validate_email(dados.get("email"), required=False) if dados.get("email") else None
        telefone = validate_phone(dados.get("telefone"), required=False) if dados.get("telefone") else None
        validate_cep(dados.get("cep"), required=False)
        emergencia_nome = _valor_texto(dados, "emergencia_nome", 120)
        emergencia_telefone = validate_phone(dados.get("emergencia_telefone"), required=False) if dados.get("emergencia_telefone") else None
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if bool(emergencia_nome) != bool(emergencia_telefone):
            raise BusinessRuleError("Informe nome e telefone do contato de emergencia.", code="missing_emergency_pair")
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if _paciente_menor(cpf) and not (emergencia_nome and emergencia_telefone):
            raise BusinessRuleError(
                "Pacientes menores de 18 anos precisam de contato de emergencia/responsavel.",
                code="minor_requires_emergency_contact",
            )
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if email:
            existente = fetch_one(
                "SELECT cpf FROM usuarios WHERE email = %s AND ativo = TRUE AND cpf <> %s LIMIT 1",
                (email, cpf),
            )
            # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
            if existente:
                raise BusinessRuleError("E-mail ja cadastrado em outra conta.", code="email_already_exists")
        # Retorno padronizado para quem chamou esta função.
        return {"email": email, "telefone": telefone}

    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if tipo_formulario == "preconsulta_completa":
        sem_queixas = parse_bool(dados.get("sem_queixas"), default=False, field_name="sem_queixas")
        consentimento = parse_bool(
            _primeiro_valor_presente(dados, "consentimento_triagem", "consentimento"),
            default=False,
            field_name="consentimento_triagem",
        )
        sintomas = _valor_texto(dados, "sintomas", 3000)
        observacoes = _valor_texto(dados, "observacoes", 5000)
        medicamentos = _valor_texto(dados, "medicamentos", 3000)
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if not consentimento:
            raise BusinessRuleError("Confirme o consentimento da pre-consulta antes de enviar.", code="missing_preconsult_consent")
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if not sem_queixas and not (sintomas or observacoes or medicamentos):
            raise BusinessRuleError("Descreva os sintomas ou marque que nao ha queixas atuais.", code="empty_preconsult")

    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if tipo_formulario == "preferencias_visuais":
        horario = _valor_texto(dados, "horario_preferido", 80)
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if len(horario) > 80:
            raise BusinessRuleError("Horario preferido muito longo.", code="invalid_preference")

    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if tipo_formulario == "checkin":
        status = _valor_texto(dados, "status", 60).lower()
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if status and status not in {"qr code liberado", "rascunho", "confirmado"}:
            raise BusinessRuleError("Status de check-in invalido.", code="invalid_checkin_status")

    # Retorno padronizado para quem chamou esta função.
    return {}
