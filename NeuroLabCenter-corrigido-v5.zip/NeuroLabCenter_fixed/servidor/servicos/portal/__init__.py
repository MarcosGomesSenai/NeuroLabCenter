"""
Arquivo: servidor/servicos/portal/__init__.py

Objetivo:
    Implementar uma parte do servidor Flask do NeuroLab Center.

Como manter:
    Leia os comentários antes de alterar regras de negócio, rotas ou acesso ao banco.
    Preserve nomes em português e imports do pacote servidor.

Observação:
    Comentários foram adicionados para facilitar apresentação e manutenção.
"""

"""
NeuroLab Center - servidor/servicos/portal/__init__.py

Responsabilidade:
    Camada de serviços: regras de negócio e operações com pacientes, usuários e agendamentos.

Usado por:
    servidor/app.py ou outros módulos do pacote servidor.

Manutenção:
    Este comentário foi adicionado para facilitar leitura em apresentação e manutenção.
    Preserve os imports atualizados para o pacote `servidor`.
"""

from servidor.servicos.portal.painel import obter_painel
from servidor.servicos.portal.documentos import (
    criar_documento,
    listar_documentos,
    obter_documento,
    remover_documento,
)
from servidor.servicos.portal.formularios import (
    listar_exames,
    obter_formulario,
    obter_preconsulta,
    obter_preferencias,
    salvar_exame,
    salvar_formulario,
    salvar_foto_perfil,
    salvar_preconsulta,
    salvar_preferencias,
)

__all__ = [
    "criar_documento",
    "listar_documentos",
    "listar_exames",
    "obter_documento",
    "obter_formulario",
    "obter_painel",
    "obter_preconsulta",
    "obter_preferencias",
    "remover_documento",
    "salvar_exame",
    "salvar_formulario",
    "salvar_foto_perfil",
    "salvar_preconsulta",
    "salvar_preferencias",
]
