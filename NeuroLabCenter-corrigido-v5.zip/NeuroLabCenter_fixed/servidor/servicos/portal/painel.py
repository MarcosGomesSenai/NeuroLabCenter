"""
Arquivo: servidor/servicos/portal/painel.py

Objetivo:
    Implementar uma parte do servidor Flask do NeuroLab Center.

Como manter:
    Leia os comentários antes de alterar regras de negócio, rotas ou acesso ao banco.
    Preserve nomes em português e imports do pacote servidor.

Observação:
    Comentários foram adicionados para facilitar apresentação e manutenção.
"""

"""
NeuroLab Center - servidor/servicos/portal/painel.py

Responsabilidade:
    Camada de serviços: regras de negócio e operações com pacientes, usuários e agendamentos.

Usado por:
    servidor/app.py ou outros módulos do pacote servidor.

Manutenção:
    Este comentário foi adicionado para facilitar leitura em apresentação e manutenção.
    Preserve os imports atualizados para o pacote `servidor`.
"""

from servidor.banco_de_dados.conexao import fetch_all
from servidor.servicos.familia import listar_perfis_acessiveis
from servidor.servicos.pacientes import buscar_paciente_por_cpf
from servidor.servicos.portal.documentos import listar_documentos
from servidor.servicos.portal.formularios import (
    listar_exames,
    obter_preconsulta,
    obter_preferencias,
)
from servidor.servicos.portal.apoio import _resolver_perfil_cpf


# Função obter_painel: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def obter_painel(cpf_titular, perfil_cpf=None):
    cpf = _resolver_perfil_cpf(cpf_titular, perfil_cpf)
    paciente = buscar_paciente_por_cpf(cpf)

    agendamentos = fetch_all(
        """
        SELECT a.id, a.data_consulta, a.hora_consulta, a.tipo_consulta, a.tipo_atendimento,
               a.status, m.especialidade, u.nome AS unidade_nome,
               um.nome AS medico_nome
          FROM agendamentos a
          JOIN pacientes p ON p.id = a.id_paciente
          JOIN medicos m ON m.id = a.id_medico
          JOIN usuarios um ON um.id = m.id_usuario
          JOIN unidades u ON u.id = a.id_unidade
         WHERE p.cpf = %s
         ORDER BY a.data_consulta DESC, a.hora_consulta DESC
         LIMIT 20
        """,
        (cpf,),
    )

    documentos = listar_documentos(cpf_titular, cpf)
    preconsulta = obter_preconsulta(cpf_titular, cpf)
    exames = listar_exames(cpf_titular, cpf)
    preferencias = obter_preferencias(cpf_titular, cpf)
    perfis = listar_perfis_acessiveis(cpf_titular)

    # Retorno padronizado para quem chamou esta função.
    return {
        "perfil_ativo": {
            "cpf": paciente["cpf"],
            "nome": paciente["nome"],
            "email": paciente.get("email"),
            "telefone": paciente.get("telefone"),
            "data_nascimento": paciente.get("data_nascimento"),
            "foto_perfil": paciente.get("foto_perfil"),
        },
        "agendamentos": agendamentos,
        "documentos": documentos,
        "preconsulta": preconsulta,
        "exames": exames,
        "preferencias": preferencias,
        "perfis_familia": perfis,
        "kpis": {
            "agendamentos": len(agendamentos),
            "documentos": len(documentos),
            "perfis_familia": len(perfis),
        },
    }
