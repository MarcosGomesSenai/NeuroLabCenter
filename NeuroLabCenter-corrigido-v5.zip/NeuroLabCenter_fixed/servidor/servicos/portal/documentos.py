"""
Arquivo: servidor/servicos/portal/documentos.py

Objetivo:
    Implementar uma parte do servidor Flask do NeuroLab Center.

Como manter:
    Leia os comentários antes de alterar regras de negócio, rotas ou acesso ao banco.
    Preserve nomes em português e imports do pacote servidor.

Observação:
    Comentários foram adicionados para facilitar apresentação e manutenção.
"""

"""
NeuroLab Center - servidor/servicos/portal/documentos.py

Responsabilidade:
    Camada de serviços: regras de negócio e operações com pacientes, usuários e agendamentos.

Usado por:
    servidor/app.py ou outros módulos do pacote servidor.

Manutenção:
    Este comentário foi adicionado para facilitar leitura em apresentação e manutenção.
    Preserve os imports atualizados para o pacote `servidor`.
"""

from servidor.banco_de_dados.conexao import db_cursor, fetch_all, fetch_one
from servidor.servicos.portal.apoio import (
    CATEGORIAS_DOCUMENTO,
    DATA_URI_PREFIXOS_DOCUMENTO,
    MAX_DOCUMENTO_BYTES,
    STATUS_DOCUMENTO,
    _primeiro_valor_presente,
    _resolver_perfil_cpf,
)
from servidor.utilitarios.erros import BusinessRuleError, NotFoundError
from servidor.utilitarios.validacoes import parse_bool, validate_data_uri_base64


# Função listar_documentos: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def listar_documentos(cpf_titular, perfil_cpf=None):
    cpf = _resolver_perfil_cpf(cpf_titular, perfil_cpf)
    # Retorno padronizado para quem chamou esta função.
    return fetch_all(
        """
        SELECT id, nome_arquivo, tipo_arquivo, status, criado_em,
               categoria, tamanho_kb, consentimento_lgpd,
               CASE WHEN conteudo_base64 IS NULL OR conteudo_base64 = '' THEN 0 ELSE 1 END AS tem_conteudo
          FROM documentos_paciente
         WHERE cpf_paciente = %s
         ORDER BY criado_em DESC
        """,
        (cpf,),
    ) or []


# Função obter_documento: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def obter_documento(cpf_titular, perfil_cpf, doc_id):
    cpf = _resolver_perfil_cpf(cpf_titular, perfil_cpf)
    row = fetch_one(
        """
        SELECT id, nome_arquivo, tipo_arquivo, categoria, tamanho_kb, status, conteudo_base64, criado_em
          FROM documentos_paciente
         WHERE id = %s AND cpf_paciente = %s
        """,
        (doc_id, cpf),
    )
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if not row:
        raise NotFoundError("Documento nao encontrado.", code="document_not_found")
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if not row.get("conteudo_base64"):
        raise BusinessRuleError("Documento sem arquivo salvo para visualizacao.", code="document_without_content")
    # Retorno padronizado para quem chamou esta função.
    return row


# Função criar_documento: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def criar_documento(cpf_titular, perfil_cpf, data):
    cpf = _resolver_perfil_cpf(cpf_titular, perfil_cpf)
    nome = (data.get("nome_arquivo") or data.get("nome") or "").strip()
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if not nome:
        raise BusinessRuleError("Nome do documento obrigatorio.", code="missing_filename")
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if len(nome) > 180:
        raise BusinessRuleError("Nome do documento muito longo.", code="filename_too_long")

    categoria = (data.get("categoria") or "").strip().lower()
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if not categoria:
        raise BusinessRuleError("Categoria do documento obrigatoria.", code="missing_document_category")
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if categoria not in CATEGORIAS_DOCUMENTO:
        raise BusinessRuleError("Categoria de documento invalida.", code="invalid_document_category")

    consentimento = parse_bool(
        _primeiro_valor_presente(data, "consentimento", "consentimento_lgpd", "consentiu"),
        default=False,
        field_name="consentimento_lgpd",
    )
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if not consentimento:
        raise BusinessRuleError("Confirme a autorizacao/LGPD para enviar o documento.", code="missing_document_consent")

    conteudo = data.get("conteudo_base64") or ""
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if not conteudo:
        raise BusinessRuleError("Arquivo do documento obrigatorio para permitir visualizacao.", code="missing_document_content")
    raw = validate_data_uri_base64(conteudo, DATA_URI_PREFIXOS_DOCUMENTO, MAX_DOCUMENTO_BYTES, "document")

    tipo_informado = (data.get("tipo_arquivo") or data.get("tipo") or "").strip()[:40]
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if str(conteudo).lower().startswith("data:application/pdf"):
        tipo_detectado = "pdf"
    else:
        tipo_detectado = "imagem"
    tipo = tipo_informado or tipo_detectado
    status = (data.get("status") or "enviado").strip().lower()[:40]
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if status not in STATUS_DOCUMENTO:
        status = "enviado"
    tamanho_kb = max(1, round(len(raw) / 1024))

    with db_cursor(commit=True) as cursor:
        cursor.execute(
            """
            INSERT INTO documentos_paciente (
                cpf_paciente, nome_arquivo, tipo_arquivo, categoria, tamanho_kb,
                consentimento_lgpd, status, conteudo_base64
            )
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
            """,
            (cpf, nome, tipo, categoria, tamanho_kb, True, status, conteudo),
        )
        doc_id = cursor.lastrowid

    # Retorno padronizado para quem chamou esta função.
    return {
        "id": doc_id,
        "nome_arquivo": nome,
        "tipo_arquivo": tipo,
        "categoria": categoria,
        "tamanho_kb": tamanho_kb,
        "status": status,
        "tem_conteudo": 1,
    }


# Função remover_documento: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def remover_documento(cpf_titular, perfil_cpf, doc_id):
    cpf = _resolver_perfil_cpf(cpf_titular, perfil_cpf)
    with db_cursor(commit=True) as cursor:
        cursor.execute(
            "DELETE FROM documentos_paciente WHERE id = %s AND cpf_paciente = %s",
            (doc_id, cpf),
        )
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if cursor.rowcount == 0:
            raise NotFoundError("Documento nao encontrado.", code="document_not_found")
    # Retorno padronizado para quem chamou esta função.
    return {"id": doc_id, "removido": True}
