"""
Arquivo: servidor/servicos/portal/formularios.py

Objetivo:
    Implementar uma parte do servidor Flask do NeuroLab Center.

Como manter:
    Leia os comentários antes de alterar regras de negócio, rotas ou acesso ao banco.
    Preserve nomes em português e imports do pacote servidor.

Observação:
    Comentários foram adicionados para facilitar apresentação e manutenção.
"""

"""
NeuroLab Center - servidor/servicos/portal/formularios.py

Responsabilidade:
    Camada de serviços: regras de negócio e operações com pacientes, usuários e agendamentos.

Usado por:
    servidor/app.py ou outros módulos do pacote servidor.

Manutenção:
    Este comentário foi adicionado para facilitar leitura em apresentação e manutenção.
    Preserve os imports atualizados para o pacote `servidor`.
"""

# ============================================================================
# Seção consolidada
# ============================================================================
"""
NeuroLab Center — organização modular avançada
Origem: servidor/services/portal/forms.py
Parte 01: executada pelo wrapper para manter compatibilidade de imports.
"""

"""NeuroLab Center — formulários, exames, preferências e foto

Arquivo: servidor/services/portal/forms.py

Por que existe:
    Este módulo separa a Área do Paciente em responsabilidades menores.
    A divisão reduz arquivos grandes e facilita explicar o fluxo na apresentação.
"""

import json

from servidor.banco_de_dados.conexao import db_cursor, fetch_all, fetch_one
from servidor.servicos.portal.apoio import (
    DATA_URI_PREFIXOS_IMAGEM,
    MAX_FOTO_BYTES,
    STATUS_EXAME,
    _limpar_json_formulario,
    _primeiro_valor_presente,
    _resolver_perfil_cpf,
    _salvar_json_formulario,
    _validar_dados_formulario,
    _validar_tipo_formulario,
    _valor_texto,
)
from servidor.utilitarios.datas import parse_date
from servidor.utilitarios.erros import BusinessRuleError, NotFoundError
from servidor.utilitarios.validacoes import parse_bool, validate_data_uri_base64


# Função obter_preconsulta: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def obter_preconsulta(cpf_titular, perfil_cpf=None):
    cpf = _resolver_perfil_cpf(cpf_titular, perfil_cpf)
    row = fetch_one(
        "SELECT sintomas, medicamentos, observacoes, sem_queixas, consentimento_triagem, atualizado_em FROM preconsulta_paciente WHERE cpf_paciente = %s",
        (cpf,),
    )
    # Retorno padronizado para quem chamou esta função.
    return row or {"sintomas": "", "medicamentos": "", "observacoes": "", "sem_queixas": False}


# Função salvar_preconsulta: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def salvar_preconsulta(cpf_titular, perfil_cpf, data):
    cpf = _resolver_perfil_cpf(cpf_titular, perfil_cpf)
    sintomas = _valor_texto(data, "sintomas", 3000)
    medicamentos = _valor_texto(data, "medicamentos", 3000)
    observacoes = _valor_texto(data, "observacoes", 5000)
    sem_queixas = parse_bool(data.get("sem_queixas"), default=False, field_name="sem_queixas")
    consentimento = parse_bool(
        _primeiro_valor_presente(data, "consentimento_triagem", "consentimento"),
        default=False,
        field_name="consentimento_triagem",
    )

    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if not sem_queixas and not (sintomas or medicamentos or observacoes):
        raise BusinessRuleError("Pre-consulta vazia. Informe sintomas, medicamentos, observacoes ou marque sem queixas.", code="empty_preconsult")
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if not consentimento:
        raise BusinessRuleError("Confirme o consentimento da pre-consulta antes de enviar.", code="missing_preconsult_consent")

    dados_completos = _limpar_json_formulario({**data, "sem_queixas": sem_queixas, "consentimento_triagem": consentimento})
    with db_cursor(commit=True) as cursor:
        cursor.execute(
            """
            INSERT INTO preconsulta_paciente (
                cpf_paciente, sintomas, medicamentos, observacoes, sem_queixas, consentimento_triagem
            )
            VALUES (%s, %s, %s, %s, %s, %s)
            ON DUPLICATE KEY UPDATE
                sintomas = VALUES(sintomas),
                medicamentos = VALUES(medicamentos),
                observacoes = VALUES(observacoes),
                sem_queixas = VALUES(sem_queixas),
                consentimento_triagem = VALUES(consentimento_triagem),
                atualizado_em = NOW()
            """,
            (cpf, sintomas, medicamentos, observacoes, sem_queixas, consentimento),
        )
        _salvar_json_formulario(cursor, cpf, "preconsulta_completa", dados_completos)

    # Retorno padronizado para quem chamou esta função.
    return obter_preconsulta(cpf_titular, cpf)


# Função listar_exames: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def listar_exames(cpf_titular, perfil_cpf=None):
    cpf = _resolver_perfil_cpf(cpf_titular, perfil_cpf)
    # Retorno padronizado para quem chamou esta função.
    return fetch_all(
        """
        SELECT id, nome, status, preparo, data_referencia, criado_em, atualizado_em
          FROM exames_paciente
         WHERE cpf_paciente = %s
         ORDER BY atualizado_em DESC
        """,
        (cpf,),
    ) or []

# ============================================================================
# Seção consolidada
# ============================================================================
"""
NeuroLab Center — organização modular avançada
Origem: servidor/services/portal/forms.py
Parte 02: executada pelo wrapper para manter compatibilidade de imports.
"""

def salvar_exame(cpf_titular, perfil_cpf, data):
    cpf = _resolver_perfil_cpf(cpf_titular, perfil_cpf)
    nome = (data.get("nome") or "").strip()
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if not nome:
        raise BusinessRuleError("Nome do exame obrigatorio.", code="missing_exam_name")
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if len(nome) > 120:
        raise BusinessRuleError("Nome do exame muito longo.", code="exam_name_too_long")
    status = (data.get("status") or "Agendado").strip()
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if status.lower() not in STATUS_EXAME:
        raise BusinessRuleError("Status do exame invalido.", code="invalid_exam_status")
    data_referencia = (data.get("data_referencia") or "").strip()
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if data_referencia:
        parse_date(data_referencia[:10], "data_referencia")

    with db_cursor(commit=True) as cursor:
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if data.get("id"):
            cursor.execute(
                """
                UPDATE exames_paciente
                   SET nome = %s, status = %s, preparo = %s, data_referencia = %s, atualizado_em = NOW()
                 WHERE id = %s AND cpf_paciente = %s
                """,
                (nome, status, data.get("preparo") or "", data_referencia, data["id"], cpf),
            )
            # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
            if cursor.rowcount == 0:
                raise NotFoundError("Exame nao encontrado para este paciente.", code="exam_not_found")
            exam_id = data["id"]
        else:
            cursor.execute(
                """
                INSERT INTO exames_paciente (cpf_paciente, nome, status, preparo, data_referencia)
                VALUES (%s, %s, %s, %s, %s)
                """,
                (cpf, nome, status, data.get("preparo") or "", data_referencia),
            )
            exam_id = cursor.lastrowid

    # Retorno padronizado para quem chamou esta função.
    return {"id": exam_id, "nome": nome, "status": status}


# Função obter_preferencias: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def obter_preferencias(cpf_titular, perfil_cpf=None):
    cpf = _resolver_perfil_cpf(cpf_titular, perfil_cpf)
    row = fetch_one(
        "SELECT whatsapp, email, sms, atualizado_em FROM preferencias_paciente WHERE cpf_paciente = %s",
        (cpf,),
    )
    preferencias = row or {"whatsapp": True, "email": True, "sms": False}
    # Retorno padronizado para quem chamou esta função.
    return {
        **preferencias,
        "whatsapp": bool(preferencias.get("whatsapp")),
        "email": bool(preferencias.get("email")),
        "sms": bool(preferencias.get("sms")),
    }


# Função salvar_preferencias: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def salvar_preferencias(cpf_titular, perfil_cpf, data):
    cpf = _resolver_perfil_cpf(cpf_titular, perfil_cpf)
    whatsapp = parse_bool(data.get("whatsapp"), default=True, field_name="whatsapp")
    email = parse_bool(data.get("email"), default=True, field_name="email")
    sms = parse_bool(data.get("sms"), default=False, field_name="sms")

    with db_cursor(commit=True) as cursor:
        cursor.execute(
            """
            INSERT INTO preferencias_paciente (cpf_paciente, whatsapp, email, sms)
            VALUES (%s, %s, %s, %s)
            ON DUPLICATE KEY UPDATE
                whatsapp = VALUES(whatsapp),
                email = VALUES(email),
                sms = VALUES(sms),
                atualizado_em = NOW()
            """,
            (cpf, whatsapp, email, sms),
        )

    # Retorno padronizado para quem chamou esta função.
    return obter_preferencias(cpf_titular, cpf)


# Função salvar_foto_perfil: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def salvar_foto_perfil(cpf_titular, perfil_cpf, foto_base64):
    cpf = _resolver_perfil_cpf(cpf_titular, perfil_cpf)
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if foto_base64:
        validate_data_uri_base64(foto_base64, DATA_URI_PREFIXOS_IMAGEM, MAX_FOTO_BYTES, "profile_photo")
    with db_cursor(commit=True) as cursor:
        cursor.execute(
            "UPDATE pacientes SET foto_perfil = %s, atualizado_em = NOW() WHERE cpf = %s",
            (foto_base64 or None, cpf),
        )
    # Retorno padronizado para quem chamou esta função.
    return {"cpf": cpf, "foto_salva": bool(foto_base64)}


# Função obter_formulario: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def obter_formulario(cpf_titular, perfil_cpf, tipo):
    cpf = _resolver_perfil_cpf(cpf_titular, perfil_cpf)
    tipo_formulario = _validar_tipo_formulario(tipo)
    row = fetch_one(
        """
        SELECT tipo_formulario, dados_json, atualizado_em
          FROM formularios_paciente
         WHERE cpf_paciente = %s AND tipo_formulario = %s
        """,
        (cpf, tipo_formulario),
    )
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if not row:
        # Retorno padronizado para quem chamou esta função.
        return {"tipo_formulario": tipo_formulario, "dados": {}, "atualizado_em": None}
    # Bloco protegido: captura erros previsíveis sem derrubar a API.
    try:
        dados = json.loads(row.get("dados_json") or "{}")
    except json.JSONDecodeError:
        dados = {}
    # Retorno padronizado para quem chamou esta função.
    return {"tipo_formulario": tipo_formulario, "dados": dados, "atualizado_em": row.get("atualizado_em")}

# ============================================================================
# Seção consolidada
# ============================================================================
"""
NeuroLab Center — organização modular avançada
Origem: servidor/services/portal/forms.py
Parte 03: executada pelo wrapper para manter compatibilidade de imports.
"""

def salvar_formulario(cpf_titular, perfil_cpf, tipo, dados):
    cpf = _resolver_perfil_cpf(cpf_titular, perfil_cpf)
    tipo_formulario = _validar_tipo_formulario(tipo)
    dados_limpos = _limpar_json_formulario(dados)
    atualizacoes = _validar_dados_formulario(cpf, tipo_formulario, dados_limpos)

    with db_cursor(commit=True) as cursor:
        _salvar_json_formulario(cursor, cpf, tipo_formulario, dados_limpos)
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if tipo_formulario == "dados_cadastrais":
            # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
            if atualizacoes.get("email") or atualizacoes.get("telefone"):
                cursor.execute(
                    """
                    UPDATE usuarios
                       SET email = COALESCE(%s, email),
                           telefone = COALESCE(%s, telefone)
                     WHERE cpf = %s
                    """,
                    (atualizacoes.get("email"), atualizacoes.get("telefone"), cpf),
                )

    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if tipo_formulario == "preconsulta_completa":
        # Mantem a tabela resumida de pre-consulta sincronizada com o formulario completo.
        return salvar_preconsulta(cpf_titular, cpf, dados_limpos)
    # Retorno padronizado para quem chamou esta função.
    return obter_formulario(cpf_titular, cpf, tipo_formulario)
