"""
Arquivo: servidor/modelos/entidades.py

Objetivo:
    Implementar uma parte do servidor Flask do NeuroLab Center.

Como manter:
    Leia os comentários antes de alterar regras de negócio, rotas ou acesso ao banco.
    Preserve nomes em português e imports do pacote servidor.

Observação:
    Comentários foram adicionados para facilitar apresentação e manutenção.
"""

"""
NeuroLab Center - servidor/modelos/entidades.py

Responsabilidade:
    Modelos e estruturas de domínio usados pelo servidor.

Usado por:
    servidor/app.py ou outros módulos do pacote servidor.

Manutenção:
    Este comentário foi adicionado para facilitar leitura em apresentação e manutenção.
    Preserve os imports atualizados para o pacote `servidor`.
"""

from dataclasses import dataclass
from datetime import date, time
from typing import Optional


@dataclass(frozen=True)
# Classe AppointmentRequest: representa uma estrutura reutilizável pelo backend.
class AppointmentRequest:
    cpf_cliente: str
    id_medico: int
    id_unidade: int
    data_consulta: date
    hora_consulta: time
    tipo_consulta: str
    tipo_atendimento: str
    cpf_responsavel: Optional[str] = None
    id_convenio: Optional[int] = None
    id_exame: Optional[int] = None
