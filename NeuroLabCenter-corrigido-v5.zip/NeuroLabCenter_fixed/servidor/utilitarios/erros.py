"""
Arquivo: servidor/utilitarios/erros.py

Objetivo:
    Implementar uma parte do servidor Flask do NeuroLab Center.

Como manter:
    Leia os comentários antes de alterar regras de negócio, rotas ou acesso ao banco.
    Preserve nomes em português e imports do pacote servidor.

Observação:
    Comentários foram adicionados para facilitar apresentação e manutenção.
"""

"""
NeuroLab Center - servidor/utilitarios/erros.py

Responsabilidade:
    Funções auxiliares do servidor, como validação, CPF, datas, segurança e respostas.

Usado por:
    servidor/app.py ou outros módulos do pacote servidor.

Manutenção:
    Este comentário foi adicionado para facilitar leitura em apresentação e manutenção.
    Preserve os imports atualizados para o pacote `servidor`.
"""

class BusinessRuleError(Exception):
    status_code = 400
    code = "business_rule_error"

    # Função __init__: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
    def __init__(self, message, code=None, status_code=None):
        super().__init__(message)
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if code:
            self.code = code
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if status_code:
            self.status_code = status_code


# Classe NotFoundError: representa uma estrutura reutilizável pelo backend.
class NotFoundError(BusinessRuleError):
    status_code = 404
    code = "not_found"


# Classe UnauthorizedError: representa uma estrutura reutilizável pelo backend.
class UnauthorizedError(BusinessRuleError):
    status_code = 401
    code = "unauthorized"
