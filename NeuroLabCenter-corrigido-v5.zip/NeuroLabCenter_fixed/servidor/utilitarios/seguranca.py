"""
Arquivo: servidor/utilitarios/seguranca.py

Objetivo:
    Implementar uma parte do servidor Flask do NeuroLab Center.

Como manter:
    Leia os comentários antes de alterar regras de negócio, rotas ou acesso ao banco.
    Preserve nomes em português e imports do pacote servidor.

Observação:
    Comentários foram adicionados para facilitar apresentação e manutenção.
"""

"""
NeuroLab Center - servidor/utilitarios/seguranca.py

Responsabilidade:
    Funções auxiliares do servidor, como validação, CPF, datas, segurança e respostas.

Usado por:
    servidor/app.py ou outros módulos do pacote servidor.

Manutenção:
    Este comentário foi adicionado para facilitar leitura em apresentação e manutenção.
    Preserve os imports atualizados para o pacote `servidor`.
"""

from datetime import datetime, timezone
import hashlib
import secrets

import bcrypt
import jwt

from servidor.configuracao import Config
from servidor.utilitarios.erros import UnauthorizedError


# Função hash_password: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def hash_password(password):
    raw = str(password or "")
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if len(raw) < 8:
        raise UnauthorizedError("A senha deve ter pelo menos 8 caracteres.", code="weak_password", status_code=400)
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if not any(char.isupper() for char in raw):
        raise UnauthorizedError("A senha deve conter pelo menos uma letra maiuscula.", code="weak_password", status_code=400)
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if not any(char.islower() for char in raw):
        raise UnauthorizedError("A senha deve conter pelo menos uma letra minuscula.", code="weak_password", status_code=400)
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if not any(char.isdigit() for char in raw):
        raise UnauthorizedError("A senha deve conter pelo menos um numero.", code="weak_password", status_code=400)
    # Retorno padronizado para quem chamou esta função.
    return bcrypt.hashpw(raw.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")


# Função verify_password: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def verify_password(password, password_hash):
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if not password or not password_hash:
        # Retorno padronizado para quem chamou esta função.
        return False
    # Bloco protegido: captura erros previsíveis sem derrubar a API.
    try:
        # Retorno padronizado para quem chamou esta função.
        return bcrypt.checkpw(str(password).encode("utf-8"), password_hash.encode("utf-8"))
    except ValueError:
        # Retorno padronizado para quem chamou esta função.
        return False


# Função create_token: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def create_token(user):
    now = datetime.now(timezone.utc)
    payload = {
        "sub": str(user["id"]),
        "cpf": user["cpf"],
        "tipo_usuario": user["tipo_usuario"],
        "iat": int(now.timestamp()),
        "exp": int((now + Config.JWT_EXPIRES_IN).timestamp()),
    }
    # Retorno padronizado para quem chamou esta função.
    return jwt.encode(payload, Config.JWT_SECRET, algorithm="HS256")


# Função decode_token: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def decode_token(token):
    # Bloco protegido: captura erros previsíveis sem derrubar a API.
    try:
        # Retorno padronizado para quem chamou esta função.
        return jwt.decode(token, Config.JWT_SECRET, algorithms=["HS256"])
    except jwt.PyJWTError:
        raise UnauthorizedError("Token invalido ou expirado.", code="invalid_token")


# Função generate_password_reset_token: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def generate_password_reset_token():
    # Retorno padronizado para quem chamou esta função.
    return secrets.token_urlsafe(32)


# Função hash_password_reset_token: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def hash_password_reset_token(token):
    raw = str(token or "").strip()
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if not raw:
        # Retorno padronizado para quem chamou esta função.
        return ""
    # Retorno padronizado para quem chamou esta função.
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()
