"""
Arquivo: servidor/utilitarios/datas.py

Objetivo:
    Implementar uma parte do servidor Flask do NeuroLab Center.

Como manter:
    Leia os comentários antes de alterar regras de negócio, rotas ou acesso ao banco.
    Preserve nomes em português e imports do pacote servidor.

Observação:
    Comentários foram adicionados para facilitar apresentação e manutenção.
"""

"""
NeuroLab Center - servidor/utilitarios/datas.py

Responsabilidade:
    Funções auxiliares do servidor, como validação, CPF, datas, segurança e respostas.

Usado por:
    servidor/app.py ou outros módulos do pacote servidor.

Manutenção:
    Este comentário foi adicionado para facilitar leitura em apresentação e manutenção.
    Preserve os imports atualizados para o pacote `servidor`.
"""

from datetime import date, datetime, time

from servidor.utilitarios.erros import BusinessRuleError


# Função parse_date: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def parse_date(value, field_name="data"):
    # Bloco protegido: captura erros previsíveis sem derrubar a API.
    try:
        # Retorno padronizado para quem chamou esta função.
        return date.fromisoformat(str(value))
    except (TypeError, ValueError):
        raise BusinessRuleError(f"{field_name} deve estar no formato YYYY-MM-DD.", code="invalid_date")


# Função parse_time: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def parse_time(value, field_name="hora"):
    # Bloco protegido: captura erros previsíveis sem derrubar a API.
    try:
        text = str(value)
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if len(text) == 5:
            text = f"{text}:00"
        # Retorno padronizado para quem chamou esta função.
        return time.fromisoformat(text)
    except (TypeError, ValueError):
        raise BusinessRuleError(f"{field_name} deve estar no formato HH:MM.", code="invalid_time")


# Função combine_date_time: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def combine_date_time(date_value, time_value):
    # Retorno padronizado para quem chamou esta função.
    return datetime.combine(parse_date(date_value, "data_consulta"), parse_time(time_value, "hora_consulta"))


# Função age_from_birthdate: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def age_from_birthdate(birthdate, today=None):
    today = today or date.today()
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if isinstance(birthdate, str):
        birthdate = parse_date(birthdate, "data_nascimento")
    years = today.year - birthdate.year
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if (today.month, today.day) < (birthdate.month, birthdate.day):
        years -= 1
    # Retorno padronizado para quem chamou esta função.
    return years


# Função hours_until: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def hours_until(moment):
    # Retorno padronizado para quem chamou esta função.
    return (moment - datetime.now()).total_seconds() / 3600
