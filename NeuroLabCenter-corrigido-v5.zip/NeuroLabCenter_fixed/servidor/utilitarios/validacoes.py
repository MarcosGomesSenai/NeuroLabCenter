"""
Arquivo: servidor/utilitarios/validacoes.py

Objetivo:
    Implementar uma parte do servidor Flask do NeuroLab Center.

Como manter:
    Leia os comentários antes de alterar regras de negócio, rotas ou acesso ao banco.
    Preserve nomes em português e imports do pacote servidor.

Observação:
    Comentários foram adicionados para facilitar apresentação e manutenção.
"""

"""
NeuroLab Center - servidor/utilitarios/validacoes.py

Responsabilidade:
    Funções auxiliares do servidor, como validação, CPF, datas, segurança e respostas.

Usado por:
    servidor/app.py ou outros módulos do pacote servidor.

Manutenção:
    Este comentário foi adicionado para facilitar leitura em apresentação e manutenção.
    Preserve os imports atualizados para o pacote `servidor`.
"""

import base64
import binascii
import re
from datetime import date

from servidor.utilitarios.erros import BusinessRuleError

_EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
_TRUE_VALUES = {"1", "true", "t", "sim", "s", "yes", "y", "on"}
_FALSE_VALUES = {"0", "false", "f", "nao", "não", "n", "no", "off"}


# Função parse_bool: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def parse_bool(value, default=False, field_name="campo"):
    """Converte booleanos vindos do front-end sem transformar 'false' em True."""
    if value is None or value == "":
        # Retorno padronizado para quem chamou esta função.
        return default
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if isinstance(value, bool):
        # Retorno padronizado para quem chamou esta função.
        return value
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if isinstance(value, (int, float)) and value in (0, 1):
        # Retorno padronizado para quem chamou esta função.
        return bool(value)
    text = str(value).strip().lower()
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if text in _TRUE_VALUES:
        # Retorno padronizado para quem chamou esta função.
        return True
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if text in _FALSE_VALUES:
        # Retorno padronizado para quem chamou esta função.
        return False
    raise BusinessRuleError(f"{field_name} deve ser verdadeiro ou falso.", code="invalid_boolean")


# Função positive_int: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def positive_int(value, field_name, required=True):
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if value is None or value == "":
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if required:
            raise BusinessRuleError(f"{field_name} e obrigatorio.", code=f"missing_{field_name}")
        # Retorno padronizado para quem chamou esta função.
        return None
    # Bloco protegido: captura erros previsíveis sem derrubar a API.
    try:
        number = int(value)
    except (TypeError, ValueError):
        raise BusinessRuleError(f"{field_name} deve ser numerico.", code=f"invalid_{field_name}")
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if number <= 0:
        raise BusinessRuleError(f"{field_name} deve ser maior que zero.", code=f"invalid_{field_name}")
    # Retorno padronizado para quem chamou esta função.
    return number


# Função validate_email: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def validate_email(value, required=False, field_name="email"):
    email = str(value or "").strip().lower()
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if not email:
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if required:
            raise BusinessRuleError(f"{field_name} e obrigatorio.", code="missing_email")
        # Retorno padronizado para quem chamou esta função.
        return None
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if len(email) > 120 or not _EMAIL_RE.match(email):
        raise BusinessRuleError(f"{field_name} invalido.", code="invalid_email")
    # Retorno padronizado para quem chamou esta função.
    return email


# Função validate_phone: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def validate_phone(value, required=False, field_name="telefone"):
    phone = str(value or "").strip()
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if not phone:
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if required:
            raise BusinessRuleError(f"{field_name} e obrigatorio.", code="missing_phone")
        # Retorno padronizado para quem chamou esta função.
        return None
    digits = "".join(ch for ch in phone if ch.isdigit())
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if len(digits) not in (10, 11):
        raise BusinessRuleError(f"{field_name} deve ter 10 ou 11 digitos.", code="invalid_phone")
    # Retorno padronizado para quem chamou esta função.
    return phone


# Função validate_cep: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def validate_cep(value, required=False):
    digits = "".join(ch for ch in str(value or "") if ch.isdigit())
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if not digits:
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if required:
            raise BusinessRuleError("CEP e obrigatorio.", code="missing_zipcode")
        # Retorno padronizado para quem chamou esta função.
        return None
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if len(digits) != 8:
        raise BusinessRuleError("CEP deve ter 8 digitos.", code="invalid_zipcode")
    # Retorno padronizado para quem chamou esta função.
    return digits


# Função ensure_not_future_date: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def ensure_not_future_date(value, field_name="data"):
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if value and value > date.today():
        raise BusinessRuleError(f"{field_name} nao pode ser futura.", code="date_in_future")
    # Retorno padronizado para quem chamou esta função.
    return value


# Função validate_data_uri_base64: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def validate_data_uri_base64(data_uri, allowed_prefixes, max_bytes, code_prefix="file"):
    content = str(data_uri or "")
    lower = content.lower()
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if not any(lower.startswith(prefix) for prefix in allowed_prefixes):
        raise BusinessRuleError("Formato de arquivo invalido.", code=f"invalid_{code_prefix}_payload")
    # Bloco protegido: captura erros previsíveis sem derrubar a API.
    try:
        encoded = content.split(",", 1)[1]
    except IndexError:
        raise BusinessRuleError("Arquivo em base64 invalido.", code=f"invalid_{code_prefix}_payload")
    # Bloco protegido: captura erros previsíveis sem derrubar a API.
    try:
        raw = base64.b64decode(encoded, validate=True)
    except (binascii.Error, ValueError):
        raise BusinessRuleError("Arquivo em base64 invalido.", code=f"invalid_{code_prefix}_base64")
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if len(raw) == 0:
        raise BusinessRuleError("Arquivo vazio nao pode ser enviado.", code=f"empty_{code_prefix}")
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if len(raw) > max_bytes:
        raise BusinessRuleError("Arquivo acima do limite permitido.", code=f"{code_prefix}_too_large")
    # Retorno padronizado para quem chamou esta função.
    return raw
