"""
Arquivo: servidor/utilitarios/respostas.py

Objetivo:
    Implementar uma parte do servidor Flask do NeuroLab Center.

Como manter:
    Leia os comentários antes de alterar regras de negócio, rotas ou acesso ao banco.
    Preserve nomes em português e imports do pacote servidor.

Observação:
    Comentários foram adicionados para facilitar apresentação e manutenção.
"""

"""
NeuroLab Center - servidor/utilitarios/respostas.py

Responsabilidade:
    Funções auxiliares do servidor, como validação, CPF, datas, segurança e respostas.

Usado por:
    servidor/app.py ou outros módulos do pacote servidor.

Manutenção:
    Este comentário foi adicionado para facilitar leitura em apresentação e manutenção.
    Preserve os imports atualizados para o pacote `servidor`.
"""

from datetime import date, datetime, time, timedelta
from decimal import Decimal


# Função to_jsonable: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def to_jsonable(value):
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if isinstance(value, list):
        # Retorno padronizado para quem chamou esta função.
        return [to_jsonable(item) for item in value]
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if isinstance(value, dict):
        # Retorno padronizado para quem chamou esta função.
        return {key: to_jsonable(item) for key, item in value.items()}
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if isinstance(value, (datetime, date, time)):
        # Retorno padronizado para quem chamou esta função.
        return value.isoformat()
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if isinstance(value, timedelta):
        total = int(value.total_seconds())
        hours = total // 3600
        minutes = (total % 3600) // 60
        seconds = total % 60
        # Retorno padronizado para quem chamou esta função.
        return f"{hours:02d}:{minutes:02d}:{seconds:02d}"
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if isinstance(value, Decimal):
        # Retorno padronizado para quem chamou esta função.
        return float(value)
    # Retorno padronizado para quem chamou esta função.
    return value


# Função ok: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def ok(data=None, status=200):
    # Retorno padronizado para quem chamou esta função.
    return to_jsonable(data or {}), status


# Função created: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def created(data=None):
    # Retorno padronizado para quem chamou esta função.
    return to_jsonable(data or {}), 201
