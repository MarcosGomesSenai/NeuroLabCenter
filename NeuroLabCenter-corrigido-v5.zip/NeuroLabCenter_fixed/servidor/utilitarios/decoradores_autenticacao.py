"""
Arquivo: servidor/utilitarios/decoradores_autenticacao.py

Objetivo:
    Implementar uma parte do servidor Flask do NeuroLab Center.

Como manter:
    Leia os comentários antes de alterar regras de negócio, rotas ou acesso ao banco.
    Preserve nomes em português e imports do pacote servidor.

Observação:
    Comentários foram adicionados para facilitar apresentação e manutenção.
"""

"""
NeuroLab Center - servidor/utilitarios/decoradores_autenticacao.py

Responsabilidade:
    Funções auxiliares do servidor, como validação, CPF, datas, segurança e respostas.

Usado por:
    servidor/app.py ou outros módulos do pacote servidor.

Manutenção:
    Este comentário foi adicionado para facilitar leitura em apresentação e manutenção.
    Preserve os imports atualizados para o pacote `servidor`.
"""

from functools import wraps

from flask import g, request

from servidor.utilitarios.erros import UnauthorizedError
from servidor.utilitarios.seguranca import decode_token


# Função _extract_bearer_token: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def _extract_bearer_token():
    header = request.headers.get("Authorization", "")
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if header.startswith("Bearer "):
        # Retorno padronizado para quem chamou esta função.
        return header[7:].strip()
    # Retorno padronizado para quem chamou esta função.
    return None


# Função require_auth: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def require_auth(view):
    @wraps(view)
    # Função wrapped: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
    def wrapped(*args, **kwargs):
        token = _extract_bearer_token()
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if not token:
            raise UnauthorizedError("Autenticacao obrigatoria.", code="auth_required")
        payload = decode_token(token)
        g.auth = payload
        g.cpf = payload.get("cpf")
        g.user_id = int(payload.get("sub"))
        g.tipo_usuario = payload.get("tipo_usuario")
        # Retorno padronizado para quem chamou esta função.
        return view(*args, **kwargs)

    # Retorno padronizado para quem chamou esta função.
    return wrapped



# Função require_roles: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def require_roles(*roles):
    allowed = {str(role).lower() for role in roles}

    # Função decorator: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
    def decorator(view):
        @wraps(view)
        # Função wrapped: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
        def wrapped(*args, **kwargs):
            token = _extract_bearer_token()
            # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
            if not token:
                raise UnauthorizedError("Autenticacao obrigatoria.", code="auth_required")
            payload = decode_token(token)
            g.auth = payload
            g.cpf = payload.get("cpf")
            g.user_id = int(payload.get("sub"))
            g.tipo_usuario = payload.get("tipo_usuario")
            # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
            if str(g.tipo_usuario or "").lower() not in allowed:
                raise UnauthorizedError("Permissao insuficiente.", code="forbidden", status_code=403)
            # Retorno padronizado para quem chamou esta função.
            return view(*args, **kwargs)

        # Retorno padronizado para quem chamou esta função.
        return wrapped

    # Retorno padronizado para quem chamou esta função.
    return decorator
