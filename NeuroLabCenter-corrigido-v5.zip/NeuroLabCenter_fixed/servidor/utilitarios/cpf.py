"""
Arquivo: servidor/utilitarios/cpf.py

Objetivo:
    Implementar uma parte do servidor Flask do NeuroLab Center.

Como manter:
    Leia os comentários antes de alterar regras de negócio, rotas ou acesso ao banco.
    Preserve nomes em português e imports do pacote servidor.

Observação:
    Comentários foram adicionados para facilitar apresentação e manutenção.
"""

"""
NeuroLab Center - servidor/utilitarios/cpf.py

Responsabilidade:
    Funções auxiliares do servidor, como validação, CPF, datas, segurança e respostas.

Usado por:
    servidor/app.py ou outros módulos do pacote servidor.

Manutenção:
    Este comentário foi adicionado para facilitar leitura em apresentação e manutenção.
    Preserve os imports atualizados para o pacote `servidor`.
"""

from servidor.utilitarios.erros import BusinessRuleError


# Função only_digits: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def only_digits(value):
    # Retorno padronizado para quem chamou esta função.
    return "".join(char for char in str(value or "") if char.isdigit())


# Função is_valid_cpf: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def is_valid_cpf(value):
    cpf = only_digits(value)
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if len(cpf) != 11:
        # Retorno padronizado para quem chamou esta função.
        return False
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if cpf == cpf[0] * 11:
        # Retorno padronizado para quem chamou esta função.
        return False

    # Laço de repetição: percorre registros ou dados recebidos do sistema.
    for size in (9, 10):
        total = sum(int(cpf[index]) * (size + 1 - index) for index in range(size))
        digit = (total * 10) % 11
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if digit == 10:
            digit = 0
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if digit != int(cpf[size]):
            # Retorno padronizado para quem chamou esta função.
            return False
    # Retorno padronizado para quem chamou esta função.
    return True


# Função normalize_cpf: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def normalize_cpf(value, field_name="cpf"):
    cpf = only_digits(value)
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if not is_valid_cpf(cpf):
        raise BusinessRuleError(f"{field_name} invalido.", code="invalid_cpf")
    # Retorno padronizado para quem chamou esta função.
    return cpf


# Função mask_cpf: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def mask_cpf(value):
    cpf = only_digits(value)
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if len(cpf) != 11:
        # Retorno padronizado para quem chamou esta função.
        return cpf
    # Retorno padronizado para quem chamou esta função.
    return f"{cpf[:3]}.***.***-{cpf[-2:]}"
