"""
Arquivo: servidor/rotas/agendamentos.py

Objetivo:
    Implementar uma parte do servidor Flask do NeuroLab Center.

Como manter:
    Leia os comentários antes de alterar regras de negócio, rotas ou acesso ao banco.
    Preserve nomes em português e imports do pacote servidor.

Observação:
    Comentários foram adicionados para facilitar apresentação e manutenção.
"""

"""
NeuroLab Center - servidor/rotas/agendamentos.py

Responsabilidade:
    Rotas Flask: recebe requisições HTTP do front-end e chama os serviços corretos.

Usado por:
    servidor/app.py ou outros módulos do pacote servidor.

Manutenção:
    Este comentário foi adicionado para facilitar leitura em apresentação e manutenção.
    Preserve os imports atualizados para o pacote `servidor`.
"""

from flask import Blueprint, g, jsonify, request

from servidor.servicos.agendamentos import (
    cancelar_agendamento,
    confirmar_agendamento_responsavel,
    consultar_confirmacao_agendamento,
    criar_agendamento,
    listar_agendamentos_por_data,
    listar_agendamentos_por_paciente,
    listar_horarios_ocupados,
    reagendar_agendamento,
)
from servidor.utilitarios.decoradores_autenticacao import require_auth
from servidor.servicos.familia import assert_acesso_perfil
from servidor.utilitarios.respostas import created, ok
from servidor.utilitarios.validacoes import positive_int

bp = Blueprint("agendamentos", __name__)


# Função _is_admin: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def _is_admin():
    # Retorno padronizado para quem chamou esta função.
    return str(getattr(g, "tipo_usuario", "") or "").lower() in {"admin", "administrador"}


# Função _cpf_perfil_autorizado: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def _cpf_perfil_autorizado(data):
    alvo = data.get("cpf_cliente") or data.get("perfil_cpf") or g.cpf
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if not _is_admin():
        assert_acesso_perfil(g.cpf, alvo)
    # Retorno padronizado para quem chamou esta função.
    return alvo


# Função _aplicar_cpfs_autorizados: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def _aplicar_cpfs_autorizados(data):
    data["cpf_cliente"] = _cpf_perfil_autorizado(data)
    data["cpf_responsavel"] = g.cpf
    # Retorno padronizado para quem chamou esta função.
    return data


@bp.post("/agendamentos")
@require_auth
# Função criar_agendamento_route: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def criar_agendamento_route():
    data = request.get_json(silent=True) or {}
    data = _aplicar_cpfs_autorizados(data)
    payload, status = created(criar_agendamento(data))
    # Retorno padronizado para quem chamou esta função.
    return jsonify(payload), status


@bp.get("/agendamentos")
@require_auth
# Função listar_agendamentos_route: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def listar_agendamentos_route():
    cpf_logado = g.cpf
    data = request.args.get("data")
    cpf_solicitado = request.args.get("cpf") or request.args.get("perfil_cpf")
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if cpf_solicitado:
        cpf_autorizado = _cpf_perfil_autorizado({"cpf_cliente": cpf_solicitado})
        payload, status = ok({"agendamentos": listar_agendamentos_por_paciente(cpf_autorizado)})
    elif data:
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if not _is_admin():
            payload, status = ok({"agendamentos": listar_agendamentos_por_paciente(cpf_logado)})
        else:
            payload, status = ok({"agendamentos": listar_agendamentos_por_data(data)})
    else:
        payload, status = ok({"mensagem": "Informe cpf, perfil_cpf ou data para listar agendamentos."}, 400)
    # Retorno padronizado para quem chamou esta função.
    return jsonify(payload), status


@bp.get("/agendamentos/disponibilidade")
# Função listar_horarios_ocupados_route: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def listar_horarios_ocupados_route():
    payload, status = ok({"disponibilidade": listar_horarios_ocupados(request.args)})
    # Retorno padronizado para quem chamou esta função.
    return jsonify(payload), status


@bp.post("/agendamentos/<int:appointment_id>/confirmar-responsavel")
# Função confirmar_responsavel_route: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def confirmar_responsavel_route(appointment_id):
    data = request.get_json(silent=True) or {}
    payload, status = ok(confirmar_agendamento_responsavel(appointment_id, data))
    # Retorno padronizado para quem chamou esta função.
    return jsonify(payload), status


@bp.post("/confirmar_agendamento")
# Função confirmar_agendamento_alias_route: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def confirmar_agendamento_alias_route():
    data = request.get_json(silent=True) or {}
    appointment_id = positive_int(data.get("id_agendamento"), "id_agendamento")
    payload, status = ok(confirmar_agendamento_responsavel(appointment_id, data))
    # Retorno padronizado para quem chamou esta função.
    return jsonify(payload), status


@bp.get("/confirmar_agendamento")
# Função consultar_link_confirmacao_route: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def consultar_link_confirmacao_route():
    data = {
        "cpf_responsavel": request.args.get("cpf_responsavel") or request.args.get("cpf"),
        "confirmacao_token": request.args.get("confirmacao_token") or request.args.get("token"),
    }
    appointment_id = positive_int(request.args.get("id_agendamento") or request.args.get("id"), "id_agendamento")
    payload, status = ok(consultar_confirmacao_agendamento(appointment_id, data))
    # Retorno padronizado para quem chamou esta função.
    return jsonify(payload), status


@bp.put("/agendamentos/<int:appointment_id>")
@require_auth
# Função reagendar_agendamento_route: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def reagendar_agendamento_route(appointment_id):
    data = request.get_json(silent=True) or {}
    data["cpf_cliente"] = g.cpf
    data["cpf_responsavel"] = g.cpf
    payload, status = ok(reagendar_agendamento(appointment_id, data))
    # Retorno padronizado para quem chamou esta função.
    return jsonify(payload), status


@bp.delete("/agendamentos/<int:appointment_id>")
@require_auth
# Função cancelar_agendamento_route: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def cancelar_agendamento_route(appointment_id):
    data = request.get_json(silent=True) or {}
    data["cpf_cliente"] = g.cpf
    data["cpf_responsavel"] = g.cpf
    payload, status = ok(cancelar_agendamento(appointment_id, data))
    # Retorno padronizado para quem chamou esta função.
    return jsonify(payload), status
