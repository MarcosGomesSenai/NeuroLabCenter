"""
Arquivo: servidor/rotas/portal.py

Objetivo:
    Implementar uma parte do servidor Flask do NeuroLab Center.

Como manter:
    Leia os comentários antes de alterar regras de negócio, rotas ou acesso ao banco.
    Preserve nomes em português e imports do pacote servidor.

Observação:
    Comentários foram adicionados para facilitar apresentação e manutenção.
"""

"""
NeuroLab Center - servidor/rotas/portal.py

Responsabilidade:
    Rotas Flask: recebe requisições HTTP do front-end e chama os serviços corretos.

Usado por:
    servidor/app.py ou outros módulos do pacote servidor.

Manutenção:
    Este comentário foi adicionado para facilitar leitura em apresentação e manutenção.
    Preserve os imports atualizados para o pacote `servidor`.
"""

from flask import Blueprint, g, jsonify, request

from servidor.servicos.familia import (
    cadastrar_e_vincular_familiar,
    desvincular_familiar,
    listar_perfis_acessiveis,
)
from servidor.servicos.portal_paciente import (
    criar_documento,
    obter_painel,
    obter_preconsulta,
    obter_preferencias,
    listar_documentos,
    listar_exames,
    obter_documento,
    obter_formulario,
    remover_documento,
    salvar_exame,
    salvar_foto_perfil,
    salvar_formulario,
    salvar_preconsulta,
    salvar_preferencias,
)
from servidor.utilitarios.decoradores_autenticacao import require_auth
from servidor.utilitarios.respostas import created, ok

bp = Blueprint("portal", __name__)


# Função _perfil_query: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def _perfil_query():
    # Retorno padronizado para quem chamou esta função.
    return request.args.get("perfil_cpf") or g.cpf


# Função _dados_formulario_payload: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def _dados_formulario_payload(data):
    """Aceita tanto {dados: {...}} quanto campos diretos enviados pelo front-end."""
    if isinstance(data.get("dados"), dict):
        # Retorno padronizado para quem chamou esta função.
        return data["dados"]
    # Retorno padronizado para quem chamou esta função.
    return {
        chave: valor
        # Laço de repetição: percorre registros ou dados recebidos do sistema.
        for chave, valor in data.items()
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if chave not in {"perfil_cpf", "cpf_perfil", "cpf_titular"}
    }


@bp.get("/portal/painel")
@require_auth
# Função painel: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def painel():
    payload, status = ok(obter_painel(g.cpf, _perfil_query()))
    # Retorno padronizado para quem chamou esta função.
    return jsonify(payload), status


@bp.get("/portal/documentos")
@require_auth
# Função documentos_listar: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def documentos_listar():
    payload, status = ok(listar_documentos(g.cpf, _perfil_query()))
    # Retorno padronizado para quem chamou esta função.
    return jsonify(payload), status


@bp.post("/portal/documentos")
@require_auth
# Função documentos_criar: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def documentos_criar():
    data = request.get_json(silent=True) or {}
    payload, status = created(criar_documento(g.cpf, data.get("perfil_cpf") or _perfil_query(), data))
    # Retorno padronizado para quem chamou esta função.
    return jsonify(payload), status


@bp.get("/portal/documentos/<int:doc_id>")
@require_auth
# Função documentos_obter: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def documentos_obter(doc_id):
    payload, status = ok(obter_documento(g.cpf, _perfil_query(), doc_id))
    # Retorno padronizado para quem chamou esta função.
    return jsonify(payload), status


@bp.delete("/portal/documentos/<int:doc_id>")
@require_auth
# Função documentos_remover: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def documentos_remover(doc_id):
    payload, status = ok(remover_documento(g.cpf, _perfil_query(), doc_id))
    # Retorno padronizado para quem chamou esta função.
    return jsonify(payload), status


@bp.get("/portal/preconsulta")
@require_auth
# Função preconsulta_obter: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def preconsulta_obter():
    payload, status = ok(obter_preconsulta(g.cpf, _perfil_query()))
    # Retorno padronizado para quem chamou esta função.
    return jsonify(payload), status


@bp.put("/portal/preconsulta")
@require_auth
# Função preconsulta_salvar: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def preconsulta_salvar():
    data = request.get_json(silent=True) or {}
    payload, status = ok(salvar_preconsulta(g.cpf, data.get("perfil_cpf") or _perfil_query(), data))
    # Retorno padronizado para quem chamou esta função.
    return jsonify(payload), status


@bp.get("/portal/exames")
@require_auth
# Função exames_listar: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def exames_listar():
    payload, status = ok(listar_exames(g.cpf, _perfil_query()))
    # Retorno padronizado para quem chamou esta função.
    return jsonify(payload), status


@bp.post("/portal/exames")
@require_auth
# Função exames_salvar: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def exames_salvar():
    data = request.get_json(silent=True) or {}
    payload, status = ok(salvar_exame(g.cpf, data.get("perfil_cpf") or _perfil_query(), data))
    # Retorno padronizado para quem chamou esta função.
    return jsonify(payload), status




@bp.get("/portal/formularios/<tipo>")
@require_auth
# Função formulario_obter: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def formulario_obter(tipo):
    payload, status = ok(obter_formulario(g.cpf, _perfil_query(), tipo))
    # Retorno padronizado para quem chamou esta função.
    return jsonify(payload), status


@bp.put("/portal/formularios/<tipo>")
@require_auth
# Função formulario_salvar: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def formulario_salvar(tipo):
    data = request.get_json(silent=True) or {}
    payload, status = ok(salvar_formulario(g.cpf, data.get("perfil_cpf") or _perfil_query(), tipo, _dados_formulario_payload(data)))
    # Retorno padronizado para quem chamou esta função.
    return jsonify(payload), status


@bp.get("/portal/preferencias")
@require_auth
# Função preferencias_obter: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def preferencias_obter():
    payload, status = ok(obter_preferencias(g.cpf, _perfil_query()))
    # Retorno padronizado para quem chamou esta função.
    return jsonify(payload), status


@bp.put("/portal/preferencias")
@require_auth
# Função preferencias_salvar: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def preferencias_salvar():
    data = request.get_json(silent=True) or {}
    payload, status = ok(salvar_preferencias(g.cpf, data.get("perfil_cpf") or _perfil_query(), data))
    # Retorno padronizado para quem chamou esta função.
    return jsonify(payload), status


@bp.put("/portal/foto")
@require_auth
# Função foto_salvar: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def foto_salvar():
    data = request.get_json(silent=True) or {}
    payload, status = ok(
        salvar_foto_perfil(g.cpf, data.get("perfil_cpf") or _perfil_query(), data.get("foto_base64"))
    )
    # Retorno padronizado para quem chamou esta função.
    return jsonify(payload), status


@bp.get("/portal/familia")
@require_auth
# Função familia_listar: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def familia_listar():
    payload, status = ok({"perfis": listar_perfis_acessiveis(g.cpf)})
    # Retorno padronizado para quem chamou esta função.
    return jsonify(payload), status


@bp.post("/portal/familia/membro")
@require_auth
# Função familia_cadastrar_membro: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def familia_cadastrar_membro():
    """Cadastro completo (mesmo de /cadastro) + vinculo a conta familia."""
    data = request.get_json(silent=True) or {}
    payload, status = created(cadastrar_e_vincular_familiar(g.cpf, data))
    # Retorno padronizado para quem chamou esta função.
    return jsonify(payload), status


@bp.delete("/portal/familia/<cpf_membro>")
@require_auth
# Função familia_desvincular: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def familia_desvincular(cpf_membro):
    payload, status = ok(desvincular_familiar(g.cpf, cpf_membro))
    # Retorno padronizado para quem chamou esta função.
    return jsonify(payload), status
