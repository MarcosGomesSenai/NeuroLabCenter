"""
Arquivo: servidor/rotas/catalogos.py

Objetivo:
    Implementar uma parte do servidor Flask do NeuroLab Center.

Como manter:
    Leia os comentários antes de alterar regras de negócio, rotas ou acesso ao banco.
    Preserve nomes em português e imports do pacote servidor.

Observação:
    Comentários foram adicionados para facilitar apresentação e manutenção.
"""

"""
NeuroLab Center - servidor/rotas/catalogos.py

Responsabilidade:
    Rotas Flask: recebe requisições HTTP do front-end e chama os serviços corretos.

Usado por:
    servidor/app.py ou outros módulos do pacote servidor.

Manutenção:
    Este comentário foi adicionado para facilitar leitura em apresentação e manutenção.
    Preserve os imports atualizados para o pacote `servidor`.
"""

from flask import Blueprint, jsonify

from servidor.servicos.catalogos import get_unit_by_zip_code, list_doctors, list_exams, list_health_plans, list_units
from servidor.utilitarios.respostas import ok

bp = Blueprint("catalog", __name__)


@bp.get("/unidades")
# Função units: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def units():
    payload, status = ok({"unidades": list_units()})
    # Retorno padronizado para quem chamou esta função.
    return jsonify(payload), status


@bp.get("/unidades/por-cep/<cep>")
# Função unit_by_zip_code: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def unit_by_zip_code(cep):
    payload, status = ok({"unidade": get_unit_by_zip_code(cep)})
    # Retorno padronizado para quem chamou esta função.
    return jsonify(payload), status


@bp.get("/medicos")
# Função doctors: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def doctors():
    payload, status = ok({"medicos": list_doctors()})
    # Retorno padronizado para quem chamou esta função.
    return jsonify(payload), status


@bp.get("/convenios")
# Função health_plans: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def health_plans():
    payload, status = ok({"convenios": list_health_plans()})
    # Retorno padronizado para quem chamou esta função.
    return jsonify(payload), status


@bp.get("/exames")
# Função exams: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def exams():
    payload, status = ok({"exames": list_exams()})
    # Retorno padronizado para quem chamou esta função.
    return jsonify(payload), status
