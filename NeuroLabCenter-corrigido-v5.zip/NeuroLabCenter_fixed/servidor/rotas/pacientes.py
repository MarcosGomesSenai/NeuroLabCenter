"""
Arquivo: servidor/rotas/pacientes.py

Objetivo:
    Implementar uma parte do servidor Flask do NeuroLab Center.

Como manter:
    Leia os comentários antes de alterar regras de negócio, rotas ou acesso ao banco.
    Preserve nomes em português e imports do pacote servidor.

Observação:
    Comentários foram adicionados para facilitar apresentação e manutenção.
"""

"""
NeuroLab Center - servidor/rotas/pacientes.py

Responsabilidade:
    Rotas Flask: recebe requisições HTTP do front-end e chama os serviços corretos.

Usado por:
    servidor/app.py ou outros módulos do pacote servidor.

Manutenção:
    Este comentário foi adicionado para facilitar leitura em apresentação e manutenção.
    Preserve os imports atualizados para o pacote `servidor`.
"""

from flask import Blueprint, g, jsonify, request

from servidor.servicos.agendamentos import listar_agendamentos_por_paciente
from servidor.servicos.familia import assert_acesso_perfil
from servidor.servicos.pacientes import buscar_paciente_por_cpf, atualizar_responsavel_paciente
from servidor.utilitarios.decoradores_autenticacao import require_auth
from servidor.utilitarios.respostas import ok

bp = Blueprint("pacientes", __name__)


# Função _is_admin: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def _is_admin():
    # Retorno padronizado para quem chamou esta função.
    return str(getattr(g, "tipo_usuario", "") or "").lower() in {"admin", "administrador"}


# Função _validar_acesso_paciente: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def _validar_acesso_paciente(cpf):
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if not _is_admin():
        assert_acesso_perfil(g.cpf, cpf)


@bp.get("/pacientes/<cpf>")
@require_auth
# Função buscar_paciente_route: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def buscar_paciente_route(cpf):
    _validar_acesso_paciente(cpf)
    payload, status = ok(buscar_paciente_por_cpf(cpf))
    # Retorno padronizado para quem chamou esta função.
    return jsonify(payload), status


@bp.get("/pacientes/<cpf>/agendamentos")
@require_auth
# Função listar_agendamentos_paciente_route: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def listar_agendamentos_paciente_route(cpf):
    _validar_acesso_paciente(cpf)
    payload, status = ok({"agendamentos": listar_agendamentos_por_paciente(cpf)})
    # Retorno padronizado para quem chamou esta função.
    return jsonify(payload), status


@bp.put("/pacientes/<cpf>/responsavel")
@require_auth
# Função atualizar_responsavel_route: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def atualizar_responsavel_route(cpf):
    _validar_acesso_paciente(cpf)
    data = request.get_json(silent=True) or {}
    payload, status = ok(atualizar_responsavel_paciente(cpf, data))
    # Retorno padronizado para quem chamou esta função.
    return jsonify(payload), status
