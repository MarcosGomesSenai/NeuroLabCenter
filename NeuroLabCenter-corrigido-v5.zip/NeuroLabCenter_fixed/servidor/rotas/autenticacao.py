"""
Arquivo: servidor/rotas/autenticacao.py

Objetivo:
    Implementar uma parte do servidor Flask do NeuroLab Center.

Como manter:
    Leia os comentários antes de alterar regras de negócio, rotas ou acesso ao banco.
    Preserve nomes em português e imports do pacote servidor.

Observação:
    Comentários foram adicionados para facilitar apresentação e manutenção.
"""

"""
NeuroLab Center - servidor/rotas/autenticacao.py

Responsabilidade:
    Rotas Flask: recebe requisições HTTP do front-end e chama os serviços corretos.

Usado por:
    servidor/app.py ou outros módulos do pacote servidor.

Manutenção:
    Este comentário foi adicionado para facilitar leitura em apresentação e manutenção.
    Preserve os imports atualizados para o pacote `servidor`.
"""

from flask import Blueprint, jsonify, request

from servidor.servicos.login_e_cadastro import (
    authenticate_user,
    create_user,
    redefinir_senha_por_token,
    solicitar_recuperacao_senha,
)
from servidor.utilitarios.respostas import created, ok

bp = Blueprint("auth", __name__)


@bp.post("/login")
# Função login: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def login():
    data = request.get_json(silent=True) or {}
    payload, status = ok(authenticate_user(data.get("cpf"), data.get("senha")))
    # Retorno padronizado para quem chamou esta função.
    return jsonify(payload), status


@bp.post("/usuarios")
# Função register_user: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def register_user():
    data = request.get_json(silent=True) or {}
    payload, status = created(create_user(data))
    # Retorno padronizado para quem chamou esta função.
    return jsonify(payload), status


@bp.post("/cadastro")
# Função cadastro: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def cadastro():
    data = request.get_json(silent=True) or {}
    payload, status = created(create_user(data))
    # Retorno padronizado para quem chamou esta função.
    return jsonify(payload), status


@bp.post("/esqueci-senha")
@bp.post("/auth/esqueci-senha")
@bp.post("/auth/forgot-password")
# Função esqueci_senha: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def esqueci_senha():
    data = request.get_json(silent=True) or {}
    payload, status = ok(
        solicitar_recuperacao_senha(
            data,
            ip=request.headers.get("X-Forwarded-For", request.remote_addr),
            user_agent=request.headers.get("User-Agent", ""),
        )
    )
    # Retorno padronizado para quem chamou esta função.
    return jsonify(payload), status


@bp.post("/redefinir-senha")
@bp.post("/auth/redefinir-senha")
@bp.post("/auth/reset-password")
# Função redefinir_senha: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def redefinir_senha():
    data = request.get_json(silent=True) or {}
    payload, status = ok(redefinir_senha_por_token(data))
    # Retorno padronizado para quem chamou esta função.
    return jsonify(payload), status
