"""
Arquivo: servidor/rotas/fila.py

Objetivo:
    Implementar uma parte do servidor Flask do NeuroLab Center.

Como manter:
    Leia os comentários antes de alterar regras de negócio, rotas ou acesso ao banco.
    Preserve nomes em português e imports do pacote servidor.

Observação:
    Comentários foram adicionados para facilitar apresentação e manutenção.
"""

"""
NeuroLab Center - servidor/rotas/fila.py

Responsabilidade:
    Rotas Flask: recebe requisições HTTP do front-end e chama os serviços corretos.

Usado por:
    servidor/app.py ou outros módulos do pacote servidor.

Manutenção:
    Este comentário foi adicionado para facilitar leitura em apresentação e manutenção.
    Preserve os imports atualizados para o pacote `servidor`.
"""

from flask import Blueprint, g, jsonify, request

from servidor.servicos.fila_de_espera import criar_entrada_fila
from servidor.servicos.familia import assert_acesso_perfil
from servidor.utilitarios.decoradores_autenticacao import require_auth
from servidor.utilitarios.respostas import created

# Função _is_admin: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def _is_admin():
    # Retorno padronizado para quem chamou esta função.
    return str(getattr(g, "tipo_usuario", "") or "").lower() in {"admin", "administrador"}


# Função _cpf_perfil_autorizado: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def _cpf_perfil_autorizado(data):
    alvo = data.get("cpf_cliente") or data.get("perfil_cpf") or g.cpf
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if not _is_admin():
        assert_acesso_perfil(g.cpf, alvo)
    # Retorno padronizado para quem chamou esta função.
    return alvo


bp = Blueprint("fila", __name__)


@bp.post("/fila-espera")
@require_auth
# Função criar_fila_espera_route: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def criar_fila_espera_route():
    data = request.get_json(silent=True) or {}
    data["cpf_cliente"] = _cpf_perfil_autorizado(data)
    payload, status = created(criar_entrada_fila(data))
    # Retorno padronizado para quem chamou esta função.
    return jsonify(payload), status
