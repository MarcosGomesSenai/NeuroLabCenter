"""
Arquivo: servidor/rotas/__init__.py

Objetivo:
    Implementar uma parte do servidor Flask do NeuroLab Center.

Como manter:
    Leia os comentários antes de alterar regras de negócio, rotas ou acesso ao banco.
    Preserve nomes em português e imports do pacote servidor.

Observação:
    Comentários foram adicionados para facilitar apresentação e manutenção.
"""

"""
NeuroLab Center - servidor/rotas/__init__.py

Responsabilidade:
    Rotas Flask: recebe requisições HTTP do front-end e chama os serviços corretos.

Usado por:
    servidor/app.py ou outros módulos do pacote servidor.

Manutenção:
    Este comentário foi adicionado para facilitar leitura em apresentação e manutenção.
    Preserve os imports atualizados para o pacote `servidor`.
"""

from flask_cors import CORS

from servidor.rotas.agendamentos import bp as agendamentos_bp
from servidor.rotas.autenticacao import bp as auth_bp
from servidor.rotas.catalogos import bp as catalog_bp
from servidor.rotas.avaliacoes import bp as feedback_bp
from servidor.rotas.fila import bp as fila_bp
from servidor.rotas.pacientes import bp as pacientes_bp
from servidor.rotas.usuarios import bp as usuarios_bp
from servidor.rotas.portal import bp as portal_bp


# Função register_routes: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def register_routes(app, prefix="/api"):
    CORS(app, resources={r"/api/*": {"origins": app.config.get("CORS_ORIGINS", "*")}})
    app.register_blueprint(auth_bp, url_prefix=prefix)
    app.register_blueprint(usuarios_bp, url_prefix=prefix)
    app.register_blueprint(pacientes_bp, url_prefix=prefix)
    app.register_blueprint(agendamentos_bp, url_prefix=prefix)
    app.register_blueprint(feedback_bp, url_prefix=prefix)
    app.register_blueprint(fila_bp, url_prefix=prefix)
    app.register_blueprint(catalog_bp, url_prefix=prefix)
    app.register_blueprint(portal_bp, url_prefix=prefix)
