"""
Arquivo: servidor/rotas/avaliacoes.py

Objetivo:
    Implementar uma parte do servidor Flask do NeuroLab Center.

Como manter:
    Leia os comentários antes de alterar regras de negócio, rotas ou acesso ao banco.
    Preserve nomes em português e imports do pacote servidor.

Observação:
    Comentários foram adicionados para facilitar apresentação e manutenção.
"""

"""
NeuroLab Center - servidor/rotas/avaliacoes.py

Responsabilidade:
    Rotas Flask: recebe requisições HTTP do front-end e chama os serviços corretos.

Usado por:
    servidor/app.py ou outros módulos do pacote servidor.

Manutenção:
    Este comentário foi adicionado para facilitar leitura em apresentação e manutenção.
    Preserve os imports atualizados para o pacote `servidor`.
"""

from flask import Blueprint, g, jsonify, request

from servidor.servicos.avaliacoes import create_feedback, create_general_feedback, doctor_average, doctor_comments, unit_average, unit_comments
from servidor.servicos.familia import assert_acesso_perfil
from servidor.utilitarios.decoradores_autenticacao import require_auth
from servidor.utilitarios.respostas import created, ok

# Função _is_admin: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def _is_admin():
    # Retorno padronizado para quem chamou esta função.
    return str(getattr(g, "tipo_usuario", "") or "").lower() in {"admin", "administrador"}


# Função _cpf_perfil_autorizado: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def _cpf_perfil_autorizado(data):
    alvo = data.get("cpf_cliente") or data.get("perfil_cpf") or g.cpf
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if not _is_admin():
        assert_acesso_perfil(g.cpf, alvo)
    # Retorno padronizado para quem chamou esta função.
    return alvo


bp = Blueprint("feedback", __name__)


@bp.post("/feedback")
@require_auth
# Função create_feedback_route: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def create_feedback_route():
    data = request.get_json(silent=True) or {}
    data["cpf_cliente"] = _cpf_perfil_autorizado(data)
    payload, status = created(create_feedback(data))
    # Retorno padronizado para quem chamou esta função.
    return jsonify(payload), status


@bp.post("/feedback/geral")
@require_auth
# Função create_general_feedback_route: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def create_general_feedback_route():
    data = request.get_json(silent=True) or {}
    data["cpf_cliente"] = _cpf_perfil_autorizado(data)
    payload, status = created(create_general_feedback(data))
    # Retorno padronizado para quem chamou esta função.
    return jsonify(payload), status


@bp.get("/feedback/medicos/<int:doctor_id>/media")
# Função doctor_feedback_average_route: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def doctor_feedback_average_route(doctor_id):
    payload, status = ok({"resultado": doctor_average(doctor_id)})
    # Retorno padronizado para quem chamou esta função.
    return jsonify(payload), status


@bp.get("/feedback/medicos/<int:doctor_id>/comentarios")
# Função doctor_feedback_comments_route: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def doctor_feedback_comments_route(doctor_id):
    payload, status = ok({"comentarios": doctor_comments(doctor_id)})
    # Retorno padronizado para quem chamou esta função.
    return jsonify(payload), status


@bp.get("/feedback/unidades/<int:unit_id>/media")
# Função unit_feedback_average_route: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def unit_feedback_average_route(unit_id):
    payload, status = ok({"resultado": unit_average(unit_id)})
    # Retorno padronizado para quem chamou esta função.
    return jsonify(payload), status


@bp.get("/feedback/unidades/<int:unit_id>/comentarios")
# Função unit_feedback_comments_route: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def unit_feedback_comments_route(unit_id):
    payload, status = ok({"comentarios": unit_comments(unit_id)})
    # Retorno padronizado para quem chamou esta função.
    return jsonify(payload), status
