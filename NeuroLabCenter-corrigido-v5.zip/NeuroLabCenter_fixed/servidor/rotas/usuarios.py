"""
Arquivo: servidor/rotas/usuarios.py

Objetivo:
    Implementar uma parte do servidor Flask do NeuroLab Center.

Como manter:
    Leia os comentários antes de alterar regras de negócio, rotas ou acesso ao banco.
    Preserve nomes em português e imports do pacote servidor.

Observação:
    Comentários foram adicionados para facilitar apresentação e manutenção.
"""

"""
NeuroLab Center - servidor/rotas/usuarios.py

Responsabilidade:
    Rotas Flask: recebe requisições HTTP do front-end e chama os serviços corretos.

Usado por:
    servidor/app.py ou outros módulos do pacote servidor.

Manutenção:
    Este comentário foi adicionado para facilitar leitura em apresentação e manutenção.
    Preserve os imports atualizados para o pacote `servidor`.
"""

from time import time

from flask import Blueprint, g, jsonify, request

from servidor.banco_de_dados.executor_sql import execute_query, query_all, query_one
from servidor.utilitarios.cpf import normalize_cpf
from servidor.utilitarios.erros import BusinessRuleError, NotFoundError, UnauthorizedError
from servidor.utilitarios.respostas import ok
from servidor.utilitarios.validacoes import parse_bool
from servidor.utilitarios.decoradores_autenticacao import require_auth, require_roles

bp = Blueprint("usuarios", __name__)

_CPF_EXISTS_WINDOW_SECONDS = 60
_CPF_EXISTS_MAX_REQUESTS = 20
_cpf_exists_attempts = {}


# Função _client_key: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def _client_key():
    forwarded = request.headers.get("X-Forwarded-For", "")
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if forwarded:
        # Retorno padronizado para quem chamou esta função.
        return forwarded.split(",")[0].strip()
    # Retorno padronizado para quem chamou esta função.
    return request.remote_addr or "local"


# Função _limitar_consulta_cpf_publica: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def _limitar_consulta_cpf_publica():
    """Limita chamadas publicas de /usuarios/<cpf>/existe.

    A rota continua publica para validar cadastro/login, mas nao deve aceitar
    tentativas ilimitadas de enumeracao de CPFs.
    """
    agora = time()
    chave = _client_key()
    recentes = [
        momento
        # Laço de repetição: percorre registros ou dados recebidos do sistema.
        for momento in _cpf_exists_attempts.get(chave, [])
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if agora - momento < _CPF_EXISTS_WINDOW_SECONDS
    ]
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if len(recentes) >= _CPF_EXISTS_MAX_REQUESTS:
        _cpf_exists_attempts[chave] = recentes
        raise BusinessRuleError(
            "Muitas consultas de CPF em pouco tempo. Aguarde e tente novamente.",
            code="cpf_lookup_rate_limited",
            status_code=429,
        )
    recentes.append(agora)
    _cpf_exists_attempts[chave] = recentes



# Função _pode_ver_usuario: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def _pode_ver_usuario(cpf_normalizado):
    tipo = str(getattr(g, "tipo_usuario", "") or "").lower()
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if tipo in {"admin", "administrador", "recepcionista"}:
        # Retorno padronizado para quem chamou esta função.
        return True
    # Retorno padronizado para quem chamou esta função.
    return normalize_cpf(getattr(g, "cpf", "") or "") == cpf_normalizado


SAFE_USER_FIELDS = "id, cpf, nome, telefone, email, tipo_usuario, data_cadastro, ativo"


@bp.get("/usuarios")
@require_roles("admin", "recepcionista")
# Função list_users: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def list_users():
    tipo_usuario = request.args.get("tipo_usuario")
    ativo = request.args.get("ativo")

    filters = []
    params = []
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if tipo_usuario:
        filters.append("tipo_usuario = %s")
        params.append(tipo_usuario)
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if ativo is not None:
        filters.append("ativo = %s")
        params.append(parse_bool(ativo, field_name="ativo"))

    where = f" WHERE {' AND '.join(filters)}" if filters else ""
    usuarios = query_all(
        f"SELECT {SAFE_USER_FIELDS} FROM usuarios{where} ORDER BY nome",
        tuple(params),
    )
    payload, status = ok({"usuarios": usuarios})
    # Retorno padronizado para quem chamou esta função.
    return jsonify(payload), status


@bp.get("/usuarios/<cpf>")
@require_auth
# Função get_user: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def get_user(cpf):
    normalized = normalize_cpf(cpf)
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if not _pode_ver_usuario(normalized):
        raise UnauthorizedError("Permissao insuficiente para consultar este usuario.", code="forbidden", status_code=403)

    usuario = query_one(
        f"SELECT {SAFE_USER_FIELDS} FROM usuarios WHERE cpf = %s",
        (normalized,),
    )
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if not usuario:
        raise NotFoundError("Usuario nao encontrado.", code="user_not_found")

    payload, status = ok(usuario)
    # Retorno padronizado para quem chamou esta função.
    return jsonify(payload), status


@bp.get("/usuarios/<cpf>/existe")
# Função user_exists: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def user_exists(cpf):
    _limitar_consulta_cpf_publica()
    normalized = normalize_cpf(cpf)
    usuario = query_one(
        "SELECT cpf FROM usuarios WHERE cpf = %s",
        (normalized,),
    )
    # Retorna somente o minimo necessario para cadastro/login.
    # Dados cadastrais completos ficam protegidos em GET /usuarios/<cpf>.
    payload, status = ok({"cpf": normalized, "existe": bool(usuario)})
    # Retorno padronizado para quem chamou esta função.
    return jsonify(payload), status


@bp.patch("/usuarios/<cpf>/status")
@require_roles("admin")
# Função update_user_status: concentra uma etapa da regra de negócio, rota ou apoio do servidor.
def update_user_status(cpf):
    data = request.get_json(silent=True) or {}
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if "ativo" not in data:
        raise BusinessRuleError("Informe o campo ativo.", code="missing_active_status")

    normalized = normalize_cpf(cpf)
    ativo_normalizado = parse_bool(data.get("ativo"), field_name="ativo")
    usuario = query_one("SELECT cpf FROM usuarios WHERE cpf = %s", (normalized,))
    # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
    if not usuario:
        raise NotFoundError("Usuario nao encontrado.", code="user_not_found")
    execute_query(
        "UPDATE usuarios SET ativo = %s WHERE cpf = %s",
        (ativo_normalizado, normalized),
    )
    payload, status = ok({"cpf": normalized, "ativo": ativo_normalizado})
    # Retorno padronizado para quem chamou esta função.
    return jsonify(payload), status
