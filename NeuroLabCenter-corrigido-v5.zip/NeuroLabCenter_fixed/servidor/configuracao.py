"""
Arquivo: servidor/configuracao.py

Objetivo:
    Implementar uma parte do servidor Flask do NeuroLab Center.

Como manter:
    Leia os comentários antes de alterar regras de negócio, rotas ou acesso ao banco.
    Preserve nomes em português e imports do pacote servidor.

Observação:
    Comentários foram adicionados para facilitar apresentação e manutenção.
"""

"""
NeuroLab Center - servidor/configuracao.py

Responsabilidade:
    Configurações centrais do servidor, incluindo MySQL, JWT e prefixo da API.

Usado por:
    servidor/app.py ou outros módulos do pacote servidor.

Manutenção:
    Este comentário foi adicionado para facilitar leitura em apresentação e manutenção.
    Preserve os imports atualizados para o pacote `servidor`.
"""

import os
from datetime import timedelta
from pathlib import Path

from dotenv import load_dotenv

load_dotenv(Path(__file__).resolve().parent / ".env")


# Classe Config: representa uma estrutura reutilizável pelo backend.
class Config:
    APP_NAME = "NeuroLab Center API"
    API_PREFIX = os.getenv("API_PREFIX", "/api")
    DEBUG = os.getenv("FLASK_DEBUG", "false").lower() == "true"
    CORS_ORIGINS = [
        origin.strip()
        # Laço de repetição: percorre registros ou dados recebidos do sistema.
        for origin in os.getenv(
            "CORS_ORIGINS",
            "http://127.0.0.1:5500,http://localhost:5500,http://127.0.0.1:5000,http://localhost:5000"
        ).split(",")
        # Decisão de fluxo: valida estado, permissão ou regra antes de continuar.
        if origin.strip()
    ]

    # Banco oficial do projeto: MySQL.
    # O projeto nao usa SQLite nem fallback automatico para outro banco.
    DB_DRIVER = "mysql"

    MYSQL_HOST = os.getenv("MYSQL_HOST", "localhost")
    MYSQL_PORT = int(os.getenv("MYSQL_PORT", "3306"))
    MYSQL_USER = os.getenv("MYSQL_USER", "root")
    MYSQL_PASSWORD = os.getenv("MYSQL_PASSWORD", "")  # definir no .env; sem senha = string vazia
    MYSQL_DATABASE = os.getenv("MYSQL_DATABASE", "neurolabcenter")
    MYSQL_POOL_NAME = os.getenv("MYSQL_POOL_NAME", "neurolab_pool")
    MYSQL_POOL_SIZE = int(os.getenv("MYSQL_POOL_SIZE", "5"))

    JWT_SECRET = os.getenv("JWT_SECRET", "neurolab-local-dev-secret-change-this-before-production-2026")
    JWT_EXPIRES_IN = timedelta(hours=int(os.getenv("JWT_EXPIRES_HOURS", "8")))

    MINOR_CONFIRMATION_AGE = int(os.getenv("MINOR_CONFIRMATION_AGE", "18"))
    RESPONSIBLE_CONFIRMATION_EXPIRES_HOURS = int(
        os.getenv("RESPONSIBLE_CONFIRMATION_EXPIRES_HOURS", "12")
    )

    CONSULTATION_MIN_HOURS = int(os.getenv("CONSULTATION_MIN_HOURS", "24"))
    TELECONSULTATION_MIN_HOURS = int(os.getenv("TELECONSULTATION_MIN_HOURS", "24"))
    EXAM_MIN_HOURS = int(os.getenv("EXAM_MIN_HOURS", "1"))
    APPOINTMENT_MAX_DAYS_AHEAD = int(os.getenv("APPOINTMENT_MAX_DAYS_AHEAD", "90"))

    RESCHEDULE_LIMIT_30_DAYS = int(os.getenv("RESCHEDULE_LIMIT_30_DAYS", "2"))
    SUS_RESCHEDULE_LIMIT_30_DAYS = int(os.getenv("SUS_RESCHEDULE_LIMIT_30_DAYS", "1"))

    CONSULTATION_CANCEL_MIN_HOURS = int(os.getenv("CONSULTATION_CANCEL_MIN_HOURS", "24"))
    EXAM_CANCEL_MIN_HOURS = int(os.getenv("EXAM_CANCEL_MIN_HOURS", "1"))

    LOGIN_MAX_ATTEMPTS = int(os.getenv("LOGIN_MAX_ATTEMPTS", "5"))
    LOGIN_BLOCK_MINUTES = int(os.getenv("LOGIN_BLOCK_MINUTES", "15"))

    PASSWORD_RESET_EXPIRES_MINUTES = int(os.getenv("PASSWORD_RESET_EXPIRES_MINUTES", "30"))
    PASSWORD_RESET_RATE_LIMIT_MINUTES = int(os.getenv("PASSWORD_RESET_RATE_LIMIT_MINUTES", "30"))
    PASSWORD_RESET_MAX_REQUESTS = int(os.getenv("PASSWORD_RESET_MAX_REQUESTS", "3"))
    # Por seguranca, o token de recuperacao nao e exposto por padrao.
    # Para demonstracao local sem SMTP, defina PASSWORD_RESET_EXPOSE_TOKEN=true conscientemente.
    PASSWORD_RESET_EXPOSE_TOKEN = os.getenv("PASSWORD_RESET_EXPOSE_TOKEN", "false").lower() == "true"
