<#
Arquivo: scripts/run-tests.ps1
# Etapa do script: executa uma ação auxiliar para validação/manutenção do projeto.
Objetivo: script auxiliar para testes ou execução local do projeto.
# Etapa do script: executa uma ação auxiliar para validação/manutenção do projeto.
Como manter: ajuste caminhos conforme a estrutura do NeuroLab Center.
#>

<#
  NeuroLab Center — documentação do script

# Etapa do script: executa uma ação auxiliar para validação/manutenção do projeto.
  Arquivo: scripts/run-tests.ps1

# Etapa do script: executa uma ação auxiliar para validação/manutenção do projeto.
  Por que este arquivo existe:
# Etapa do script: executa uma ação auxiliar para validação/manutenção do projeto.
  Automatiza comandos repetitivos para reduzir erro manual na hora de testar
# Etapa do script: executa uma ação auxiliar para validação/manutenção do projeto.
  ou apresentar o projeto em ambiente Windows.
#>

$ErrorActionPreference = "Stop"

# Etapa do script: executa uma ação auxiliar para validação/manutenção do projeto.
$root = Split-Path -Parent $PSScriptRoot

# Etapa do script: executa uma ação auxiliar para validação/manutenção do projeto.
Push-Location $root
# Etapa do script: executa uma ação auxiliar para validação/manutenção do projeto.
try {
# Etapa do script: executa uma ação auxiliar para validação/manutenção do projeto.
    python -m compileall -q servidor
# Etapa do script: executa uma ação auxiliar para validação/manutenção do projeto.
    python -m pytest servidor\testes\testes_fluxos_principais.py servidor\testes\test_banco_e_apresentacao.py

# Etapa do script: executa uma ação auxiliar para validação/manutenção do projeto.
    Push-Location (Join-Path $root "api-do-chatbot")
# Etapa do script: executa uma ação auxiliar para validação/manutenção do projeto.
    try {
# Etapa do script: executa uma ação auxiliar para validação/manutenção do projeto.
        npm test
# Etapa do script: executa uma ação auxiliar para validação/manutenção do projeto.
    } finally {
# Etapa do script: executa uma ação auxiliar para validação/manutenção do projeto.
        Pop-Location
# Etapa do script: executa uma ação auxiliar para validação/manutenção do projeto.
    }

# Etapa do script: executa uma ação auxiliar para validação/manutenção do projeto.
    Get-ChildItem -Recurse -Filter *.js |
# Etapa do script: executa uma ação auxiliar para validação/manutenção do projeto.
        Where-Object { $_.FullName -notlike "*\node_modules\*" } |
# Etapa do script: executa uma ação auxiliar para validação/manutenção do projeto.
        ForEach-Object {
# Etapa do script: executa uma ação auxiliar para validação/manutenção do projeto.
            node --check $_.FullName
# Etapa do script: executa uma ação auxiliar para validação/manutenção do projeto.
        }
# Etapa do script: executa uma ação auxiliar para validação/manutenção do projeto.
} finally {
# Etapa do script: executa uma ação auxiliar para validação/manutenção do projeto.
    Pop-Location
# Etapa do script: executa uma ação auxiliar para validação/manutenção do projeto.
}
