"""Aplica cache-bust nos HTML e limpa cadastros do MySQL."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

LOG = []


def cache_bust_html():
    for html in (ROOT / "site" / "paginas").glob("*.html"):
        text = html.read_text(encoding="utf-8")
        new = text
        for name in ("api-do-servidor.js", "autenticacao.js", "formularios.js", "inicializacao.js"):
            new = re.sub(rf"{re.escape(name)}(\?v=\d+)?", f"{name}?v=20260612", new)
        if new != text:
            html.write_text(new, encoding="utf-8")
            LOG.append(f"HTML atualizado: {html.name}")


def limpar_banco():
    from servidor.banco_de_dados.limpar_dados import limpar_cadastros_pessoais

    limpar_cadastros_pessoais()
    LOG.append("MySQL: todos os CPFs removidos da tabela usuarios.")


if __name__ == "__main__":
    cache_bust_html()
    try:
        limpar_banco()
    except Exception as error:
        LOG.append(f"ERRO MySQL: {error}")
    output = "\n".join(LOG) if LOG else "Nada a fazer."
    print(output)
    (ROOT / "scripts" / "aplicar_correcao_cpf.log").write_text(output, encoding="utf-8")
