/*
 * Arquivo: recursos/scripts/agendamento.js
 * Objetivo: controlar comportamentos da interface do NeuroLab Center.
 * Como manter: mantenha funções pequenas, nomes claros e evite misturar páginas diferentes.
 * Observação: comentários explicam blocos, funções, validações e integração com o servidor.
 */

/*
 * NeuroLab Center - recursos/scripts/agendamento.js
 * Responsabilidade: Script principal de funcionalidade do site.
 * Usado por: Páginas HTML em site/paginas/.
 * Manutenção: mantenha funções relacionadas juntas e evite misturar regras de páginas diferentes.
 */

/**
 * NeuroLab Center — agendamento.js
 * Arquivo consolidado para apresentação e manutenção.
 * Carregadores document.write e pastas part/section foram substituídos por código direto.
 */

// ============================================================================
// ============================================================================

/**
 * NeuroLab Center — documentação do arquivo
 *
 * Arquivo: recursos/scripts/app/booking-flow.js
 *
 * Por que este arquivo existe:
 * Este script fica separado para manter uma responsabilidade clara no site
 * ou no microserviço Node.js. Isso evita que a apresentação dependa de um único
 * arquivo gigante e facilita encontrar erros de caminho, import ou regra visual.
 */

// ====== INICIALIZAÇÃO: Garantir variáveis globais ======
if (typeof agendamentoAtual === 'undefined') {
  window.agendamentoAtual = {};
}
if (typeof agendamentoPasso === 'undefined') {
  window.agendamentoPasso = 1;
}
if (typeof holdInterval === 'undefined') {
  window.holdInterval = null;
}
if (typeof holdExpiraEm === 'undefined') {
  window.holdExpiraEm = null;
}

function selecionarTipo(nome, codigo) {
  // O fluxo guarda estado em agendamentoAtual para permitir navegação por passos
  // sem enviar dados incompletos para a API antes da confirmação final.
  agendamentoAtual = { tipoNome: nome, tipoCodigo: codigo };
  document.querySelectorAll('#agStep1 .tipo-btn').forEach(btn => btn.classList.remove('selected'));
  window.event?.currentTarget?.classList.add('selected');
  const avisoTeleSus = $('avisoTeleSus');
  const btnSus = $('btnSUS');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (avisoTeleSus) avisoTeleSus.classList.toggle('hidden', codigo !== 'TELE');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (btnSus) btnSus.disabled = codigo === 'TELE';
  irParaPasso(2);
}

// Função selecionarCobertura: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function selecionarCobertura(cobertura) {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (agendamentoAtual.tipoCodigo === 'TELE' && cobertura === 'SUS') {
    mostrarToast('Teleconsulta não está disponível pelo SUS. Escolha Particular ou Convênio.', 'aviso');
    return;
  }

  document.querySelectorAll('#agStep2 .tipo-btn').forEach(btn => btn.classList.remove('selected'));
  window.event?.currentTarget?.classList.add('selected');
  agendamentoAtual.cobertura = cobertura;

  const convenioSelect = $('convenioSelect');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (cobertura === 'Convênio') {
    convenioSelect?.classList.remove('hidden');
    return;
  }

// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (convenioSelect) convenioSelect.classList.add('hidden');
  agendamentoAtual.convenio = '';
  
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (agendamentoAtual.tipoCodigo === 'TELE') {
    agendamentoAtual.unidade = 'Teleconsulta Central';
    agendamentoAtual.endereco = 'Atendimento Online por Vídeo';
    irParaPasso(4);
  } else {
    irParaPasso(3);
  }
}

// Função confirmarConvenio: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function confirmarConvenio() {
  const convenio = $('convenioNome')?.value;
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!convenio) {
    mostrarToast('Selecione um convênio para continuar.', 'aviso');
    return;
  }

  agendamentoAtual.convenio = convenio;
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (agendamentoAtual.tipoCodigo === 'TELE') {
    agendamentoAtual.unidade = 'Teleconsulta Central';
    agendamentoAtual.endereco = 'Atendimento Online por Vídeo';
    irParaPasso(4);
  } else {
    irParaPasso(3);
  }
}

// Função voltarPasso: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function voltarPasso() {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (agendamentoPasso > 1) {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (agendamentoAtual.tipoCodigo === 'TELE' && agendamentoPasso === 4) {
      irParaPasso(2);
    } else {
      irParaPasso(agendamentoPasso - 1);
    }
  }
}

// Função buscarUnidadePorCep: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function buscarUnidadePorCep() {
  const cep = somenteDigitos($('agCep')?.value);
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (cep.length !== 8) {
    mostrarToast('Digite um CEP válido com 8 dígitos.', 'aviso');
    return;
  }
  $('unidadesDisponiveis')?.classList.remove('hidden');
}

// Função selecionarUnidade: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function selecionarUnidade(nome, endereco) {
  agendamentoAtual.unidade = nome;
  agendamentoAtual.endereco = endereco;
  document.querySelectorAll('.unidade-card').forEach(card => card.classList.remove('selected'));
  window.event?.currentTarget?.classList.add('selected');
  const label = $('ag4Label');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (label) label.textContent = `${agendamentoAtual.tipoNome || ''} · ${agendamentoAtual.cobertura || ''} · ${nome}`;
  irParaPasso(4);
}

// Função selecionarMedico: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function selecionarMedico(nome, crm, especialidade, rating, avaliacoes) {
  agendamentoAtual.medico = nome;
  agendamentoAtual.crm = crm;
  agendamentoAtual.especialidade = especialidade;
  agendamentoAtual.rating = rating;
  agendamentoAtual.avaliacoes = avaliacoes;
  document.querySelectorAll('.medico-card').forEach(card => card.classList.remove('selected'));
  window.event?.currentTarget?.classList.add('selected');
  irParaPasso(5);
}


// Função selecionarHorario: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function selecionarHorario(dia, horario, elemento) {
  agendamentoAtual.dia = dia;
  agendamentoAtual.horario = horario;
  document.querySelectorAll('.horario-btn').forEach(btn => btn.classList.remove('selected'));
  elemento?.classList.add('selected');
  iniciarHold(10 * 60);
  $('btnAvancarPasso6')?.classList.remove('hidden');
}

// Função iniciarHold: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function iniciarHold(segundos) {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (holdInterval) window.clearInterval(holdInterval);
  holdInterval = null;
  holdExpiraEm = Date.now() + segundos * 1000;
  $('holdTimer')?.classList.remove('hidden');
  atualizarHold();
  holdInterval = window.setInterval(atualizarHold, 1000);
}

// Função atualizarHold: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function atualizarHold() {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!holdExpiraEm) return;
  const restante = Math.max(0, Math.floor((holdExpiraEm - Date.now()) / 1000));
  const minutos = String(Math.floor(restante / 60)).padStart(2, '0');
  const segundos = String(restante % 60).padStart(2, '0');
  const label = $('holdHorarioLabel');
  const countdown = $('holdCountdown');

// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (label) label.textContent = `${agendamentoAtual.dia || ''} às ${agendamentoAtual.horario || ''}`;
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (countdown) {
    countdown.textContent = `${minutos}:${segundos}`;
    countdown.classList.toggle('urgente', restante <= 60);
  }

// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (restante <= 0) {
    liberarHold();
    mostrarToast('Tempo esgotado. O horário foi liberado. Selecione novamente.', 'aviso', 5000);
    irParaPasso(5);
  }
}

// Função liberarHold: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function liberarHold(limparHorario = true) {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (holdInterval) window.clearInterval(holdInterval);
  holdInterval = null;
  holdExpiraEm = null;
  $('holdTimer')?.classList.add('hidden');
  $('btnAvancarPasso6')?.classList.add('hidden');
  document.querySelectorAll('.horario-btn').forEach(btn => btn.classList.remove('selected'));
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (limparHorario) {
    delete agendamentoAtual.dia;
    delete agendamentoAtual.horario;
  }
}

// Função voltarPassoComHold: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function voltarPassoComHold() {
  liberarHold();
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (agendamentoPasso > 1) irParaPasso(agendamentoPasso - 1);
}

// Função avancarParaConfirmacao: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function avancarParaConfirmacao() {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!agendamentoAtual.dia || !agendamentoAtual.horario) {
    mostrarToast('Selecione um horário para continuar.', 'aviso');
    return;
  }

  preencherResumo('resumoAgendamento');
  const prepBox = $('prepExameBox');
  const prepLista = $('prepExameLista');
  const isExame = agendamentoAtual.tipoCodigo === 'EXAM';
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (prepBox && prepLista) {
    prepBox.classList.toggle('hidden', !isExame);
    prepLista.innerHTML = isExame ? examesInfo[0].preparo.map(item => `<li>${item}</li>`).join('') : '';
  }
  irParaPasso(6);
}

// Função confirmarAgendamentoFinal: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
async function confirmarAgendamentoFinal() {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!holdExpiraEm || holdExpiraEm < Date.now()) {
    mostrarToast('O horário reservado expirou. Selecione novamente.', 'aviso');
    liberarHold();
    irParaPasso(5);
    return;
  }

  const pacienteCpf = typeof getPerfilAtivoCpf === 'function' ? getPerfilAtivoCpf() : null;
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!pacienteCpf || pacienteCpf === 'visitante') {
    mostrarToast('Entre na sua conta para salvar o agendamento no banco.', 'aviso', 6000);
    return;
  }
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (typeof apiCriarAgendamentoMySQL !== 'function') {
    console.error('[AGENDAMENTO] apiCriarAgendamentoMySQL não está carregada!');
    mostrarToast('Erro ao carregar cliente da API. Recarregue a página.', 'erro', 6000);
    return;
  }

// Bloco protegido: tenta executar a ação e permite tratar falhas sem travar a página.
  try {
    console.log('[AGENDAMENTO] Iniciando confirmação com dados:', agendamentoAtual);
    
    const botaoConfirmar = document.querySelector('button[onclick="confirmarAgendamentoFinal()"]');
    if (botaoConfirmar) botaoConfirmar.disabled = true;
    
    const registro = await apiCriarAgendamentoMySQL(agendamentoAtual);
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (holdInterval) window.clearInterval(holdInterval);
    holdInterval = null;
    holdExpiraEm = null;
    
    console.log('[AGENDAMENTO] Sucesso! Registro:', registro);
    preencherResumo('sucessoResumo', registro);
    irParaPasso('Sucesso');
    mostrarToast('Agendamento confirmado com sucesso! Verifique seu e-mail e WhatsApp.', 'sucesso');
  } catch (erro) {
    console.error('[AGENDAMENTO] Erro ao confirmar:', erro);
    mostrarToast(erro.message || 'Erro ao confirmar agendamento. Tente novamente.', 'erro', 7000);
    
    const botaoConfirmar = document.querySelector('button[onclick="confirmarAgendamentoFinal()"]');
    if (botaoConfirmar) botaoConfirmar.disabled = false;
  }
}

// Função novoAgendamento: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function novoAgendamento() {
  agendamentoAtual = {};
  liberarHold();
  document.querySelectorAll('.selected').forEach(el => el.classList.remove('selected'));
  irParaPasso(1);
}


// Função irParaPasso: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function irParaPasso(passo) {
  agendamentoPasso = typeof passo === 'number' ? passo : 6;
  document.querySelectorAll('.ag-step').forEach(step => step.classList.add('hidden'));
  const alvo = passo === 'Sucesso' ? $('agStepSucesso') : $(`agStep${passo}`);
  alvo?.classList.remove('hidden');

  const passoNumerico = passo === 'Sucesso' ? 6 : passo;
  document.querySelectorAll('.progress-step').forEach(step => {
    const numero = Number(step.dataset.step);
    step.classList.toggle('active', numero === passoNumerico);
    step.classList.toggle('done', numero < passoNumerico || passo === 'Sucesso');
  });

  const fill = $('progressFill');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (fill) fill.style.width = `${((passoNumerico - 1) / 5) * 100}%`;
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

// Função preencherResumo: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function preencherResumo(id, dados = agendamentoAtual) {
  const container = $(id);
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!container) return;
  const cobertura = dados.cobertura === 'Convênio' && dados.convenio ? `${dados.cobertura} (${dados.convenio})` : dados.cobertura;
  container.innerHTML = `
    <div class="resumo-row"><span class="resumo-label">Tipo</span><span class="resumo-val">${dados.tipoNome || '-'}</span></div>
    <div class="resumo-row"><span class="resumo-label">Cobertura</span><span class="resumo-val">${cobertura || '-'}</span></div>
    <div class="resumo-row"><span class="resumo-label">Unidade</span><span class="resumo-val">${dados.unidade || '-'}</span></div>
    <div class="resumo-row"><span class="resumo-label">Médico</span><span class="resumo-val">${dados.medico || '-'} ${dados.crm ? `· ${dados.crm}` : ''}</span></div>
    <div class="resumo-row"><span class="resumo-label">Data</span><span class="resumo-val">${dados.dia || '-'} às ${dados.horario || '-'}</span></div>
  `;
}

// ============================================================================
// ============================================================================

// ── Calendário dinâmico adaptativo com disponibilidade vinda do MySQL ──────────────────────
const DIAS_PT = ['Dom','Seg','Ter','Qua','Qui','Sex','Sáb'];
// Configuração ou referência reutilizada pelas funções deste arquivo.
const MESES_PT = ['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez'];

// Configuração ou referência reutilizada pelas funções deste arquivo.
const SLOTS_MANHA = ['07:30','08:00','08:30','09:00','09:30','10:00','10:30','11:00','11:30'];
// Configuração ou referência reutilizada pelas funções deste arquivo.
const SLOTS_TARDE = ['13:00','13:30','14:00','14:30','15:00','15:30','16:00','16:30','17:00'];

// Função nlCalendarIso: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function nlCalendarIso(date) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
}

// Função nlCalendarHorariosOcupados: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
async function nlCalendarHorariosOcupados(dataISO) {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!agendamentoAtual?.medico || !agendamentoAtual?.unidade || typeof apiConsultarDisponibilidadeMySQL !== 'function') return [];
// Bloco protegido: tenta executar a ação e permite tratar falhas sem travar a página.
  try {
    const disponibilidade = await apiConsultarDisponibilidadeMySQL({ ...agendamentoAtual, dataISO });
    return (disponibilidade.horarios_ocupados || []).map(h => String(h).slice(0, 5));
  } catch (erro) {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (typeof mostrarToast === 'function') {
      mostrarToast('Não foi possível consultar horários ocupados no MySQL. Verifique Flask/MySQL.', 'aviso', 5000);
    }
    return [];
  }
}

async function buildCalendar() {
  const grid = document.getElementById('calendarGrid');
  if (!grid) return;
  
  const minDate = new Date();
  minDate.setDate(minDate.getDate() + 1);
  const minIso = nlCalendarIso(minDate);

  grid.innerHTML = `
    <div style="margin-bottom: 20px;">
      <label style="font-weight: bold; display: block; margin-bottom: 8px;">Selecione o dia desejado:</label>
      <input type="date" id="calendarDateInput" min="${minIso}" class="view-style-008" style="padding: 10px; border-radius: 8px; border: 1px solid #ccc; width: 100%; max-width: 300px; font-size: 16px;">
    </div>
    <div id="calendarSlotsContainer">
      <p class="empty-state">Selecione uma data acima para ver os horários disponíveis.</p>
    </div>
  `;

  document.getElementById('calendarDateInput').addEventListener('change', async function() {
    const container = document.getElementById('calendarSlotsContainer');
    if (!this.value) {
      container.innerHTML = '<p class="empty-state">Selecione uma data acima para ver os horários disponíveis.</p>';
      return;
    }
    
    const d = new Date(this.value + 'T12:00:00');
    const dow = d.getDay();
    if (dow === 0 || dow === 6) {
      container.innerHTML = '<p class="empty-state" style="color: red;">Não há atendimento aos finais de semana. Selecione um dia útil.</p>';
      return;
    }
    
    container.innerHTML = '<div class="empty-state"><span>⏳</span><p>Consultando disponibilidade no MySQL...</p></div>';
    
    const dataISO = this.value;
    const short = `${DIAS_PT[dow]} ${String(d.getDate()).padStart(2, '0')}/${String(d.getMonth() + 1).padStart(2, '0')}`;
    const occ = await nlCalendarHorariosOcupados(dataISO);
    
    container.innerHTML = `
      <div class="cal-day-col" style="max-width: 100%; border: none;">
        <div class="cal-day-header">${DIAS_PT[dow]}<small>${d.getDate()} ${MESES_PT[d.getMonth()]}</small></div>
        <div class="cal-slots" style="display: flex; flex-wrap: wrap; gap: 10px; justify-content: flex-start;">
          <div style="width: 100%;"><div class="cal-period-label">☀️ Manhã</div></div>
          ${SLOTS_MANHA.map(h => `<button class="cal-slot${occ.includes(h) ? ' ocupado' : ''}" ${occ.includes(h) ? 'disabled' : ''} onclick="selecionarHorario('${short}','${h}',this); agendamentoAtual.dataISO='${dataISO}'">${h}</button>`).join('')}
          <div style="width: 100%;"><div class="cal-period-label">🌤️ Tarde</div></div>
          ${SLOTS_TARDE.map(h => `<button class="cal-slot${occ.includes(h) ? ' ocupado' : ''}" ${occ.includes(h) ? 'disabled' : ''} onclick="selecionarHorario('${short}','${h}',this); agendamentoAtual.dataISO='${dataISO}'">${h}</button>`).join('')}
        </div>
      </div>
    `;
  });
}

// Configuração ou referência reutilizada pelas funções deste arquivo.
const _origSel = window.selecionarHorario;
const nlCalendarSelecionarHorario = (dia, hora, el) => {
  document.querySelectorAll('.cal-slot.selecionado').forEach(b => b.classList.remove('selecionado'));
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (el) el.classList.add('selecionado');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (typeof _origSel === 'function') _origSel(dia, hora, el);
};
window.selecionarHorario = nlCalendarSelecionarHorario;

// Evento da interface: conecta uma ação do usuário com uma função do sistema.
document.addEventListener('DOMContentLoaded', buildCalendar);
// Configuração ou referência reutilizada pelas funções deste arquivo.
const _origAv = window.avancarPasso;
window.avancarPasso = function(...args) {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (typeof _origAv === 'function') _origAv(...args);
  setTimeout(() => { if (!document.getElementById('agStep5')?.classList.contains('hidden')) buildCalendar(); }, 50);
};

// Busca de unidade por rua/avenida no agendamento
window.buscarUnidadePorRua = function() {
  const input = document.getElementById('agRua');
  const termo = (input?.value || '').trim();
  const grid = document.getElementById('unidadesDisponiveis');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!termo || termo.length < 3) {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (typeof mostrarToast === 'function') mostrarToast('Digite pelo menos 3 letras do endereço.', 'aviso');
    return;
  }
  const termoNorm = (typeof normalizarTexto === 'function') ? normalizarTexto(termo) : termo.toLowerCase();
  const todasUnidades = typeof NL_UNIDADES !== 'undefined' ? NL_UNIDADES : [];
  const encontradas = todasUnidades.filter(u =>
    termoNorm && (
      (typeof normalizarTexto === 'function' ? normalizarTexto(u.endereco) : u.endereco.toLowerCase()).includes(termoNorm) ||
      (typeof normalizarTexto === 'function' ? normalizarTexto(u.nome) : u.nome.toLowerCase()).includes(termoNorm)
    ) && u.modalidades && !u.modalidades.every(m => m === 'TELE')
  );
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!grid) return;
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!encontradas.length) {
    grid.innerHTML = '<p class="field-hint error">Nenhuma unidade encontrada para esse endereço.</p>';
    return;
  }
  grid.innerHTML = encontradas.map(u => `
    <div class="unidade-card" onclick="selecionarUnidade('${u.nome.replace(/'/g, "\\'")}', '${u.endereco.replace(/'/g, "\\'")}')">
      <div class="unidade-icon">🏥</div>
      <div class="unidade-info"><strong>${u.nome}</strong><span>${u.endereco}</span></div>
    </div>
  `).join('');
};
