/*
 * Arquivo: recursos/scripts/comum/busca-de-endereco.js
 * Objetivo: controlar comportamentos da interface do NeuroLab Center.
 * Como manter: mantenha funções pequenas, nomes claros e evite misturar páginas diferentes.
 * Observação: comentários explicam blocos, funções, validações e integração com o servidor.
 */

/*
 * NeuroLab Center - recursos/scripts/comum/busca-de-endereco.js
 * Responsabilidade: Funções compartilhadas por várias páginas, como avisos, busca, exames e regras.
 * Usado por: Páginas HTML em site/paginas/.
 * Manutenção: mantenha funções relacionadas juntas e evite misturar regras de páginas diferentes.
 */

/**
 * NeuroLab Center — address-search.js
 * Busca de CEP, cidade, rua e integração com mapa.
 * Separado do antigo utils.js para facilitar manutenção.
 */

// ============================================================================

/**
 * NeuroLab Center — documentação do arquivo
 *
 * Arquivo: recursos/scripts/compartilhado/address-search.js
 *
 * Por que este arquivo existe:
 * Este script fica separado para manter uma responsabilidade clara no site
 * ou no microserviço Node.js. Isso evita que a apresentação dependa de um único
 * arquivo gigante e facilita encontrar erros de caminho, import ou regra visual.
 */

// Utilitários locais: este arquivo não depende mais de plans-units-patient.js.
function nlAddressSafeText(valor) {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (typeof window.nlSafeText === 'function') return window.nlSafeText(valor);
  return String(valor ?? '').replace(/[&<>"']/g, (char) => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#039;'
  }[char]));
}

// Função nlAddressDigits: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function nlAddressDigits(valor) {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (typeof window.somenteDigitos === 'function') return window.somenteDigitos(valor);
  return String(valor || '').replace(/\D/g, '');
}

// API pública usada: ViaCEP.
// Ela consulta o CEP, pega cidade/UF/bairro e abre o mapa da região com uma busca de hospital.
function mascararCep(input) {
  let valor = input.value.replace(/\D/g, '').slice(0, 8);
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (valor.length > 5) valor = valor.replace(/^(\d{5})(\d{1,3})$/, '$1-$2');
  input.value = valor;
}

// Função pesquisarCepAPI: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
async function pesquisarCepAPI(inputId = 'cepBusca') {
  const input = document.getElementById(inputId) || document.getElementById('cepBusca') || document.getElementById('ruaBusca');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!input) return;
  const resultado = document.getElementById('resultadoCep');
  const mapaBox = document.getElementById('mapaBox');
  const mapaIframe = document.getElementById('mapaIframe');
  const cep = input.value.replace(/\D/g, '');

// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!resultado || !mapaBox || !mapaIframe) {
    const grid = document.getElementById('unidadesDisponiveis');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (grid && cep.length === 8 && typeof NL_UNIDADES !== 'undefined') {
      const unidades = NL_UNIDADES.filter(unidade => unidade.modalidades && !unidade.modalidades.every(m => m === 'TELE'));
      grid.classList.remove('hidden');
      grid.innerHTML = unidades.map((unidade, index) => `
        <div class="unidade-card ${index === 0 ? 'recomendada' : ''}" onclick="selecionarUnidade('${unidade.nome.replace(/'/g, "\\'")}', '${unidade.endereco.replace(/'/g, "\\'")}')">
          <strong>${nlAddressSafeText(unidade.nome)}</strong>
          <small>${nlAddressSafeText(unidade.endereco)}</small>
          <div class="tags" style="margin-top:8px;">${(unidade.coberturas || []).map(c => `<span class="tag">${nlAddressSafeText(c)}</span>`).join('')}</div>
        </div>
      `).join('');
      return;
    }
    return pesquisarPorRua(inputId);
  }

// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!cep || cep.length !== 8) {
    resultado.classList.remove('loading');
    resultado.innerHTML = 'Digite um CEP válido com 8 números. Ex: 09015-000.';
    mapaBox.classList.add('hidden');
    return;
  }

  resultado.classList.add('loading');
  resultado.innerHTML = 'Consultando CEP na API ViaCEP...';

// Bloco protegido: tenta executar a ação e permite tratar falhas sem travar a página.
  try {
    const resposta = await fetch(`https://viacep.com.br/ws/${cep}/json/`);
    const dados = await resposta.json();

// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (dados.erro) {
      resultado.classList.remove('loading');
      resultado.innerHTML = '<strong>CEP não encontrado.</strong><br>Confira os números e tente novamente.';
      mapaBox.classList.add('hidden');
      return;
    }

    const logradouro = dados.logradouro || '';
    const enderecoCompleto = [logradouro, dados.bairro, dados.localidade, dados.uf].filter(Boolean).join(' - ');
    const endereco = `${dados.localidade} ${dados.uf} ${dados.bairro || ''}`.trim();
    const ruaBusca = document.getElementById('ruaBusca');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (ruaBusca && dados.logradouro) {
      ruaBusca.value = [dados.logradouro, dados.bairro].filter(Boolean).join(', ');
      ruaBusca.dataset.cep = cep;
    }
    const buscaMapa = encodeURIComponent(`hospital NeuroLab Center próximo de ${endereco}`);
    const linkMapa = `https://www.google.com/maps/search/?api=1&query=${buscaMapa}`;
    const linkWaze = `https://waze.com/ul?q=${buscaMapa}`;
    const embedMapa = `https://maps.google.com/maps?q=${buscaMapa}&output=embed`;

    if (window.speechSynthesis) {
      window.speechSynthesis.speak(new SpeechSynthesisUtterance(`Endereço encontrado: ${logradouro || dados.localidade}`));
    }

    resultado.classList.remove('loading');
    resultado.innerHTML = `
      <strong>Região encontrada: ${dados.localidade} - ${dados.uf}</strong><br>
      Bairro: ${dados.bairro || 'não informado'}<br>
      Endereço base: ${enderecoCompleto || 'não informado'}<br><br>
      Unidade sugerida: <strong>Hospital NeuroLab Center da região</strong><br>
      <a class="map-link" href="${linkMapa}" target="_blank">Abrir no Google Maps →</a><br>
      <a class="map-link" style="color: #007bff; font-weight: bold; margin-top: 5px; display: inline-block;" href="${linkWaze}" target="_blank">Abrir no Waze →</a>
    `;

    mapaIframe.src = embedMapa;
    mapaBox.classList.remove('hidden');
  } catch (erro) {
    resultado.classList.remove('loading');
    resultado.innerHTML = '<strong>Erro ao consultar o CEP.</strong><br>Verifique sua internet ou tente novamente mais tarde.';
    mapaBox.classList.add('hidden');
  }
}


// Função normalizarTexto: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function normalizarTexto(texto) {
  return texto
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .trim();
}

// Função nlEnderecoPartes: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function nlEnderecoPartes(valor) {
  const texto = (valor || '').trim().replace(/\s+/g, ' ');
  const digitos = nlAddressDigits(texto);
  const temLetra = /[A-Za-zÀ-ÿ]/.test(texto);
  const cep = digitos.length >= 8 && !temLetra ? digitos.slice(0, 8) : '';
  const numeroMatch = !cep ? texto.match(/(?:,\s*|\s+)(\d{1,6}[A-Za-z]?)\s*$/) : null;
  const numero = numeroMatch ? numeroMatch[1] : '';
  const ruaBase = numeroMatch ? texto.slice(0, numeroMatch.index).replace(/[,\s]+$/, '') : texto;

  return {
    texto,
    cep,
    numero,
    ruaBase,
    busca: cep ? texto : (numero ? `${ruaBase} ${numero}` : texto)
  };
}

// Função nlEnderecoEhCep: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function nlEnderecoEhCep(valor) {
  return Boolean(nlEnderecoPartes(valor).cep);
}

// Compatibilidade com botões antigos
function pesquisarCidade() {
  pesquisarCepAPI();
}

// Função pesquisarEnderecoInteligente: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function pesquisarEnderecoInteligente(inputId = 'ruaBusca') {
  const input = document.getElementById(inputId);
  const valor = (input?.value || '').trim();
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!valor) return;
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (nlEnderecoEhCep(valor)) return pesquisarCepAPI(inputId);
  return pesquisarPorRua(inputId);
}


// Função pesquisarPorRua: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function pesquisarPorRua(inputId = 'ruaBusca') {
  const input = document.getElementById(inputId) || document.getElementById('ruaBusca');
  const resultado = document.getElementById('resultadoCep');
  const mapaBox = document.getElementById('mapaBox');
  const mapaIframe = document.getElementById('mapaIframe');
  const termo = (input?.value || '').trim();

  const mostrarMensagem = (html, tipo = 'info') => {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (resultado) {
      resultado.classList.remove('loading');
      resultado.innerHTML = html;
    } else if (typeof mostrarToast === 'function') {
      mostrarToast(String(html).replace(/<[^>]+>/g, ' '), tipo);
    }
  };

  const esconderMapa = () => mapaBox?.classList.add('hidden');
  const mostrarMapa = (src) => {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (!mapaBox || !mapaIframe) return;
    mapaIframe.src = src;
    mapaBox.classList.remove('hidden');
  };

// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!termo || termo.length < 3) {
    mostrarMensagem('Digite pelo menos 3 letras do nome da rua, avenida ou bairro.', 'aviso');
    esconderMapa();
    return;
  }

  const unidades = (typeof NL_UNIDADES !== 'undefined' && Array.isArray(NL_UNIDADES)) ? NL_UNIDADES : [];
  const partesEndereco = nlEnderecoPartes(termo);
  const termoNorm = normalizarTexto(partesEndereco.ruaBase || termo);

  const unidadeEncontrada = unidades.find(unidade =>
    normalizarTexto(unidade.endereco || '').includes(termoNorm) ||
    normalizarTexto(unidade.nome || '').includes(termoNorm)
  );

// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (unidadeEncontrada) {
    const buscaMapa = encodeURIComponent(unidadeEncontrada.endereco || unidadeEncontrada.nome);
    const linkMapa = `https://www.google.com/maps/search/?api=1&query=${buscaMapa}`;
    const linkWaze = `https://waze.com/ul?q=${buscaMapa}`;
    const embedMapa = unidadeEncontrada.mapa || `https://maps.google.com/maps?q=${buscaMapa}&output=embed`;

    if (window.speechSynthesis) {
      window.speechSynthesis.speak(new SpeechSynthesisUtterance(`Unidade encontrada: ${unidadeEncontrada.nome}`));
    }

    mostrarMensagem(`
      <strong>Unidade encontrada: ${nlAddressSafeText(unidadeEncontrada.nome)}</strong><br>
      Endereço: ${nlAddressSafeText(unidadeEncontrada.endereco)}<br><br>
      <a class="map-link" href="${linkMapa}" target="_blank" rel="noopener">Abrir no Google Maps →</a><br>
      <a class="map-link" style="color: #007bff; font-weight: bold; margin-top: 5px; display: inline-block;" href="${linkWaze}" target="_blank" rel="noopener">Abrir no Waze →</a>
    `);
    mostrarMapa(embedMapa);
    return;
  }

  const grid = document.getElementById('unidadesDisponiveis');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (grid && unidades.length) {
    const encontradas = unidades.filter(unidade =>
      !unidade.modalidades?.every(m => m === 'TELE') && (
        normalizarTexto(unidade.endereco || '').includes(termoNorm) ||
        normalizarTexto(unidade.nome || '').includes(termoNorm) ||
        normalizarTexto((unidade.coberturas || []).join(' ')).includes(termoNorm)
      )
    );
    grid.classList.remove('hidden');
    grid.innerHTML = encontradas.length ? encontradas.map(unidade => `
      <div class="unidade-card" onclick="selecionarUnidade('${String(unidade.nome || '').replace(/'/g, "\\'")}', '${String(unidade.endereco || '').replace(/'/g, "\\'")}')">
        <div class="unidade-icon">🏥</div>
        <div class="unidade-info"><strong>${nlAddressSafeText(unidade.nome)}</strong><span>${nlAddressSafeText(unidade.endereco)}</span></div>
      </div>
    `).join('') : '<p class="field-hint error">Nenhuma unidade encontrada para esse endereço.</p>';
  }

  const buscaMapa = encodeURIComponent(`NeuroLab Center ${partesEndereco.busca} Santo André SP`);
  const linkMapa = `https://www.google.com/maps/search/?api=1&query=${buscaMapa}`;
  const linkWaze = `https://waze.com/ul?q=${buscaMapa}`;
  const embedMapa = `https://maps.google.com/maps?q=${buscaMapa}&output=embed`;

  if (window.speechSynthesis) {
    window.speechSynthesis.speak(new SpeechSynthesisUtterance(`Buscando por: ${partesEndereco.busca}`));
  }

  mostrarMensagem(`
    <strong>Buscando por: "${nlAddressSafeText(partesEndereco.busca)}"</strong><br>
    Nenhuma unidade NeuroLab encontrada exatamente nesse endereço. Veja as unidades mais próximas no mapa ou confira a lista abaixo.<br><br>
    <a class="map-link" href="${linkMapa}" target="_blank" rel="noopener">Ver no Google Maps →</a><br>
    <a class="map-link" style="color: #007bff; font-weight: bold; margin-top: 5px; display: inline-block;" href="${linkWaze}" target="_blank" rel="noopener">Ver no Waze →</a>
  `);
  mostrarMapa(embedMapa);
}

// ============================================================================
