/*
 * Arquivo: recursos/scripts/inicializacao.js
 * Objetivo: controlar comportamentos da interface do NeuroLab Center.
 * Como manter: mantenha funções pequenas, nomes claros e evite misturar páginas diferentes.
 * Observação: comentários explicam blocos, funções, validações e integração com o servidor.
 */

/*
 * NeuroLab Center - recursos/scripts/inicializacao.js
 * Responsabilidade: Script principal de funcionalidade do site.
 * Usado por: Páginas HTML em site/paginas/.
 * Manutenção: mantenha funções relacionadas juntas e evite misturar regras de páginas diferentes.
 */

/**
 * NeuroLab Center — main.js
 * Inicialização global do front-end.
 *
 * As funções auxiliares foram separadas em recursos/scripts/pagina-inicial/ para facilitar
 * manutenção e evitar arquivos com mais de 500 linhas.
 */

// ============================================================================

// Inicializações globais compartilhadas entre páginas.
function marcarNavAtiva() {
  const atual = typeof paginaAtual === 'function' ? paginaAtual() : ((window.location.pathname.split('/').pop() || 'index.html').toLowerCase());
  document.querySelectorAll('nav a, footer a').forEach(link => {
    const href = (link.getAttribute('href') || '').split('#')[0] || 'index.html';
    link.classList.toggle('active', href.toLowerCase() === atual);
  });
}

// Função aplicarModalDaUrl: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function aplicarModalDaUrl() {
  const params = new URLSearchParams(window.location.search);
  const modal = params.get('modal');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (modal === 'login' && typeof abrirModalLogin === 'function') abrirModalLogin();
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (modal === 'cadastro') {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (params.get('familia') === '1' && typeof abrirCadastroFamiliar === 'function') {
      setTimeout(() => abrirCadastroFamiliar(), 100);
    } else if (typeof abrirModalCadastro === 'function') {
      abrirModalCadastro();
    }
  }
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (modal === 'recuperar' && typeof abrirRecuperarSenha === 'function') abrirRecuperarSenha();
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (modal === 'avaliacao' && typeof abrirModalAvaliacao === 'function') abrirModalAvaliacao();
}

// Evento da interface: conecta uma ação do usuário com uma função do sistema.
function limparCachesLocaisObsoletos() {
  [
    'neurolab_usuarios',
    'neurolab_agendamentos',
    'neurolab_fila_espera',
    'neurolab_avaliacoes',
    'neurolab_vinculos_familia',
    'neurolab_cadastro_rascunho'
  ].forEach((chave) => localStorage.removeItem(chave));
}

document.addEventListener('DOMContentLoaded', () => {
  limparCachesLocaisObsoletos();
  const pg = paginaAtual();
  const precisaLogin = ['agendamento.html', 'area-paciente.html'];
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (precisaLogin.includes(pg)) {
    const sessao = lerJson(STORAGE_KEYS.usuarioAtual, null);
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (!sessao?.cpf) {
      const destino = `${pg}${window.location.search}${window.location.hash}`;
      const loginUrl = typeof nlUrlLoginComRetorno === 'function'
        ? nlUrlLoginComRetorno(destino)
        : `index.html?modal=login&next=${encodeURIComponent(destino)}`;
      window.location.replace(loginUrl);
      return;
    }
  }

  // Melhorias visuais e comportamentais ficam centralizadas aqui para evitar JS carregado sem inicializar.
  if (typeof aplicarIdentidadeVisualLegada === 'function') aplicarIdentidadeVisualLegada();
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (typeof aplicarAjustesBootstrapLegado === 'function') aplicarAjustesBootstrapLegado();
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (typeof prepararMenuResponsivo === 'function') prepararMenuResponsivo();
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (typeof prepararNavbarFixa === 'function') prepararNavbarFixa();
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (typeof prepararSugestoesBusca === 'function') prepararSugestoesBusca();
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (typeof prepararAtalhosGlobais === 'function') prepararAtalhosGlobais();
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (typeof prepararBotaoVoltarTopo === 'function') prepararBotaoVoltarTopo();
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (typeof prepararValidacaoBootstrap === 'function') prepararValidacaoBootstrap();
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (typeof prepararToggleSenha === 'function') prepararToggleSenha();
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (typeof prepararForcaSenha === 'function') prepararForcaSenha();
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (typeof prepararHomeEnxuta === 'function') prepararHomeEnxuta();
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (typeof marcarNavAtiva === 'function') marcarNavAtiva();
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (typeof atualizarHeader === 'function') atualizarHeader();
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (typeof aplicarModalDaUrl === 'function') aplicarModalDaUrl();
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (typeof renderDashboardAgendamentos === 'function') renderDashboardAgendamentos();
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (typeof criarEstrelas === 'function') document.querySelectorAll('.estrelas').forEach(criarEstrelas);
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if ($('npsScale') && typeof criarNps === 'function') criarNps($('npsScale'));
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if ($('agStep1')) {
    const params = new URLSearchParams(window.location.search);
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (params.get('modo') === 'online') {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
      if (typeof selecionarTipo === 'function') selecionarTipo('Teleconsulta', 'TELE');
    } else if (typeof irParaPasso === 'function') {
      irParaPasso(1);
    }
  }

  // CPF inline validation bindings
  const cpfFields = [
    { id: 'cadCpf', hint: 'cadCpfHint' },
    { id: 'cadCpfAdol', hint: 'cadCpfAdolHint' },
    { id: 'loginCpf', hint: 'loginCpfHint' },
    { id: 'recCpf', hint: 'recHint' }
  ];
  cpfFields.forEach(({ id, hint }) => {
    const campo = $(id);
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (campo) {
// Evento da interface: conecta uma ação do usuário com uma função do sistema.
      campo.addEventListener('input', () => {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
        if (typeof mascararCpf === 'function') mascararCpf(campo);
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
        if (typeof validarCpfInline === 'function') validarCpfInline(campo, hint);
      });
    }
  });
});
