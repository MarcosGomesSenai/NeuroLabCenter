/*
 * Arquivo: recursos/scripts/autenticacao.js
 * Objetivo: controlar comportamentos da interface do NeuroLab Center.
 * Como manter: mantenha funções pequenas, nomes claros e evite misturar páginas diferentes.
 * Observação: comentários explicam blocos, funções, validações e integração com o servidor.
 */

/*
 * NeuroLab Center - recursos/scripts/autenticacao.js
 * Responsabilidade: Script principal de funcionalidade do site.
 * Usado por: Páginas HTML em site/paginas/.
 * Manutenção: mantenha funções relacionadas juntas e evite misturar regras de páginas diferentes.
 */

/**
 * NeuroLab Center — auth.js
 * Arquivo consolidado para apresentação e manutenção.
 * Carregadores document.write e pastas part/section foram substituídos por código direto.
 */

// ============================================================================
// ============================================================================

// Sessão e bloqueio de storage local.
// O banco oficial do projeto é MySQL. O navegador guarda apenas sessão, token/perfil ativo e preferências leves.
const STORAGE_KEYS = {
  usuarioAtual: 'neurolab_usuario_atual'
};

// Função $: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function $(id) {
  return document.getElementById(id);
}

// Função somenteDigitos: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function somenteDigitos(valor) {
  return String(valor || '').replace(/\D/g, '');
}

// Função paginaAtual: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function paginaAtual() {
  const arquivo = window.location.pathname.split('/').pop() || 'index.html';
  return arquivo.toLowerCase();
}

// Função chaveDeDadoDeNegocio: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function chaveDeDadoDeNegocio(chave) {
  const k = String(chave || '');
  return (
    k === 'neurolab_usuarios' ||
    k === 'neurolab_agendamentos' ||
    k === 'neurolab_fila_espera' ||
    k === 'neurolab_avaliacoes' ||
    k === 'neurolab_recuperacao_senha' ||
    k === 'neurolab_cadastro_rascunho' ||
    k === 'neurolab_agendamento_rascunho' ||
    k === 'neurolab_medicos_favoritos' ||
    k === 'neurolab_planos_comparar' ||
    k === 'neurolab_vinculos_familia' ||
    k === 'neurolab_checkin_atual' ||
    k.startsWith('neurolab_dependentes') ||
    k.startsWith('neurolab_documentos') ||
    k.startsWith('neurolab_preconsulta') ||
    k.startsWith('neurolab_paciente_') ||
    k.startsWith('neurolab_area_') ||
    k.startsWith('neurolab_exames_paciente')
  );
}

// Função lerJson: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function lerJson(chave, fallback) {
// Bloco protegido: tenta executar a ação e permite tratar falhas sem travar a página.
  try {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (chaveDeDadoDeNegocio(chave)) return fallback;
    return JSON.parse(localStorage.getItem(chave)) ?? fallback;
  } catch (erro) {
    return fallback;
  }
}

// Função salvarJson: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function salvarJson(chave, valor) {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (chaveDeDadoDeNegocio(chave)) {
    console.warn(`[NeuroLab] Gravação fora do MySQL bloqueada para ${chave}. Use a API/MySQL.`);
    return false;
  }
  localStorage.setItem(chave, JSON.stringify(valor));
  return true;
}

// ============================================================================
// ============================================================================

// ============================================================
// NAVEGAÇÃO, MODAIS E FLUXOS DO PACIENTE
// ============================================================
// Estado de tela e fluxos.
// Sessão, helpers globais e bloqueio de localStorage ficam em recursos/scripts/app/session-storage.js.
let cadastroTipoAtual = 'adulto';
let loginEtapa = 'cpf';
let agendamentoPasso = 1;
// Configuração ou referência reutilizada pelas funções deste arquivo.
let agendamentoAtual = {};
let holdInterval = null;
let holdExpiraEm = null;
// Configuração ou referência reutilizada pelas funções deste arquivo.
let avaliacaoAtual = { medico: 0, recepcao: 0, agendamento: 0, nps: null };

/* ── Conta família: sessão mínima no navegador; dados oficiais sempre via API/MySQL ── */
const FAMILY_STORAGE = {
  perfilAtivoCpf: 'neurolab_perfil_ativo_cpf'
};

// Função getUsuarioLogado: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function getUsuarioLogado() {
  return lerJson(STORAGE_KEYS.usuarioAtual, null);
}

// Função getVinculosDoTitular: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function getVinculosDoTitular() {
  console.warn('[NeuroLab] Vínculos familiares locais desativados. Use /api/portal/familia.');
  return { membros: [] };
}

// Função listarPerfisFamilia: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function listarPerfisFamilia() {
  const titular = getUsuarioLogado();
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!titular?.cpf) return [];
  return [{
    cpf: titular.cpf,
    nome: titular.nome,
    papel: 'Eu',
    tipo_vinculo: 'titular'
  }];
}

// getPerfilAtivoCpf() fica centralizada em shared/api-client.js.
// O único dado de família mantido no navegador é o CPF ativo da sessão.
function getPerfilAtivoUsuario() {
  const titular = getUsuarioLogado();
  const cpf = typeof getPerfilAtivoCpf === 'function' ? getPerfilAtivoCpf() : titular?.cpf;
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!titular?.cpf) return null;
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!cpf || cpf === titular.cpf) return titular;
  return { cpf, nome: 'Perfil familiar', papel: 'Família' };
}

// Função trocarPerfilFamiliaPorCpf: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function trocarPerfilFamiliaPorCpf(cpf) {
  const titular = getUsuarioLogado();
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!titular?.cpf || !cpf) return;
  localStorage.setItem(FAMILY_STORAGE.perfilAtivoCpf, String(cpf).replace(/\D/g, ''));
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (typeof setPerfilAtivoCpf === 'function') setPerfilAtivoCpf(cpf);
}

// Função cadastrarFamiliarVinculado: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
async function cadastrarFamiliarVinculado(dados) {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (typeof apiPortalCadastrarFamiliar !== 'function') {
    mostrarToast('API de conta família indisponível. Ligue o Flask/MySQL.', 'aviso');
    return false;
  }
// Bloco protegido: tenta executar a ação e permite tratar falhas sem travar a página.
  try {
    await apiPortalCadastrarFamiliar(dados);
    mostrarToast('Familiar cadastrado e vinculado no MySQL.', 'sucesso');
    return true;
  } catch (erro) {
    mostrarToast(erro.message || 'Não foi possível vincular familiar no MySQL.', 'erro', 7000);
    return false;
  }
}

// Função desvincularFamiliar: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
async function desvincularFamiliar(cpf) {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (typeof apiPortalDesvincularFamiliar !== 'function') return false;
// Bloco protegido: tenta executar a ação e permite tratar falhas sem travar a página.
  try {
    await apiPortalDesvincularFamiliar(cpf);
    const titular = getUsuarioLogado();
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (typeof getPerfilAtivoCpf === 'function' && getPerfilAtivoCpf() === String(cpf).replace(/\D/g, '') && titular?.cpf) {
      localStorage.setItem(FAMILY_STORAGE.perfilAtivoCpf, titular.cpf);
    }
    mostrarToast('Familiar desvinculado no MySQL.', 'info');
    return true;
  } catch (erro) {
    mostrarToast(erro.message || 'Não foi possível desvincular no MySQL.', 'erro', 7000);
    return false;
  }
}

// Função chaveDadosPerfil: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function chaveDadosPerfil(base, cpf) {
  return `${base}_${cpf || getPerfilAtivoCpf() || 'anon'}`;
}

// Função agendamentosDoPerfil: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
async function agendamentosDoPerfil(cpf) {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (typeof apiListarAgendamentosPaciente === 'function') {
    return apiListarAgendamentosPaciente(cpf || getPerfilAtivoCpf());
  }
  return [];
}

// Função obterPacienteParaAgendamento: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function obterPacienteParaAgendamento() {
  const titular = getUsuarioLogado();
  const perfil = getPerfilAtivoUsuario();
  return {
    pacienteCpf: perfil?.cpf || titular?.cpf || 'visitante',
    pacienteNome: perfil?.nome || titular?.nome || 'Paciente visitante',
    agendadoPorCpf: titular?.cpf || null,
    agendadoPorNome: titular?.nome || null
  };
}

/* Funções locais antigas de família removidas: dados oficiais agora passam pela API/MySQL. */

// ============================================================================
// ============================================================================

/**
 * NeuroLab Center — documentação do arquivo
 *
 * Arquivo: recursos/scripts/compartilhado/auth-header.js
 *
 * Por que este arquivo existe:
 * Este script fica separado para manter uma responsabilidade clara no site
 * ou no microserviço Node.js. Isso evita que a apresentação dependa de um único
 * arquivo gigante e facilita encontrar erros de caminho, import ou regra visual.
 */

// ============================================================
// CPF INLINE VALIDATION (Componente 3 — RN-02)
// Valida CPF em tempo real enquanto o usuário digita
// ============================================================
async function validarCpfInline(input, hintId) {
  const cpf = somenteDigitos(input.value);
  const hint = document.getElementById(hintId);
  
  input.classList.remove('cpf-valido', 'cpf-invalido');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (hint) { hint.textContent = ''; hint.className = 'field-hint'; }

  // Clean up any old duplicate alert
  const oldAlert = document.getElementById(hintId + '-dup-alert');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (oldAlert) oldAlert.remove();

// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (cpf.length < 11) return;

// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!cpfValido(cpf)) {
    input.classList.add('cpf-invalido');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (hint) {
      hint.textContent = '❌ CPF inválido. Verifique os dígitos.';
      hint.className = 'field-hint error';
    }
    return false;
  }

  // CPF duplicado é verificado somente pela API/MySQL.
  let duplicado = false;

// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (typeof apiDisponivel === 'function' && (await apiDisponivel())) {
// Bloco protegido: tenta executar a ação e permite tratar falhas sem travar a página.
    try {
      const res = typeof apiUsuarioExiste === 'function'
        ? await apiUsuarioExiste(cpf)
        : await apiRequest(`/usuarios/${cpf}/existe`);
      duplicado = typeof interpretarUsuarioExiste === 'function'
        ? interpretarUsuarioExiste(res)
        : res?.existe === true;
    } catch (_) {
      // 404 or other errors mean the CPF is free to use
    }
  }

// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (duplicado && (hintId === 'cadCpfHint' || hintId === 'cadCpfAdolHint' || input.id === 'cadCpf' || input.id === 'cadCpfAdol')) {
    input.classList.add('cpf-invalido');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (hint) {
      hint.textContent = ''; // Clear simple text to show premium alert instead
      hint.className = 'field-hint';
    }
    
    const alertBox = document.createElement('div');
    alertBox.id = hintId + '-dup-alert';
    alertBox.className = 'cpf-duplicate-alert';
    alertBox.innerHTML = `
      <div class="dup-alert-content">
        <span class="dup-alert-icon">⚠️</span>
        <div>
          <strong>Este CPF já está cadastrado!</strong>
          <p>Seus dados estão protegidos. Faça login ou recupere sua senha para prosseguir.</p>
        </div>
      </div>
      <button class="btn btn-light btn-sm btn-dup-login" onclick="fecharModal('modalCadastro'); abrirModalLogin(); preencherCpfLogin('${cpf}');">Já tenho conta → Entrar</button>
    `;
    input.parentNode.appendChild(alertBox);
    return false;
  }

  input.classList.add('cpf-valido');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (hint) {
    hint.textContent = '✅ CPF disponível';
    hint.className = 'field-hint success';
  }
  return true;
}

// ============================================================
// HEADER DINÂMICO (Componente 2 — RN-04)
// Atualiza header conforme estado de autenticação
// ============================================================
const AUTH_RETURN_KEY = 'neurolab_auth_return_to';

// Função nlDestinoLocalSeguro: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function nlDestinoLocalSeguro(valor, fallback = 'area-paciente.html') {
  const permitido = [
    'index.html',
    'agendamento.html',
    'area-paciente.html',
    'teleconsulta.html',
    'exames.html',
    'unidades.html',
    'medicos.html',
    'convenios.html',
    'ajuda.html'
  ];
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!valor) return fallback;
// Bloco protegido: tenta executar a ação e permite tratar falhas sem travar a página.
  try {
    const destino = new URL(decodeURIComponent(String(valor)), window.location.href);
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (destino.origin !== window.location.origin) return fallback;
    const arquivo = (destino.pathname.split('/').pop() || 'index.html').toLowerCase();
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (!permitido.includes(arquivo)) return fallback;
    return `${arquivo}${destino.search}${destino.hash}`;
  } catch (_) {
    return fallback;
  }
}


// Função nlDefinirRetornoAuth: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function nlDefinirRetornoAuth(destino) {
  const seguro = nlDestinoLocalSeguro(destino, 'area-paciente.html');
  sessionStorage.setItem(AUTH_RETURN_KEY, seguro);
  return seguro;
}

// Função nlUrlLoginComRetorno: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function nlUrlLoginComRetorno(destino) {
  const seguro = nlDefinirRetornoAuth(destino);
  return `index.html?modal=login&next=${encodeURIComponent(seguro)}`;
}

// Função nlConsumirRetornoAuth: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function nlConsumirRetornoAuth(fallback = 'area-paciente.html') {
  const params = new URLSearchParams(window.location.search);
  const salvo = params.get('next') || sessionStorage.getItem(AUTH_RETURN_KEY);
  const seguro = nlDestinoLocalSeguro(salvo, fallback);
  sessionStorage.removeItem(AUTH_RETURN_KEY);
  return seguro;
}

// Função atualizarHeader: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function atualizarHeader() {
  const usuario = lerJson(STORAGE_KEYS.usuarioAtual, null);
  const authButtons = document.querySelectorAll('.auth-buttons');

  authButtons.forEach(container => {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
    if (usuario && usuario.nome) {
      const primeiroNome = usuario.nome.split(' ')[0];
      container.innerHTML = `
        <span style="font-weight:700; color:var(--verde-principal); font-size:14px;">Olá, ${primeiroNome} 👤</span>
        <a class="btn btn-light" href="area-paciente.html">Minha área</a>
        <button class="btn btn-primary" onclick="fazerLogout()">Sair</button>
      `;
    } else {
      const pagina = paginaAtual();
      const cadastroHref = pagina === 'index.html' ? '#' : 'index.html?modal=cadastro';
      const loginHref = pagina === 'index.html' ? '#' : 'index.html?modal=login';
      const cadastroOnclick = pagina === 'index.html' ? 'onclick="abrirModalCadastro(); return false;"' : '';
      const loginOnclick = pagina === 'index.html' ? 'onclick="abrirModalLogin(); return false;"' : '';
      container.innerHTML = `
        <a class="btn btn-light" href="${loginHref}" ${loginOnclick}>Entrar</a>
        <a class="btn btn-primary" href="${cadastroHref}" ${cadastroOnclick}>Cadastrar</a>
      `;
    }
  });
}

// Função fazerLogout: executa uma etapa específica da lógica da interface ou comunicação com o sistema.
function fazerLogout() {
  localStorage.removeItem(STORAGE_KEYS.usuarioAtual);
  localStorage.removeItem('neurolab_auth_token');
  localStorage.removeItem('neurolab_perfil_ativo_cpf');
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (typeof setAuthToken === 'function') setAuthToken('');
  mostrarToast('Sessão encerrada com sucesso.', 'sucesso');
  setTimeout(() => { window.location.href = 'index.html'; }, 600);
}

// ============================================================
// GUARD DE AUTENTICAÇÃO (Componente 4 — RN-01)
// Verifica login antes de permitir agendamento
// ============================================================
function verificarAuthParaAgendamento() {
  const usuario = lerJson(STORAGE_KEYS.usuarioAtual, null);
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
  if (!usuario || !usuario.cpf) {
    mostrarToast('Faça login ou crie uma conta para agendar.', 'aviso');
    const destino = paginaAtual() === 'agendamento.html'
      ? `agendamento.html${window.location.search}${window.location.hash}`
      : 'agendamento.html';
    nlDefinirRetornoAuth(destino);
    setTimeout(() => {
// Validação/decisão: garante que o fluxo siga apenas quando as condições estiverem corretas.
      if (paginaAtual() === 'index.html') {
        abrirModalLogin();
      } else {
        window.location.href = nlUrlLoginComRetorno(destino);
      }
    }, 800);
    return false;
  }
  return true;
}
