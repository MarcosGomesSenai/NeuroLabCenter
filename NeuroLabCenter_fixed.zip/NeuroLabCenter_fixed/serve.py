#!/usr/bin/env python3
"""Servidor HTTP simples para servir arquivos estáticos do NeuroLab Center."""

import http.server
import socketserver
import os
from pathlib import Path

PORT = 8080
DIRECTORY = str(Path(__file__).parent)

class MyHTTPRequestHandler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=DIRECTORY, **kwargs)
    
    def end_headers(self):
        """Adiciona headers para evitar cache e CORS issues."""
        self.send_header('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0')
        self.send_header('Access-Control-Allow-Origin', '*')
        super().end_headers()

os.chdir(DIRECTORY)
with socketserver.TCPServer(("", PORT), MyHTTPRequestHandler) as httpd:
    print(f"Servidor iniciado em http://localhost:{PORT}/")
    print(f"Pasta raiz: {DIRECTORY}")
    print(f"Abra: http://localhost:{PORT}/site/paginas/agendamento.html")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nServidor parado.")
