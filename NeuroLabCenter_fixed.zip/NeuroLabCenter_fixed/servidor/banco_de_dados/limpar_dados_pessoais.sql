-- ============================================================================
-- Remove todos os cadastros com CPF (usuarios, pacientes, medicos, agendamentos).
-- Mantém apenas o catalogo: unidades, convenios e exames.
-- ============================================================================

USE neurolabcenter;

SET FOREIGN_KEY_CHECKS = 0;

DELETE FROM agendamento_eventos;
DELETE FROM feedback;
DELETE FROM feedback_geral;
DELETE FROM agendamentos;
DELETE FROM documentos_paciente;
DELETE FROM preconsulta_paciente;
DELETE FROM formularios_paciente;
DELETE FROM preferencias_paciente;
DELETE FROM exames_paciente;
DELETE FROM fila_espera;
DELETE FROM conta_familia_vinculos;
DELETE FROM senha_recuperacao_tokens;
DELETE FROM notificacoes;
DELETE FROM pacientes;
DELETE FROM medicos_unidades;
DELETE FROM medicos;
DELETE FROM usuarios;

SET FOREIGN_KEY_CHECKS = 1;
