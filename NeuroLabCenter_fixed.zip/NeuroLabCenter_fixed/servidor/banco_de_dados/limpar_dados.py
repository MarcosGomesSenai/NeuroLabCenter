"""
Remove todos os cadastros com CPF do MySQL (usuarios, pacientes, agendamentos etc.).
Mantém o catalogo: unidades, convenios e exames.

Uso:
    python -m servidor.banco_de_dados.limpar_dados
"""

from pathlib import Path
import sys

if __package__ in {None, ""}:
    sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import mysql.connector

from servidor.configuracao import Config
from servidor.banco_de_dados.criar_banco import _run_sql_file


def limpar_cadastros_pessoais():
    connection = mysql.connector.connect(
        host=Config.MYSQL_HOST,
        port=Config.MYSQL_PORT,
        user=Config.MYSQL_USER,
        password=Config.MYSQL_PASSWORD,
        autocommit=False,
    )
    cursor = connection.cursor(dictionary=True)
    base_dir = Path(__file__).resolve().parent
    try:
        _run_sql_file(cursor, base_dir / "limpar_dados_pessoais.sql")
        connection.commit()
    except Exception:
        connection.rollback()
        raise
    finally:
        cursor.close()
        connection.close()


if __name__ == "__main__":
    limpar_cadastros_pessoais()
    print("Cadastros com CPF removidos. Unidades, convenios e exames foram mantidos.")
