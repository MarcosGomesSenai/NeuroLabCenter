-- ============================================================================
-- Arquivo: servidor/banco_de_dados/dados_iniciais.sql
-- Objetivo: catalogo inicial (unidades, convenios, exames). Sem CPFs cadastrados.
-- Como manter: cadastros de pacientes e medicos sao criados pelo site, nao por seed.
-- ============================================================================

USE neurolabcenter;

INSERT IGNORE INTO unidades (id, nome, endereco, cidade, cep, telefone, horario_ini, horario_fim, aceita_sus, ativo)
VALUES
(1, 'NeuroLabCenter Santo Andre', 'R. Amazonas, 48 - Centro', 'Santo Andre', '09000000', '(11) 4002-8922', '07:00:00', '19:00:00', TRUE, TRUE),
(2, 'NeuroLabCenter Sao Bernardo', 'Av. Kennedy, 303 - Jardim do Mar', 'Sao Bernardo do Campo', '09726000', '(11) 4002-8923', '08:00:00', '18:00:00', FALSE, TRUE),
(3, 'Teleconsulta NeuroLab', 'Atendimento online', 'Online', '00000000', '(11) 4002-8922', '07:00:00', '21:00:00', FALSE, TRUE);

INSERT IGNORE INTO convenios (id, nome, ativo)
VALUES
(1, 'Unimed', TRUE),
(2, 'Bradesco Saude', TRUE),
(3, 'SulAmerica', TRUE),
(4, 'Amil', TRUE);

INSERT IGNORE INTO unidades_convenios (id_unidade, id_convenio)
VALUES
(1, 1), (1, 2), (1, 3), (1, 4),
(2, 1), (2, 2),
(3, 1), (3, 2), (3, 3), (3, 4);

INSERT IGNORE INTO exames (id, nome, descricao, preparo_recomendado, duracao_minutos, ativo)
VALUES
(1, 'Eletroencefalograma', 'Exame EEG para avaliacao de atividade cerebral.', 'Cabelos limpos e secos, sem gel ou creme.', 40, TRUE),
(2, 'Eletroneuromiografia', 'Avaliacao neurofisiologica de nervos e musculos.', 'Evitar cremes na pele no dia do exame.', 60, TRUE),
(3, 'Polissonografia', 'Exame do sono.', 'Seguir rotina habitual de sono e levar itens pessoais.', 480, TRUE);

UPDATE unidades SET nome = 'Santo André - Centro', endereco = 'R. Amazonas, 48 - Centro, Santo André - SP', cidade = 'Santo André', cep = '09000000' WHERE id = 1;
UPDATE unidades SET nome = 'São Bernardo - Jardim do Mar', endereco = 'Av. Kennedy, 303 - Jardim do Mar, São Bernardo do Campo - SP', cidade = 'São Bernardo do Campo', cep = '09726000' WHERE id = 2;
UPDATE unidades SET nome = 'Teleconsulta NeuroLab', endereco = 'Atendimento online', cidade = 'Online', cep = '00000000' WHERE id = 3;

INSERT IGNORE INTO unidades (id, nome, endereco, cidade, cep, telefone, horario_ini, horario_fim, aceita_sus, ativo)
VALUES
(4, 'Santo André - Vila Pires', 'R. Senador Fláquer, 512 - Vila Pires, Santo André - SP', 'Santo André', '09195000', '(11) 4002-8924', '08:00:00', '18:00:00', FALSE, TRUE),
(5, 'Moema - Neurodiagnóstico', 'Av. Ibirapuera, 2120 - Moema, São Paulo - SP', 'São Paulo', '04028001', '(11) 4002-8925', '07:00:00', '19:00:00', FALSE, TRUE),
(6, 'Tatuapé - Neuropediatria', 'R. Itapura, 986 - Tatuapé, São Paulo - SP', 'São Paulo', '03310000', '(11) 4002-8926', '08:00:00', '18:00:00', FALSE, TRUE),
(7, 'Paulista - Sono e Cognição', 'Av. Paulista, 171 - Bela Vista, São Paulo - SP', 'São Paulo', '01311000', '(11) 4002-8927', '07:00:00', '19:00:00', FALSE, TRUE);

UPDATE convenios SET nome = 'Bradesco Saúde' WHERE id = 2;
UPDATE convenios SET nome = 'SulAmérica' WHERE id = 3;
INSERT IGNORE INTO convenios (id, nome, ativo)
VALUES
(5, 'Porto Seguro Saúde', TRUE),
(6, 'NotreDame Intermédica', TRUE),
(7, 'Care Plus', TRUE),
(8, 'Omint', TRUE),
(9, 'Golden Cross', TRUE),
(10, 'Alice', TRUE),
(11, 'Prevent Senior', TRUE),
(12, 'Sompo Saúde', TRUE),
(13, 'Mediservice', TRUE),
(14, 'Cassi', TRUE);

INSERT IGNORE INTO unidades_convenios (id_unidade, id_convenio)
VALUES
(4,1),(4,2),(4,3),(4,4),(4,5),
(5,1),(5,2),(5,3),(5,4),(5,5),(5,8),(5,12),(5,14),
(6,1),(6,4),(6,6),(6,7),(6,10),
(7,2),(7,3),(7,7),(7,8),(7,9),(7,11),
(1,5),(1,9),(1,11),(1,12),(1,14),
(2,4),(2,6),(2,13),
(3,5),(3,6),(3,7),(3,8),(3,9),(3,10),(3,11),(3,12),(3,13),(3,14);
