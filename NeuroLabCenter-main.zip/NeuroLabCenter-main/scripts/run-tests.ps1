$ErrorActionPreference = "Stop"

$root = Split-Path -Parent $PSScriptRoot

Push-Location $root
try {
    python -m compileall -q back_end
    python -m pytest back_end\tests

    Push-Location (Join-Path $root "apis")
    try {
        npm test
    } finally {
        Pop-Location
    }

    Get-ChildItem -Recurse -Filter *.js |
        Where-Object { $_.FullName -notlike "*\node_modules\*" } |
        ForEach-Object {
            node --check $_.FullName
        }
} finally {
    Pop-Location
}
