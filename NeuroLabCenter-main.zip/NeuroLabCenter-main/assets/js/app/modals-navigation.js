function abrirMenu() {
  const menu = $('menu');
  if (menu) menu.classList.toggle('open');
}

function navegarPara(arquivo) {
  window.location.href = arquivo;
}

function buscarSite() {
  const input = $('busca');
  const termo = normalizarTexto(input?.value || '');

  if (!termo) {
    mostrarToast('Digite algo para buscar. Ex: enxaqueca, EEG, unidade ou consultas.', 'aviso');
    return;
  }

  if (termo.includes('online') || termo.includes('chat') || termo.includes('teleconsulta')) {
    navegarPara('teleconsulta.html');
  } else if (termo.includes('eletro') || termo.includes('exame') || termo.includes('polissonografia') || termo.includes('eeg')) {
    navegarPara('exames.html');
  } else if (termo.includes('unidade') || termo.includes('endereco') || termo.includes('cidade') || termo.includes('cep')) {
    navegarPara('unidades.html');
  } else {
    navegarPara('especialidades.html');
  }
}

function abrirModal(id) {
  const modal = $(id);
  if (!modal) return false;
  modal.classList.add('open');
  document.body.style.overflow = 'hidden';
  return true;
}

function fecharModal(id) {
  const modal = $(id);
  if (modal) modal.classList.remove('open');
  if (!document.querySelector('.modal-overlay.open')) document.body.style.overflow = '';
  if (id === 'modalAgendamento') liberarHold(false);
  if (id === 'modalCadastro') {
    window.NLUX = window.NLUX || {};
    NLUX.cadastroFamilia = false;
    document.getElementById('cadFamiliaExtra')?.classList.add('hidden');
  }
}

function abrirCadastroFamiliar() {
  if (!getAuthToken?.()) {
    mostrarToast('Entre na sua conta antes de cadastrar um familiar.', 'aviso');
    abrirModalLogin();
    return;
  }
  window.NLUX = window.NLUX || {};
  NLUX.cadastroFamilia = true;
  const extra = document.getElementById('cadFamiliaExtra');
  if (extra) extra.classList.remove('hidden');
  const titulo = document.querySelector('#modalCadastro h3');
  if (titulo) titulo.textContent = 'Cadastrar familiar';
  switchCadastro('adulto');
  if (paginaAtual() === 'index.html') {
    abrirModalCadastro();
  } else {
    navegarPara('index.html?modal=cadastro&familia=1');
  }
}

function abrirModalCadastro() {
  if (abrirModal('modalCadastro')) return;
  navegarPara('index.html?modal=cadastro');
}

function abrirModalLogin() {
  if (abrirModal('modalLogin')) return;
  navegarPara('index.html?modal=login');
}

function abrirRecuperarSenha() {
  fecharModal('modalLogin');
  if (abrirModal('modalRecuperarSenha')) return;
  navegarPara('index.html?modal=recuperar');
}

function abrirModalAvaliacao() {
  if (abrirModal('modalAvaliacao')) return;
  navegarPara('index.html?modal=avaliacao');
}

function abrirAgendamento() {
  if (!verificarAuthParaAgendamento()) return;

  const titular = typeof getUsuarioLogado === 'function' ? getUsuarioLogado() : null;
  const cpfAtivo = typeof getPerfilAtivoCpf === 'function' ? getPerfilAtivoCpf() : titular?.cpf;
  if (titular?.cpf && cpfAtivo && cpfAtivo !== titular.cpf) {
    const perfil = typeof listarPerfisFamilia === 'function'
      ? listarPerfisFamilia().find(p => p.cpf === cpfAtivo)
      : null;
    if (perfil) {
      mostrarToast(`Agendando para ${perfil.nome} (${perfil.papel}).`, 'info');
    }
  }

  if (paginaAtual() !== 'agendamento.html') {
    navegarPara('agendamento.html');
    return;
  }

  window.scrollTo({ top: 0, behavior: 'smooth' });
}

