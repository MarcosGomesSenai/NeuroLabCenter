// ============================================================
// NAVEGAÇÃO, MODAIS E FLUXOS DO PACIENTE
// ============================================================
const STORAGE_KEYS = {
  usuarios: 'neurolab_usuarios',
  usuarioAtual: 'neurolab_usuario_atual',
  agendamentos: 'neurolab_agendamentos',
  fila: 'neurolab_fila_espera',
  avaliacoes: 'neurolab_avaliacoes',
  recuperacao: 'neurolab_recuperacao_senha'
};

const PBKDF2_ITER = 210000;

function bufToB64(buffer) {
  const bytes = buffer instanceof Uint8Array ? buffer : new Uint8Array(buffer);
  let binary = '';
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
  }
  return btoa(binary);
}

function b64ToBuf(b64) {
  const binary = atob(b64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes;
}

async function criarCredencialSenha(senhaPlain) {
  const enc = new TextEncoder().encode(senhaPlain);
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const keyMaterial = await crypto.subtle.importKey(
    'raw',
    enc,
    { name: 'PBKDF2' },
    false,
    ['deriveBits']
  );
  const bits = await crypto.subtle.deriveBits(
    { name: 'PBKDF2', salt, iterations: PBKDF2_ITER, hash: 'SHA-256' },
    keyMaterial,
    256
  );
  return {
    pwdKdf: {
      algo: 'PBKDF2-SHA256',
      iter: PBKDF2_ITER,
      saltB64: bufToB64(salt),
      hashB64: bufToB64(new Uint8Array(bits))
    }
  };
}

async function senhaCorrespondeCredencial(usuario, senhaPlain) {
  if (usuario.senha && typeof usuario.senha === 'string') {
    return senhaPlain === usuario.senha;
  }
  const kdf = usuario.pwdKdf;
  if (!kdf?.saltB64 || !kdf.hashB64 || !Number(kdf.iter)) return false;
  const enc = new TextEncoder().encode(senhaPlain);
  const salt = b64ToBuf(kdf.saltB64);
  const esperado = b64ToBuf(kdf.hashB64);
  const keyMaterial = await crypto.subtle.importKey(
    'raw',
    enc,
    { name: 'PBKDF2' },
    false,
    ['deriveBits']
  );
  const bits = await crypto.subtle.deriveBits(
    { name: 'PBKDF2', salt, iterations: kdf.iter, hash: 'SHA-256' },
    keyMaterial,
    esperado.length * 8
  );
  const obtido = new Uint8Array(bits);
  if (obtido.length !== esperado.length) return false;
  let diff = 0;
  for (let i = 0; i < obtido.length; i++) diff |= obtido[i] ^ esperado[i];
  return diff === 0;
}

let cadastroTipoAtual = 'adulto';
let loginEtapa = 'cpf';
let agendamentoPasso = 1;
let agendamentoAtual = {};
let holdInterval = null;
let holdExpiraEm = null;
let avaliacaoAtual = { medico: 0, recepcao: 0, agendamento: 0, nps: null };

function $(id) {
  return document.getElementById(id);
}

function chaveDeDadoDeNegocio(chave) {
  const k = String(chave || '');
  return (
    k === 'neurolab_usuarios' ||
    k === 'neurolab_agendamentos' ||
    k === 'neurolab_fila_espera' ||
    k === 'neurolab_avaliacoes' ||
    k === 'neurolab_recuperacao_senha' ||
    k === 'neurolab_cadastro_rascunho' ||
    k === 'neurolab_agendamento_rascunho' ||
    k === 'neurolab_medicos_favoritos' ||
    k === 'neurolab_planos_comparar' ||
    k === 'neurolab_buscas_recentes' ||
    k === 'neurolab_vinculos_familia' ||
    k === 'neurolab_checkin_atual' ||
    k.startsWith('neurolab_dependentes') ||
    k.startsWith('neurolab_documentos') ||
    k.startsWith('neurolab_preconsulta') ||
    k.startsWith('neurolab_paciente_') ||
    k.startsWith('neurolab_area_') ||
    k.startsWith('neurolab_exames_paciente')
  );
}

function lerJson(chave, fallback) {
  try {
    if (chaveDeDadoDeNegocio(chave)) return fallback;
    return JSON.parse(localStorage.getItem(chave)) ?? fallback;
  } catch (erro) {
    return fallback;
  }
}

function salvarJson(chave, valor) {
  if (chaveDeDadoDeNegocio(chave)) {
    console.warn(`[NeuroLab] Gravação fora do MySQL bloqueada para ${chave}. Use a API/MySQL.`);
    return false;
  }
  localStorage.setItem(chave, JSON.stringify(valor));
  return true;
}

function somenteDigitos(valor) {
  return String(valor || '').replace(/\D/g, '');
}

function paginaAtual() {
  const arquivo = window.location.pathname.split('/').pop() || 'index.html';
  return arquivo.toLowerCase();
}

/* ── Conta família: perfis vinculados (CPF próprio, dados isolados) ── */
const FAMILY_STORAGE = {
  vinculos: 'neurolab_vinculos_familia',
  perfilAtivoCpf: 'neurolab_perfil_ativo_cpf'
};

function getUsuarioLogado() {
  return lerJson(STORAGE_KEYS.usuarioAtual, null);
}

function getVinculosDoTitular(titularCpf) {
  const todos = lerJson(FAMILY_STORAGE.vinculos, {});
  if (!todos[titularCpf]) {
    todos[titularCpf] = { membros: [] };
    salvarJson(FAMILY_STORAGE.vinculos, todos);
  }
  return todos[titularCpf];
}

function listarPerfisFamilia() {
  const titular = getUsuarioLogado();
  if (!titular?.cpf) return [];
  const usuarios = lerJson(STORAGE_KEYS.usuarios, []);
  const lista = [{
    cpf: titular.cpf,
    nome: titular.nome,
    papel: 'Eu',
    nascimento: usuarios.find(u => u.cpf === titular.cpf)?.nascimento || ''
  }];
  getVinculosDoTitular(titular.cpf).membros.forEach(membro => {
    const usuario = usuarios.find(u => u.cpf === membro.cpf);
    lista.push({
      cpf: membro.cpf,
      nome: usuario?.nome || membro.nome,
      papel: membro.papel || 'Familiar',
      nascimento: usuario?.nascimento || membro.nascimento || ''
    });
  });
  return lista;
}

function getPerfilAtivoCpf() {
  const titular = getUsuarioLogado();
  if (!titular?.cpf) return null;
  const ativo = localStorage.getItem(FAMILY_STORAGE.perfilAtivoCpf);
  if (!ativo || ativo === titular.cpf) return titular.cpf;
  const vinculado = getVinculosDoTitular(titular.cpf).membros.some(m => m.cpf === ativo);
  return vinculado ? ativo : titular.cpf;
}

function getPerfilAtivoUsuario() {
  const cpf = getPerfilAtivoCpf();
  if (!cpf) return null;
  return lerJson(STORAGE_KEYS.usuarios, []).find(u => u.cpf === cpf) || null;
}

function trocarPerfilFamiliaPorCpf(cpf) {
  const titular = getUsuarioLogado();
  if (!titular?.cpf) return;
  const permitido = listarPerfisFamilia().some(p => p.cpf === cpf);
  if (!permitido) return;
  localStorage.setItem(FAMILY_STORAGE.perfilAtivoCpf, cpf);
  if (typeof setPerfilAtivoCpf === 'function') setPerfilAtivoCpf(cpf);
}

function chaveDadosPerfil(base, cpf) {
  return `${base}_${cpf || getPerfilAtivoCpf() || 'anon'}`;
}

function agendamentosDoPerfil(cpf) {
  return lerJson(STORAGE_KEYS.agendamentos, []).filter(item => item.pacienteCpf === cpf);
}

function obterPacienteParaAgendamento() {
  const titular = getUsuarioLogado();
  const perfil = getPerfilAtivoUsuario();
  return {
    pacienteCpf: perfil?.cpf || titular?.cpf || 'visitante',
    pacienteNome: perfil?.nome || titular?.nome || 'Paciente visitante',
    agendadoPorCpf: titular?.cpf || null,
    agendadoPorNome: titular?.nome || null
  };
}

async function cadastrarFamiliarVinculado(dados) {
  const titular = getUsuarioLogado();
  if (!titular?.cpf) {
    mostrarToast('Entre na sua conta para vincular familiares.', 'aviso');
    return false;
  }

  const usuarios = lerJson(STORAGE_KEYS.usuarios, []);
  const cpf = somenteDigitos(dados.cpf);
  const idade = idadeEmAnos(dados.nascimento);

  if (!cpfValido(cpf)) {
    mostrarToast('CPF inválido do familiar.', 'error');
    return false;
  }
  if (cpf === titular.cpf) {
    mostrarToast('Use outro CPF. Este é o da conta titular.', 'aviso');
    return false;
  }
  if (usuarios.some(u => u.cpf === cpf)) {
    mostrarToast('CPF já cadastrado. Se for da família, vincule pela Área do Paciente.', 'aviso');
    return false;
  }
  if (!nomeCompletoValido(dados.nome)) {
    mostrarToast('Informe o nome completo do familiar.', 'aviso');
    return false;
  }
  if (idade === null) {
    mostrarToast('Informe a data de nascimento.', 'aviso');
    return false;
  }
  if (somenteDigitos(dados.celular).length < 10) {
    mostrarToast('Informe um celular válido.', 'aviso');
    return false;
  }
  if (!senhaValida(dados.senha)) {
    mostrarToast('Senha: mínimo 8 caracteres, 1 letra e 1 número.', 'aviso');
    return false;
  }
  if (dados.senha !== dados.senhaConfirm) {
    mostrarToast('As senhas não conferem.', 'aviso');
    return false;
  }

  let pwdCredencial;
  try {
    pwdCredencial = await criarCredencialSenha(dados.senha);
  } catch (_) {
    mostrarToast('Não foi possível criar a credencial. Tente outro navegador.', 'error');
    return false;
  }

  const familiar = {
    cpf,
    nome: dados.nome.trim(),
    nascimento: dados.nascimento,
    celular: dados.celular,
    email: dados.email || '',
    ...pwdCredencial,
    tipo: 'familiar',
    contaFamiliaTitular: titular.cpf,
    papelFamilia: dados.papel.trim(),
    tentativas: 0,
    bloqueadoAte: 0,
    criadoEm: new Date().toISOString()
  };

  usuarios.push(familiar);
  salvarJson(STORAGE_KEYS.usuarios, usuarios);

  const vinculos = lerJson(FAMILY_STORAGE.vinculos, {});
  const grupo = getVinculosDoTitular(titular.cpf);
  if (grupo.membros.some(m => m.cpf === cpf)) {
    mostrarToast('Este familiar já está vinculado.', 'aviso');
    return false;
  }
  grupo.membros.push({
    cpf,
    nome: familiar.nome,
    papel: familiar.papelFamilia,
    nascimento: familiar.nascimento,
    vinculadoEm: new Date().toISOString()
  });
  vinculos[titular.cpf] = grupo;
  salvarJson(FAMILY_STORAGE.vinculos, vinculos);

  mostrarToast(`${familiar.nome} vinculado à conta família.`, 'sucesso');
  return true;
}

function desvincularFamiliar(cpf) {
  const titular = getUsuarioLogado();
  if (!titular?.cpf || cpf === titular.cpf) return;

  const vinculos = lerJson(FAMILY_STORAGE.vinculos, {});
  const grupo = getVinculosDoTitular(titular.cpf);
  grupo.membros = grupo.membros.filter(m => m.cpf !== cpf);
  vinculos[titular.cpf] = grupo;
  salvarJson(FAMILY_STORAGE.vinculos, vinculos);

  if (getPerfilAtivoCpf() === cpf) {
    localStorage.setItem(FAMILY_STORAGE.perfilAtivoCpf, titular.cpf);
  }
}

