function mascararCpf(input) {
  let valor = somenteDigitos(input.value).slice(0, 11);
  valor = valor.replace(/(\d{3})(\d)/, '$1.$2');
  valor = valor.replace(/(\d{3})(\d)/, '$1.$2');
  valor = valor.replace(/(\d{3})(\d{1,2})$/, '$1-$2');
  input.value = valor;
}

function mascararTelefone(input) {
  let valor = somenteDigitos(input.value).slice(0, 11);
  if (valor.length > 10) {
    valor = valor.replace(/^(\d{2})(\d{5})(\d{1,4})$/, '($1) $2-$3');
  } else if (valor.length > 6) {
    valor = valor.replace(/^(\d{2})(\d{4})(\d{1,4})$/, '($1) $2-$3');
  } else if (valor.length > 2) {
    valor = valor.replace(/^(\d{2})(\d{1,5})$/, '($1) $2');
  }
  input.value = valor;
}

function cpfValido(cpfEntrada) {
  const cpf = somenteDigitos(cpfEntrada);
  if (cpf.length !== 11 || /^(\d)\1+$/.test(cpf)) return false;

  const calcularDigito = (base) => {
    let soma = 0;
    for (let i = 0; i < base.length; i++) soma += Number(base[i]) * (base.length + 1 - i);
    const resto = (soma * 10) % 11;
    return resto === 10 ? 0 : resto;
  };

  return calcularDigito(cpf.slice(0, 9)) === Number(cpf[9]) &&
    calcularDigito(cpf.slice(0, 10)) === Number(cpf[10]);
}

function idadeEmAnos(dataIso) {
  if (!dataIso) return null;
  const nascimento = new Date(`${dataIso}T00:00:00`);
  if (Number.isNaN(nascimento.getTime())) return null;
  const hoje = new Date();
  let idade = hoje.getFullYear() - nascimento.getFullYear();
  const mes = hoje.getMonth() - nascimento.getMonth();
  if (mes < 0 || (mes === 0 && hoje.getDate() < nascimento.getDate())) idade--;
  return idade;
}

function senhaValida(senha) {
  return /[A-Za-z]/.test(senha) && /\d/.test(senha) && String(senha).length >= 8;
}

function nomeCompletoValido(nome) {
  return String(nome || '').trim().split(/\s+/).length >= 2;
}

function setHint(id, mensagem, tipo = 'info') {
  const el = $(id);
  if (!el) return;
  el.textContent = mensagem;
  el.className = `field-hint ${tipo}`;
}


function preencherCpfLogin(cpf) {
  const campo = $('loginCpf');
  if (!campo) return;
  campo.value = cpf;
  mascararCpf(campo);
  loginEtapa = 'cpf';
  $('loginSenhaGroup')?.classList.add('hidden');
  const btn = $('btnLoginProximo');
  if (btn) btn.textContent = 'Continuar';
  setTimeout(() => campo.focus(), 80);
}

function mostrarCpfDuplicadoCadastro(campoId, hintId) {
  const campo = $(campoId);
  const hint = $(hintId);
  const cpf = somenteDigitos(campo?.value || '');
  const alertId = `${hintId}-dup-alert`;
  document.getElementById(alertId)?.remove();

  if (campo) {
    campo.classList.remove('cpf-valido');
    campo.classList.add('cpf-invalido', 'is-invalid');
    campo.focus();
  }

  if (hint) {
    hint.textContent = '';
    hint.className = 'field-hint error';
  }

  const alvo = campo?.closest('.form-group') || hint?.parentElement;
  if (!alvo) return;
  alvo.insertAdjacentHTML('beforeend', `
    <div class="cpf-duplicate-alert cpf-duplicate-alert-strong" id="${alertId}" role="alert">
      <div class="dup-alert-content">
        <span class="dup-alert-icon">⚠️</span>
        <div>
          <strong>CPF já utilizado no sistema</strong>
          <p>Esse CPF já possui uma conta. Por segurança, use login ou recuperação de senha em vez de criar outro cadastro.</p>
        </div>
      </div>
      <button type="button" class="btn btn-light btn-sm btn-dup-login" onclick="fecharModal('modalCadastro'); abrirModalLogin(); preencherCpfLogin('${cpf}');">Fazer login com este CPF</button>
    </div>
  `);
}

function switchCadastro(tipo) {
  cadastroTipoAtual = tipo;
  $('formAdulto')?.style.setProperty('display', tipo === 'adulto' ? 'block' : 'none');
  $('formAdolescente')?.style.setProperty('display', tipo === 'adolescente' ? 'block' : 'none');
  $('tabAdulto')?.classList.toggle('active', tipo === 'adulto');
  $('tabAdolescente')?.classList.toggle('active', tipo === 'adolescente');
  setHint('cadGeralHint', '');
}

async function realizarCadastro() {
  const usuarios = lerJson(STORAGE_KEYS.usuarios, []);
  const termos = $('cadTermos')?.checked;
  const isAdulto = cadastroTipoAtual === 'adulto';
  const dados = isAdulto
    ? {
        cpf: $('cadCpf')?.value,
        nascimento: $('cadNascimento')?.value,
        nome: $('cadNome')?.value,
        celular: $('cadCelular')?.value,
        email: $('cadEmail')?.value,
        senha: $('cadSenha')?.value,
        senhaConfirm: $('cadSenhaConfirm')?.value,
        tipo: 'adulto'
      }
    : {
        cpf: $('cadCpfAdol')?.value,
        nascimento: $('cadNascAdol')?.value,
        nome: $('cadNomeAdol')?.value,
        celular: $('cadCelAdol')?.value,
        cpfResponsavel: $('cadCpfResp')?.value,
        senha: $('cadSenhaAdol')?.value,
        senhaConfirm: $('cadSenhaAdolConfirm')?.value,
        tipo: 'adolescente'
      };

  const modoFamilia = window.NLUX?.cadastroFamilia;
  const usuarioLogado = getUsuarioLogado();
  if (modoFamilia && !isAdulto && usuarioLogado && usuarioLogado.cpf) {
    dados.cpfResponsavel = usuarioLogado.cpf;
  }

  const cpf = somenteDigitos(dados.cpf);
  const idade = idadeEmAnos(dados.nascimento);
  const apiOnline = typeof apiDisponivel === 'function' && (await apiDisponivel());

  if (!cpfValido(cpf)) return setHint('cadGeralHint', 'CPF inválido. Verifique os números digitados.', 'error');
  if (!apiOnline && usuarios.some(usuario => usuario.cpf === cpf)) {
    mostrarCpfDuplicadoCadastro(isAdulto ? 'cadCpf' : 'cadCpfAdol', isAdulto ? 'cadCpfHint' : 'cadCpfAdolHint');
    return setHint('cadGeralHint', 'CPF já utilizado. Faça login ou recupere sua senha.', 'error');
  }
  if (!nomeCompletoValido(dados.nome)) return setHint('cadGeralHint', 'Informe o nome completo com pelo menos duas palavras.', 'error');
  if (idade === null) return setHint('cadGeralHint', 'Informe uma data de nascimento válida.', 'error');
  if (isAdulto && idade < 18) return setHint('cadGeralHint', 'Use a aba Menor de idade para pacientes de 0 a 17 anos.', 'error');
  if (!isAdulto && (idade < 0 || idade > 17)) return setHint('cadGeralHint', 'A conta de menor de idade é permitida apenas para 0 a 17 anos.', 'error');
  if (!isAdulto && !cpfValido(dados.cpfResponsavel)) return setHint('cadGeralHint', 'Informe um CPF de responsável válido.', 'error');
  if (somenteDigitos(dados.celular).length < 10) return setHint('cadGeralHint', 'Informe um celular válido com DDD.', 'error');
  if (!senhaValida(dados.senha)) return setHint('cadGeralHint', 'A senha precisa ter 8 caracteres, uma letra e um número.', 'error');
  if (dados.senha !== dados.senhaConfirm) return setHint('cadGeralHint', 'As senhas não conferem.', 'error');
  if (!termos) return setHint('cadGeralHint', 'Aceite os Termos de Uso e Política de Privacidade para criar a conta.', 'error');

  const papel = $('cadFamiliaPapel')?.value?.trim() || '';
  const email = (dados.email || '').trim().toLowerCase();

  if (modoFamilia && !papel) {
    return setHint('cadGeralHint', 'Informe o parentesco do familiar (Filho, Mãe, etc.).', 'error');
  }
  if (apiOnline && isAdulto && !email) {
    return setHint('cadGeralHint', 'E-mail é obrigatório para salvar no banco de dados.', 'error');
  }

  const apiPayload = {
    cpf,
    nome: dados.nome.trim(),
    email: email || `paciente.${cpf}@neurolab.local`,
    telefone: dados.celular,
    data_nascimento: dados.nascimento,
    senha: dados.senha,
    tipo_usuario: 'paciente',
    cpf_responsavel: isAdulto ? undefined : somenteDigitos(dados.cpfResponsavel)
  };

  if (apiOnline) {
    try {
      if (modoFamilia) {
        if (!getAuthToken?.()) {
          return setHint('cadGeralHint', 'Entre na sua conta para cadastrar um familiar.', 'error');
        }
        const familiarCriado = await apiPortalCadastrarFamiliar({ ...apiPayload, papel });
        if (familiarCriado?.cpf && typeof setPerfilAtivoCpf === 'function') setPerfilAtivoCpf(familiarCriado.cpf);
        window.NLUX.cadastroFamilia = false;
        document.getElementById('cadFamiliaExtra')?.classList.add('hidden');
        limparRascunhoCadastro();
        setHint('cadGeralHint', 'Familiar cadastrado no banco e vinculado à conta família.', 'success');
        setTimeout(() => {
          fecharModal('modalCadastro');
          if (paginaArquivo() === 'area-paciente.html' && typeof initPortalPaciente === 'function') {
            initPortalPaciente();
          } else {
            const destino = typeof nlConsumirRetornoAuth === 'function'
              ? nlConsumirRetornoAuth('area-paciente.html')
              : 'area-paciente.html';
            navegarPara(destino);
          }
        }, 700);
        return;
      }

      await apiCadastro(apiPayload);
      await apiLogin(cpf, dados.senha);
      limparRascunhoCadastro();
      setHint('cadGeralHint', 'Conta salva no banco. Login realizado.', 'success');
      setTimeout(() => {
        fecharModal('modalCadastro');
        const destino = typeof nlConsumirRetornoAuth === 'function'
          ? nlConsumirRetornoAuth('area-paciente.html')
          : 'area-paciente.html';
        navegarPara(destino);
      }, 700);
      return;
    } catch (erro) {
      const msg = erro?.message || 'Não foi possível salvar no servidor.';
      if (erro?.code === 'cpf_already_exists') {
        mostrarCpfDuplicadoCadastro(isAdulto ? 'cadCpf' : 'cadCpfAdol', isAdulto ? 'cadCpfHint' : 'cadCpfAdolHint');
        return setHint('cadGeralHint', 'CPF já cadastrado. Faça login ou recupere sua senha.', 'error');
      }
      return setHint('cadGeralHint', msg, 'error');
    }
  }

  return setHint(
    'cadGeralHint',
    'Back-end indisponível. Inicie o Flask e tente novamente para salvar no banco.',
    'error'
  );
}
async function avancarLogin() {
  const cpf = somenteDigitos($('loginCpf')?.value);

  if (!cpfValido(cpf)) return setHint('loginCpfHint', 'CPF inválido. Verifique os números digitados.', 'error');
  if (typeof apiDisponivel !== 'function' || !(await apiDisponivel())) {
    return setHint('loginCpfHint', 'Back-end indisponível. Inicie o Flask para entrar.', 'error');
  }

  if (loginEtapa === 'cpf') {
    try {
      const consulta = typeof apiUsuarioExiste === 'function'
        ? await apiUsuarioExiste(cpf)
        : await apiRequest(`/usuarios/${cpf}`);
      if (!consulta?.existe && !consulta?.cpf) {
        return setHint('loginCpfHint', 'CPF nÃ£o encontrado no banco. Crie uma conta.', 'error');
      }
    } catch (_) {
      return setHint('loginCpfHint', 'CPF não encontrado no banco. Crie uma conta.', 'error');
    }

    $('loginSenhaGroup')?.classList.remove('hidden');
    $('btnLoginProximo').textContent = 'Entrar';
    setHint('loginCpfHint', 'CPF encontrado no banco. Digite sua senha.', 'success');
    loginEtapa = 'senha';
    $('loginSenha')?.focus();
    return;
  }

  const senha = $('loginSenha')?.value || '';
  try {
    await apiLogin(cpf, senha);
    setHint('loginSenhaHint', 'Login realizado com sucesso pelo banco.', 'success');
    setTimeout(() => {
      fecharModal('modalLogin');
      const destino = typeof nlConsumirRetornoAuth === 'function'
        ? nlConsumirRetornoAuth('area-paciente.html')
        : 'area-paciente.html';
      navegarPara(destino);
    }, 500);
  } catch (erro) {
    setHint('loginSenhaHint', erro.message || 'Senha incorreta.', 'error');
  }
}

async function enviarRecuperacao() {
  const cpf = somenteDigitos($('recCpf')?.value);
  if (!cpfValido(cpf)) return setHint('recHint', 'CPF inválido. Verifique os números digitados.', 'error');
  if (typeof apiDisponivel !== 'function' || !(await apiDisponivel())) {
    return setHint('recHint', 'Back-end indisponível. Inicie o Flask para recuperar a senha.', 'error');
  }

  try {
    const resposta = await apiRequest('/esqueci-senha', {
      method: 'POST',
      body: JSON.stringify({ cpf })
    });
    const token = resposta?.token_recuperacao ? ` Token local de teste: ${resposta.token_recuperacao}` : '';
    setHint('recHint', `${resposta?.mensagem || 'Solicitação registrada no banco.'}${token}`, 'success');
  } catch (erro) {
    setHint('recHint', erro.message || 'Não foi possível solicitar recuperação de senha.', 'error');
  }
}
