const API_STORAGE = {
  token: 'neurolab_auth_token',
  perfilAtivo: 'neurolab_perfil_ativo_cpf'
};

function apiBaseUrl() {
  const meta = document.querySelector('meta[name="neurolab-api"]')?.content?.trim();
  if (meta) return meta.replace(/\/$/, '');
  if (window.NEUROLAB_API_URL) return String(window.NEUROLAB_API_URL).replace(/\/$/, '');
  if (location.hostname === 'localhost' || location.hostname === '127.0.0.1') {
    return `${location.protocol}//${location.hostname}:5000/api`;
  }
  return `${location.origin}/api`;
}

function getAuthToken() {
  return localStorage.getItem(API_STORAGE.token) || '';
}

function setAuthToken(token) {
  if (token) localStorage.setItem(API_STORAGE.token, token);
  else localStorage.removeItem(API_STORAGE.token);
}

function getPerfilAtivoCpf() {
  const titular = lerJson(STORAGE_KEYS.usuarioAtual, null);
  if (!titular?.cpf) return null;
  const ativo = localStorage.getItem(API_STORAGE.perfilAtivo);
  return ativo || titular.cpf;
}

function setPerfilAtivoCpf(cpf) {
  if (cpf) localStorage.setItem(API_STORAGE.perfilAtivo, cpf);
}

class ApiError extends Error {
  constructor(message, code, status) {
    super(message);
    this.code = code;
    this.status = status;
  }
}

async function apiRequest(path, options = {}) {
  const headers = {
    Accept: 'application/json',
    ...(options.headers || {})
  };
  const hasBody = options.body !== undefined && options.body !== null;
  if (hasBody && !(options.body instanceof FormData)) {
    headers['Content-Type'] = 'application/json';
  }
  const token = getAuthToken();
  if (token) headers.Authorization = `Bearer ${token}`;

  const response = await fetch(`${apiBaseUrl()}${path}`, {
    ...options,
    headers
  });

  let data = {};
  try {
    data = await response.json();
  } catch (_) {
    data = {};
  }

  if (!response.ok) {
    throw new ApiError(data.erro || 'Erro ao comunicar com o servidor.', data.codigo, response.status);
  }
  return data;
}

async function apiDisponivel() {
  try {
    const res = await fetch(`${apiBaseUrl()}/health`, { method: 'GET' });
    if (!res.ok) return false;
    const data = await res.json().catch(() => ({}));
    return data.status === 'online' || data.mysql === true;
  } catch (_) {
    return false;
  }
}

async function apiLogin(cpf, senha) {
  const data = await apiRequest('/login', {
    method: 'POST',
    body: JSON.stringify({ cpf: somenteDigitos(cpf), senha })
  });
  setAuthToken(data.token);
  salvarJson(STORAGE_KEYS.usuarioAtual, {
    cpf: data.cpf,
    nome: data.nome,
    email: data.email,
    tipo_usuario: data.tipo_usuario
  });
  setPerfilAtivoCpf(data.cpf);
  return data;
}

async function apiCadastro(payload) {
  return apiRequest('/cadastro', {
    method: 'POST',
    body: JSON.stringify(payload)
  });
}

async function apiUsuarioExiste(cpf) {
  const cleanCpf = typeof somenteDigitos === 'function'
    ? somenteDigitos(cpf)
    : String(cpf || '').replace(/\D/g, '');
  return apiRequest(`/usuarios/${cleanCpf}/existe`);
}

function portalQuery(perfilCpf) {
  const cpf = perfilCpf || getPerfilAtivoCpf();
  return cpf ? `?perfil_cpf=${encodeURIComponent(cpf)}` : '';
}

async function apiPortalPainel(perfilCpf) {
  return apiRequest(`/portal/painel${portalQuery(perfilCpf)}`);
}

async function apiPortalDocumentos(perfilCpf) {
  return apiRequest(`/portal/documentos${portalQuery(perfilCpf)}`);
}

async function apiPortalUploadDocumento(perfilCpf, meta) {
  return apiRequest('/portal/documentos', {
    method: 'POST',
    body: JSON.stringify({ ...meta, perfil_cpf: perfilCpf || getPerfilAtivoCpf() })
  });
}

async function apiPortalObterDocumento(perfilCpf, docId) {
  return apiRequest(`/portal/documentos/${docId}${portalQuery(perfilCpf)}`);
}

async function apiPortalRemoverDocumento(perfilCpf, docId) {
  return apiRequest(`/portal/documentos/${docId}${portalQuery(perfilCpf)}`, { method: 'DELETE' });
}

async function apiPortalPreconsulta(perfilCpf) {
  return apiRequest(`/portal/preconsulta${portalQuery(perfilCpf)}`);
}

async function apiPortalSalvarPreconsulta(perfilCpf, dados) {
  return apiRequest('/portal/preconsulta', {
    method: 'PUT',
    body: JSON.stringify({ ...dados, perfil_cpf: perfilCpf || getPerfilAtivoCpf() })
  });
}

async function apiPortalExames(perfilCpf) {
  return apiRequest(`/portal/exames${portalQuery(perfilCpf)}`);
}

async function apiPortalPreferencias(perfilCpf) {
  return apiRequest(`/portal/preferencias${portalQuery(perfilCpf)}`);
}

async function apiPortalSalvarPreferencias(perfilCpf, prefs) {
  return apiRequest('/portal/preferencias', {
    method: 'PUT',
    body: JSON.stringify({ ...prefs, perfil_cpf: perfilCpf || getPerfilAtivoCpf() })
  });
}

async function apiPortalFamilia() {
  return apiRequest('/portal/familia');
}

async function apiPortalCadastrarFamiliar(dados) {
  return apiRequest('/portal/familia/membro', {
    method: 'POST',
    body: JSON.stringify({
      cpf: somenteDigitos(dados.cpf),
      nome: dados.nome,
      email: dados.email,
      telefone: dados.telefone || dados.celular,
      data_nascimento: dados.data_nascimento || dados.nascimento,
      senha: dados.senha,
      papel: dados.papel,
      cpf_responsavel: dados.cpf_responsavel || dados.cpfResponsavel || null
    })
  });
}

async function apiPortalDesvincularFamiliar(cpfMembro) {
  return apiRequest(`/portal/familia/${somenteDigitos(cpfMembro)}`, { method: 'DELETE' });
}

async function apiPortalSalvarFoto(perfilCpf, fotoBase64) {
  return apiRequest('/portal/foto', {
    method: 'PUT',
    body: JSON.stringify({
      perfil_cpf: perfilCpf || getPerfilAtivoCpf(),
      foto_base64: fotoBase64
    })
  });
}

async function apiPortalFormulario(perfilCpf, tipo) {
  return apiRequest(`/portal/formularios/${encodeURIComponent(tipo)}${portalQuery(perfilCpf)}`);
}

async function apiPortalSalvarFormulario(perfilCpf, tipo, dados) {
  return apiRequest(`/portal/formularios/${encodeURIComponent(tipo)}`, {
    method: 'PUT',
    body: JSON.stringify({
      perfil_cpf: perfilCpf || getPerfilAtivoCpf(),
      dados: dados || {}
    })
  });
}

/* ============================================================
   Persistencia oficial via API/banco — helpers para front-end
   ============================================================ */
const NL_API_CATALOG_CACHE = { unidades: null, medicos: null, convenios: null, exames: null };

function nlApiNormalize(texto) {
  return String(texto || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-zA-Z0-9]+/g, ' ')
    .trim()
    .toLowerCase();
}

function nlApiCrmClean(texto) {
  return String(texto || '').replace(/[^0-9]/g, '');
}

async function apiCatalogo(tipo) {
  if (NL_API_CATALOG_CACHE[tipo]) return NL_API_CATALOG_CACHE[tipo];
  const mapa = { unidades: '/unidades', medicos: '/medicos', convenios: '/convenios', exames: '/exames' };
  const data = await apiRequest(mapa[tipo]);
  NL_API_CATALOG_CACHE[tipo] = data[tipo] || [];
  return NL_API_CATALOG_CACHE[tipo];
}

function nlApiEscolherPorNome(lista, nome, aliases = {}) {
  const alvo = nlApiNormalize(nome);
  if (!alvo) return null;
  const aliasId = Object.entries(aliases).find(([chave]) => alvo.includes(chave));
  if (aliasId) {
    const encontrado = lista.find(item => Number(item.id) === Number(aliasId[1]));
    if (encontrado) return encontrado;
  }
  return lista.find(item => nlApiNormalize(item.nome) === alvo)
    || lista.find(item => alvo.includes(nlApiNormalize(item.nome)) || nlApiNormalize(item.nome).includes(alvo.split(' ')[0] || alvo));
}

function nlApiDataConsulta(dados) {
  if (dados?.dataISO) return dados.dataISO;
  const raw = String(dados?.dia || '').match(/(\d{1,2})\/(\d{1,2})/);
  if (raw) {
    const hoje = new Date();
    let ano = hoje.getFullYear();
    const data = new Date(ano, Number(raw[2]) - 1, Number(raw[1]));
    if (data < new Date(hoje.getFullYear(), hoje.getMonth(), hoje.getDate())) ano += 1;
    return `${ano}-${String(raw[2]).padStart(2, '0')}-${String(raw[1]).padStart(2, '0')}`;
  }
  const state = typeof nlBookingState === 'function' ? nlBookingState() : null;
  return state?.dataISO || new Date(Date.now() + 86400000).toISOString().slice(0, 10);
}

function nlApiTipoConsulta(dados) {
  const codigo = String(dados?.tipoCodigo || '').toUpperCase();
  const texto = nlApiNormalize(`${dados?.tipoNome || ''} ${dados?.tipo || ''}`);
  if (codigo === 'EXAM' || texto.includes('exame')) return 'exame';
  if (codigo === 'TELE' || texto.includes('tele') || texto.includes('online')) return 'teleconsulta';
  return 'consulta';
}

function nlApiTipoAtendimento(dados) {
  const texto = nlApiNormalize(`${dados?.cobertura || ''} ${dados?.convenio || ''}`);
  if (texto.includes('sus')) return 'sus';
  if (texto.includes('convenio') || dados?.convenio) return 'convenio';
  return 'particular';
}

async function apiResolverAgendamento(dados) {
  const [unidades, medicos, convenios, exames] = await Promise.all([
    apiCatalogo('unidades'), apiCatalogo('medicos'), apiCatalogo('convenios'), apiCatalogo('exames')
  ]);

  const tipoConsulta = nlApiTipoConsulta(dados);
  const tipoAtendimento = nlApiTipoAtendimento(dados);
  const unidadeNome = tipoConsulta === 'teleconsulta' ? 'Teleconsulta' : (dados.unidade || dados.unidadeNome || 'Santo André - Centro');
  const unidade = nlApiEscolherPorNome(unidades, unidadeNome, {
    'santo andre': 1,
    'sao bernardo': 2,
    'teleconsulta': 3,
    'vila pires': 4,
    'moema': 5,
    'tatuape': 6,
    'paulista': 7
  });

  const crm = nlApiCrmClean(dados.crm);
  const medico = (crm && medicos.find(item => nlApiCrmClean(item.crm) === crm))
    || nlApiEscolherPorNome(medicos, dados.medico || dados.medico_nome || 'Dra. Ana Beatriz Ferreira');

  let convenio = null;
  if (tipoAtendimento === 'convenio') {
    convenio = nlApiEscolherPorNome(convenios, dados.convenio || dados.cobertura || 'Unimed', {
      'unimed': 1,
      'bradesco': 2,
      'sulamerica': 3,
      'sul america': 3,
      'amil': 4
    });
  }

  let exame = null;
  if (tipoConsulta === 'exame') {
    exame = nlApiEscolherPorNome(exames, dados.exame || dados.tipoNome || 'Eletroencefalograma', {
      'eletroencefalograma': 1,
      'eeg': 1,
      'eletroneuromiografia': 2,
      'polissonografia': 3
    }) || exames[0];
  }

  if (!unidade?.id) throw new ApiError('Unidade não encontrada no banco para este agendamento.', 'unit_not_mapped', 400);
  if (!medico?.id) throw new ApiError('Médico não encontrado no banco para este agendamento.', 'doctor_not_mapped', 400);
  if (tipoAtendimento === 'convenio' && !convenio?.id) throw new ApiError('Convênio não encontrado no banco.', 'plan_not_mapped', 400);
  if (tipoConsulta === 'exame' && !exame?.id) throw new ApiError('Exame não encontrado no banco.', 'exam_not_mapped', 400);

  return { unidade, medico, convenio, exame, tipoConsulta, tipoAtendimento };
}

async function apiCriarAgendamentoMySQL(dados) {
  if (!(await apiDisponivel())) {
    throw new ApiError('Back-end indisponível. Ligue o Flask antes de agendar.', 'backend_unavailable', 503);
  }
  const paciente = typeof obterPacienteParaAgendamento === 'function' ? obterPacienteParaAgendamento() : {};
  const cpfCliente = somenteDigitos(paciente.pacienteCpf || getPerfilAtivoCpf() || '');
  if (!cpfCliente || cpfCliente === 'visitante') {
    throw new ApiError('Entre na Área do Paciente antes de criar agendamento.', 'login_required', 401);
  }

  const resolvido = await apiResolverAgendamento(dados || {});
  const payload = {
    cpf_cliente: cpfCliente,
    cpf_responsavel: paciente.agendadoPorCpf || null,
    id_medico: resolvido.medico.id,
    id_unidade: resolvido.unidade.id,
    id_convenio: resolvido.convenio?.id || null,
    id_exame: resolvido.exame?.id || null,
    data_consulta: nlApiDataConsulta(dados || {}),
    hora_consulta: String((dados || {}).horario || (dados || {}).hora_consulta || '').slice(0, 5),
    tipo_consulta: resolvido.tipoConsulta,
    tipo_atendimento: resolvido.tipoAtendimento,
    observacao: `Criado pelo front-end NeuroLab. Médico: ${(dados || {}).medico || resolvido.medico.nome}. Unidade: ${(dados || {}).unidade || resolvido.unidade.nome}.`
  };
  if (!payload.hora_consulta) throw new ApiError('Horário obrigatório para agendamento.', 'missing_time', 400);
  const salvo = await apiRequest('/agendamentos', { method: 'POST', body: JSON.stringify(payload) });
  return {
    ...salvo,
    ...dados,
    id: salvo.id,
    status: salvo.status || 'confirmado',
    pacienteCpf: cpfCliente,
    pacienteNome: paciente.pacienteNome,
    data_consulta: payload.data_consulta,
    hora_consulta: payload.hora_consulta,
    tipo_consulta: payload.tipo_consulta,
    tipo_atendimento: payload.tipo_atendimento,
    id_medico: payload.id_medico,
    id_unidade: payload.id_unidade,
    id_convenio: payload.id_convenio,
    id_exame: payload.id_exame
  };
}
