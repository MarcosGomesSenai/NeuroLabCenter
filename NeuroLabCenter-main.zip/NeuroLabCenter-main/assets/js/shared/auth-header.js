// ============================================================
// CPF INLINE VALIDATION (Componente 3 — RN-02)
// Valida CPF em tempo real enquanto o usuário digita
// ============================================================
async function validarCpfInline(input, hintId) {
  const cpf = somenteDigitos(input.value);
  const hint = document.getElementById(hintId);
  
  input.classList.remove('cpf-valido', 'cpf-invalido');
  if (hint) { hint.textContent = ''; hint.className = 'field-hint'; }

  // Clean up any old duplicate alert
  const oldAlert = document.getElementById(hintId + '-dup-alert');
  if (oldAlert) oldAlert.remove();

  if (cpf.length < 11) return;

  if (!cpfValido(cpf)) {
    input.classList.add('cpf-invalido');
    if (hint) {
      hint.textContent = '❌ CPF inválido. Verifique os dígitos.';
      hint.className = 'field-hint error';
    }
    return false;
  }

  // Check locally first
  const usuarios = lerJson(STORAGE_KEYS.usuarios, []);
  let duplicado = usuarios.some(u => u.cpf === cpf);

  // Check on back-end API if available
  if (!duplicado && typeof apiDisponivel === 'function' && (await apiDisponivel())) {
    try {
      const res = typeof apiUsuarioExiste === 'function'
        ? await apiUsuarioExiste(cpf)
        : await apiRequest(`/usuarios/${cpf}`);
      duplicado = Boolean(res?.existe || res?.cpf);
    } catch (_) {
      // 404 or other errors mean the CPF is free to use
    }
  }

  if (duplicado && (hintId === 'cadCpfHint' || hintId === 'cadCpfAdolHint' || input.id === 'cadCpf' || input.id === 'cadCpfAdol')) {
    input.classList.add('cpf-invalido');
    if (hint) {
      hint.textContent = ''; // Clear simple text to show premium alert instead
      hint.className = 'field-hint';
    }
    
    const alertBox = document.createElement('div');
    alertBox.id = hintId + '-dup-alert';
    alertBox.className = 'cpf-duplicate-alert';
    alertBox.innerHTML = `
      <div class="dup-alert-content">
        <span class="dup-alert-icon">⚠️</span>
        <div>
          <strong>Este CPF já está cadastrado!</strong>
          <p>Seus dados estão protegidos. Faça login ou recupere sua senha para prosseguir.</p>
        </div>
      </div>
      <button class="btn btn-light btn-sm btn-dup-login" onclick="fecharModal('modalCadastro'); abrirModalLogin(); preencherCpfLogin('${cpf}');">Já tenho conta → Entrar</button>
    `;
    input.parentNode.appendChild(alertBox);
    return false;
  }

  input.classList.add('cpf-valido');
  if (hint) {
    hint.textContent = '✅ CPF disponível';
    hint.className = 'field-hint success';
  }
  return true;
}

// ============================================================
// HEADER DINÂMICO (Componente 2 — RN-04)
// Atualiza header conforme estado de autenticação
// ============================================================
const AUTH_RETURN_KEY = 'neurolab_auth_return_to';

function nlDestinoLocalSeguro(valor, fallback = 'area-paciente.html') {
  const permitido = [
    'index.html',
    'agendamento.html',
    'area-paciente.html',
    'teleconsulta.html',
    'exames.html',
    'unidades.html',
    'medicos.html',
    'convenios.html',
    'ajuda.html'
  ];
  if (!valor) return fallback;
  try {
    const destino = new URL(decodeURIComponent(String(valor)), window.location.href);
    if (destino.origin !== window.location.origin) return fallback;
    const arquivo = (destino.pathname.split('/').pop() || 'index.html').toLowerCase();
    if (!permitido.includes(arquivo)) return fallback;
    return `${arquivo}${destino.search}${destino.hash}`;
  } catch (_) {
    return fallback;
  }
}

function nlDefinirRetornoAuth(destino) {
  const seguro = nlDestinoLocalSeguro(destino, 'area-paciente.html');
  sessionStorage.setItem(AUTH_RETURN_KEY, seguro);
  return seguro;
}

function nlUrlLoginComRetorno(destino) {
  const seguro = nlDefinirRetornoAuth(destino);
  return `index.html?modal=login&next=${encodeURIComponent(seguro)}`;
}

function nlConsumirRetornoAuth(fallback = 'area-paciente.html') {
  const params = new URLSearchParams(window.location.search);
  const salvo = params.get('next') || sessionStorage.getItem(AUTH_RETURN_KEY);
  const seguro = nlDestinoLocalSeguro(salvo, fallback);
  sessionStorage.removeItem(AUTH_RETURN_KEY);
  return seguro;
}

function atualizarHeader() {
  const usuario = lerJson(STORAGE_KEYS.usuarioAtual, null);
  const authButtons = document.querySelectorAll('.auth-buttons');

  authButtons.forEach(container => {
    if (usuario && usuario.nome) {
      const primeiroNome = usuario.nome.split(' ')[0];
      container.innerHTML = `
        <span style="font-weight:700; color:var(--verde-principal); font-size:14px;">Olá, ${primeiroNome} 👤</span>
        <a class="btn btn-light" href="area-paciente.html">Minha área</a>
        <button class="btn btn-primary" onclick="fazerLogout()">Sair</button>
      `;
    } else {
      const pagina = paginaAtual();
      const cadastroHref = pagina === 'index.html' ? '#' : 'index.html?modal=cadastro';
      const loginHref = pagina === 'index.html' ? '#' : 'index.html?modal=login';
      const cadastroOnclick = pagina === 'index.html' ? 'onclick="abrirModalCadastro(); return false;"' : '';
      const loginOnclick = pagina === 'index.html' ? 'onclick="abrirModalLogin(); return false;"' : '';
      container.innerHTML = `
        <a class="btn btn-light" href="${loginHref}" ${loginOnclick}>Entrar</a>
        <a class="btn btn-primary" href="${cadastroHref}" ${cadastroOnclick}>Cadastrar</a>
      `;
    }
  });
}

function fazerLogout() {
  localStorage.removeItem(STORAGE_KEYS.usuarioAtual);
  mostrarToast('Sessão encerrada com sucesso.', 'sucesso');
  setTimeout(() => { window.location.href = 'index.html'; }, 600);
}

// ============================================================
// GUARD DE AUTENTICAÇÃO (Componente 4 — RN-01)
// Verifica login antes de permitir agendamento
// ============================================================
function verificarAuthParaAgendamento() {
  const usuario = lerJson(STORAGE_KEYS.usuarioAtual, null);
  if (!usuario || !usuario.cpf) {
    mostrarToast('Faça login ou crie uma conta para agendar.', 'aviso');
    const destino = paginaAtual() === 'agendamento.html'
      ? `agendamento.html${window.location.search}${window.location.hash}`
      : 'agendamento.html';
    nlDefinirRetornoAuth(destino);
    setTimeout(() => {
      if (paginaAtual() === 'index.html') {
        abrirModalLogin();
      } else {
        window.location.href = nlUrlLoginComRetorno(destino);
      }
    }, 800);
    return false;
  }
  return true;
}
