function renderConvenios(lista = NL_PLANOS) {
  const grid = document.getElementById('planGrid');
  if (!grid) return;
  grid.innerHTML = lista.map(plano => `
    <div class="plan-card">
      <strong>${plano.nome}</strong>
      <span>${plano.servicos.join(' · ')}</span>
      <div class="tags" style="margin-top:12px;">${plano.unidades.map(unidade => `<span class="tag">${unidade}</span>`).join('')}</div>
    </div>
  `).join('') || '<div class="safe-note">Nenhum convênio encontrado para o filtro informado.</div>';
}

function filtrarConvenios() {
  const termo = normalizarTexto(document.getElementById('planSearch')?.value || '');
  const unidade = document.getElementById('planUnit')?.value || '';
  const filtrados = NL_PLANOS.filter(plano =>
    (!termo || normalizarTexto(plano.nome).includes(termo)) &&
    (!unidade || plano.unidades.some(u => normalizarTexto(u) === normalizarTexto(unidade)))
  );
  renderConveniosMelhorados(filtrados);
}

function aprimorarUnidadesMapas() {
  if (paginaArquivo() !== 'unidades.html') return;
  document.querySelectorAll('.unidade-rica').forEach(card => {
    if (card.querySelector('.map-card')) return;
    const titulo = card.querySelector('h3')?.textContent || '';
    const unidade = NL_UNIDADES.find(item => titulo.includes(item.nome.split(' - ')[0]) || titulo.includes('Teleconsulta'));
    if (!unidade?.mapa) return;
    card.insertAdjacentHTML('beforeend', `<div class="map-card" style="margin-top:16px;"><iframe title="Mapa ${unidade.nome}" loading="lazy" src="${unidade.mapa}"></iframe></div>`);
  });
}

function renderPortalPaciente() {
  if (paginaArquivo() !== 'area-paciente.html') return;
  const section = document.querySelector('.dashboard-grid')?.closest('.container');
  if (!section || document.getElementById('portalUpgrade')) return;
  section.insertAdjacentHTML('beforeend', `
    <div class="portal-panel" id="portalUpgrade" style="margin-top:24px;">
      <h3>Área logada</h3>
      <p>Organização dos dados que o paciente espera encontrar depois do login: histórico, exames, documentos e dependentes.</p>
      <div class="portal-tabs">
        <button class="portal-tab active" onclick="alternarPortalTab('historico', this)">Histórico</button>
        <button class="portal-tab" onclick="alternarPortalTab('exames', this)">Exames</button>
        <button class="portal-tab" onclick="alternarPortalTab('documentos', this)">Documentos</button>
        <button class="portal-tab" onclick="alternarPortalTab('dependentes', this)">Dependentes</button>
      </div>
      <div id="portalContent"></div>
    </div>
  `);
  alternarPortalTab('historico');
}

function alternarPortalTab(tab, botao) {
  window.NLUX.portalTab = tab;
  document.querySelectorAll('.portal-tab').forEach(item => item.classList.remove('active'));
  botao?.classList.add('active');
  const content = document.getElementById('portalContent');
  if (!content) return;

  if (tab === 'historico') {
    content.innerHTML = `
      <div class="portal-grid">
        <div class="portal-card"><strong>Nenhum histórico carregado</strong><span>Consultas reais aparecerão depois do login e do primeiro agendamento.</span></div>
        <div class="portal-card"><strong>Dados por CPF</strong><span>O painel não mistura dados entre perfis da família.</span></div>
        <div class="portal-card"><strong>Banco MySQL</strong><span>O conteúdo oficial é carregado do MySQL pela API.</span></div>
      </div>`;
  }
  if (tab === 'exames') {
    content.innerHTML = `
      <div class="portal-grid">
        <div class="portal-card"><strong>Nenhum exame liberado</strong><span>Solicitações e laudos reais aparecerão nesta aba.</span></div>
        <div class="portal-card"><strong>Preparo</strong><span>Orientações serão exibidas quando o exame for cadastrado.</span></div>
        <div class="portal-card"><strong>Laudos</strong><span>Arquivos ficam disponíveis apenas para o CPF ativo.</span></div>
      </div>`;
  }
  if (tab === 'documentos') {
    content.innerHTML = `
      <div class="portal-grid">
        <div class="portal-card"><strong>Nenhum documento enviado</strong><span>Envie arquivos reais pela aba Documentos depois do login.</span></div>
        <div class="portal-card"><strong>Privacidade</strong><span>Documentos são tratados como dados sensíveis.</span></div>
        <div class="portal-card"><strong>Organização</strong><span>Cada CPF possui seus próprios arquivos.</span></div>
      </div>`;
  }
  if (tab === 'dependentes') {
    renderDependentes(content);
  }
}

function renderDependentes(content = document.getElementById('portalContent')) {
  const dependentes = lerJson('neurolab_dependentes', []);
  content.innerHTML = `
    <div class="portal-grid">
      ${dependentes.length ? dependentes.map(dep => `<div class="dependent-card"><strong>${dep.nome}</strong><span>${dep.parentesco} · ${dep.idade}</span><button class="btn btn-light" style="margin-top:12px;" onclick="abrirAgendamento()">Agendar para dependente</button></div>`).join('') : '<div class="patient-empty-state"><strong>Nenhum dependente salvo</strong><p>Adicione apenas cadastros reais de familiares.</p></div>'}
    </div>
    <div class="dependent-form">
      <input id="depNome" placeholder="Nome do dependente" />
      <input id="depInfo" placeholder="Parentesco e idade" />
      <button class="btn btn-primary" onclick="adicionarDependente()">Adicionar</button>
    </div>
  `;
}

function adicionarDependente() {
  const nome = document.getElementById('depNome')?.value.trim();
  const info = document.getElementById('depInfo')?.value.trim();
  if (!nome || !info) {
    alert('Informe nome, parentesco e idade do dependente.');
    return;
  }
  const [parentesco = 'Dependente', idade = ''] = info.split(',').map(item => item.trim());
  const dependentes = lerJson('neurolab_dependentes', []);
  dependentes.push({ nome, parentesco, idade });
  salvarJson('neurolab_dependentes', dependentes);
  renderDependentes();
}

function nlSafeText(valor) {
  return String(valor ?? '').replace(/[&<>"']/g, (char) => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#039;'
  }[char]));
}

function nlModalidadeLabel(codigo) {
  return {
    'CONS-ADULT': 'Consulta adulto',
    'CONS-INF': 'Neuropediatria',
    'EXAM': 'Exames',
    'TELE': 'Online'
  }[codigo] || codigo;
}

function nlDoctorInitials(nome) {
  return String(nome || '')
    .replace(/^Dr(a)?\.\s*/i, '')
    .split(/\s+/)
    .slice(0, 2)
    .map(parte => parte[0])
    .join('')
    .toUpperCase();
}

function nlClassificarEspecialidade(medico) {
  const texto = normalizarTexto(`${medico.especialidade} ${medico.tipos.join(' ')}`);
  if (texto.includes('pediatria') || medico.tipos.includes('CONS-INF')) return 'Neuropediatria';
  if (texto.includes('sono')) return 'Sono e cognição';
  if (texto.includes('exame') || texto.includes('neurofisiologico') || medico.tipos.includes('EXAM')) return 'Exames neurofisiológicos';
  if (texto.includes('cefaleia') || texto.includes('enxaqueca')) return 'Cefaleia e dor';
  if (texto.includes('memoria') || texto.includes('alzheimer') || texto.includes('cognicao')) return 'Memória e cognição';
  if (texto.includes('movimento') || texto.includes('parkinson')) return 'Distúrbios do movimento';
  return 'Neurologia geral';
}

function nlMedicoCard(medico) {
  const unidadePrincipal = medico.unidades[0] || 'Unidade a confirmar';
  return `
    <article class="doctor-profile-card">
      <div class="doctor-profile-top">
        <div class="doctor-photo">${nlDoctorInitials(medico.nome)}</div>
        <div>
          <strong>${nlSafeText(medico.nome)}</strong>
          <span>${nlSafeText(medico.crm)} · ${nlSafeText(medico.especialidade)}</span>
        </div>
      </div>
      <div class="doctor-profile-meta">
        <span>${medico.rating.toFixed(1)} avaliação</span>
        <span>${medico.avaliacoes} opiniões</span>
        <span>${nlSafeText(unidadePrincipal)}</span>
      </div>
      <div class="tags">${medico.coberturas.map(item => `<span class="tag">${nlSafeText(item)}</span>`).join('')}</div>
      <button class="btn btn-primary" onclick="abrirAgendamento()">Agendar com este médico</button>
    </article>
  `;
}

function renderMedicosPage() {
  const pageRoot = document.getElementById('medicosPageRoot');
  const root = pageRoot;
  if (!pageRoot || pageRoot.dataset.medicosEnhanced === 'true') return;
  pageRoot.dataset.medicosEnhanced = 'true';

  const grupos = [...new Set(NL_MEDICOS.map(nlClassificarEspecialidade))];
  const content = `
    <div class="doctor-filter-panel">
      <button class="doctor-filter-chip active" onclick="filtrarMedicosEspecialidade('Todos', this)">Todos</button>
      ${grupos.map(grupo => `<button class="doctor-filter-chip" onclick="filtrarMedicosEspecialidade('${grupo.replace(/'/g, "\\'")}', this)">${grupo}</button>`).join('')}
    </div>
    <div class="doctor-specialty-grid" id="doctorSpecialtyGrid">
      ${NL_MEDICOS.map(medico => `<div data-specialty="${nlClassificarEspecialidade(medico)}">${nlMedicoCard(medico)}</div>`).join('')}
    </div>
  `;

  pageRoot.innerHTML = content;
  return;

  root.innerHTML = `
    <div class="container">
      <div class="section-title">
        <h2>Médicos por especialidade</h2>
        <p>Uma visão clara de quem atende cada linha de cuidado, unidade e modalidade.</p>
      </div>
      ${content}
      <div class="text-center mt-4"><a class="btn btn-light" href="medicos.html">Abrir página completa de médicos</a></div>
    </div>
  `;
}

function filtrarMedicosEspecialidade(especialidade, botao) {
  document.querySelectorAll('.doctor-filter-chip').forEach(chip => chip.classList.remove('active'));
  botao?.classList.add('active');
  document.querySelectorAll('#doctorSpecialtyGrid > div').forEach(card => {
    card.classList.toggle('hidden', especialidade !== 'Todos' && card.dataset.specialty !== especialidade);
  });
}

function renderUnidadesCompleta() {
  if (paginaArquivo() !== 'unidades.html') return;
  const grid = document.querySelector('.unidade-rica')?.parentElement;
  if (!grid || grid.dataset.unitEnhanced === 'true') return;
  grid.dataset.unitEnhanced = 'true';

  const imagensClinicas = [
    '../../assets/img/Area-de-espera.jpg',
    '../../assets/img/central-de-saude.jpg',
    '../../assets/img/Diagnpsticos-completos.jpg'
  ];

  grid.className = 'unit-showcase-grid unit-showcase-grid-refined';
  grid.innerHTML = NL_UNIDADES.map((unidade, index) => {
    const imagem = unidade.imagem || imagensClinicas[index % imagensClinicas.length];
    const recursos = (unidade.recursos && unidade.recursos.length ? unidade.recursos : [
      unidade.modalidades.includes('EXAM') ? 'Exames neurológicos' : 'Consultas presenciais',
      unidade.modalidades.includes('TELE') ? 'Teleconsulta de apoio' : 'Recepção presencial',
      unidade.coberturas.includes('SUS') ? 'Cotas SUS' : 'Convênios privados'
    ]).slice(0, 4);
    const enderecoEsc = unidade.endereco.replace(/'/g, "\\'");
    const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(unidade.endereco)}`;
    const horario = unidade.horario || (unidade.nome.includes('Centro') ? 'Seg–Sex 7h às 19h · Sáb 8h às 13h' : 'Seg–Sex 8h às 18h · Sáb 8h às 12h');
    const possuiExames = unidade.modalidades.includes('EXAM');
    const possuiTele = unidade.modalidades.includes('TELE');

    return `
      <article class="unit-showcase-card unit-visual-card">
        <div class="unit-showcase-photo">
          <img src="${imagem}" alt="Recepção e frente da unidade ${nlSafeText(unidade.nome)}" loading="lazy">
          <span class="unit-photo-badge">Unidade física</span>
          <a class="unit-map-link" href="${mapsUrl}" target="_blank" rel="noopener">Abrir no Maps ↗</a>
        </div>
        <div class="unit-map-preview">
          <iframe title="Mapa da unidade ${nlSafeText(unidade.nome)}" loading="lazy" referrerpolicy="no-referrer-when-downgrade" src="${unidade.mapa}"></iframe>
        </div>
        <div class="unit-showcase-body">
          <div class="unit-heading unit-heading-clean">
            <div>
              <span class="unit-city-label">NeuroLab Center</span>
              <h3>${nlSafeText(unidade.nome)}</h3>
            </div>
            <span>${nlSafeText(unidade.distancia)}</span>
          </div>
          <p class="unit-address-line">${nlSafeText(unidade.endereco)}</p>
          <div class="unit-info-row">
            <span>🕐 ${nlSafeText(horario)}</span>
            <span>${possuiExames ? '🧠 Exames no local' : '🩺 Consultas presenciais'}</span>
            <span>${possuiTele ? '💻 Suporte à teleconsulta' : '👥 Atendimento presencial'}</span>
          </div>
          <div class="unit-resource-grid unit-resource-fixed">
            ${recursos.map(recurso => `<span>${nlSafeText(recurso)}</span>`).join('')}
          </div>
          <div class="tags unit-tags-fixed">${unidade.coberturas.map(item => `<span class="tag">${nlSafeText(item)}</span>`).join('')}</div>
          <div class="unit-card-actions unit-card-actions-single">
            <button class="btn btn-primary" onclick="abrirAgendamento()">Agendar nesta unidade</button>
            <button class="btn btn-outline-unit" type="button" onclick="copiarEnderecoUnidade('${enderecoEsc}')">Copiar endereço</button>
          </div>
        </div>
      </article>
    `;
  }).join('');
}

function copiarEnderecoUnidade(endereco) {
  const texto = String(endereco || '').trim();
  if (!texto) return;
  navigator.clipboard?.writeText(texto)
    .then(() => mostrarToast('Endereço copiado.', 'sucesso'))
    .catch(() => mostrarToast(texto, 'info'));
}

let portalApiCache = null;

async function carregarPortalApi() {
  if (typeof getAuthToken !== 'function' || !getAuthToken()) return null;
  if (typeof apiDisponivel !== 'function' || !(await apiDisponivel())) return null;
  try {
    portalApiCache = await apiPortalPainel(getPerfilAtivoCpf());
    return portalApiCache;
  } catch (erro) {
    mostrarToast(erro.message || 'Não foi possível carregar dados do banco.', 'aviso');
    return null;
  }
}

async function initPortalPaciente() {
  if (paginaArquivo() !== 'area-paciente.html') return;
  await carregarPortalApi();
  const grid = document.querySelector('.patient-app-shell, .dashboard-grid');
  if (grid) delete grid.dataset.patientEnhanced;
  renderPortalPacienteNovo();
}

function renderPortalPacienteNovo() {
  if (paginaArquivo() !== 'area-paciente.html') return;
  const grid = document.querySelector('.dashboard-grid, .patient-app-shell');
  if (!grid) return;
  grid.dataset.patientEnhanced = 'true';

  const api = portalApiCache;
  const usuario = getUsuarioLogado();

  if (!usuario?.cpf && !api?.perfil_ativo) {
    grid.className = 'patient-app-shell patient-app-shell-empty';
    grid.innerHTML = `
      <section class="patient-login-empty">
        <div class="patient-login-icon">🔐</div>
        <span class="quick-access-label">Área segura</span>
        <h2>Entre com CPF para carregar seus dados reais.</h2>
        <p>Nenhum agendamento, documento ou familiar falso será exibido aqui. A área do paciente passa a mostrar apenas informações salvas na sua sessão ou no MySQL.</p>
        <div class="patient-empty-actions">
          <a class="btn btn-primary" href="index.html?modal=login">Entrar com CPF</a>
          <a class="btn btn-light" href="index.html?modal=cadastro">Criar conta</a>
        </div>
      </section>
    `;
    return;
  }

  const perfisFamilia = api?.perfis_familia || listarPerfisFamilia();
  const cpfPerfil = getPerfilAtivoCpf();
  const perfilDetalhe = perfisFamilia.find(p => p.cpf === cpfPerfil) || perfisFamilia[0];
  const perfilApi = api?.perfil_ativo;
  const perfilUsuario = getPerfilAtivoUsuario();
  const nomeCompleto = perfilApi?.nome || perfilUsuario?.nome || perfilDetalhe?.nome || usuario?.nome || 'Paciente';
  const nome = nomeCompleto.split(' ')[0];
  const agendamentos = api?.agendamentos || agendamentosDoPerfil(cpfPerfil);
  const proximo = agendamentos[0] || agendamentos[agendamentos.length - 1];
  const fotoPerfil = perfilApi?.foto_perfil || '';
  const progresso = calcularCompletudePerfil();
  const uploadsLocais = lerJson(chaveDadosPerfil('neurolab_documentos_upload', cpfPerfil), []);
  const docsPaciente = api?.documentos || uploadsLocais || [];
  const perfilContexto = perfilDetalhe?.cpf === usuario?.cpf ? 'Perfil titular' : `${perfilDetalhe?.papel || 'Familiar'} vinculado`;
  const cpfMascarado = cpfPerfil
    ? `CPF ${String(cpfPerfil).slice(0, 3)}.***.***-${String(cpfPerfil).slice(-2)}`
    : 'CPF não informado';

  grid.className = 'patient-app-shell patient-app-shell-refined';
  grid.innerHTML = `
    <aside class="patient-sidebar">
      <div class="patient-profile-card text-center">
        <div class="patient-avatar patient-avatar-photo mx-auto" style="${fotoPerfil ? `background-image:url('${fotoPerfil}')` : ''}">${fotoPerfil ? '' : nlDoctorInitials(nome)}</div>
        <label class="btn btn-outline-secondary btn-sm mt-2 patient-photo-button">
          Trocar foto
          <input type="file" accept="image/*" class="d-none" onchange="salvarFotoPerfilPaciente(this)">
        </label>
        <strong class="d-block mt-2">${nlSafeText(nomeCompleto)}</strong>
        <span class="patient-context-label">${nlSafeText(perfilContexto)}</span>
        <small>${cpfMascarado}</small>
        <div class="patient-profile-progress">
          <span>Perfil ${progresso}% completo</span>
          <div><i style="width:${progresso}%"></i></div>
        </div>
      </div>
      <div class="patient-family-switch">
        <label for="familiaPerfilSelect" class="form-label">Conta fam\u00edlia</label>
        <select id="familiaPerfilSelect" class="form-select" onchange="trocarPerfilFamilia(this.value)">
          ${perfisFamilia.map(perfil => `<option value="${nlSafeText(perfil.cpf)}" ${perfil.cpf === cpfPerfil ? 'selected' : ''}>${nlSafeText(perfil.papel)} — ${nlSafeText(perfil.nome)}</option>`).join('')}
        </select>
        <small>Troque de perfil sem sair da conta. Agendamentos e documentos s\u00f3 do CPF ativo.</small>
      </div>
      <div class="patient-sidebar-actions">
        <button class="btn btn-primary" onclick="abrirAgendamento()">Novo agendamento</button>
        <button class="btn btn-light" onclick="alternarPacienteSecao('familia')">Gerenciar família</button>
      </div>
    </aside>
    <section class="patient-main-panel">
      <div class="patient-welcome-card">
        <div>
          <span class="quick-access-label">Painel do paciente</span>
          <h2>Olá, ${nlSafeText(nome)}.</h2>
          <p>Dados reais do perfil selecionado, separados por CPF e carregados do MySQL.</p>
        </div>
        <div class="patient-status-stack">
          <span>Conta protegida por LGPD</span>
          <strong>${proximo ? 'Consulta encontrada' : 'Sem consulta ativa'}</strong>
        </div>
      </div>
      <div class="patient-kpis">
        <div><strong>${agendamentos.length || 0}</strong><span>agendamentos</span></div>
        <div><strong>${docsPaciente.length}</strong><span>documentos</span></div>
        <div><strong>${perfisFamilia.length}</strong><span>perfis família</span></div>
        <div><strong>${progresso}%</strong><span>perfil completo</span></div>
      </div>
      <div class="patient-card-lg">
        <div>
          <span class="quick-access-label">Próxima etapa</span>
          <h3>${proximo?.medico_nome || proximo?.medico || 'Nenhum agendamento ativo'}</h3>
          <p>${proximo ? `${proximo.tipo_consulta || proximo.tipoNome || 'Consulta'} · ${proximo.data_consulta || proximo.dia || ''} ${proximo.hora_consulta || proximo.horario || ''} · ${nlSafeText(perfilDetalhe?.nome || '')}` : 'Nenhum horário marcado para este CPF. Use o botão de agendamento quando quiser criar uma consulta real.'}</p>
        </div>
        <div class="patient-action-row">
          <button class="btn btn-light" onclick="abrirAgendamento()">${proximo ? 'Reagendar' : 'Agendar'}</button>
          <button class="btn btn-primary" onclick="registrarCheckinPaciente()">Check-in</button>
        </div>
      </div>
      <div class="patient-tabs" role="tablist" aria-label="Área do Paciente">
        <button class="active" type="button" onclick="alternarPacienteSecao('resumo', this)">Resumo</button>
        <button type="button" onclick="alternarPacienteSecao('documentos', this)">Documentos</button>
        <button type="button" onclick="alternarPacienteSecao('preconsulta', this)">Pré-consulta</button>
        <button type="button" onclick="alternarPacienteSecao('exames', this)">Exames</button>
        <button type="button" onclick="alternarPacienteSecao('familia', this)">Conta família</button>
        <button type="button" onclick="alternarPacienteSecao('preferencias', this)">Lembretes</button>
      </div>
      <div id="patientDynamicPanel" class="patient-dynamic-panel"></div>
    </section>
  `;
  alternarPacienteSecao('resumo');
}

function salvarFotoPerfilPaciente(input) {
  const arquivo = input?.files?.[0];
  if (!arquivo) return;
  if (!arquivo.type.startsWith('image/')) {
    mostrarToast('Selecione uma imagem para a foto do perfil.', 'aviso');
    input.value = '';
    return;
  }

  const leitor = new FileReader();
  leitor.onload = async () => {
    const foto = String(leitor.result || '');
    const cpf = getPerfilAtivoCpf();
    // Foto de perfil grava apenas no MySQL pela versão ativa abaixo.
    let salvouMysql = false;
    if (typeof getAuthToken === 'function' && getAuthToken()) {
      try {
        await apiPortalSalvarFoto(cpf, foto);
        salvouMysql = true;
      } catch (_) {
        salvouMysql = false;
      }
    }
    document.querySelectorAll('.patient-avatar-photo').forEach(avatar => {
      avatar.style.backgroundImage = `url('${foto}')`;
      avatar.textContent = '';
    });
    mostrarToast(salvouMysql ? 'Foto salva no MySQL.' : 'Foto não salva: MySQL/API indisponível.', 'sucesso');
  };
  leitor.readAsDataURL(arquivo);
}

async function trocarPerfilFamilia(cpf) {
  trocarPerfilFamiliaPorCpf(cpf);
  if (typeof setPerfilAtivoCpf === 'function') setPerfilAtivoCpf(cpf);
  portalApiCache = null;
  await initPortalPaciente();
  const perfil = (portalApiCache?.perfis_familia || listarPerfisFamilia()).find(p => p.cpf === getPerfilAtivoCpf());
  mostrarToast(`Perfil ativo: ${perfil?.nome || 'Titular'}. Dados carregados do banco para este CPF.`, 'info');
}

function documentoPacienteRef(doc) {
  return encodeURIComponent(String(doc.local_id || doc.id || doc.nome_arquivo || doc.nome || ''));
}

function documentoPacienteLocal(cpf, ref) {
  const chave = chaveDadosPerfil('neurolab_documentos_upload', cpf);
  const docs = lerJson(chave, []);
  return docs.find(doc => String(doc.local_id || doc.id || doc.nome_arquivo || doc.nome) === String(ref));
}

function listaDocumentosLocais(cpf) {
  return lerJson(chaveDadosPerfil('neurolab_documentos_upload', cpf), []);
}

function salvarListaDocumentosLocais(cpf, docs) {
  salvarJson(chaveDadosPerfil('neurolab_documentos_upload', cpf), docs);
}

function preconsultaVazia(dados) {
  return !String(dados?.sintomas || '').trim() && !String(dados?.medicamentos || '').trim() && !String(dados?.observacoes || '').trim();
}

async function alternarPacienteSecao(secao = 'resumo', botao) {
  if (paginaArquivo() !== 'area-paciente.html') return;
  const painel = document.getElementById('patientDynamicPanel');
  if (!painel) return;

  document.querySelectorAll('.patient-tabs button').forEach(item => item.classList.remove('active'));
  const ativo = botao || [...document.querySelectorAll('.patient-tabs button')].find(item => item.getAttribute('onclick')?.includes(`'${secao}'`));
  ativo?.classList.add('active');

  const cpfPerfil = getPerfilAtivoCpf();
  const usaApi = typeof getAuthToken === 'function' && getAuthToken();

  const agendamentos = portalApiCache?.agendamentos || agendamentosDoPerfil(cpfPerfil);
  let docs = portalApiCache?.documentos;
  if (!docs) {
    docs = lerJson(chaveDadosPerfil('neurolab_documentos_upload', cpfPerfil), []);
  }
  const prefs = portalApiCache?.preferencias || lerJson(chaveDadosPerfil('neurolab_paciente_preferencias', cpfPerfil), { whatsapp: true, email: true, sms: false });

  if (secao === 'documentos') {
    const docsLocais = listaDocumentosLocais(cpfPerfil);
    if (usaApi) {
      try {
        const docsApi = await apiPortalDocumentos(cpfPerfil);
        docs = [...(docsApi || []), ...docsLocais.filter(local => !local.sincronizado_mysql)];
      } catch (_) {
        docs = docsLocais;
      }
    } else {
      docs = docsLocais;
    }
    painel.innerHTML = `
      <div class="patient-doc-upload patient-save-box">
        <div>
          <strong>Enviar documento</strong>
          <p class="mb-0">RG, CNH, carteirinha do convênio ou laudos anteriores. O arquivo fica vinculado ao CPF ativo.</p>
        </div>
        <label class="btn btn-primary mb-0">
          Selecionar arquivo
          <input type="file" id="patientDocInput" accept=".pdf,image/*" onchange="uploadDocumentoPaciente(this)" hidden>
        </label>
      </div>
      <div class="patient-doc-list">
        ${(docs || []).map(doc => {
          const ref = documentoPacienteRef(doc);
          const nomeDoc = doc.nome_arquivo || doc.nome || 'Documento';
          const origem = doc.id || doc.id_mysql ? 'MySQL' : 'Não sincronizado';
          return `
            <article>
              <div>
                <strong>${nlSafeText(nomeDoc)}</strong>
                <span>${nlSafeText(doc.tipo_arquivo || doc.tipo || 'arquivo')} · ${nlSafeText(doc.status || 'enviado')} · ${origem}${doc.criado_em ? ` · ${String(doc.criado_em).slice(0, 10)}` : doc.data ? ` · ${doc.data}` : ''}</span>
              </div>
              <div class="patient-doc-actions">
                <button class="btn btn-light btn-sm" onclick="abrirDocumentoPaciente('${ref}')">Visualizar</button>
                <button class="btn btn-light btn-sm text-danger" onclick="removerDocumentoPaciente('${ref}')">Apagar</button>
              </div>
            </article>
          `;
        }).join('') || '<div class="patient-empty-state"><strong>Nenhum documento enviado</strong><p>Envie um arquivo para habilitar visualizar e apagar nesta aba.</p></div>'}
      </div>
    `;
    return;
  }

  if (secao === 'preconsulta') {
    const localPreconsulta = lerJson(chaveDadosPerfil('neurolab_preconsulta', cpfPerfil), { sintomas: '', medicamentos: '', observacoes: '' });
    let anamnese = portalApiCache?.preconsulta;
    if (usaApi && (!anamnese || preconsultaVazia(anamnese))) {
      try {
        anamnese = await apiPortalPreconsulta(cpfPerfil);
      } catch (_) { /* mantem vazio quando MySQL/API nao responder */ }
    }
    if (!anamnese || (preconsultaVazia(anamnese) && !preconsultaVazia(localPreconsulta))) {
      anamnese = localPreconsulta;
    }
    painel.innerHTML = `
      <div class="patient-preconsulta-form patient-save-box-vertical">
        <div class="patient-form-head">
          <div>
            <strong>Pré-consulta / Anamnese digital</strong>
            <p>Preencha antes da consulta. A pré-consulta é salva somente no MySQL pela API.</p>
          </div>
          <span class="patient-save-pill" id="preconsultaStatus">${preconsultaVazia(anamnese) ? 'Ainda não preenchida' : 'Dados carregados'}</span>
        </div>
        <label class="form-label mt-2">Sintomas principais</label>
        <textarea id="preSintomas" oninput="salvarRascunhoPreConsultaPaciente()" placeholder="Ex.: dor de cabeça frequente, tontura...">${nlSafeText(anamnese.sintomas)}</textarea>
        <label class="form-label mt-3">Medicamentos em uso</label>
        <textarea id="preMedicamentos" oninput="salvarRascunhoPreConsultaPaciente()" placeholder="Nome e dosagem">${nlSafeText(anamnese.medicamentos)}</textarea>
        <label class="form-label mt-3">Outras observações</label>
        <textarea id="preObservacoes" oninput="salvarRascunhoPreConsultaPaciente()" placeholder="Alergias, cirurgias, exames recentes">${nlSafeText(anamnese.observacoes)}</textarea>
        <button class="btn btn-primary mt-3" onclick="salvarPreConsultaPaciente()">Salvar pré-consulta</button>
      </div>
    `;
    return;
  }

  if (secao === 'exames') {
    let exames = portalApiCache?.exames;
    if (usaApi) {
      try {
        exames = await apiPortalExames(cpfPerfil);
      } catch (_) { /* noop */ }
    }
    if (!exames?.length) {
      exames = lerJson(chaveDadosPerfil('neurolab_exames_paciente', cpfPerfil), []);
    }
    painel.innerHTML = exames.length ? `
      <div class="patient-exam-list">
        ${exames.map((ex, i) => `
          <article>
            <div>
              <strong>${nlSafeText(ex.nome)}</strong>
              <span>${nlSafeText(ex.status)} · ${nlSafeText(ex.data_referencia || ex.data || '')}</span>
              <small class="d-block text-muted">Preparo: ${nlSafeText(ex.preparo || 'Orientações serão exibidas quando o exame for cadastrado.')}</small>
            </div>
            <button class="btn btn-light" onclick="gerarDocumentoPaciente('${ex.nome.replace(/'/g, "\\'")}')">Ver laudo</button>
          </article>
        `).join('')}
      </div>
    ` : `
      <div class="patient-empty-state">
        <strong>Nenhum exame disponível</strong>
        <p>Quando um exame for solicitado ou um laudo for liberado, ele aparecerá nesta aba com dados do banco.</p>
        <button class="btn btn-primary" onclick="abrirAgendamento()">Agendar exame</button>
      </div>
    `;
    return;
  }

  if (secao === 'familia') {
    let perfis = portalApiCache?.perfis_familia || listarPerfisFamilia();
    if (usaApi) {
      try {
        const fam = await apiPortalFamilia();
        perfis = fam.perfis || perfis;
      } catch (_) { /* noop */ }
    }
    const titular = getUsuarioLogado();
    painel.innerHTML = `
      <p class="mb-3">A conta família mostra somente perfis realmente vinculados ao titular. Cada familiar mantém CPF, documentos e agendamentos separados.</p>
      <div class="patient-family-list">
        ${perfis.length ? perfis.map(perfil => `
          <article>
            <div>
              <strong>${nlSafeText(perfil.papel)} — ${nlSafeText(perfil.nome)}</strong>
              <span>${perfil.cpf === cpfPerfil ? 'Perfil ativo agora' : 'Vinculado · CPF ' + String(perfil.cpf).slice(0, 3) + '.***-' + String(perfil.cpf).slice(-2)}</span>
            </div>
            <div class="patient-family-actions">
              ${perfil.cpf !== cpfPerfil ? `<button class="btn btn-light btn-sm" onclick="trocarPerfilFamilia('${perfil.cpf}')">Usar perfil</button>` : '<span class="badge bg-success">Ativo</span>'}
              ${perfil.cpf !== titular?.cpf ? `<button class="btn btn-light btn-sm" onclick="removerPerfilFamilia('${perfil.cpf}')">Desvincular</button>` : '<span class="badge bg-light text-dark">Titular</span>'}
            </div>
          </article>
        `).join('') : '<div class="patient-empty-state"><strong>Nenhum familiar vinculado</strong><p>Cadastre um filho, neto ou outro responsável apenas quando houver dados reais.</p></div>'}
      </div>
      <div class="patient-family-register mt-4">
        <button class="btn btn-primary" onclick="abrirCadastroFamiliar()">Cadastrar familiar (mesmo processo de nova conta)</button>
        <p class="text-muted small mt-2 mb-0">Abre o formulário completo: CPF, nome, data de nascimento, celular, e-mail e senha. Os dados são salvos no banco de dados e vinculados à sua conta família.</p>
      </div>
    `;
    return;
  }

  if (secao === 'preferencias') {
    painel.innerHTML = `
      <div class="patient-preference-grid">
        ${[
          ['whatsapp', 'WhatsApp', 'Confirmações e lembretes rápidos.'],
          ['email', 'E-mail', 'Documentos, recibos e orientações.'],
          ['sms', 'SMS', 'Alertas curtos quando necessário.']
        ].map(([chave, titulo, texto]) => `
          <label>
            <span><strong>${titulo}</strong><small>${texto}</small></span>
            <input type="checkbox" ${prefs[chave] ? 'checked' : ''} onchange="atualizarPreferenciaPaciente('${chave}', this.checked)">
          </label>
        `).join('')}
      </div>
    `;
    return;
  }

  const perfil = listarPerfisFamilia().find(p => p.cpf === cpfPerfil);
  painel.innerHTML = `
    ${perfil ? `<p class="patient-perfil-banner">Visualizando dados de <strong>${nlSafeText(perfil.nome)}</strong> (${nlSafeText(perfil.papel)}). Este painel não mistura dados de outros CPFs da família.</p>` : ''}
    <div class="patient-summary-grid">
      <article>
        <span>Agendamentos</span>
        <strong>${agendamentos.length ? `${agendamentos.length} registro(s)` : 'Nenhum registro'}</strong>
        <small>${agendamentos.length ? 'Carregado para o CPF ativo.' : 'Agendamentos reais aparecerão após salvar no sistema.'}</small>
      </article>
      <article>
        <span>Documentos</span>
        <strong>${(docs || []).length ? `${docs.length} arquivo(s)` : 'Nenhum enviado'}</strong>
        <small>Envie RG, carteirinha ou laudos para agilizar a recepção.</small>
      </article>
      <article>
        <span>Conta família</span>
        <strong>${listarPerfisFamilia().length} perfil(is)</strong>
        <small>Use apenas cadastros reais vinculados pelo CPF.</small>
      </article>
    </div>
  `;
}

async function atualizarPreferenciaPaciente(chave, valor) {
  const cpf = getPerfilAtivoCpf();
  const storageKey = chaveDadosPerfil('neurolab_paciente_preferencias', cpf);
  const prefs = { whatsapp: true, email: true, sms: false, ...(portalApiCache?.preferencias || lerJson(storageKey, {})) };
  prefs[chave] = Boolean(valor);
  salvarJson(storageKey, prefs);

  if (portalApiCache) portalApiCache.preferencias = prefs;
  let salvouMysql = false;
  if (typeof getAuthToken === 'function' && getAuthToken()) {
    try {
      const salvo = await apiPortalSalvarPreferencias(cpf, prefs);
      if (portalApiCache) portalApiCache.preferencias = salvo;
      salvarJson(storageKey, salvo);
      salvouMysql = true;
    } catch (_) {
      salvouMysql = false;
    }
  }
  mostrarToast(salvouMysql ? 'Preferência salva no MySQL.' : 'Preferência não salva: MySQL/API indisponível.', 'sucesso');
}

function registrarCheckinPaciente() {
  salvarJson('neurolab_checkin_atual', { feitoEm: new Date().toISOString(), status: 'QR Code liberado', cpf: getPerfilAtivoCpf() });
  abrirModalPaciente('checkin');
  mostrarToast('Check-in salvo para o CPF ativo.', 'sucesso');
}

async function abrirDocumentoPaciente(docRef) {
  const ref = decodeURIComponent(String(docRef || ''));
  const cpf = getPerfilAtivoCpf();
  let doc = documentoPacienteLocal(cpf, ref);

  if (!doc && typeof getAuthToken === 'function' && getAuthToken() && /^\d+$/.test(ref)) {
    try {
      doc = await apiPortalObterDocumento(cpf, ref);
    } catch (erro) {
      mostrarToast(erro.message || 'Não foi possível abrir o documento.', 'erro');
      return;
    }
  }

  const conteudo = doc?.conteudo_base64;
  if (!conteudo) {
    mostrarToast('Este documento não possui arquivo salvo para visualização. Envie novamente o PDF ou imagem.', 'aviso');
    return;
  }

  const nome = doc.nome_arquivo || doc.nome || 'documento';
  const janela = window.open('', '_blank');
  if (janela) {
    janela.document.write(`
      <!doctype html><html lang="pt-BR"><head><title>${nlSafeText(nome)}</title><style>body{margin:0;background:#0f172a}iframe,img{width:100%;height:100vh;border:0;object-fit:contain;background:#fff}</style></head>
      <body>${String(conteudo).startsWith('data:image/') ? `<img src="${conteudo}" alt="${nlSafeText(nome)}">` : `<iframe src="${conteudo}" title="${nlSafeText(nome)}"></iframe>`}</body></html>
    `);
    janela.document.close();
  } else {
    const link = document.createElement('a');
    link.href = conteudo;
    link.download = nome;
    link.click();
  }
}

function salvarDocumentoLocalPaciente(cpf, arquivo, base64, extras = {}) {
  const chave = chaveDadosPerfil('neurolab_documentos_upload', cpf);
  const uploads = lerJson(chave, []);
  const localId = extras.local_id || `local-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
  uploads.unshift({
    local_id: localId,
    nome_arquivo: arquivo.name,
    nome: arquivo.name,
    tipo_arquivo: arquivo.type.includes('pdf') ? 'PDF' : 'Imagem',
    tipo: arquivo.type.includes('pdf') ? 'PDF' : 'Imagem',
    status: extras.status || 'não salvo no MySQL',
    data: new Date().toLocaleDateString('pt-BR'),
    conteudo_base64: base64,
    sincronizado_mysql: Boolean(extras.sincronizado_mysql),
    id_mysql: extras.id_mysql || null
  });
  salvarJson(chave, uploads);
}

function uploadDocumentoPaciente(input) {
  const arquivo = input?.files?.[0];
  if (!arquivo) return;
  if (!arquivo.type.includes('pdf') && !arquivo.type.startsWith('image/')) {
    mostrarToast('Envie apenas PDF ou imagem.', 'aviso');
    input.value = '';
    return;
  }

  const cpf = getPerfilAtivoCpf();
  const leitor = new FileReader();
  leitor.onload = async () => {
    const base64 = String(leitor.result || '');
    let salvouMysql = false;
    let idMysql = null;

    if (typeof getAuthToken === 'function' && getAuthToken()) {
      try {
        const salvo = await apiPortalUploadDocumento(cpf, {
          nome_arquivo: arquivo.name,
          tipo_arquivo: arquivo.type.includes('pdf') ? 'PDF' : 'Imagem',
          conteudo_base64: base64
        });
        salvouMysql = true;
        idMysql = salvo.id;
        portalApiCache = null;
        await carregarPortalApi();
      } catch (_) {
        salvouMysql = false;
      }
    }

    if (!salvouMysql) {
      salvarDocumentoLocalPaciente(cpf, arquivo, base64);
    }

    input.value = '';
    mostrarToast(salvouMysql ? 'Documento salvo no MySQL.' : 'Documento não salvo: MySQL/API indisponível.', 'sucesso');
    alternarPacienteSecao('documentos');
  };
  leitor.readAsDataURL(arquivo);
}

async function removerDocumentoPaciente(docRef) {
  const ref = decodeURIComponent(String(docRef || ''));
  const cpf = getPerfilAtivoCpf();
  if (!ref) return;
  if (!confirm('Apagar este documento da Área do Paciente?')) return;

  const docsLocais = listaDocumentosLocais(cpf);
  const novaLista = docsLocais.filter(doc => String(doc.local_id || doc.id || doc.nome_arquivo || doc.nome) !== ref);
  const removeuLocal = novaLista.length !== docsLocais.length;
  if (removeuLocal) salvarListaDocumentosLocais(cpf, novaLista);

  let removeuMysql = false;
  if (!removeuLocal && typeof getAuthToken === 'function' && getAuthToken() && /^\d+$/.test(ref)) {
    try {
      await apiPortalRemoverDocumento(cpf, ref);
      removeuMysql = true;
      portalApiCache = null;
      await carregarPortalApi();
    } catch (erro) {
      mostrarToast(erro.message || 'Erro ao apagar documento do MySQL.', 'erro');
      return;
    }
  }

  mostrarToast(removeuMysql ? 'Documento apagado do MySQL.' : 'Documento apagado.', 'sucesso');
  alternarPacienteSecao('documentos');
}

function lerPreConsultaCampos() {
  return {
    sintomas: document.getElementById('preSintomas')?.value?.trim() || '',
    medicamentos: document.getElementById('preMedicamentos')?.value?.trim() || '',
    observacoes: document.getElementById('preObservacoes')?.value?.trim() || '',
    atualizado_em: new Date().toISOString()
  };
}

function salvarRascunhoPreConsultaPaciente() {
  const cpf = getPerfilAtivoCpf();
  const dados = lerPreConsultaCampos();
  salvarJson(chaveDadosPerfil('neurolab_preconsulta', cpf), dados);
  const status = document.getElementById('preconsultaStatus');
  if (status) status.textContent = 'Rascunho salvo';
}

async function salvarPreConsultaPaciente() {
  const cpf = getPerfilAtivoCpf();
  const dados = lerPreConsultaCampos();
  salvarJson(chaveDadosPerfil('neurolab_preconsulta', cpf), dados);
  if (portalApiCache) portalApiCache.preconsulta = dados;

  let salvouMysql = false;
  if (typeof getAuthToken === 'function' && getAuthToken()) {
    try {
      const salvo = await apiPortalSalvarPreconsulta(cpf, dados);
      if (portalApiCache) portalApiCache.preconsulta = salvo;
      salvarJson(chaveDadosPerfil('neurolab_preconsulta', cpf), salvo);
      salvouMysql = true;
    } catch (_) {
      salvouMysql = false;
    }
  }

  const status = document.getElementById('preconsultaStatus');
  if (status) status.textContent = salvouMysql ? 'Salva no MySQL' : 'Não salva: MySQL offline';
  mostrarToast(salvouMysql ? 'Pré-consulta salva no MySQL.' : 'Pré-consulta não salva: MySQL/API indisponível.', 'sucesso');
}

async function removerPerfilFamilia(cpf) {
  const titular = getUsuarioLogado();
  if (!titular?.cpf || cpf === titular.cpf) return;
  if (!confirm('Desvincular este familiar da conta? A conta dele continua no sistema, mas deixa de aparecer na sua família.')) return;
  if (getAuthToken()) {
    try {
      await apiPortalDesvincularFamiliar(cpf);
    } catch (erro) {
      mostrarToast(erro.message || 'Erro ao desvincular.', 'error');
      return;
    }
  } else {
    desvincularFamiliar(cpf);
  }
  portalApiCache = null;
  await initPortalPaciente();
  alternarPacienteSecao('familia');
  mostrarToast('Familiar desvinculado.', 'info');
}


/* === Área do Paciente 2.0 — visual refinado + persistência de formulários === */
function nlMascaraCpf(cpf) {
  const clean = String(cpf || '').replace(/\D/g, '');
  return clean.length === 11 ? `${clean.slice(0, 3)}.***.***-${clean.slice(-2)}` : 'CPF não informado';
}

function nlInputValue(value) {
  return nlSafeText(value || '');
}

function nlPacienteStorageKey(tipo, cpf = getPerfilAtivoCpf()) {
  return chaveDadosPerfil(`neurolab_area_${tipo}`, cpf);
}

function nlFormularioLocal(tipo, fallback = {}) {
  return { ...(fallback || {}), ...lerJson(nlPacienteStorageKey(tipo), {}) };
}

async function nlCarregarFormularioPaciente(tipo, fallback = {}) {
  const local = nlFormularioLocal(tipo, fallback);
  if (typeof getAuthToken !== 'function' || !getAuthToken() || typeof apiPortalFormulario !== 'function') {
    return local;
  }
  try {
    const api = await apiPortalFormulario(getPerfilAtivoCpf(), tipo);
    const dados = { ...local, ...(api?.dados || {}) };
    salvarJson(nlPacienteStorageKey(tipo), dados);
    return dados;
  } catch (_) {
    return local;
  }
}

async function nlSalvarFormularioPaciente(tipo, dados, statusId) {
  const cpf = getPerfilAtivoCpf();
  const dadosComMeta = { ...(dados || {}), atualizado_em: new Date().toISOString() };
  salvarJson(nlPacienteStorageKey(tipo, cpf), dadosComMeta);
  let salvouMysql = false;
  if (typeof getAuthToken === 'function' && getAuthToken() && typeof apiPortalSalvarFormulario === 'function') {
    try {
      const salvo = await apiPortalSalvarFormulario(cpf, tipo, dadosComMeta);
      salvarJson(nlPacienteStorageKey(tipo, cpf), salvo?.dados || dadosComMeta);
      salvouMysql = true;
    } catch (_) {
      salvouMysql = false;
    }
  }
  const status = statusId ? document.getElementById(statusId) : null;
  if (status) status.textContent = salvouMysql ? 'Salvo no MySQL' : 'Não salvo: MySQL offline';
  return salvouMysql;
}

function nlDadosPacientePadrao(perfil = {}) {
  return {
    email: perfil.email || getPerfilAtivoUsuario()?.email || getUsuarioLogado()?.email || '',
    telefone: perfil.telefone || getPerfilAtivoUsuario()?.telefone || getUsuarioLogado()?.telefone || getUsuarioLogado()?.celular || '',
    emergencia_nome: '',
    emergencia_telefone: '',
    convenio: '',
    carteirinha: '',
    endereco: '',
    cep: '',
    cidade: '',
    observacao_recepcao: '',
  };
}

function nlContarCamposPreenchidos(obj, chaves) {
  return chaves.reduce((total, chave) => total + (String(obj?.[chave] || '').trim() ? 1 : 0), 0);
}

function nlCalcularCompletudeArea(cpf, perfil, docs, agendamentos) {
  const dados = nlFormularioLocal('dados_cadastrais', nlDadosPacientePadrao(perfil));
  const pre = lerJson(chaveDadosPerfil('neurolab_preconsulta', cpf), {});
  let pontos = 0;
  if (cpf) pontos += 15;
  if (perfil?.nome || getPerfilAtivoUsuario()?.nome || getUsuarioLogado()?.nome) pontos += 15;
  if (dados.telefone || perfil?.telefone) pontos += 10;
  if (dados.email || perfil?.email) pontos += 10;
  if (dados.emergencia_nome && dados.emergencia_telefone) pontos += 15;
  if ((docs || []).length) pontos += 10;
  if (nlContarCamposPreenchidos(pre, ['sintomas', 'medicamentos', 'observacoes', 'alergias', 'doencas_previas']) >= 2) pontos += 15;
  if ((agendamentos || []).length) pontos += 10;
  return Math.min(100, pontos);
}

function nlStatusSincronizacao() {
  return (typeof getAuthToken === 'function' && getAuthToken()) ? 'MySQL habilitado' : 'Login necessário';
}

function renderPortalPacienteNovo() {
  if (paginaArquivo() !== 'area-paciente.html') return;
  const grid = document.querySelector('.dashboard-grid, .patient-app-shell');
  if (!grid) return;
  grid.dataset.patientEnhanced = 'true';

  const api = portalApiCache;
  const usuario = getUsuarioLogado();

  if (!usuario?.cpf && !api?.perfil_ativo) {
    grid.className = 'patient-app-shell patient-app-shell-empty patient-area-v2';
    grid.innerHTML = `
      <section class="patient-login-empty patient-login-empty-v2">
        <div class="patient-login-icon">🔐</div>
        <span class="quick-access-label">Área segura</span>
        <h2>Entre com CPF para acessar a Área do Paciente.</h2>
        <p>A tela não exibe dados falsos. Após o login, seus agendamentos, documentos, pré-consulta, família e preferências são carregados por CPF.</p>
        <div class="patient-empty-actions">
          <a class="btn btn-primary" href="index.html?modal=login">Entrar com CPF</a>
          <a class="btn btn-light" href="index.html?modal=cadastro">Criar conta</a>
        </div>
      </section>
    `;
    return;
  }

  const perfisFamilia = api?.perfis_familia || listarPerfisFamilia();
  const cpfPerfil = getPerfilAtivoCpf();
  const perfilDetalhe = perfisFamilia.find(p => p.cpf === cpfPerfil) || perfisFamilia[0] || {};
  const perfilApi = api?.perfil_ativo || {};
  const perfilUsuario = getPerfilAtivoUsuario() || {};
  const nomeCompleto = perfilApi.nome || perfilUsuario.nome || perfilDetalhe.nome || usuario.nome || 'Paciente';
  const nome = nomeCompleto.split(' ')[0];
  const agendamentos = api?.agendamentos || agendamentosDoPerfil(cpfPerfil);
  const proximo = agendamentos[0] || null;
  const docsLocais = listaDocumentosLocais(cpfPerfil);
  const docsPaciente = [...(api?.documentos || []), ...docsLocais.filter(doc => !doc.sincronizado_mysql)];
  const fotoPerfil = perfilApi.foto_perfil || '';
  const progresso = nlCalcularCompletudeArea(cpfPerfil, perfilApi, docsPaciente, agendamentos);
  const perfilContexto = perfilDetalhe?.cpf === usuario?.cpf ? 'Perfil titular' : `${perfilDetalhe?.papel || 'Familiar'} vinculado`;

  grid.className = 'patient-app-shell patient-app-shell-refined patient-area-v2';
  grid.innerHTML = `
    <aside class="patient-sidebar patient-sidebar-v2">
      <div class="patient-profile-card text-center patient-profile-v2">
        <div class="patient-avatar patient-avatar-photo mx-auto" style="${fotoPerfil ? `background-image:url('${fotoPerfil}')` : ''}">${fotoPerfil ? '' : nlDoctorInitials(nome)}</div>
        <label class="btn btn-outline-secondary btn-sm mt-2 patient-photo-button">
          Trocar foto
          <input type="file" accept="image/*" class="d-none" onchange="salvarFotoPerfilPaciente(this)">
        </label>
        <strong class="d-block mt-2">${nlSafeText(nomeCompleto)}</strong>
        <span class="patient-context-label">${nlSafeText(perfilContexto)}</span>
        <small>CPF ${nlMascaraCpf(cpfPerfil)}</small>
        <div class="patient-profile-progress">
          <span>Perfil ${progresso}% completo</span>
          <div><i style="width:${progresso}%"></i></div>
        </div>
      </div>

      <div class="patient-family-switch patient-side-block">
        <label for="familiaPerfilSelect" class="form-label">Conta família</label>
        <select id="familiaPerfilSelect" class="form-select" onchange="trocarPerfilFamilia(this.value)">
          ${perfisFamilia.map(perfil => `<option value="${nlSafeText(perfil.cpf)}" ${perfil.cpf === cpfPerfil ? 'selected' : ''}>${nlSafeText(perfil.papel)} — ${nlSafeText(perfil.nome)}</option>`).join('')}
        </select>
        <small>O CPF ativo define quais dados aparecem no painel.</small>
      </div>

      <div class="patient-side-block patient-security-box">
        <span>🔒 Segurança</span>
        <strong>${nlStatusSincronizacao()}</strong>
        <small>Documentos e formulários são separados por CPF e salvos no MySQL.</small>
      </div>

      <div class="patient-sidebar-actions">
        <button class="btn btn-primary" onclick="abrirAgendamento()">Novo agendamento</button>
        <button class="btn btn-light" onclick="alternarPacienteSecao('dados')">Editar dados</button>
      </div>
    </aside>

    <section class="patient-main-panel patient-main-v2">
      <div class="patient-welcome-card patient-welcome-v2">
        <div>
          <span class="quick-access-label">Painel do paciente</span>
          <h2>Olá, ${nlSafeText(nome)}.</h2>
          <p>Gerencie seus dados, documentos, pré-consulta e família sem misturar informações entre CPFs.</p>
        </div>
        <div class="patient-status-stack">
          <span>LGPD + CPF ativo</span>
          <strong>${proximo ? 'Consulta encontrada' : 'Pronto para agendar'}</strong>
        </div>
      </div>

      <div class="patient-kpis patient-kpis-v2">
        <div><strong>${agendamentos.length || 0}</strong><span>agendamentos</span></div>
        <div><strong>${docsPaciente.length}</strong><span>documentos</span></div>
        <div><strong>${perfisFamilia.length}</strong><span>perfis família</span></div>
        <div><strong>${progresso}%</strong><span>perfil completo</span></div>
      </div>

      <div class="patient-card-lg patient-next-card-v2">
        <div>
          <span class="quick-access-label">Próxima etapa</span>
          <h3>${proximo?.medico_nome || proximo?.medico || 'Nenhum agendamento ativo'}</h3>
          <p>${proximo ? `${proximo.tipo_consulta || proximo.tipoNome || 'Consulta'} · ${proximo.data_consulta || proximo.dia || ''} ${proximo.hora_consulta || proximo.horario || ''} · ${nlSafeText(perfilDetalhe?.nome || nomeCompleto)}` : 'Complete seus dados e envie documentos para deixar o atendimento mais rápido.'}</p>
        </div>
        <div class="patient-action-row">
          <button class="btn btn-light" onclick="alternarPacienteSecao('preconsulta')">Pré-consulta</button>
          <button class="btn btn-primary" onclick="abrirAgendamento()">${proximo ? 'Reagendar' : 'Agendar'}</button>
        </div>
      </div>

      <div class="patient-tabs patient-tabs-v2" role="tablist" aria-label="Área do Paciente">
        <button class="active" type="button" onclick="alternarPacienteSecao('resumo', this)">Resumo</button>
        <button type="button" onclick="alternarPacienteSecao('dados', this)">Meus dados</button>
        <button type="button" onclick="alternarPacienteSecao('documentos', this)">Documentos</button>
        <button type="button" onclick="alternarPacienteSecao('preconsulta', this)">Pré-consulta</button>
        <button type="button" onclick="alternarPacienteSecao('exames', this)">Exames</button>
        <button type="button" onclick="alternarPacienteSecao('familia', this)">Conta família</button>
        <button type="button" onclick="alternarPacienteSecao('preferencias', this)">Lembretes</button>
      </div>
      <div id="patientDynamicPanel" class="patient-dynamic-panel patient-panel-v2"></div>
    </section>
  `;
  alternarPacienteSecao('resumo');
}

function nlPacienteFormInput(id, label, value, placeholder = '', type = 'text') {
  return `<label class="patient-field"><span>${label}</span><input id="${id}" type="${type}" value="${nlInputValue(value)}" placeholder="${nlInputValue(placeholder)}"></label>`;
}

function nlPacienteFormTextarea(id, label, value, placeholder = '') {
  return `<label class="patient-field patient-field-full"><span>${label}</span><textarea id="${id}" placeholder="${nlInputValue(placeholder)}">${nlSafeText(value || '')}</textarea></label>`;
}

async function alternarPacienteSecao(secao = 'resumo', botao) {
  if (paginaArquivo() !== 'area-paciente.html') return;
  const painel = document.getElementById('patientDynamicPanel');
  if (!painel) return;

  document.querySelectorAll('.patient-tabs button').forEach(item => item.classList.remove('active'));
  const ativo = botao || [...document.querySelectorAll('.patient-tabs button')].find(item => item.getAttribute('onclick')?.includes(`'${secao}'`));
  ativo?.classList.add('active');

  const cpfPerfil = getPerfilAtivoCpf();
  const perfil = portalApiCache?.perfil_ativo || getPerfilAtivoUsuario() || getUsuarioLogado() || {};
  const usaApi = typeof getAuthToken === 'function' && getAuthToken();
  const agendamentos = portalApiCache?.agendamentos || agendamentosDoPerfil(cpfPerfil);
  let docs = portalApiCache?.documentos || listaDocumentosLocais(cpfPerfil);
  const prefs = portalApiCache?.preferencias || lerJson(chaveDadosPerfil('neurolab_paciente_preferencias', cpfPerfil), { whatsapp: true, email: true, sms: false });

  if (secao === 'dados') {
    const dados = await nlCarregarFormularioPaciente('dados_cadastrais', nlDadosPacientePadrao(perfil));
    painel.innerHTML = `
      <div class="patient-section-head">
        <div><strong>Meus dados</strong><p>Atualize contatos e informações úteis para a recepção. Tudo fica vinculado ao CPF ativo.</p></div>
        <span class="patient-save-pill" id="dadosStatus">${dados.atualizado_em ? 'Dados carregados' : 'Não enviado'}</span>
      </div>
      <div class="patient-form-grid">
        ${nlPacienteFormInput('dadosEmail', 'E-mail de contato', dados.email, 'exemplo@email.com', 'email')}
        ${nlPacienteFormInput('dadosTelefone', 'Celular / WhatsApp', dados.telefone, '(11) 99999-9999')}
        ${nlPacienteFormInput('dadosEmergenciaNome', 'Contato de emergência', dados.emergencia_nome, 'Nome do responsável/contato')}
        ${nlPacienteFormInput('dadosEmergenciaTelefone', 'Telefone de emergência', dados.emergencia_telefone, '(11) 99999-9999')}
        ${nlPacienteFormInput('dadosConvenio', 'Convênio', dados.convenio, 'Particular, SUS ou nome do convênio')}
        ${nlPacienteFormInput('dadosCarteirinha', 'Número da carteirinha', dados.carteirinha, 'Opcional')}
        ${nlPacienteFormInput('dadosCep', 'CEP', dados.cep, '00000-000')}
        ${nlPacienteFormInput('dadosCidade', 'Cidade', dados.cidade, 'Santo André - SP')}
        ${nlPacienteFormTextarea('dadosEndereco', 'Endereço completo', dados.endereco, 'Rua, número, bairro e complemento')}
        ${nlPacienteFormTextarea('dadosObservacaoRecepcao', 'Observação para recepção', dados.observacao_recepcao, 'Ex.: preciso de acessibilidade, prefiro confirmação por WhatsApp...')}
      </div>
      <div class="patient-form-actions">
        <button class="btn btn-primary" onclick="salvarDadosCadastraisPaciente()">Salvar dados</button>
        <small>Ao salvar, os dados são enviados para o MySQL pela API.</small>
      </div>
    `;
    return;
  }

  if (secao === 'documentos') {
    const docsLocais = listaDocumentosLocais(cpfPerfil);
    if (usaApi) {
      try {
        const docsApi = await apiPortalDocumentos(cpfPerfil);
        docs = [...(docsApi || []), ...docsLocais.filter(local => !local.sincronizado_mysql)];
      } catch (_) {
        docs = docsLocais;
      }
    } else {
      docs = docsLocais;
    }
    painel.innerHTML = `
      <div class="patient-section-head">
        <div><strong>Documentos</strong><p>Envie RG, carteirinha, encaminhamento, laudos ou exames anteriores.</p></div>
        <span class="patient-save-pill">${(docs || []).length} arquivo(s)</span>
      </div>
      <div class="patient-doc-upload patient-doc-upload-v2">
        <div>
          <strong>Adicionar novo arquivo</strong>
          <p class="mb-0">PDF ou imagem. O arquivo fica separado por CPF e pode ser visualizado ou apagado depois.</p>
        </div>
        <label class="btn btn-primary mb-0">
          Selecionar arquivo
          <input type="file" id="patientDocInput" accept=".pdf,image/*" onchange="uploadDocumentoPaciente(this)" hidden>
        </label>
      </div>
      <div class="patient-doc-list patient-doc-list-v2">
        ${(docs || []).map(doc => {
          const ref = documentoPacienteRef(doc);
          const nomeDoc = doc.nome_arquivo || doc.nome || 'Documento';
          const tipoDoc = doc.tipo_arquivo || doc.tipo || 'arquivo';
          const origem = doc.id || doc.id_mysql ? 'MySQL' : 'Não sincronizado';
          const temConteudo = doc.conteudo_base64 || doc.tem_conteudo;
          return `
            <article>
              <div class="patient-doc-icon">${String(tipoDoc).toLowerCase().includes('pdf') ? 'PDF' : 'IMG'}</div>
              <div class="patient-doc-info">
                <strong>${nlSafeText(nomeDoc)}</strong>
                <span>${nlSafeText(tipoDoc)} · ${nlSafeText(doc.status || 'enviado')} · ${origem}${doc.criado_em ? ` · ${String(doc.criado_em).slice(0, 10)}` : doc.data ? ` · ${doc.data}` : ''}</span>
                <small>${temConteudo ? 'Arquivo disponível para visualização.' : 'Metadado salvo; reenvie se precisar visualizar o conteúdo.'}</small>
              </div>
              <div class="patient-doc-actions">
                <button class="btn btn-light btn-sm" onclick="abrirDocumentoPaciente('${ref}')">Visualizar</button>
                <button class="btn btn-light btn-sm text-danger" onclick="removerDocumentoPaciente('${ref}')">Apagar</button>
              </div>
            </article>
          `;
        }).join('') || '<div class="patient-empty-state"><strong>Nenhum documento enviado</strong><p>Envie um arquivo real para liberar visualização, exclusão e vínculo com o CPF ativo.</p></div>'}
      </div>
    `;
    return;
  }

  if (secao === 'preconsulta') {
    const localPreconsulta = lerJson(chaveDadosPerfil('neurolab_preconsulta', cpfPerfil), {});
    let anamnese = { sintomas: '', intensidade: '', inicio_sintomas: '', medicamentos: '', alergias: '', doencas_previas: '', exames_recentes: '', observacoes: '', ...localPreconsulta };
    if (usaApi) {
      try {
        const apiCore = await apiPortalPreconsulta(cpfPerfil);
        const apiCompleta = await nlCarregarFormularioPaciente('preconsulta_completa', {});
        anamnese = { ...anamnese, ...(apiCore || {}), ...(apiCompleta || {}) };
      } catch (_) { /* mantem vazio quando MySQL/API nao responder */ }
    }
    painel.innerHTML = `
      <div class="patient-section-head">
        <div><strong>Pré-consulta / Anamnese digital</strong><p>Preencha antes do atendimento para reduzir tempo na recepção e melhorar a triagem.</p></div>
        <span class="patient-save-pill" id="preconsultaStatus">${preconsultaVazia(anamnese) ? 'Ainda não preenchida' : 'Dados carregados'}</span>
      </div>
      <div class="patient-form-grid patient-preconsulta-v2">
        ${nlPacienteFormTextarea('preSintomas', 'Sintomas principais', anamnese.sintomas, 'Ex.: dor de cabeça frequente, tontura, formigamento...')}
        <label class="patient-field"><span>Intensidade do sintoma</span><select id="preIntensidade"><option value="">Selecione</option>${['Leve', 'Moderado', 'Forte', 'Muito forte'].map(op => `<option ${anamnese.intensidade === op ? 'selected' : ''}>${op}</option>`).join('')}</select></label>
        ${nlPacienteFormInput('preInicioSintomas', 'Quando começou?', anamnese.inicio_sintomas, 'Ex.: há 2 semanas')}
        ${nlPacienteFormTextarea('preMedicamentos', 'Medicamentos em uso', anamnese.medicamentos, 'Nome, dosagem e frequência')}
        ${nlPacienteFormTextarea('preAlergias', 'Alergias', anamnese.alergias, 'Medicamentos, alimentos ou outras alergias')}
        ${nlPacienteFormTextarea('preDoencasPrevias', 'Doenças prévias / histórico', anamnese.doencas_previas, 'Hipertensão, diabetes, epilepsia, cirurgias...')}
        ${nlPacienteFormTextarea('preExamesRecentes', 'Exames recentes', anamnese.exames_recentes, 'EEG, ressonância, tomografia, exames laboratoriais...')}
        ${nlPacienteFormTextarea('preObservacoes', 'Outras observações', anamnese.observacoes, 'Informações importantes para o médico')}
      </div>
      <div class="patient-form-actions">
        <button class="btn btn-light" onclick="salvarRascunhoPreConsultaPaciente()">Salvar rascunho</button>
        <button class="btn btn-primary" onclick="salvarPreConsultaPaciente()">Enviar pré-consulta</button>
        <small>A pré-consulta é enviada para o MySQL pela API ao salvar.</small>
      </div>
    `;
    document.querySelectorAll('#patientDynamicPanel textarea, #patientDynamicPanel input, #patientDynamicPanel select').forEach(campo => {
      campo.addEventListener('input', salvarRascunhoPreConsultaPaciente);
      campo.addEventListener('change', salvarRascunhoPreConsultaPaciente);
    });
    return;
  }

  if (secao === 'exames') {
    let exames = portalApiCache?.exames;
    if (usaApi) {
      try { exames = await apiPortalExames(cpfPerfil); } catch (_) { /* noop */ }
    }
    if (!exames?.length) exames = lerJson(chaveDadosPerfil('neurolab_exames_paciente', cpfPerfil), []);
    painel.innerHTML = `
      <div class="patient-section-head"><div><strong>Exames</strong><p>Solicitações, preparo e laudos aparecem aqui quando cadastrados para o CPF ativo.</p></div><span class="patient-save-pill">${exames.length || 0} registro(s)</span></div>
      ${exames.length ? `<div class="patient-exam-list patient-exam-list-v2">${exames.map(ex => `
        <article>
          <div><strong>${nlSafeText(ex.nome)}</strong><span>${nlSafeText(ex.status)} · ${nlSafeText(ex.data_referencia || ex.data || '')}</span><small>Preparo: ${nlSafeText(ex.preparo || 'Orientação ainda não cadastrada.')}</small></div>
          <button class="btn btn-light" onclick="gerarDocumentoPaciente('${String(ex.nome).replace(/'/g, "\\'")}')">Ver laudo</button>
        </article>`).join('')}</div>` : `<div class="patient-empty-state"><strong>Nenhum exame disponível</strong><p>Quando um exame for solicitado ou um laudo for liberado, ele aparecerá nesta aba.</p><button class="btn btn-primary" onclick="abrirAgendamento()">Agendar exame</button></div>`}
    `;
    return;
  }

  if (secao === 'familia') {
    let perfis = portalApiCache?.perfis_familia || listarPerfisFamilia();
    if (usaApi) {
      try { const fam = await apiPortalFamilia(); perfis = fam.perfis || perfis; } catch (_) { /* noop */ }
    }
    const titular = getUsuarioLogado();
    painel.innerHTML = `
      <div class="patient-section-head"><div><strong>Conta família</strong><p>Perfis vinculados ao titular. Cada CPF possui documentos, pré-consulta e agendamentos separados.</p></div><span class="patient-save-pill">${perfis.length} perfil(is)</span></div>
      <div class="patient-family-list patient-family-list-v2">
        ${perfis.length ? perfis.map(perfilItem => `
          <article>
            <div><strong>${nlSafeText(perfilItem.papel)} — ${nlSafeText(perfilItem.nome)}</strong><span>${perfilItem.cpf === cpfPerfil ? 'Perfil ativo agora' : 'CPF ' + nlMascaraCpf(perfilItem.cpf)}</span></div>
            <div class="patient-family-actions">
              ${perfilItem.cpf !== cpfPerfil ? `<button class="btn btn-light btn-sm" onclick="trocarPerfilFamilia('${perfilItem.cpf}')">Usar perfil</button>` : '<span class="badge bg-success">Ativo</span>'}
              ${perfilItem.cpf !== titular?.cpf ? `<button class="btn btn-light btn-sm" onclick="removerPerfilFamilia('${perfilItem.cpf}')">Desvincular</button>` : '<span class="badge bg-light text-dark">Titular</span>'}
            </div>
          </article>`).join('') : '<div class="patient-empty-state"><strong>Nenhum familiar vinculado</strong><p>Cadastre um filho, neto ou outro familiar com dados reais.</p></div>'}
      </div>
      <div class="patient-family-register mt-4">
        <button class="btn btn-primary" onclick="abrirCadastroFamiliar()">Cadastrar familiar</button>
        <p class="text-muted small mt-2 mb-0">Usa o cadastro completo e salva o vínculo no MySQL pela API.</p>
      </div>
    `;
    return;
  }

  if (secao === 'preferencias') {
    const prefsExtra = await nlCarregarFormularioPaciente('preferencias_visuais', { unidade_preferida: '', horario_preferido: '', observacoes_lembretes: '' });
    painel.innerHTML = `
      <div class="patient-section-head"><div><strong>Lembretes e preferências</strong><p>Defina como a clínica deve falar com você e quais horários prefere.</p></div><span class="patient-save-pill" id="prefsStatus">Preferências carregadas</span></div>
      <div class="patient-preference-grid patient-preference-grid-v2">
        ${[
          ['whatsapp', 'WhatsApp', 'Confirmações e lembretes rápidos.'],
          ['email', 'E-mail', 'Documentos, recibos e orientações.'],
          ['sms', 'SMS', 'Alertas curtos quando necessário.']
        ].map(([chave, titulo, texto]) => `
          <label><span><strong>${titulo}</strong><small>${texto}</small></span><input type="checkbox" ${prefs[chave] ? 'checked' : ''} onchange="atualizarPreferenciaPaciente('${chave}', this.checked)"></label>
        `).join('')}
      </div>
      <div class="patient-form-grid mt-3">
        ${nlPacienteFormInput('prefUnidade', 'Unidade preferida', prefsExtra.unidade_preferida, 'Ex.: Santo André - Centro')}
        ${nlPacienteFormInput('prefHorario', 'Horário preferido', prefsExtra.horario_preferido, 'Ex.: manhã, tarde ou sábado')}
        ${nlPacienteFormTextarea('prefObs', 'Observações de lembrete', prefsExtra.observacoes_lembretes, 'Ex.: confirmar sempre pelo WhatsApp da minha mãe')}
      </div>
      <div class="patient-form-actions"><button class="btn btn-primary" onclick="salvarPreferenciasExtrasPaciente()">Salvar preferências</button></div>
    `;
    return;
  }

  const perfilFamilia = listarPerfisFamilia().find(p => p.cpf === cpfPerfil);
  const dados = nlFormularioLocal('dados_cadastrais', nlDadosPacientePadrao(perfil));
  const pre = lerJson(chaveDadosPerfil('neurolab_preconsulta', cpfPerfil), {});
  const docsResumo = docs || [];
  painel.innerHTML = `
    ${perfilFamilia ? `<p class="patient-perfil-banner">Visualizando dados de <strong>${nlSafeText(perfilFamilia.nome)}</strong> (${nlSafeText(perfilFamilia.papel)}). Nada de outro CPF aparece aqui.</p>` : ''}
    <div class="patient-summary-grid patient-summary-grid-v2">
      <article><span>Dados cadastrais</span><strong>${nlContarCamposPreenchidos(dados, ['telefone','email','emergencia_nome','emergencia_telefone','endereco'])}/5 campos</strong><small>${dados.emergencia_nome ? 'Contato de emergência informado.' : 'Falta contato de emergência.'}</small></article>
      <article><span>Documentos</span><strong>${docsResumo.length ? `${docsResumo.length} arquivo(s)` : 'Nenhum enviado'}</strong><small>Envie documentos para agilizar a recepção.</small></article>
      <article><span>Pré-consulta</span><strong>${preconsultaVazia(pre) ? 'Pendente' : 'Preenchida'}</strong><small>${pre.atualizado_em ? `Atualizada em ${new Date(pre.atualizado_em).toLocaleDateString('pt-BR')}` : 'Preencha antes do atendimento.'}</small></article>
      <article><span>Sincronização</span><strong>${nlStatusSincronizacao()}</strong><small>${usaApi ? 'Dados conectados à API.' : 'Abra a API Flask para gravar no MySQL.'}</small></article>
    </div>
    <div class="patient-timeline-v2">
      <strong>Checklist antes da consulta</strong>
      <div><span class="${dados.telefone && dados.email ? 'ok' : ''}">1</span> Conferir contato</div>
      <div><span class="${docsResumo.length ? 'ok' : ''}">2</span> Enviar documentos</div>
      <div><span class="${preconsultaVazia(pre) ? '' : 'ok'}">3</span> Preencher pré-consulta</div>
      <div><span class="${agendamentos.length ? 'ok' : ''}">4</span> Agendar atendimento</div>
    </div>
  `;
}

function lerDadosCadastraisCampos() {
  return {
    email: document.getElementById('dadosEmail')?.value?.trim() || '',
    telefone: document.getElementById('dadosTelefone')?.value?.trim() || '',
    emergencia_nome: document.getElementById('dadosEmergenciaNome')?.value?.trim() || '',
    emergencia_telefone: document.getElementById('dadosEmergenciaTelefone')?.value?.trim() || '',
    convenio: document.getElementById('dadosConvenio')?.value?.trim() || '',
    carteirinha: document.getElementById('dadosCarteirinha')?.value?.trim() || '',
    cep: document.getElementById('dadosCep')?.value?.trim() || '',
    cidade: document.getElementById('dadosCidade')?.value?.trim() || '',
    endereco: document.getElementById('dadosEndereco')?.value?.trim() || '',
    observacao_recepcao: document.getElementById('dadosObservacaoRecepcao')?.value?.trim() || ''
  };
}

async function salvarDadosCadastraisPaciente() {
  const dados = lerDadosCadastraisCampos();
  if (!dados.telefone && !dados.email) {
    mostrarToast('Informe pelo menos telefone ou e-mail.', 'aviso');
    return;
  }
  const salvouMysql = await nlSalvarFormularioPaciente('dados_cadastrais', dados, 'dadosStatus');
  mostrarToast(salvouMysql ? 'Dados salvos no MySQL.' : 'Dados não salvos: MySQL/API indisponível.', 'sucesso');
}

function preconsultaVazia(dados) {
  return nlContarCamposPreenchidos(dados || {}, ['sintomas', 'medicamentos', 'observacoes', 'alergias', 'doencas_previas', 'exames_recentes']) === 0;
}

function lerPreConsultaCampos() {
  return {
    sintomas: document.getElementById('preSintomas')?.value?.trim() || '',
    intensidade: document.getElementById('preIntensidade')?.value?.trim() || '',
    inicio_sintomas: document.getElementById('preInicioSintomas')?.value?.trim() || '',
    medicamentos: document.getElementById('preMedicamentos')?.value?.trim() || '',
    alergias: document.getElementById('preAlergias')?.value?.trim() || '',
    doencas_previas: document.getElementById('preDoencasPrevias')?.value?.trim() || '',
    exames_recentes: document.getElementById('preExamesRecentes')?.value?.trim() || '',
    observacoes: document.getElementById('preObservacoes')?.value?.trim() || '',
    atualizado_em: new Date().toISOString()
  };
}

function salvarRascunhoPreConsultaPaciente() {
  const cpf = getPerfilAtivoCpf();
  const dados = lerPreConsultaCampos();
  salvarJson(chaveDadosPerfil('neurolab_preconsulta', cpf), dados);
  salvarJson(nlPacienteStorageKey('preconsulta_completa', cpf), dados);
  const status = document.getElementById('preconsultaStatus');
  if (status) status.textContent = 'Rascunho salvo';
}

async function salvarPreConsultaPaciente() {
  const cpf = getPerfilAtivoCpf();
  const dados = lerPreConsultaCampos();
  salvarJson(chaveDadosPerfil('neurolab_preconsulta', cpf), dados);
  if (portalApiCache) portalApiCache.preconsulta = dados;

  let salvouMysql = false;
  if (typeof getAuthToken === 'function' && getAuthToken()) {
    try {
      await apiPortalSalvarPreconsulta(cpf, {
        sintomas: dados.sintomas,
        medicamentos: dados.medicamentos,
        observacoes: [
          dados.observacoes,
          dados.alergias ? `Alergias: ${dados.alergias}` : '',
          dados.doencas_previas ? `Histórico: ${dados.doencas_previas}` : '',
          dados.exames_recentes ? `Exames recentes: ${dados.exames_recentes}` : '',
          dados.intensidade ? `Intensidade: ${dados.intensidade}` : '',
          dados.inicio_sintomas ? `Início: ${dados.inicio_sintomas}` : ''
        ].filter(Boolean).join('\n')
      });
      await nlSalvarFormularioPaciente('preconsulta_completa', dados, 'preconsultaStatus');
      salvouMysql = true;
    } catch (_) {
      salvouMysql = false;
    }
  }
  if (!salvouMysql) await nlSalvarFormularioPaciente('preconsulta_completa', dados, 'preconsultaStatus');
  const status = document.getElementById('preconsultaStatus');
  if (status) status.textContent = salvouMysql ? 'Salva no MySQL' : 'Não salva: MySQL offline';
  mostrarToast(salvouMysql ? 'Pré-consulta completa salva no MySQL.' : 'Pré-consulta não salva: MySQL/API indisponível.', 'sucesso');
}

async function salvarPreferenciasExtrasPaciente() {
  const dados = {
    unidade_preferida: document.getElementById('prefUnidade')?.value?.trim() || '',
    horario_preferido: document.getElementById('prefHorario')?.value?.trim() || '',
    observacoes_lembretes: document.getElementById('prefObs')?.value?.trim() || ''
  };
  const salvouMysql = await nlSalvarFormularioPaciente('preferencias_visuais', dados, 'prefsStatus');
  mostrarToast(salvouMysql ? 'Preferências salvas no MySQL.' : 'Preferências não salvas: MySQL/API indisponível.', 'sucesso');
}

async function registrarCheckinPaciente() {
  const dados = { feito_em: new Date().toISOString(), status: 'QR Code liberado', cpf: getPerfilAtivoCpf() };
  salvarJson('neurolab_checkin_atual', dados);
  await nlSalvarFormularioPaciente('checkin', dados);
  abrirModalPaciente('checkin');
  mostrarToast('Check-in salvo para o CPF ativo.', 'sucesso');
}

/* === Área do Paciente 3.0 — regras de negócio + design premium === */
function nlSomenteDigitos(valor) {
  return String(valor || '').replace(/\D/g, '');
}

function nlTelefoneValido(valor) {
  const digitos = nlSomenteDigitos(valor);
  return !digitos || digitos.length === 10 || digitos.length === 11;
}

function nlEmailValido(valor) {
  const email = String(valor || '').trim();
  return !email || /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email);
}

function nlDataNascimentoPerfil() {
  const perfil = portalApiCache?.perfil_ativo || getPerfilAtivoUsuario?.() || getUsuarioLogado?.() || {};
  return perfil.data_nascimento || perfil.nascimento || perfil.dataNascimento || '';
}

function nlIdadePorData(data) {
  if (!data) return null;
  const nasc = new Date(String(data).slice(0, 10) + 'T00:00:00');
  if (Number.isNaN(nasc.getTime())) return null;
  const hoje = new Date();
  let idade = hoje.getFullYear() - nasc.getFullYear();
  const mes = hoje.getMonth() - nasc.getMonth();
  if (mes < 0 || (mes === 0 && hoje.getDate() < nasc.getDate())) idade -= 1;
  return idade;
}

function nlPacienteMenorAtual() {
  const idade = nlIdadePorData(nlDataNascimentoPerfil());
  return idade !== null && idade < 18;
}

function nlPacienteDocCategoriaLabel(categoria) {
  const mapa = {
    documento_identidade: 'Documento de identidade',
    convenio: 'Carteirinha do convênio',
    encaminhamento: 'Encaminhamento médico',
    laudo: 'Laudo / exame anterior',
    consentimento: 'Termo / autorização',
    outros: 'Outros'
  };
  return mapa[categoria] || 'Documento';
}

function nlPendenciasPaciente(dados, docs, pre, agendamentos) {
  const pendencias = [];
  if (!dados.telefone && !dados.email) pendencias.push('Informe telefone ou e-mail de contato.');
  if (nlPacienteMenorAtual() && (!dados.emergencia_nome || !dados.emergencia_telefone)) pendencias.push('Menor de idade: informe contato de emergência/responsável.');
  if (!docs?.length) pendencias.push('Envie pelo menos um documento para agilizar a recepção.');
  if (preconsultaVazia(pre)) pendencias.push('Preencha a pré-consulta antes do atendimento.');
  if (!agendamentos?.length) pendencias.push('Nenhum agendamento ativo para o CPF selecionado.');
  return pendencias;
}

function nlCalcularCompletudeArea(cpf, perfil, docs, agendamentos) {
  const dados = nlFormularioLocal('dados_cadastrais', nlDadosPacientePadrao(perfil));
  const pre = lerJson(chaveDadosPerfil('neurolab_preconsulta', cpf), {});
  let pontos = 0;
  if (cpf) pontos += 12;
  if (perfil?.nome || getPerfilAtivoUsuario()?.nome || getUsuarioLogado()?.nome) pontos += 12;
  if (dados.telefone || perfil?.telefone) pontos += 12;
  if (dados.email || perfil?.email) pontos += 10;
  if (dados.emergencia_nome && dados.emergencia_telefone) pontos += 14;
  if ((docs || []).length) pontos += 12;
  if (!preconsultaVazia(pre)) pontos += 18;
  if ((agendamentos || []).length) pontos += 10;
  return Math.min(100, pontos);
}

function nlPacienteCareCard(titulo, texto, ok, acao, secao) {
  return `
    <article class="patient-care-card ${ok ? 'is-ok' : ''}">
      <span>${ok ? '✓' : '!'}</span>
      <div><strong>${titulo}</strong><small>${texto}</small></div>
      <button type="button" class="btn btn-light btn-sm" onclick="alternarPacienteSecao('${secao}')">${acao}</button>
    </article>
  `;
}

function renderPortalPacienteNovo() {
  if (paginaArquivo() !== 'area-paciente.html') return;
  const grid = document.querySelector('.dashboard-grid, .patient-app-shell');
  if (!grid) return;

  const api = portalApiCache;
  const usuario = getUsuarioLogado();
  if (!usuario?.cpf && !api?.perfil_ativo) {
    grid.className = 'patient-app-shell patient-app-shell-empty patient-area-v3';
    grid.innerHTML = `
      <section class="patient-login-empty patient-login-empty-v3">
        <div class="patient-login-icon">🔐</div>
        <span class="quick-access-label">Área segura</span>
        <h2>Entre com CPF para acessar dados reais.</h2>
        <p>Agendamentos, documentos, pré-consulta e conta família só aparecem quando existem no navegador ou no MySQL. Nada de dados falsos.</p>
        <div class="patient-empty-actions">
          <a class="btn btn-primary" href="index.html?modal=login">Entrar com CPF</a>
          <a class="btn btn-light" href="index.html?modal=cadastro">Criar conta</a>
        </div>
      </section>
    `;
    return;
  }

  const perfisFamilia = api?.perfis_familia || listarPerfisFamilia();
  const cpfPerfil = getPerfilAtivoCpf();
  const perfilDetalhe = perfisFamilia.find(p => p.cpf === cpfPerfil) || perfisFamilia[0] || {};
  const perfilApi = api?.perfil_ativo || {};
  const perfilUsuario = getPerfilAtivoUsuario() || {};
  const nomeCompleto = perfilApi.nome || perfilUsuario.nome || perfilDetalhe.nome || usuario.nome || 'Paciente';
  const nome = nomeCompleto.split(' ')[0];
  const agendamentos = api?.agendamentos || agendamentosDoPerfil(cpfPerfil);
  const proximo = agendamentos[0] || null;
  const docsLocais = listaDocumentosLocais(cpfPerfil);
  const docsPaciente = [...(api?.documentos || []), ...docsLocais.filter(doc => !doc.sincronizado_mysql)];
  const fotoPerfil = perfilApi.foto_perfil || '';
  const dados = nlFormularioLocal('dados_cadastrais', nlDadosPacientePadrao(perfilApi));
  const pre = lerJson(chaveDadosPerfil('neurolab_preconsulta', cpfPerfil), {});
  const progresso = nlCalcularCompletudeArea(cpfPerfil, perfilApi, docsPaciente, agendamentos);
  const pendencias = nlPendenciasPaciente(dados, docsPaciente, pre, agendamentos);
  const perfilContexto = perfilDetalhe?.cpf === usuario?.cpf ? 'Titular da conta' : `${perfilDetalhe?.papel || 'Familiar'} vinculado`;
  const idade = nlIdadePorData(perfilApi.data_nascimento || perfilDetalhe.data_nascimento || perfilUsuario.data_nascimento);

  grid.className = 'patient-app-shell patient-app-shell-refined patient-area-v3';
  grid.innerHTML = `
    <aside class="patient-sidebar patient-sidebar-v3">
      <div class="patient-profile-card patient-profile-v3 text-center">
        <div class="patient-avatar patient-avatar-photo mx-auto" style="${fotoPerfil ? `background-image:url('${fotoPerfil}')` : ''}">${fotoPerfil ? '' : nlDoctorInitials(nome)}</div>
        <label class="btn btn-outline-secondary btn-sm mt-2 patient-photo-button">
          Trocar foto
          <input type="file" accept="image/*" class="d-none" onchange="salvarFotoPerfilPaciente(this)">
        </label>
        <strong class="d-block mt-2">${nlSafeText(nomeCompleto)}</strong>
        <span class="patient-context-label">${nlSafeText(perfilContexto)}</span>
        <small>CPF ${nlMascaraCpf(cpfPerfil)}${idade !== null ? ` · ${idade} anos` : ''}</small>
        <div class="patient-profile-progress patient-profile-progress-v3">
          <span>Perfil ${progresso}% completo</span>
          <div><i style="width:${progresso}%"></i></div>
        </div>
      </div>

      <div class="patient-side-block patient-family-switch">
        <label for="familiaPerfilSelect" class="form-label">Conta família</label>
        <select id="familiaPerfilSelect" class="form-select" onchange="trocarPerfilFamilia(this.value)">
          ${perfisFamilia.map(perfil => `<option value="${nlSafeText(perfil.cpf)}" ${perfil.cpf === cpfPerfil ? 'selected' : ''}>${nlSafeText(perfil.papel)} — ${nlSafeText(perfil.nome)}</option>`).join('')}
        </select>
        <small>Todos os módulos obedecem ao CPF ativo.</small>
      </div>

      <div class="patient-side-block patient-rule-box">
        <span>Regras ativas</span>
        <ul>
          <li>Dados isolados por CPF.</li>
          <li>Menor de 18 exige responsável.</li>
          <li>Documentos: PDF/imagem até 5 MB.</li>
          <li>Pré-consulta exige consentimento.</li>
        </ul>
      </div>

      <div class="patient-sidebar-actions">
        <button class="btn btn-primary" onclick="abrirAgendamento()">Novo agendamento</button>
        <button class="btn btn-light" onclick="alternarPacienteSecao('dados')">Completar cadastro</button>
      </div>
    </aside>

    <section class="patient-main-panel patient-main-v3">
      <div class="patient-welcome-card patient-welcome-v3">
        <div>
          <span class="quick-access-label">Painel do paciente</span>
          <h2>Olá, ${nlSafeText(nome)}.</h2>
          <p>Uma área mais limpa, com regras de negócio visíveis, pendências reais e salvamento por CPF.</p>
        </div>
        <div class="patient-status-stack patient-status-v3">
          <span>${nlStatusSincronizacao()}</span>
          <strong>${pendencias.length ? `${pendencias.length} pendência(s)` : 'Tudo pronto'}</strong>
        </div>
      </div>

      <div class="patient-kpis patient-kpis-v3">
        <div><strong>${agendamentos.length || 0}</strong><span>agendamentos</span></div>
        <div><strong>${docsPaciente.length}</strong><span>documentos</span></div>
        <div><strong>${perfisFamilia.length}</strong><span>perfis família</span></div>
        <div><strong>${progresso}%</strong><span>perfil completo</span></div>
      </div>

      <div class="patient-care-grid">
        ${nlPacienteCareCard('Dados cadastrais', dados.telefone || dados.email ? 'Contato informado' : 'Falta contato principal', dados.telefone || dados.email, 'Editar', 'dados')}
        ${nlPacienteCareCard('Documentos', docsPaciente.length ? `${docsPaciente.length} arquivo(s)` : 'Nenhum arquivo enviado', docsPaciente.length, 'Enviar', 'documentos')}
        ${nlPacienteCareCard('Pré-consulta', preconsultaVazia(pre) ? 'Pendente antes do atendimento' : 'Informações preenchidas', !preconsultaVazia(pre), 'Preencher', 'preconsulta')}
        ${nlPacienteCareCard('Agendamento', proximo ? 'Consulta encontrada' : 'Sem consulta ativa', Boolean(proximo), 'Agendar', 'resumo')}
      </div>

      <div class="patient-card-lg patient-next-card-v3">
        <div>
          <span class="quick-access-label">Próxima etapa</span>
          <h3>${proximo?.medico_nome || proximo?.medico || (pendencias[0] || 'Nenhum agendamento ativo')}</h3>
          <p>${proximo ? `${proximo.tipo_consulta || proximo.tipoNome || 'Consulta'} · ${proximo.data_consulta || proximo.dia || ''} ${proximo.hora_consulta || proximo.horario || ''} · ${nlSafeText(perfilDetalhe?.nome || nomeCompleto)}` : 'Complete cadastro, documentos e pré-consulta para reduzir etapas na recepção.'}</p>
        </div>
        <div class="patient-action-row">
          <button class="btn btn-light" onclick="alternarPacienteSecao('preconsulta')">Pré-consulta</button>
          <button class="btn btn-primary" onclick="abrirAgendamento()">${proximo ? 'Reagendar' : 'Agendar'}</button>
        </div>
      </div>

      <div class="patient-tabs patient-tabs-v3" role="tablist" aria-label="Área do Paciente">
        <button class="active" type="button" onclick="alternarPacienteSecao('resumo', this)">Resumo</button>
        <button type="button" onclick="alternarPacienteSecao('dados', this)">Meus dados</button>
        <button type="button" onclick="alternarPacienteSecao('documentos', this)">Documentos</button>
        <button type="button" onclick="alternarPacienteSecao('preconsulta', this)">Pré-consulta</button>
        <button type="button" onclick="alternarPacienteSecao('exames', this)">Exames</button>
        <button type="button" onclick="alternarPacienteSecao('familia', this)">Conta família</button>
        <button type="button" onclick="alternarPacienteSecao('preferencias', this)">Lembretes</button>
      </div>
      <div id="patientDynamicPanel" class="patient-dynamic-panel patient-panel-v3"></div>
    </section>
  `;
  alternarPacienteSecao('resumo');
}

function nlPacienteSelect(id, label, value, options) {
  return `<label class="patient-field"><span>${label}</span><select id="${id}">${options.map(([val, txt]) => `<option value="${nlSafeText(val)}" ${value === val ? 'selected' : ''}>${nlSafeText(txt)}</option>`).join('')}</select></label>`;
}

async function alternarPacienteSecao(secao = 'resumo', botao) {
  if (paginaArquivo() !== 'area-paciente.html') return;
  const painel = document.getElementById('patientDynamicPanel');
  if (!painel) return;

  document.querySelectorAll('.patient-tabs button').forEach(item => item.classList.remove('active'));
  const ativo = botao || [...document.querySelectorAll('.patient-tabs button')].find(item => item.getAttribute('onclick')?.includes(`'${secao}'`));
  ativo?.classList.add('active');

  const cpfPerfil = getPerfilAtivoCpf();
  const perfil = portalApiCache?.perfil_ativo || getPerfilAtivoUsuario() || getUsuarioLogado() || {};
  const usaApi = typeof getAuthToken === 'function' && getAuthToken();
  const agendamentos = portalApiCache?.agendamentos || agendamentosDoPerfil(cpfPerfil);
  let docs = portalApiCache?.documentos || listaDocumentosLocais(cpfPerfil);
  const prefs = portalApiCache?.preferencias || lerJson(chaveDadosPerfil('neurolab_paciente_preferencias', cpfPerfil), { whatsapp: true, email: true, sms: false });

  if (secao === 'dados') {
    const dados = await nlCarregarFormularioPaciente('dados_cadastrais', nlDadosPacientePadrao(perfil));
    const menor = nlPacienteMenorAtual();
    painel.innerHTML = `
      <div class="patient-section-head patient-section-head-v3">
        <div><strong>Meus dados</strong><p>Campos salvos por CPF. O contato de emergência vira obrigatório para menores de 18 anos.</p></div>
        <span class="patient-save-pill" id="dadosStatus">${dados.atualizado_em ? 'Dados carregados' : 'Não enviado'}</span>
      </div>
      ${menor ? '<div class="patient-rule-alert">Paciente menor de 18 anos: informe nome e telefone do responsável/contato de emergência.</div>' : ''}
      <div class="patient-form-grid patient-form-grid-v3">
        ${nlPacienteFormInput('dadosEmail', 'E-mail de contato', dados.email, 'exemplo@email.com', 'email')}
        ${nlPacienteFormInput('dadosTelefone', 'Celular / WhatsApp', dados.telefone, '(11) 99999-9999')}
        ${nlPacienteFormInput('dadosEmergenciaNome', `Contato de emergência${menor ? ' *' : ''}`, dados.emergencia_nome, 'Nome do responsável/contato')}
        ${nlPacienteFormInput('dadosEmergenciaTelefone', `Telefone de emergência${menor ? ' *' : ''}`, dados.emergencia_telefone, '(11) 99999-9999')}
        ${nlPacienteFormInput('dadosConvenio', 'Convênio', dados.convenio, 'Particular, SUS ou nome do convênio')}
        ${nlPacienteFormInput('dadosCarteirinha', 'Número da carteirinha', dados.carteirinha, 'Opcional')}
        ${nlPacienteFormInput('dadosCep', 'CEP', dados.cep, '00000-000')}
        ${nlPacienteFormInput('dadosCidade', 'Cidade', dados.cidade, 'Santo André - SP')}
        ${nlPacienteFormTextarea('dadosEndereco', 'Endereço completo', dados.endereco, 'Rua, número, bairro e complemento')}
        ${nlPacienteFormTextarea('dadosObservacaoRecepcao', 'Observação para recepção', dados.observacao_recepcao, 'Acessibilidade, melhor forma de contato, preferências...')}
      </div>
      <div class="patient-form-actions patient-form-actions-v3">
        <button class="btn btn-primary" onclick="salvarDadosCadastraisPaciente()">Salvar dados</button>
        <small>Valida e-mail, telefone, CEP e responsável quando necessário.</small>
      </div>
    `;
    return;
  }

  if (secao === 'documentos') {
    const docsLocais = listaDocumentosLocais(cpfPerfil);
    if (usaApi) {
      try {
        const docsApi = await apiPortalDocumentos(cpfPerfil);
        docs = [...(docsApi || []), ...docsLocais.filter(local => !local.sincronizado_mysql)];
      } catch (_) { docs = docsLocais; }
    } else { docs = docsLocais; }
    const metaDocs = lerJson(chaveDadosPerfil('neurolab_documentos_meta', cpfPerfil), {});
    docs = (docs || []).map(doc => ({ ...doc, ...(doc.id ? (metaDocs[doc.id] || {}) : {}) }));
    painel.innerHTML = `
      <div class="patient-section-head patient-section-head-v3">
        <div><strong>Documentos</strong><p>Envie arquivos por categoria. O sistema valida formato, tamanho e consentimento antes de salvar.</p></div>
        <span class="patient-save-pill">${(docs || []).length} arquivo(s)</span>
      </div>
      <div class="patient-doc-upload-v3">
        <div class="patient-doc-upload-main">
          <strong>Adicionar novo arquivo</strong>
          <p>Permitido: PDF, PNG, JPG ou WEBP até 5 MB.</p>
          <div class="patient-doc-controls">
            <select id="patientDocCategoria">
              <option value="documento_identidade">Documento de identidade</option>
              <option value="convenio">Carteirinha do convênio</option>
              <option value="encaminhamento">Encaminhamento médico</option>
              <option value="laudo">Laudo / exame anterior</option>
              <option value="consentimento">Termo / autorização</option>
              <option value="outros">Outros</option>
            </select>
            <label class="btn btn-primary mb-0">
              Selecionar arquivo
              <input type="file" id="patientDocInput" accept=".pdf,image/png,image/jpeg,image/webp" onchange="uploadDocumentoPaciente(this)" hidden>
            </label>
          </div>
          <label class="patient-consent-line"><input type="checkbox" id="patientDocConsent"> Confirmo que posso enviar este documento e autorizo o uso para atendimento.</label>
        </div>
      </div>
      <div class="patient-doc-list patient-doc-list-v3">
        ${(docs || []).map(doc => {
          const ref = documentoPacienteRef(doc);
          const nomeDoc = doc.nome_arquivo || doc.nome || 'Documento';
          const tipoDoc = doc.tipo_arquivo || doc.tipo || 'arquivo';
          const origem = doc.id || doc.id_mysql ? 'MySQL' : 'Não sincronizado';
          const temConteudo = doc.conteudo_base64 || doc.tem_conteudo;
          return `
            <article>
              <div class="patient-doc-icon">${String(tipoDoc).toLowerCase().includes('pdf') ? 'PDF' : 'IMG'}</div>
              <div class="patient-doc-info">
                <strong>${nlSafeText(nomeDoc)}</strong>
                <span>${nlSafeText(nlPacienteDocCategoriaLabel(doc.categoria))} · ${nlSafeText(tipoDoc)} · ${origem}${doc.tamanho_kb ? ` · ${doc.tamanho_kb} KB` : ''}</span>
                <small>${temConteudo ? 'Disponível para visualizar e apagar.' : 'Sem conteúdo salvo para visualização.'}</small>
              </div>
              <div class="patient-doc-actions">
                <button class="btn btn-light btn-sm" onclick="abrirDocumentoPaciente('${ref}')">Visualizar</button>
                <button class="btn btn-light btn-sm text-danger" onclick="removerDocumentoPaciente('${ref}')">Apagar</button>
              </div>
            </article>`;
        }).join('') || '<div class="patient-empty-state"><strong>Nenhum documento enviado</strong><p>Envie um documento real para liberar visualização e exclusão.</p></div>'}
      </div>
    `;
    return;
  }

  if (secao === 'preconsulta') {
    const localPreconsulta = lerJson(chaveDadosPerfil('neurolab_preconsulta', cpfPerfil), {});
    let anamnese = { sintomas: '', intensidade: '', inicio_sintomas: '', medicamentos: '', alergias: '', doencas_previas: '', exames_recentes: '', observacoes: '', sinais_alerta: [], consentimento_triagem: false, sem_queixas: false, ...localPreconsulta };
    if (usaApi) {
      try {
        const apiCore = await apiPortalPreconsulta(cpfPerfil);
        const apiCompleta = await nlCarregarFormularioPaciente('preconsulta_completa', {});
        anamnese = { ...anamnese, ...(apiCore || {}), ...(apiCompleta || {}) };
      } catch (_) { /* mantem vazio quando MySQL/API nao responder */ }
    }
    const sinais = Array.isArray(anamnese.sinais_alerta) ? anamnese.sinais_alerta : [];
    painel.innerHTML = `
      <div class="patient-section-head patient-section-head-v3">
        <div><strong>Pré-consulta / triagem</strong><p>Formulário mais completo para reduzir dúvidas no atendimento. Não substitui atendimento de urgência.</p></div>
        <span class="patient-save-pill" id="preconsultaStatus">${preconsultaVazia(anamnese) ? 'Ainda não preenchida' : 'Dados carregados'}</span>
      </div>
      <div class="patient-risk-banner">Caso exista piora rápida ou situação urgente, procure atendimento de emergência em vez de aguardar a consulta.</div>
      <div class="patient-form-grid patient-form-grid-v3 patient-preconsulta-v3">
        <label class="patient-consent-line patient-field-full"><input type="checkbox" id="preSemQueixas" ${anamnese.sem_queixas ? 'checked' : ''}> Não tenho queixas atuais, quero apenas atualizar meus dados.</label>
        ${nlPacienteFormTextarea('preSintomas', 'Sintomas principais', anamnese.sintomas, 'Descreva o que está sentindo, frequência e contexto')}
        ${nlPacienteSelect('preIntensidade', 'Intensidade do sintoma', anamnese.intensidade, [['', 'Selecione'], ['Leve', 'Leve'], ['Moderado', 'Moderado'], ['Forte', 'Forte'], ['Muito forte', 'Muito forte']])}
        ${nlPacienteFormInput('preInicioSintomas', 'Quando começou?', anamnese.inicio_sintomas, 'Ex.: há 2 semanas')}
        ${nlPacienteFormTextarea('preMedicamentos', 'Medicamentos em uso', anamnese.medicamentos, 'Nome, dosagem e frequência')}
        ${nlPacienteFormTextarea('preAlergias', 'Alergias', anamnese.alergias, 'Medicamentos, alimentos ou outras alergias')}
        ${nlPacienteFormTextarea('preDoencasPrevias', 'Histórico de saúde', anamnese.doencas_previas, 'Doenças prévias, cirurgias, acompanhamentos...')}
        ${nlPacienteFormTextarea('preExamesRecentes', 'Exames recentes', anamnese.exames_recentes, 'Laudos ou exames feitos recentemente')}
        ${nlPacienteFormTextarea('preObservacoes', 'Outras observações', anamnese.observacoes, 'Informações que o médico deve saber')}
        <div class="patient-field patient-field-full patient-alert-checks">
          <span>Sinais de atenção para triagem</span>
          ${[
            ['inicio_subito', 'Sintoma começou de repente'],
            ['desmaio_convulsao', 'Desmaio ou convulsão recente'],
            ['fraqueza_importante', 'Fraqueza importante ou alteração de fala'],
            ['febre_persistente', 'Febre persistente junto dos sintomas']
          ].map(([valor, texto]) => `<label><input type="checkbox" value="${valor}" ${sinais.includes(valor) ? 'checked' : ''}> ${texto}</label>`).join('')}
        </div>
        <label class="patient-consent-line patient-field-full"><input type="checkbox" id="preConsentimento" ${anamnese.consentimento_triagem ? 'checked' : ''}> Confirmo que as informações são verdadeiras e autorizo o uso para triagem do atendimento.</label>
      </div>
      <div class="patient-form-actions patient-form-actions-v3">
        <button class="btn btn-light" onclick="salvarRascunhoPreConsultaPaciente()">Salvar rascunho</button>
        <button class="btn btn-primary" onclick="salvarPreConsultaPaciente()">Enviar pré-consulta</button>
        <small>Envio oficial pelo MySQL; as regras são validadas antes de salvar.</small>
      </div>
    `;
    document.querySelectorAll('#patientDynamicPanel textarea, #patientDynamicPanel input, #patientDynamicPanel select').forEach(campo => {
      campo.addEventListener('input', salvarRascunhoPreConsultaPaciente);
      campo.addEventListener('change', salvarRascunhoPreConsultaPaciente);
    });
    return;
  }

  if (secao === 'exames') {
    let exames = portalApiCache?.exames;
    if (usaApi) { try { exames = await apiPortalExames(cpfPerfil); } catch (_) {} }
    if (!exames?.length) exames = lerJson(chaveDadosPerfil('neurolab_exames_paciente', cpfPerfil), []);
    painel.innerHTML = `
      <div class="patient-section-head patient-section-head-v3"><div><strong>Exames</strong><p>Somente exames vinculados ao CPF ativo aparecem aqui.</p></div><span class="patient-save-pill">${exames.length || 0} registro(s)</span></div>
      ${exames.length ? `<div class="patient-exam-list patient-exam-list-v3">${exames.map(ex => `<article><div><strong>${nlSafeText(ex.nome)}</strong><span>${nlSafeText(ex.status)} · ${nlSafeText(ex.data_referencia || ex.data || '')}</span><small>Preparo: ${nlSafeText(ex.preparo || 'Orientação ainda não cadastrada.')}</small></div><button class="btn btn-light" onclick="gerarDocumentoPaciente('${String(ex.nome).replace(/'/g, "\\'")}')">Ver laudo</button></article>`).join('')}</div>` : `<div class="patient-empty-state"><strong>Nenhum exame disponível</strong><p>Quando um exame for solicitado ou um laudo for liberado, ele aparecerá aqui.</p><button class="btn btn-primary" onclick="abrirAgendamento()">Agendar exame</button></div>`}
    `;
    return;
  }

  if (secao === 'familia') {
    let perfis = portalApiCache?.perfis_familia || listarPerfisFamilia();
    if (usaApi) { try { const fam = await apiPortalFamilia(); perfis = fam.perfis || perfis; } catch (_) {} }
    const titular = getUsuarioLogado();
    painel.innerHTML = `
      <div class="patient-section-head patient-section-head-v3"><div><strong>Conta família</strong><p>Vínculo familiar real: cada CPF tem documentos, pré-consulta e agendamentos próprios.</p></div><span class="patient-save-pill">${perfis.length} perfil(is)</span></div>
      <div class="patient-family-list patient-family-list-v3">
        ${perfis.length ? perfis.map(perfilItem => `<article><div><strong>${nlSafeText(perfilItem.papel)} — ${nlSafeText(perfilItem.nome)}</strong><span>${perfilItem.cpf === cpfPerfil ? 'Perfil ativo agora' : 'CPF ' + nlMascaraCpf(perfilItem.cpf)}</span></div><div class="patient-family-actions">${perfilItem.cpf !== cpfPerfil ? `<button class="btn btn-light btn-sm" onclick="trocarPerfilFamilia('${perfilItem.cpf}')">Usar perfil</button>` : '<span class="badge bg-success">Ativo</span>'}${perfilItem.cpf !== titular?.cpf ? `<button class="btn btn-light btn-sm" onclick="removerPerfilFamilia('${perfilItem.cpf}')">Desvincular</button>` : '<span class="badge bg-light text-dark">Titular</span>'}</div></article>`).join('') : '<div class="patient-empty-state"><strong>Nenhum familiar vinculado</strong><p>Cadastre familiares reais com CPF próprio.</p></div>'}
      </div>
      <div class="patient-family-register mt-4"><button class="btn btn-primary" onclick="abrirCadastroFamiliar()">Cadastrar familiar</button><p class="text-muted small mt-2 mb-0">Para filho, neto ou dependente: 0 a 17 anos deve ter responsável vinculado.</p></div>
    `;
    return;
  }

  if (secao === 'preferencias') {
    const prefsExtra = await nlCarregarFormularioPaciente('preferencias_visuais', { unidade_preferida: '', horario_preferido: '', observacoes_lembretes: '' });
    painel.innerHTML = `
      <div class="patient-section-head patient-section-head-v3"><div><strong>Lembretes e preferências</strong><p>Controle os canais e preferências de atendimento sem misturar CPFs.</p></div><span class="patient-save-pill" id="prefsStatus">Preferências carregadas</span></div>
      <div class="patient-preference-grid patient-preference-grid-v3">
        ${[['whatsapp','WhatsApp','Confirmações e lembretes rápidos.'],['email','E-mail','Documentos, recibos e orientações.'],['sms','SMS','Alertas curtos quando necessário.']].map(([chave,titulo,texto]) => `<label><span><strong>${titulo}</strong><small>${texto}</small></span><input type="checkbox" ${prefs[chave] ? 'checked' : ''} onchange="atualizarPreferenciaPaciente('${chave}', this.checked)"></label>`).join('')}
      </div>
      <div class="patient-form-grid patient-form-grid-v3 mt-3">
        ${nlPacienteFormInput('prefUnidade', 'Unidade preferida', prefsExtra.unidade_preferida, 'Ex.: Santo André - Centro')}
        ${nlPacienteFormInput('prefHorario', 'Horário preferido', prefsExtra.horario_preferido, 'Ex.: manhã, tarde ou sábado')}
        ${nlPacienteFormTextarea('prefObs', 'Observações de lembrete', prefsExtra.observacoes_lembretes, 'Ex.: confirmar sempre pelo WhatsApp')}
      </div>
      <div class="patient-form-actions"><button class="btn btn-primary" onclick="salvarPreferenciasExtrasPaciente()">Salvar preferências</button></div>
    `;
    return;
  }

  const dados = nlFormularioLocal('dados_cadastrais', nlDadosPacientePadrao(perfil));
  const pre = lerJson(chaveDadosPerfil('neurolab_preconsulta', cpfPerfil), {});
  const docsResumo = docs || [];
  const pendencias = nlPendenciasPaciente(dados, docsResumo, pre, agendamentos);
  painel.innerHTML = `
    <div class="patient-summary-v3">
      <div class="patient-pending-box ${pendencias.length ? '' : 'is-ok'}">
        <strong>${pendencias.length ? 'Pendências para deixar o atendimento pronto' : 'Painel sem pendências principais'}</strong>
        ${pendencias.length ? `<ul>${pendencias.map(item => `<li>${nlSafeText(item)}</li>`).join('')}</ul>` : '<p>Dados principais completos para o fluxo básico de atendimento.</p>'}
      </div>
      <div class="patient-summary-grid patient-summary-grid-v3">
        <article><span>Dados cadastrais</span><strong>${nlContarCamposPreenchidos(dados, ['telefone','email','emergencia_nome','emergencia_telefone','endereco'])}/5 campos</strong><small>${dados.emergencia_nome ? 'Contato de emergência informado.' : 'Contato de emergência pendente.'}</small></article>
        <article><span>Documentos</span><strong>${docsResumo.length ? `${docsResumo.length} arquivo(s)` : 'Nenhum enviado'}</strong><small>PDF/imagem até 5 MB, separados por CPF.</small></article>
        <article><span>Pré-consulta</span><strong>${preconsultaVazia(pre) ? 'Pendente' : 'Preenchida'}</strong><small>${pre.atualizado_em ? `Atualizada em ${new Date(pre.atualizado_em).toLocaleDateString('pt-BR')}` : 'Preencha antes do atendimento.'}</small></article>
        <article><span>Sincronização</span><strong>${nlStatusSincronizacao()}</strong><small>${usaApi ? 'Dados conectados à API.' : 'Abra a API Flask para gravar no MySQL.'}</small></article>
      </div>
    </div>
  `;
}

function lerDadosCadastraisCampos() {
  return {
    email: document.getElementById('dadosEmail')?.value?.trim() || '',
    telefone: document.getElementById('dadosTelefone')?.value?.trim() || '',
    emergencia_nome: document.getElementById('dadosEmergenciaNome')?.value?.trim() || '',
    emergencia_telefone: document.getElementById('dadosEmergenciaTelefone')?.value?.trim() || '',
    convenio: document.getElementById('dadosConvenio')?.value?.trim() || '',
    carteirinha: document.getElementById('dadosCarteirinha')?.value?.trim() || '',
    cep: document.getElementById('dadosCep')?.value?.trim() || '',
    cidade: document.getElementById('dadosCidade')?.value?.trim() || '',
    endereco: document.getElementById('dadosEndereco')?.value?.trim() || '',
    observacao_recepcao: document.getElementById('dadosObservacaoRecepcao')?.value?.trim() || ''
  };
}

async function salvarDadosCadastraisPaciente() {
  const dados = lerDadosCadastraisCampos();
  if (!dados.telefone && !dados.email) return mostrarToast('Informe pelo menos telefone ou e-mail.', 'aviso');
  if (!nlEmailValido(dados.email)) return mostrarToast('E-mail inválido.', 'aviso');
  if (!nlTelefoneValido(dados.telefone)) return mostrarToast('Celular deve ter 10 ou 11 dígitos.', 'aviso');
  if (dados.emergencia_telefone && !nlTelefoneValido(dados.emergencia_telefone)) return mostrarToast('Telefone de emergência deve ter 10 ou 11 dígitos.', 'aviso');
  if (Boolean(dados.emergencia_nome) !== Boolean(dados.emergencia_telefone)) return mostrarToast('Informe nome e telefone do contato de emergência.', 'aviso');
  if (dados.cep && nlSomenteDigitos(dados.cep).length !== 8) return mostrarToast('CEP deve ter 8 dígitos.', 'aviso');
  if (nlPacienteMenorAtual() && (!dados.emergencia_nome || !dados.emergencia_telefone)) return mostrarToast('Menor de idade precisa de contato de emergência.', 'aviso');

  const salvouMysql = await nlSalvarFormularioPaciente('dados_cadastrais', dados, 'dadosStatus');
  mostrarToast(salvouMysql ? 'Dados validados e salvos no MySQL.' : 'Dados não salvos: MySQL/API indisponível.', 'sucesso');
  renderPortalPacienteNovo();
}

function lerPreConsultaCampos() {
  return {
    sem_queixas: Boolean(document.getElementById('preSemQueixas')?.checked),
    sintomas: document.getElementById('preSintomas')?.value?.trim() || '',
    intensidade: document.getElementById('preIntensidade')?.value?.trim() || '',
    inicio_sintomas: document.getElementById('preInicioSintomas')?.value?.trim() || '',
    medicamentos: document.getElementById('preMedicamentos')?.value?.trim() || '',
    alergias: document.getElementById('preAlergias')?.value?.trim() || '',
    doencas_previas: document.getElementById('preDoencasPrevias')?.value?.trim() || '',
    exames_recentes: document.getElementById('preExamesRecentes')?.value?.trim() || '',
    observacoes: document.getElementById('preObservacoes')?.value?.trim() || '',
    sinais_alerta: [...document.querySelectorAll('.patient-alert-checks input:checked')].map(item => item.value),
    consentimento_triagem: Boolean(document.getElementById('preConsentimento')?.checked),
    atualizado_em: new Date().toISOString()
  };
}

function preconsultaVazia(dados) {
  return !dados?.sem_queixas && nlContarCamposPreenchidos(dados || {}, ['sintomas', 'medicamentos', 'observacoes', 'alergias', 'doencas_previas', 'exames_recentes']) === 0;
}

async function salvarPreConsultaPaciente() {
  const cpf = getPerfilAtivoCpf();
  const dados = lerPreConsultaCampos();
  if (!dados.sem_queixas && !dados.sintomas && !dados.observacoes && !dados.medicamentos) return mostrarToast('Descreva os sintomas ou marque “não tenho queixas atuais”.', 'aviso');
  if (!dados.consentimento_triagem) return mostrarToast('Confirme o consentimento da pré-consulta.', 'aviso');

  salvarJson(chaveDadosPerfil('neurolab_preconsulta', cpf), dados);
  salvarJson(nlPacienteStorageKey('preconsulta_completa', cpf), dados);
  if (portalApiCache) portalApiCache.preconsulta = dados;

  let salvouMysql = false;
  if (typeof getAuthToken === 'function' && getAuthToken()) {
    try {
      await apiPortalSalvarPreconsulta(cpf, {
        sintomas: dados.sem_queixas ? 'Paciente marcou sem queixas atuais.' : dados.sintomas,
        medicamentos: dados.medicamentos,
        observacoes: [
          dados.observacoes,
          dados.alergias ? `Alergias: ${dados.alergias}` : '',
          dados.doencas_previas ? `Histórico: ${dados.doencas_previas}` : '',
          dados.exames_recentes ? `Exames recentes: ${dados.exames_recentes}` : '',
          dados.intensidade ? `Intensidade: ${dados.intensidade}` : '',
          dados.inicio_sintomas ? `Início: ${dados.inicio_sintomas}` : '',
          dados.sinais_alerta?.length ? `Sinais de atenção: ${dados.sinais_alerta.join(', ')}` : '',
          dados.sem_queixas ? 'Sem queixas atuais: sim' : ''
        ].filter(Boolean).join('\n'),
        sem_queixas: dados.sem_queixas,
        consentimento_triagem: dados.consentimento_triagem
      });
      await nlSalvarFormularioPaciente('preconsulta_completa', dados, 'preconsultaStatus');
      salvouMysql = true;
    } catch (erro) {
      mostrarToast(erro.message || 'Não foi possível salvar a pré-consulta no MySQL.', 'aviso');
      salvouMysql = false;
    }
  }
  if (!salvouMysql) await nlSalvarFormularioPaciente('preconsulta_completa', dados, 'preconsultaStatus');
  const status = document.getElementById('preconsultaStatus');
  if (status) status.textContent = salvouMysql ? 'Salva no MySQL' : 'Não salva: MySQL offline';
  if (dados.sinais_alerta?.length) mostrarToast('Pré-consulta salva. Sinais de atenção serão destacados para triagem.', 'aviso', 6000);
  else mostrarToast(salvouMysql ? 'Pré-consulta salva no MySQL.' : 'Pré-consulta não salva: MySQL/API indisponível.', 'sucesso');
  renderPortalPacienteNovo();
}

function uploadDocumentoPaciente(input) {
  const arquivo = input?.files?.[0];
  if (!arquivo) return;
  const categoria = document.getElementById('patientDocCategoria')?.value || 'outros';
  const consentiu = Boolean(document.getElementById('patientDocConsent')?.checked);
  const tiposPermitidos = ['application/pdf', 'image/png', 'image/jpeg', 'image/webp'];
  const limiteBytes = 5 * 1024 * 1024;

  if (!consentiu) {
    input.value = '';
    return mostrarToast('Confirme a autorização para enviar o documento.', 'aviso');
  }
  if (!tiposPermitidos.includes(arquivo.type)) {
    input.value = '';
    return mostrarToast('Envie apenas PDF, PNG, JPG ou WEBP.', 'aviso');
  }
  if (arquivo.size > limiteBytes) {
    input.value = '';
    return mostrarToast('Documento acima de 5 MB. Escolha um arquivo menor.', 'aviso');
  }
  if (arquivo.name.length > 180) {
    input.value = '';
    return mostrarToast('Nome do arquivo muito longo.', 'aviso');
  }

  const cpf = getPerfilAtivoCpf();
  const leitor = new FileReader();
  leitor.onload = async () => {
    const base64 = String(leitor.result || '');
    let salvouMysql = false;
    let idMysql = null;
    if (typeof getAuthToken === 'function' && getAuthToken()) {
      try {
        const salvo = await apiPortalUploadDocumento(cpf, {
          nome_arquivo: arquivo.name,
          tipo_arquivo: arquivo.type.includes('pdf') ? 'PDF' : 'Imagem',
          categoria,
          consentimento_lgpd: true,
          consentimento: true,
          tamanho_kb: Math.ceil(arquivo.size / 1024),
          conteudo_base64: base64,
          status: 'enviado'
        });
        salvouMysql = true;
        idMysql = salvo.id;
        portalApiCache = null;
        await carregarPortalApi();
      } catch (erro) {
        mostrarToast(erro.message || 'API/MySQL indisponível. Nada foi salvo fora do MySQL.', 'aviso');
      }
    }
    if (!salvouMysql) {
      salvarDocumentoLocalPaciente(cpf, arquivo, base64, { categoria, tamanho_kb: Math.ceil(arquivo.size / 1024) });
    }
    if (salvouMysql && idMysql) {
      const metaKey = chaveDadosPerfil('neurolab_documentos_meta', cpf);
      const meta = lerJson(metaKey, {});
      meta[idMysql] = { categoria, tamanho_kb: Math.ceil(arquivo.size / 1024) };
      salvarJson(metaKey, meta);
    }
    input.value = '';
    const consent = document.getElementById('patientDocConsent');
    if (consent) consent.checked = false;
    mostrarToast(salvouMysql ? 'Documento validado e salvo no MySQL.' : 'Documento não salvo: MySQL/API indisponível.', 'sucesso');
    alternarPacienteSecao('documentos');
  };
  leitor.readAsDataURL(arquivo);
}

function salvarDocumentoLocalPaciente(cpf, arquivo, base64, extras = {}) {
  const chave = chaveDadosPerfil('neurolab_documentos_upload', cpf);
  const uploads = lerJson(chave, []);
  const localId = extras.local_id || `local-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
  uploads.unshift({
    local_id: localId,
    nome_arquivo: arquivo.name,
    nome: arquivo.name,
    tipo_arquivo: arquivo.type.includes('pdf') ? 'PDF' : 'Imagem',
    tipo: arquivo.type.includes('pdf') ? 'PDF' : 'Imagem',
    categoria: extras.categoria || 'outros',
    tamanho_kb: extras.tamanho_kb || Math.ceil((arquivo.size || 0) / 1024),
    status: extras.status || 'não salvo no MySQL',
    data: new Date().toLocaleDateString('pt-BR'),
    conteudo_base64: base64,
    sincronizado_mysql: Boolean(extras.sincronizado_mysql),
    id_mysql: extras.id_mysql || null
  });
  salvarJson(chave, uploads);
}


/* ============================================================
   HOTFIX 4.0 — visualização de documentos + responsividade real
   Sobrescreve as funções anteriores sem alterar a identidade visual.
   ============================================================ */
function nlDocDecodeRef(ref) {
  try { return decodeURIComponent(String(ref || '')); }
  catch (_) { return String(ref || ''); }
}

function nlDocCandidateValues(doc) {
  return [
    doc?.local_id,
    doc?.id,
    doc?.id_mysql,
    doc?.nome_arquivo,
    doc?.nome
  ].filter(value => value !== undefined && value !== null && String(value).trim() !== '').map(value => String(value));
}

function documentoPacienteRef(doc) {
  const value = doc?.local_id || doc?.id || doc?.id_mysql || doc?.nome_arquivo || doc?.nome || '';
  return encodeURIComponent(String(value));
}

function documentoPacienteLocal(cpf, ref) {
  const decoded = nlDocDecodeRef(ref);
  const docs = listaDocumentosLocais(cpf);
  return docs.find(doc => nlDocCandidateValues(doc).some(value => value === decoded || encodeURIComponent(value) === String(ref)));
}

function nlNormalizarDocumentoBase64(doc) {
  const raw = String(doc?.conteudo_base64 || doc?.base64 || doc?.arquivo_base64 || '').trim();
  if (!raw) return '';
  if (raw.startsWith('data:')) return raw;
  const nome = String(doc?.nome_arquivo || doc?.nome || '').toLowerCase();
  const tipo = String(doc?.tipo_arquivo || doc?.tipo || '').toLowerCase();
  if (tipo.includes('pdf') || nome.endsWith('.pdf')) return `data:application/pdf;base64,${raw}`;
  if (nome.endsWith('.webp') || tipo.includes('webp')) return `data:image/webp;base64,${raw}`;
  if (nome.endsWith('.png') || tipo.includes('png')) return `data:image/png;base64,${raw}`;
  return `data:image/jpeg;base64,${raw}`;
}

function nlDataUriToBlob(dataUri) {
  const match = String(dataUri || '').match(/^data:([^;,]+)(;base64)?,(.*)$/);
  if (!match) return null;
  const mime = match[1] || 'application/octet-stream';
  const isBase64 = Boolean(match[2]);
  const payload = match[3] || '';
  let bytes;
  try {
    const binary = isBase64 ? atob(payload) : decodeURIComponent(payload);
    const slices = [];
    for (let offset = 0; offset < binary.length; offset += 1024) {
      const chunk = binary.slice(offset, offset + 1024);
      const numbers = new Array(chunk.length);
      for (let i = 0; i < chunk.length; i += 1) numbers[i] = chunk.charCodeAt(i);
      slices.push(new Uint8Array(numbers));
    }
    bytes = slices;
  } catch (_) {
    return null;
  }
  return new Blob(bytes, { type: mime });
}

function nlFecharVisualizadorDocumento() {
  const viewer = document.getElementById('patientDocumentViewer');
  if (!viewer) return;
  const objectUrl = viewer.dataset.objectUrl;
  if (objectUrl) URL.revokeObjectURL(objectUrl);
  viewer.remove();
}

function nlAbrirVisualizadorDocumento(doc) {
  const conteudo = nlNormalizarDocumentoBase64(doc);
  if (!conteudo) {
    mostrarToast('Arquivo sem conteúdo salvo. Reenvie o documento para liberar a visualização.', 'aviso');
    return;
  }

  const nome = doc?.nome_arquivo || doc?.nome || 'documento';
  const isImage = conteudo.startsWith('data:image/');
  const blob = nlDataUriToBlob(conteudo);
  const objectUrl = blob ? URL.createObjectURL(blob) : conteudo;

  nlFecharVisualizadorDocumento();
  const viewer = document.createElement('div');
  viewer.id = 'patientDocumentViewer';
  viewer.className = 'patient-document-viewer';
  viewer.dataset.objectUrl = blob ? objectUrl : '';
  viewer.innerHTML = `
    <div class="patient-document-viewer-card" role="dialog" aria-modal="true" aria-label="Visualizador de documento">
      <header class="patient-document-viewer-head">
        <div>
          <span>Documento do paciente</span>
          <strong>${nlSafeText(nome)}</strong>
        </div>
        <div class="patient-document-viewer-actions">
          <a class="btn btn-light btn-sm" href="${objectUrl}" download="${nlSafeText(nome)}" target="_blank" rel="noopener">Baixar</a>
          <button type="button" class="btn btn-primary btn-sm" onclick="nlFecharVisualizadorDocumento()">Fechar</button>
        </div>
      </header>
      <div class="patient-document-viewer-body">
        ${isImage ? `<img src="${objectUrl}" alt="${nlSafeText(nome)}">` : `<iframe src="${objectUrl}" title="${nlSafeText(nome)}"></iframe>`}
      </div>
    </div>
  `;
  viewer.addEventListener('click', event => {
    if (event.target === viewer) nlFecharVisualizadorDocumento();
  });
  document.body.appendChild(viewer);
}

async function abrirDocumentoPaciente(docRef) {
  const ref = nlDocDecodeRef(docRef);
  const cpf = getPerfilAtivoCpf();
  let doc = documentoPacienteLocal(cpf, ref);

  const idMysql = doc?.id_mysql || (/^\d+$/.test(ref) ? ref : null);
  if ((!doc || !nlNormalizarDocumentoBase64(doc)) && idMysql && typeof getAuthToken === 'function' && getAuthToken()) {
    try {
      const docMysql = await apiPortalObterDocumento(cpf, idMysql);
      doc = { ...(doc || {}), ...(docMysql || {}) };
    } catch (erro) {
      if (!doc) {
        mostrarToast(erro.message || 'Não foi possível abrir o documento no MySQL.', 'erro');
        return;
      }
    }
  }

  if (!doc || !nlNormalizarDocumentoBase64(doc)) {
    mostrarToast('Este documento foi cadastrado sem o arquivo. Reenvie o PDF/imagem para visualizar.', 'aviso');
    return;
  }

  nlAbrirVisualizadorDocumento(doc);
}

function salvarDocumentoLocalPaciente(cpf, arquivo, base64, extras = {}) {
  const chave = chaveDadosPerfil('neurolab_documentos_upload', cpf);
  const uploads = lerJson(chave, []);
  const localId = extras.local_id || (extras.id_mysql ? `mysql-${extras.id_mysql}` : `local-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`);
  const existenteIndex = uploads.findIndex(doc => doc.local_id === localId || (extras.id_mysql && String(doc.id_mysql) === String(extras.id_mysql)));
  const registro = {
    local_id: localId,
    id_mysql: extras.id_mysql || null,
    nome_arquivo: arquivo.name,
    nome: arquivo.name,
    tipo_arquivo: arquivo.type.includes('pdf') ? 'PDF' : 'Imagem',
    tipo: arquivo.type.includes('pdf') ? 'PDF' : 'Imagem',
    categoria: extras.categoria || 'outros',
    tamanho_kb: extras.tamanho_kb || Math.ceil((arquivo.size || 0) / 1024),
    status: extras.status || (extras.sincronizado_mysql ? 'enviado' : 'não salvo no MySQL'),
    data: new Date().toLocaleDateString('pt-BR'),
    conteudo_base64: base64,
    sincronizado_mysql: Boolean(extras.sincronizado_mysql)
  };
  if (existenteIndex >= 0) uploads.splice(existenteIndex, 1);
  uploads.unshift(registro);
  salvarJson(chave, uploads);
  return registro;
}

function uploadDocumentoPaciente(input) {
  const arquivo = input?.files?.[0];
  if (!arquivo) return;
  const categoria = document.getElementById('patientDocCategoria')?.value || 'outros';
  const consentiu = Boolean(document.getElementById('patientDocConsent')?.checked);
  const tiposPermitidos = ['application/pdf', 'image/png', 'image/jpeg', 'image/webp'];
  const limiteBytes = 5 * 1024 * 1024;

  if (!consentiu) {
    input.value = '';
    return mostrarToast('Confirme a autorização para enviar o documento.', 'aviso');
  }
  if (!tiposPermitidos.includes(arquivo.type)) {
    input.value = '';
    return mostrarToast('Envie apenas PDF, PNG, JPG ou WEBP.', 'aviso');
  }
  if (arquivo.size > limiteBytes) {
    input.value = '';
    return mostrarToast('Documento acima de 5 MB. Escolha um arquivo menor.', 'aviso');
  }
  if (arquivo.name.length > 180) {
    input.value = '';
    return mostrarToast('Nome do arquivo muito longo.', 'aviso');
  }

  const cpf = getPerfilAtivoCpf();
  const leitor = new FileReader();
  leitor.onload = async () => {
    const base64 = String(leitor.result || '');
    let salvouMysql = false;
    let idMysql = null;

    if (typeof getAuthToken === 'function' && getAuthToken()) {
      try {
        const salvo = await apiPortalUploadDocumento(cpf, {
          nome_arquivo: arquivo.name,
          tipo_arquivo: arquivo.type.includes('pdf') ? 'PDF' : 'Imagem',
          categoria,
          consentimento_lgpd: true,
          consentimento: true,
          tamanho_kb: Math.ceil(arquivo.size / 1024),
          conteudo_base64: base64,
          status: 'enviado'
        });
        salvouMysql = true;
        idMysql = salvo.id;
      } catch (erro) {
        mostrarToast(erro.message || 'API/MySQL indisponível. Nada foi salvo fora do MySQL.', 'aviso');
      }
    }

    salvarDocumentoLocalPaciente(cpf, arquivo, base64, {
      categoria,
      tamanho_kb: Math.ceil(arquivo.size / 1024),
      sincronizado_mysql: salvouMysql,
      id_mysql: idMysql,
      status: salvouMysql ? 'enviado' : 'não salvo no MySQL'
    });

    if (salvouMysql && idMysql) {
      const metaKey = chaveDadosPerfil('neurolab_documentos_meta', cpf);
      const meta = lerJson(metaKey, {});
      meta[idMysql] = { categoria, tamanho_kb: Math.ceil(arquivo.size / 1024) };
      salvarJson(metaKey, meta);
      portalApiCache = null;
      await carregarPortalApi();
    }

    input.value = '';
    const consent = document.getElementById('patientDocConsent');
    if (consent) consent.checked = false;
    mostrarToast(salvouMysql ? 'Documento salvo no MySQL e disponível para visualizar.' : 'Documento não salvo: MySQL/API indisponível.', 'sucesso');
    alternarPacienteSecao('documentos');
  };
  leitor.readAsDataURL(arquivo);
}

async function removerDocumentoPaciente(docRef) {
  const ref = nlDocDecodeRef(docRef);
  const cpf = getPerfilAtivoCpf();
  if (!ref) return;
  if (!confirm('Apagar este documento da Área do Paciente?')) return;

  const docsLocais = listaDocumentosLocais(cpf);
  const localEncontrado = docsLocais.find(doc => nlDocCandidateValues(doc).some(value => value === ref || encodeURIComponent(value) === String(docRef)));
  const idMysql = localEncontrado?.id_mysql || (/^\d+$/.test(ref) ? ref : null);
  const novaLista = docsLocais.filter(doc => !nlDocCandidateValues(doc).some(value => value === ref || encodeURIComponent(value) === String(docRef) || (idMysql && String(doc.id_mysql) === String(idMysql))));
  if (novaLista.length !== docsLocais.length) salvarListaDocumentosLocais(cpf, novaLista);

  let removeuMysql = false;
  if (idMysql && typeof getAuthToken === 'function' && getAuthToken()) {
    try {
      await apiPortalRemoverDocumento(cpf, idMysql);
      removeuMysql = true;
      portalApiCache = null;
      await carregarPortalApi();
    } catch (erro) {
      if (!localEncontrado) {
        mostrarToast(erro.message || 'Erro ao apagar documento do MySQL.', 'erro');
        return;
      }
    }
  }

  mostrarToast(removeuMysql ? 'Documento apagado do MySQL.' : 'Documento removido da Área do Paciente.', 'sucesso');
  alternarPacienteSecao('documentos');
}

document.addEventListener('keydown', event => {
  if (event.key === 'Escape') nlFecharVisualizadorDocumento();
});

/* ============================================================
   MYSQL ONLY — sem fallback de dados de negócio no localStorage
   ============================================================ */
async function nlMySQLPronto(mensagem = true) {
  const okToken = typeof getAuthToken === 'function' && Boolean(getAuthToken());
  const okApi = typeof apiDisponivel === 'function' && await apiDisponivel();
  if ((!okToken || !okApi) && mensagem && typeof mostrarToast === 'function') {
    mostrarToast('MySQL/API indisponível ou usuário sem login. Os dados não serão salvos fora do MySQL.', 'aviso', 6500);
  }
  return okToken && okApi;
}

function nlStatusSincronizacao() {
  return (typeof getAuthToken === 'function' && getAuthToken()) ? 'MySQL obrigatório' : 'Login necessário';
}

function listaDocumentosLocais() { return []; }
function salvarListaDocumentosLocais() { return false; }
function documentoPacienteLocal() { return null; }
function salvarDocumentoLocalPaciente() {
  mostrarToast('Gravação fora do MySQL bloqueada. Ligue o MySQL/API para gravar documentos.', 'aviso', 6500);
  return null;
}

function nlFormularioLocal(tipo, fallback = {}) { return { ...(fallback || {}) }; }

async function nlCarregarFormularioPaciente(tipo, fallback = {}) {
  if (!(await nlMySQLPronto(false)) || typeof apiPortalFormulario !== 'function') return { ...(fallback || {}) };
  try {
    const api = await apiPortalFormulario(getPerfilAtivoCpf(), tipo);
    return { ...(fallback || {}), ...(api?.dados || {}) };
  } catch (_) {
    return { ...(fallback || {}) };
  }
}

async function nlSalvarFormularioPaciente(tipo, dados, statusId) {
  const status = statusId ? document.getElementById(statusId) : null;
  if (!(await nlMySQLPronto(true)) || typeof apiPortalSalvarFormulario !== 'function') {
    if (status) status.textContent = 'Não salvo: MySQL offline';
    return false;
  }
  try {
    const cpf = getPerfilAtivoCpf();
    const dadosComMeta = { ...(dados || {}), atualizado_em: new Date().toISOString() };
    await apiPortalSalvarFormulario(cpf, tipo, dadosComMeta);
    if (status) status.textContent = 'Salvo no MySQL';
    portalApiCache = null;
    await carregarPortalApi();
    return true;
  } catch (erro) {
    if (status) status.textContent = 'Erro ao salvar no MySQL';
    mostrarToast(erro.message || 'Erro ao salvar no MySQL.', 'erro', 7000);
    return false;
  }
}

async function salvarFotoPerfilPaciente(input) {
  const arquivo = input?.files?.[0];
  if (!arquivo) return;
  if (!arquivo.type.startsWith('image/')) {
    input.value = '';
    return mostrarToast('Selecione uma imagem para a foto do perfil.', 'aviso');
  }
  if (!(await nlMySQLPronto(true))) { input.value = ''; return; }
  const leitor = new FileReader();
  leitor.onload = async () => {
    try {
      const foto = String(leitor.result || '');
      await apiPortalSalvarFoto(getPerfilAtivoCpf(), foto);
      portalApiCache = null;
      await carregarPortalApi();
      document.querySelectorAll('.patient-avatar-photo').forEach(avatar => {
        avatar.style.backgroundImage = `url('${foto}')`;
        avatar.textContent = '';
      });
      mostrarToast('Foto salva no MySQL.', 'sucesso');
    } catch (erro) {
      mostrarToast(erro.message || 'Não foi possível salvar a foto no MySQL.', 'erro', 7000);
    } finally {
      input.value = '';
    }
  };
  leitor.readAsDataURL(arquivo);
}

async function atualizarPreferenciaPaciente(chave, valor) {
  if (!(await nlMySQLPronto(true))) return;
  const cpf = getPerfilAtivoCpf();
  const prefs = { whatsapp: true, email: true, sms: false, ...(portalApiCache?.preferencias || {}) };
  prefs[chave] = Boolean(valor);
  try {
    const salvo = await apiPortalSalvarPreferencias(cpf, prefs);
    if (portalApiCache) portalApiCache.preferencias = salvo;
    mostrarToast('Preferência salva no MySQL.', 'sucesso');
  } catch (erro) {
    mostrarToast(erro.message || 'Erro ao salvar preferência no MySQL.', 'erro', 7000);
  }
}

async function salvarDadosCadastraisPaciente() {
  const dados = lerDadosCadastraisCampos();
  if (!dados.telefone && !dados.email) return mostrarToast('Informe pelo menos telefone ou e-mail.', 'aviso');
  if (!nlEmailValido(dados.email)) return mostrarToast('E-mail inválido.', 'aviso');
  if (!nlTelefoneValido(dados.telefone)) return mostrarToast('Celular deve ter 10 ou 11 dígitos.', 'aviso');
  if (dados.emergencia_telefone && !nlTelefoneValido(dados.emergencia_telefone)) return mostrarToast('Telefone de emergência deve ter 10 ou 11 dígitos.', 'aviso');
  if (Boolean(dados.emergencia_nome) !== Boolean(dados.emergencia_telefone)) return mostrarToast('Informe nome e telefone do contato de emergência.', 'aviso');
  if (dados.cep && nlSomenteDigitos(dados.cep).length !== 8) return mostrarToast('CEP deve ter 8 dígitos.', 'aviso');
  if (nlPacienteMenorAtual() && (!dados.emergencia_nome || !dados.emergencia_telefone)) return mostrarToast('Menor de idade precisa de contato de emergência.', 'aviso');

  const salvou = await nlSalvarFormularioPaciente('dados_cadastrais', dados, 'dadosStatus');
  if (salvou) {
    mostrarToast('Dados validados e salvos no MySQL.', 'sucesso');
    renderPortalPacienteNovo();
  }
}

async function salvarPreConsultaPaciente() {
  const cpf = getPerfilAtivoCpf();
  const dados = lerPreConsultaCampos();
  if (!dados.sem_queixas && !dados.sintomas && !dados.observacoes && !dados.medicamentos) return mostrarToast('Descreva os sintomas ou marque “não tenho queixas atuais”.', 'aviso');
  if (!dados.consentimento_triagem) return mostrarToast('Confirme o consentimento da pré-consulta.', 'aviso');
  if (!(await nlMySQLPronto(true))) return;
  try {
    await apiPortalSalvarPreconsulta(cpf, {
      sintomas: dados.sem_queixas ? 'Paciente marcou sem queixas atuais.' : dados.sintomas,
      medicamentos: dados.medicamentos,
      observacoes: [
        dados.observacoes,
        dados.alergias ? `Alergias: ${dados.alergias}` : '',
        dados.doencas_previas ? `Histórico: ${dados.doencas_previas}` : '',
        dados.exames_recentes ? `Exames recentes: ${dados.exames_recentes}` : '',
        dados.intensidade ? `Intensidade: ${dados.intensidade}` : '',
        dados.inicio_sintomas ? `Início: ${dados.inicio_sintomas}` : '',
        dados.sinais_alerta?.length ? `Sinais de atenção: ${dados.sinais_alerta.join(', ')}` : '',
        dados.sem_queixas ? 'Sem queixas atuais: sim' : ''
      ].filter(Boolean).join('\n'),
      sem_queixas: dados.sem_queixas,
      consentimento_triagem: dados.consentimento_triagem
    });
    await apiPortalSalvarFormulario(cpf, 'preconsulta_completa', dados);
    portalApiCache = null;
    await carregarPortalApi();
    const status = document.getElementById('preconsultaStatus');
    if (status) status.textContent = 'Salva no MySQL';
    mostrarToast('Pré-consulta salva no MySQL.', 'sucesso');
    renderPortalPacienteNovo();
  } catch (erro) {
    mostrarToast(erro.message || 'Não foi possível salvar a pré-consulta no MySQL.', 'erro', 7000);
  }
}

function uploadDocumentoPaciente(input) {
  const arquivo = input?.files?.[0];
  if (!arquivo) return;
  const categoria = document.getElementById('patientDocCategoria')?.value || 'outros';
  const consentiu = Boolean(document.getElementById('patientDocConsent')?.checked);
  const tiposPermitidos = ['application/pdf', 'image/png', 'image/jpeg', 'image/webp'];
  const limiteBytes = 5 * 1024 * 1024;
  if (!consentiu) { input.value = ''; return mostrarToast('Confirme a autorização para enviar o documento.', 'aviso'); }
  if (!tiposPermitidos.includes(arquivo.type)) { input.value = ''; return mostrarToast('Envie apenas PDF, PNG, JPG ou WEBP.', 'aviso'); }
  if (arquivo.size > limiteBytes) { input.value = ''; return mostrarToast('Documento acima de 5 MB. Escolha um arquivo menor.', 'aviso'); }
  if (arquivo.name.length > 180) { input.value = ''; return mostrarToast('Nome do arquivo muito longo.', 'aviso'); }

  const leitor = new FileReader();
  leitor.onload = async () => {
    try {
      if (!(await nlMySQLPronto(true))) return;
      await apiPortalUploadDocumento(getPerfilAtivoCpf(), {
        nome_arquivo: arquivo.name,
        tipo_arquivo: arquivo.type.includes('pdf') ? 'PDF' : 'Imagem',
        categoria,
        consentimento_lgpd: true,
        consentimento: true,
        tamanho_kb: Math.ceil(arquivo.size / 1024),
        conteudo_base64: String(leitor.result || ''),
        status: 'enviado'
      });
      portalApiCache = null;
      await carregarPortalApi();
      const consent = document.getElementById('patientDocConsent');
      if (consent) consent.checked = false;
      mostrarToast('Documento validado e salvo no MySQL.', 'sucesso');
      alternarPacienteSecao('documentos');
    } catch (erro) {
      mostrarToast(erro.message || 'Não foi possível salvar documento no MySQL.', 'erro', 7000);
    } finally {
      input.value = '';
    }
  };
  leitor.readAsDataURL(arquivo);
}

async function abrirDocumentoPaciente(docRef) {
  const ref = nlDocDecodeRef(docRef);
  const idMysql = /^\d+$/.test(ref) ? ref : null;
  if (!idMysql) return mostrarToast('Documento sem ID do MySQL. Reenvie o arquivo com a API ativa.', 'aviso');
  if (!(await nlMySQLPronto(true))) return;
  try {
    const doc = await apiPortalObterDocumento(getPerfilAtivoCpf(), idMysql);
    nlAbrirVisualizadorDocumento(doc);
  } catch (erro) {
    mostrarToast(erro.message || 'Não foi possível abrir o documento no MySQL.', 'erro', 7000);
  }
}

async function removerDocumentoPaciente(docRef) {
  const ref = nlDocDecodeRef(docRef);
  const idMysql = /^\d+$/.test(ref) ? ref : null;
  if (!idMysql) return mostrarToast('Documento sem ID do MySQL. Atualize a página e tente novamente.', 'aviso');
  if (!confirm('Apagar este documento do MySQL?')) return;
  if (!(await nlMySQLPronto(true))) return;
  try {
    await apiPortalRemoverDocumento(getPerfilAtivoCpf(), idMysql);
    portalApiCache = null;
    await carregarPortalApi();
    mostrarToast('Documento apagado do MySQL.', 'sucesso');
    alternarPacienteSecao('documentos');
  } catch (erro) {
    mostrarToast(erro.message || 'Erro ao apagar documento do MySQL.', 'erro', 7000);
  }
}

async function salvarPreferenciasExtrasPaciente() {
  const dados = {
    unidade_preferida: document.getElementById('prefUnidade')?.value?.trim() || '',
    horario_preferido: document.getElementById('prefHorario')?.value?.trim() || '',
    observacoes_lembretes: document.getElementById('prefObs')?.value?.trim() || ''
  };
  const salvou = await nlSalvarFormularioPaciente('preferencias_visuais', dados, 'prefsStatus');
  if (salvou) mostrarToast('Preferências salvas no MySQL.', 'sucesso');
}

async function registrarCheckinPaciente() {
  const dados = { feito_em: new Date().toISOString(), status: 'QR Code liberado', cpf: getPerfilAtivoCpf() };
  const salvou = await nlSalvarFormularioPaciente('checkin', dados);
  if (!salvou) return;
  abrirModalPaciente('checkin');
  mostrarToast('Check-in salvo no MySQL para o CPF ativo.', 'sucesso');
}

async function removerPerfilFamilia(cpf) {
  const titular = getUsuarioLogado();
  if (!titular?.cpf || cpf === titular.cpf) return;
  if (!confirm('Desvincular este familiar da conta? A conta dele continua no MySQL, mas deixa de aparecer na sua família.')) return;
  if (!(await nlMySQLPronto(true))) return;
  try {
    await apiPortalDesvincularFamiliar(cpf);
    portalApiCache = null;
    await initPortalPaciente();
    alternarPacienteSecao('familia');
    mostrarToast('Familiar desvinculado no MySQL.', 'info');
  } catch (erro) {
    mostrarToast(erro.message || 'Erro ao desvincular familiar no MySQL.', 'erro', 7000);
  }
}
