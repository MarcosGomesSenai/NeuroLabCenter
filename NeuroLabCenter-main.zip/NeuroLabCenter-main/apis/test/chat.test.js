import assert from "node:assert/strict";
import test from "node:test";

process.env.OLLAMA_REQUIRED = "false";
process.env.OLLAMA_URL = "http://127.0.0.1:1/api/generate";

const { default: app } = await import("../src/app.js");

function listen() {
  return new Promise((resolve) => {
    const server = app.listen(0, () => resolve(server));
  });
}

function close(server) {
  return new Promise((resolve, reject) => {
    server.close((error) => (error ? reject(error) : resolve()));
  });
}

async function postJson(baseUrl, path, payload) {
  const response = await fetch(`${baseUrl}${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  });
  const data = await response.json();
  return { status: response.status, data };
}

test("chat validates empty messages", async () => {
  const server = await listen();
  try {
    const baseUrl = `http://127.0.0.1:${server.address().port}`;
    const response = await postJson(baseUrl, "/api/chat", { message: "" });
    assert.equal(response.status, 400);
    assert.match(response.data.answer, /Digite/i);
  } finally {
    await close(server);
  }
});

test("chat returns a local fallback when Ollama is unavailable", async () => {
  const server = await listen();
  try {
    const baseUrl = `http://127.0.0.1:${server.address().port}`;
    const response = await postJson(baseUrl, "/api/chat", { message: "quero agendar um exame" });
    assert.equal(response.status, 200);
    assert.match(response.data.answer, /agendamento|exames?/i);
  } finally {
    await close(server);
  }
});

test("chat emergency fallback recommends emergency care", async () => {
  const server = await listen();
  try {
    const baseUrl = `http://127.0.0.1:${server.address().port}`;
    const response = await postJson(baseUrl, "/api/chat", {
      message: "estou com dor no peito e falta de ar"
    });
    assert.equal(response.status, 200);
    assert.match(response.data.answer, /emergencia/i);
  } finally {
    await close(server);
  }
});
