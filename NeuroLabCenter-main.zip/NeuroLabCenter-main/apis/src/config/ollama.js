export const OLLAMA_URL = process.env.OLLAMA_URL || "http://localhost:11434/api/generate";
export const MODEL = process.env.OLLAMA_MODEL || "llama3.1";
export const OLLAMA_REQUIRED = String(process.env.OLLAMA_REQUIRED || "false").toLowerCase() === "true";
