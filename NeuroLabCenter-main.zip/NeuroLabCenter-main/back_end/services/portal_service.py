import json
from datetime import datetime

from back_end.database.connection import db_cursor, fetch_all, fetch_one
from back_end.services.familia_service import assert_acesso_perfil, listar_perfis_acessiveis
from back_end.services.paciente_service import buscar_paciente_por_cpf
from back_end.utils.cpf import normalize_cpf
from back_end.utils.dates import age_from_birthdate, parse_date
from back_end.utils.errors import BusinessRuleError, NotFoundError
from back_end.utils.validation import (
    parse_bool,
    validate_cep,
    validate_data_uri_base64,
    validate_email,
    validate_phone,
)

DATA_URI_PREFIXOS_DOCUMENTO = (
    "data:application/pdf;base64,",
    "data:image/png;base64,",
    "data:image/jpeg;base64,",
    "data:image/jpg;base64,",
    "data:image/webp;base64,",
)
DATA_URI_PREFIXOS_IMAGEM = (
    "data:image/png;base64,",
    "data:image/jpeg;base64,",
    "data:image/jpg;base64,",
    "data:image/webp;base64,",
)
CATEGORIAS_DOCUMENTO = {"documento_identidade", "pedido_medico", "encaminhamento", "exame", "laudo", "consentimento", "convenio", "outros"}
STATUS_DOCUMENTO = {"enviado", "validacao_pendente", "revisado", "salvo localmente"}
STATUS_EXAME = {"agendado", "realizado", "pendente", "cancelado", "em analise", "em análise"}
FORMULARIOS_PERMITIDOS = {"dados_cadastrais", "preconsulta_completa", "checkin", "preferencias_visuais"}
MAX_DOCUMENTO_BYTES = 5 * 1024 * 1024
MAX_FOTO_BYTES = 2 * 1024 * 1024


def _primeiro_valor_presente(dados, *chaves):
    """Retorna o primeiro campo realmente enviado, preservando False/0/"false".

    Usar ``a or b`` em booleanos causa erro de regra de negócio, porque
    ``False`` pode ser trocado por outro campo verdadeiro.
    """
    for chave in chaves:
        if isinstance(dados, dict) and chave in dados:
            return dados.get(chave)
    return None

def _resolver_perfil_cpf(cpf_titular, perfil_cpf=None):
    alvo = normalize_cpf(perfil_cpf or cpf_titular, "cpf_perfil")
    assert_acesso_perfil(cpf_titular, alvo)
    return alvo


def _valor_texto(dados, chave, limite=3000):
    return str((dados or {}).get(chave) or "").strip()[:limite]


def _validar_tipo_formulario(tipo):
    tipo_normalizado = (tipo or "").strip().lower().replace("-", "_")
    if tipo_normalizado not in FORMULARIOS_PERMITIDOS:
        raise BusinessRuleError("Tipo de formulario invalido.", code="invalid_form_type")
    return tipo_normalizado


def _idade_paciente(cpf):
    row = fetch_one("SELECT data_nascimento FROM pacientes WHERE cpf = %s", (cpf,))
    nascimento = row.get("data_nascimento") if row else None
    if not nascimento:
        return None
    return age_from_birthdate(nascimento)


def _paciente_menor(cpf):
    idade = _idade_paciente(cpf)
    return idade is not None and idade < 18


def _limpar_json_formulario(dados):
    if not isinstance(dados, dict):
        raise BusinessRuleError("Dados do formulario precisam ser um objeto.", code="invalid_form_payload")
    dados_limpos = {}
    for chave, valor in dados.items():
        chave_limpa = str(chave).strip()[:80]
        if not chave_limpa:
            continue
        if isinstance(valor, str):
            dados_limpos[chave_limpa] = valor.strip()[:3000]
        elif isinstance(valor, (bool, int, float)) or valor is None:
            dados_limpos[chave_limpa] = valor
        elif isinstance(valor, list):
            dados_limpos[chave_limpa] = [str(item)[:300] for item in valor[:30]]
        else:
            dados_limpos[chave_limpa] = str(valor)[:3000]
    return dados_limpos


def _salvar_json_formulario(cursor, cpf, tipo_formulario, dados_limpos):
    cursor.execute(
        """
        INSERT INTO formularios_paciente (cpf_paciente, tipo_formulario, dados_json)
        VALUES (%s, %s, %s)
        ON DUPLICATE KEY UPDATE
            dados_json = VALUES(dados_json),
            atualizado_em = NOW()
        """,
        (cpf, tipo_formulario, json.dumps(dados_limpos, ensure_ascii=False)),
    )


def _validar_dados_formulario(cpf, tipo_formulario, dados):
    if tipo_formulario == "dados_cadastrais":
        email = validate_email(dados.get("email"), required=False) if dados.get("email") else None
        telefone = validate_phone(dados.get("telefone"), required=False) if dados.get("telefone") else None
        validate_cep(dados.get("cep"), required=False)
        emergencia_nome = _valor_texto(dados, "emergencia_nome", 120)
        emergencia_telefone = validate_phone(dados.get("emergencia_telefone"), required=False) if dados.get("emergencia_telefone") else None
        if bool(emergencia_nome) != bool(emergencia_telefone):
            raise BusinessRuleError("Informe nome e telefone do contato de emergencia.", code="missing_emergency_pair")
        if _paciente_menor(cpf) and not (emergencia_nome and emergencia_telefone):
            raise BusinessRuleError(
                "Pacientes menores de 18 anos precisam de contato de emergencia/responsavel.",
                code="minor_requires_emergency_contact",
            )
        if email:
            existente = fetch_one(
                "SELECT cpf FROM usuarios WHERE email = %s AND ativo = TRUE AND cpf <> %s LIMIT 1",
                (email, cpf),
            )
            if existente:
                raise BusinessRuleError("E-mail ja cadastrado em outra conta.", code="email_already_exists")
        return {"email": email, "telefone": telefone}

    if tipo_formulario == "preconsulta_completa":
        sem_queixas = parse_bool(dados.get("sem_queixas"), default=False, field_name="sem_queixas")
        consentimento = parse_bool(
            _primeiro_valor_presente(dados, "consentimento_triagem", "consentimento"),
            default=False,
            field_name="consentimento_triagem",
        )
        sintomas = _valor_texto(dados, "sintomas", 3000)
        observacoes = _valor_texto(dados, "observacoes", 5000)
        medicamentos = _valor_texto(dados, "medicamentos", 3000)
        if not consentimento:
            raise BusinessRuleError("Confirme o consentimento da pre-consulta antes de enviar.", code="missing_preconsult_consent")
        if not sem_queixas and not (sintomas or observacoes or medicamentos):
            raise BusinessRuleError("Descreva os sintomas ou marque que nao ha queixas atuais.", code="empty_preconsult")

    if tipo_formulario == "preferencias_visuais":
        horario = _valor_texto(dados, "horario_preferido", 80)
        if len(horario) > 80:
            raise BusinessRuleError("Horario preferido muito longo.", code="invalid_preference")

    if tipo_formulario == "checkin":
        status = _valor_texto(dados, "status", 60).lower()
        if status and status not in {"qr code liberado", "rascunho", "confirmado"}:
            raise BusinessRuleError("Status de check-in invalido.", code="invalid_checkin_status")

    return {}


def obter_painel(cpf_titular, perfil_cpf=None):
    cpf = _resolver_perfil_cpf(cpf_titular, perfil_cpf)
    paciente = buscar_paciente_por_cpf(cpf)

    agendamentos = fetch_all(
        """
        SELECT a.id, a.data_consulta, a.hora_consulta, a.tipo_consulta, a.tipo_atendimento,
               a.status, m.especialidade, u.nome AS unidade_nome,
               um.nome AS medico_nome
          FROM agendamentos a
          JOIN pacientes p ON p.id = a.id_paciente
          JOIN medicos m ON m.id = a.id_medico
          JOIN usuarios um ON um.id = m.id_usuario
          JOIN unidades u ON u.id = a.id_unidade
         WHERE p.cpf = %s
         ORDER BY a.data_consulta DESC, a.hora_consulta DESC
         LIMIT 20
        """,
        (cpf,),
    )

    documentos = listar_documentos(cpf_titular, cpf)
    preconsulta = obter_preconsulta(cpf_titular, cpf)
    exames = listar_exames(cpf_titular, cpf)
    preferencias = obter_preferencias(cpf_titular, cpf)
    perfis = listar_perfis_acessiveis(cpf_titular)

    return {
        "perfil_ativo": {
            "cpf": paciente["cpf"],
            "nome": paciente["nome"],
            "email": paciente.get("email"),
            "telefone": paciente.get("telefone"),
            "data_nascimento": paciente.get("data_nascimento"),
            "foto_perfil": paciente.get("foto_perfil"),
        },
        "agendamentos": agendamentos,
        "documentos": documentos,
        "preconsulta": preconsulta,
        "exames": exames,
        "preferencias": preferencias,
        "perfis_familia": perfis,
        "kpis": {
            "agendamentos": len(agendamentos),
            "documentos": len(documentos),
            "perfis_familia": len(perfis),
        },
    }


def listar_documentos(cpf_titular, perfil_cpf=None):
    cpf = _resolver_perfil_cpf(cpf_titular, perfil_cpf)
    return fetch_all(
        """
        SELECT id, nome_arquivo, tipo_arquivo, status, criado_em,
               categoria, tamanho_kb, consentimento_lgpd,
               CASE WHEN conteudo_base64 IS NULL OR conteudo_base64 = '' THEN 0 ELSE 1 END AS tem_conteudo
          FROM documentos_paciente
         WHERE cpf_paciente = %s
         ORDER BY criado_em DESC
        """,
        (cpf,),
    ) or []


def obter_documento(cpf_titular, perfil_cpf, doc_id):
    cpf = _resolver_perfil_cpf(cpf_titular, perfil_cpf)
    row = fetch_one(
        """
        SELECT id, nome_arquivo, tipo_arquivo, categoria, tamanho_kb, status, conteudo_base64, criado_em
          FROM documentos_paciente
         WHERE id = %s AND cpf_paciente = %s
        """,
        (doc_id, cpf),
    )
    if not row:
        raise NotFoundError("Documento nao encontrado.", code="document_not_found")
    if not row.get("conteudo_base64"):
        raise BusinessRuleError("Documento sem arquivo salvo para visualizacao.", code="document_without_content")
    return row


def criar_documento(cpf_titular, perfil_cpf, data):
    cpf = _resolver_perfil_cpf(cpf_titular, perfil_cpf)
    nome = (data.get("nome_arquivo") or data.get("nome") or "").strip()
    if not nome:
        raise BusinessRuleError("Nome do documento obrigatorio.", code="missing_filename")
    if len(nome) > 180:
        raise BusinessRuleError("Nome do documento muito longo.", code="filename_too_long")

    categoria = (data.get("categoria") or "").strip().lower()
    if not categoria:
        raise BusinessRuleError("Categoria do documento obrigatoria.", code="missing_document_category")
    if categoria not in CATEGORIAS_DOCUMENTO:
        raise BusinessRuleError("Categoria de documento invalida.", code="invalid_document_category")

    consentimento = parse_bool(
        _primeiro_valor_presente(data, "consentimento", "consentimento_lgpd", "consentiu"),
        default=False,
        field_name="consentimento_lgpd",
    )
    if not consentimento:
        raise BusinessRuleError("Confirme a autorizacao/LGPD para enviar o documento.", code="missing_document_consent")

    conteudo = data.get("conteudo_base64") or ""
    if not conteudo:
        raise BusinessRuleError("Arquivo do documento obrigatorio para permitir visualizacao.", code="missing_document_content")
    raw = validate_data_uri_base64(conteudo, DATA_URI_PREFIXOS_DOCUMENTO, MAX_DOCUMENTO_BYTES, "document")

    tipo_informado = (data.get("tipo_arquivo") or data.get("tipo") or "").strip()[:40]
    if str(conteudo).lower().startswith("data:application/pdf"):
        tipo_detectado = "pdf"
    else:
        tipo_detectado = "imagem"
    tipo = tipo_informado or tipo_detectado
    status = (data.get("status") or "enviado").strip().lower()[:40]
    if status not in STATUS_DOCUMENTO:
        status = "enviado"
    tamanho_kb = max(1, round(len(raw) / 1024))

    with db_cursor(commit=True) as cursor:
        cursor.execute(
            """
            INSERT INTO documentos_paciente (
                cpf_paciente, nome_arquivo, tipo_arquivo, categoria, tamanho_kb,
                consentimento_lgpd, status, conteudo_base64
            )
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
            """,
            (cpf, nome, tipo, categoria, tamanho_kb, True, status, conteudo),
        )
        doc_id = cursor.lastrowid

    return {
        "id": doc_id,
        "nome_arquivo": nome,
        "tipo_arquivo": tipo,
        "categoria": categoria,
        "tamanho_kb": tamanho_kb,
        "status": status,
        "tem_conteudo": 1,
    }


def remover_documento(cpf_titular, perfil_cpf, doc_id):
    cpf = _resolver_perfil_cpf(cpf_titular, perfil_cpf)
    with db_cursor(commit=True) as cursor:
        cursor.execute(
            "DELETE FROM documentos_paciente WHERE id = %s AND cpf_paciente = %s",
            (doc_id, cpf),
        )
        if cursor.rowcount == 0:
            raise NotFoundError("Documento nao encontrado.", code="document_not_found")
    return {"id": doc_id, "removido": True}


def obter_preconsulta(cpf_titular, perfil_cpf=None):
    cpf = _resolver_perfil_cpf(cpf_titular, perfil_cpf)
    row = fetch_one(
        "SELECT sintomas, medicamentos, observacoes, sem_queixas, consentimento_triagem, atualizado_em FROM preconsulta_paciente WHERE cpf_paciente = %s",
        (cpf,),
    )
    return row or {"sintomas": "", "medicamentos": "", "observacoes": "", "sem_queixas": False}


def salvar_preconsulta(cpf_titular, perfil_cpf, data):
    cpf = _resolver_perfil_cpf(cpf_titular, perfil_cpf)
    sintomas = _valor_texto(data, "sintomas", 3000)
    medicamentos = _valor_texto(data, "medicamentos", 3000)
    observacoes = _valor_texto(data, "observacoes", 5000)
    sem_queixas = parse_bool(data.get("sem_queixas"), default=False, field_name="sem_queixas")
    consentimento = parse_bool(
        _primeiro_valor_presente(data, "consentimento_triagem", "consentimento"),
        default=False,
        field_name="consentimento_triagem",
    )

    if not sem_queixas and not (sintomas or medicamentos or observacoes):
        raise BusinessRuleError("Pre-consulta vazia. Informe sintomas, medicamentos, observacoes ou marque sem queixas.", code="empty_preconsult")
    if not consentimento:
        raise BusinessRuleError("Confirme o consentimento da pre-consulta antes de enviar.", code="missing_preconsult_consent")

    dados_completos = _limpar_json_formulario({**data, "sem_queixas": sem_queixas, "consentimento_triagem": consentimento})
    with db_cursor(commit=True) as cursor:
        cursor.execute(
            """
            INSERT INTO preconsulta_paciente (
                cpf_paciente, sintomas, medicamentos, observacoes, sem_queixas, consentimento_triagem
            )
            VALUES (%s, %s, %s, %s, %s, %s)
            ON DUPLICATE KEY UPDATE
                sintomas = VALUES(sintomas),
                medicamentos = VALUES(medicamentos),
                observacoes = VALUES(observacoes),
                sem_queixas = VALUES(sem_queixas),
                consentimento_triagem = VALUES(consentimento_triagem),
                atualizado_em = NOW()
            """,
            (cpf, sintomas, medicamentos, observacoes, sem_queixas, consentimento),
        )
        _salvar_json_formulario(cursor, cpf, "preconsulta_completa", dados_completos)

    return obter_preconsulta(cpf_titular, cpf)


def listar_exames(cpf_titular, perfil_cpf=None):
    cpf = _resolver_perfil_cpf(cpf_titular, perfil_cpf)
    return fetch_all(
        """
        SELECT id, nome, status, preparo, data_referencia, criado_em, atualizado_em
          FROM exames_paciente
         WHERE cpf_paciente = %s
         ORDER BY atualizado_em DESC
        """,
        (cpf,),
    ) or []


def salvar_exame(cpf_titular, perfil_cpf, data):
    cpf = _resolver_perfil_cpf(cpf_titular, perfil_cpf)
    nome = (data.get("nome") or "").strip()
    if not nome:
        raise BusinessRuleError("Nome do exame obrigatorio.", code="missing_exam_name")
    if len(nome) > 120:
        raise BusinessRuleError("Nome do exame muito longo.", code="exam_name_too_long")
    status = (data.get("status") or "Agendado").strip()
    if status.lower() not in STATUS_EXAME:
        raise BusinessRuleError("Status do exame invalido.", code="invalid_exam_status")
    data_referencia = (data.get("data_referencia") or "").strip()
    if data_referencia:
        parse_date(data_referencia[:10], "data_referencia")

    with db_cursor(commit=True) as cursor:
        if data.get("id"):
            cursor.execute(
                """
                UPDATE exames_paciente
                   SET nome = %s, status = %s, preparo = %s, data_referencia = %s, atualizado_em = NOW()
                 WHERE id = %s AND cpf_paciente = %s
                """,
                (nome, status, data.get("preparo") or "", data_referencia, data["id"], cpf),
            )
            if cursor.rowcount == 0:
                raise NotFoundError("Exame nao encontrado para este paciente.", code="exam_not_found")
            exam_id = data["id"]
        else:
            cursor.execute(
                """
                INSERT INTO exames_paciente (cpf_paciente, nome, status, preparo, data_referencia)
                VALUES (%s, %s, %s, %s, %s)
                """,
                (cpf, nome, status, data.get("preparo") or "", data_referencia),
            )
            exam_id = cursor.lastrowid

    return {"id": exam_id, "nome": nome, "status": status}


def obter_preferencias(cpf_titular, perfil_cpf=None):
    cpf = _resolver_perfil_cpf(cpf_titular, perfil_cpf)
    row = fetch_one(
        "SELECT whatsapp, email, sms, atualizado_em FROM preferencias_paciente WHERE cpf_paciente = %s",
        (cpf,),
    )
    preferencias = row or {"whatsapp": True, "email": True, "sms": False}
    return {
        **preferencias,
        "whatsapp": bool(preferencias.get("whatsapp")),
        "email": bool(preferencias.get("email")),
        "sms": bool(preferencias.get("sms")),
    }


def salvar_preferencias(cpf_titular, perfil_cpf, data):
    cpf = _resolver_perfil_cpf(cpf_titular, perfil_cpf)
    whatsapp = parse_bool(data.get("whatsapp"), default=True, field_name="whatsapp")
    email = parse_bool(data.get("email"), default=True, field_name="email")
    sms = parse_bool(data.get("sms"), default=False, field_name="sms")

    with db_cursor(commit=True) as cursor:
        cursor.execute(
            """
            INSERT INTO preferencias_paciente (cpf_paciente, whatsapp, email, sms)
            VALUES (%s, %s, %s, %s)
            ON DUPLICATE KEY UPDATE
                whatsapp = VALUES(whatsapp),
                email = VALUES(email),
                sms = VALUES(sms),
                atualizado_em = NOW()
            """,
            (cpf, whatsapp, email, sms),
        )

    return obter_preferencias(cpf_titular, cpf)


def salvar_foto_perfil(cpf_titular, perfil_cpf, foto_base64):
    cpf = _resolver_perfil_cpf(cpf_titular, perfil_cpf)
    if foto_base64:
        validate_data_uri_base64(foto_base64, DATA_URI_PREFIXOS_IMAGEM, MAX_FOTO_BYTES, "profile_photo")
    with db_cursor(commit=True) as cursor:
        cursor.execute(
            "UPDATE pacientes SET foto_perfil = %s, atualizado_em = NOW() WHERE cpf = %s",
            (foto_base64 or None, cpf),
        )
    return {"cpf": cpf, "foto_salva": bool(foto_base64)}


def obter_formulario(cpf_titular, perfil_cpf, tipo):
    cpf = _resolver_perfil_cpf(cpf_titular, perfil_cpf)
    tipo_formulario = _validar_tipo_formulario(tipo)
    row = fetch_one(
        """
        SELECT tipo_formulario, dados_json, atualizado_em
          FROM formularios_paciente
         WHERE cpf_paciente = %s AND tipo_formulario = %s
        """,
        (cpf, tipo_formulario),
    )
    if not row:
        return {"tipo_formulario": tipo_formulario, "dados": {}, "atualizado_em": None}
    try:
        dados = json.loads(row.get("dados_json") or "{}")
    except json.JSONDecodeError:
        dados = {}
    return {"tipo_formulario": tipo_formulario, "dados": dados, "atualizado_em": row.get("atualizado_em")}


def salvar_formulario(cpf_titular, perfil_cpf, tipo, dados):
    cpf = _resolver_perfil_cpf(cpf_titular, perfil_cpf)
    tipo_formulario = _validar_tipo_formulario(tipo)
    dados_limpos = _limpar_json_formulario(dados)
    atualizacoes = _validar_dados_formulario(cpf, tipo_formulario, dados_limpos)

    with db_cursor(commit=True) as cursor:
        _salvar_json_formulario(cursor, cpf, tipo_formulario, dados_limpos)
        if tipo_formulario == "dados_cadastrais":
            if atualizacoes.get("email") or atualizacoes.get("telefone"):
                cursor.execute(
                    """
                    UPDATE usuarios
                       SET email = COALESCE(%s, email),
                           telefone = COALESCE(%s, telefone)
                     WHERE cpf = %s
                    """,
                    (atualizacoes.get("email"), atualizacoes.get("telefone"), cpf),
                )

    if tipo_formulario == "preconsulta_completa":
        # Mantem a tabela resumida de pre-consulta sincronizada com o formulario completo.
        return salvar_preconsulta(cpf_titular, cpf, dados_limpos)
    return obter_formulario(cpf_titular, cpf, tipo_formulario)
