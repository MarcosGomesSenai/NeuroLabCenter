from datetime import datetime, timedelta

from mysql.connector import IntegrityError

from back_end.config import Config
from back_end.database.connection import db_cursor, fetch_one
from back_end.utils.cpf import normalize_cpf
from back_end.utils.dates import age_from_birthdate, parse_date
from back_end.utils.errors import BusinessRuleError, UnauthorizedError
from back_end.utils.security import (
    create_token,
    generate_password_reset_token,
    hash_password,
    hash_password_reset_token,
    verify_password,
)
from back_end.utils.validation import validate_email, validate_phone


VALID_USER_TYPES = {"paciente", "responsavel", "medico", "recepcionista", "admin"}
RESPONSIBLE_USER_TYPES = {"responsavel", "paciente"}

PASSWORD_RESET_MESSAGE = (
    "Se os dados estiverem corretos, as instrucoes para redefinir a senha foram geradas."
)


def _now():
    return datetime.now()


def _buscar_usuario_para_recuperacao(data):
    cpf = data.get("cpf")
    email = data.get("email")

    if cpf:
        normalized = normalize_cpf(cpf)
        return fetch_one(
            """
            SELECT id, cpf, nome, email, senha_hash, tipo_usuario, ativo
              FROM usuarios
             WHERE cpf = %s
             LIMIT 1
            """,
            (normalized,),
        )

    if email:
        normalized_email = validate_email(email, required=True)
        return fetch_one(
            """
            SELECT id, cpf, nome, email, senha_hash, tipo_usuario, ativo
              FROM usuarios
             WHERE email = %s
             LIMIT 1
            """,
            (normalized_email,),
        )

    raise BusinessRuleError(
        "Informe CPF ou e-mail para recuperar a senha.",
        code="password_reset_identifier_required",
    )


def _validar_limite_recuperacao(cpf):
    row = fetch_one(
        """
        SELECT COUNT(*) AS total
          FROM senha_recuperacao_tokens
         WHERE cpf = %s
           AND criado_em >= DATE_SUB(NOW(), INTERVAL %s MINUTE)
        """,
        (cpf, Config.PASSWORD_RESET_RATE_LIMIT_MINUTES),
    )
    total = int((row or {}).get("total") or 0)
    if total >= Config.PASSWORD_RESET_MAX_REQUESTS:
        raise BusinessRuleError(
            "Muitas solicitacoes de recuperacao. Aguarde alguns minutos e tente novamente.",
            code="password_reset_rate_limited",
            status_code=429,
        )


def solicitar_recuperacao_senha(data, ip=None, user_agent=None):
    user = _buscar_usuario_para_recuperacao(data)

    # Resposta generica evita expor se um CPF/e-mail existe no sistema.
    if not user or not user.get("ativo"):
        return {"mensagem": PASSWORD_RESET_MESSAGE}

    _validar_limite_recuperacao(user["cpf"])

    token = generate_password_reset_token()
    token_hash = hash_password_reset_token(token)
    expira_em = _now() + timedelta(minutes=Config.PASSWORD_RESET_EXPIRES_MINUTES)
    safe_agent = (user_agent or "")[:255]

    with db_cursor(commit=True) as cursor:
        cursor.execute(
            """
            UPDATE senha_recuperacao_tokens
               SET ativo = FALSE
             WHERE cpf = %s
               AND usado_em IS NULL
               AND ativo = TRUE
            """,
            (user["cpf"],),
        )
        cursor.execute(
            """
            INSERT INTO senha_recuperacao_tokens
                (cpf, token_hash, expira_em, ip_solicitante, user_agent)
            VALUES (%s, %s, %s, %s, %s)
            """,
            (user["cpf"], token_hash, expira_em, ip, safe_agent),
        )

    response = {
        "mensagem": PASSWORD_RESET_MESSAGE,
        "expira_em_minutos": Config.PASSWORD_RESET_EXPIRES_MINUTES,
    }
    if Config.PASSWORD_RESET_EXPOSE_TOKEN:
        response["token_recuperacao"] = token
        response["aviso"] = (
            "Token exposto porque PASSWORD_RESET_EXPOSE_TOKEN=true. "
            "Use apenas em ambiente local/escolar."
        )
    return response


def redefinir_senha_por_token(data):
    token = str(data.get("token") or data.get("token_recuperacao") or "").strip()
    nova_senha = data.get("nova_senha") or data.get("senha") or data.get("new_password")
    confirmacao = data.get("confirmar_senha") or data.get("confirmacao_senha") or data.get("confirm_password")

    if not token:
        raise BusinessRuleError("Token de recuperacao obrigatorio.", code="password_reset_token_required")
    if confirmacao is not None and str(nova_senha or "") != str(confirmacao):
        raise BusinessRuleError(
            "Confirmacao de senha diferente da nova senha.",
            code="password_confirmation_mismatch",
        )

    token_hash = hash_password_reset_token(token)
    reset = fetch_one(
        """
        SELECT s.id, s.cpf, s.expira_em, s.usado_em, s.ativo,
               u.senha_hash, u.ativo AS usuario_ativo
          FROM senha_recuperacao_tokens s
          JOIN usuarios u ON u.cpf = s.cpf
         WHERE s.token_hash = %s
         LIMIT 1
        """,
        (token_hash,),
    )

    if (
        not reset
        or not reset.get("ativo")
        or reset.get("usado_em") is not None
        or not reset.get("usuario_ativo")
        or reset.get("expira_em") < _now()
    ):
        raise BusinessRuleError(
            "Token de recuperacao invalido ou expirado.",
            code="password_reset_token_invalid",
        )

    if verify_password(nova_senha, reset.get("senha_hash")):
        raise BusinessRuleError(
            "A nova senha deve ser diferente da senha atual.",
            code="password_must_change",
        )

    nova_hash = hash_password(nova_senha)

    with db_cursor(commit=True) as cursor:
        cursor.execute(
            """
            UPDATE usuarios
               SET senha_hash = %s,
                   tentativas_login = 0,
                   bloqueado_ate = NULL
             WHERE cpf = %s
            """,
            (nova_hash, reset["cpf"]),
        )
        cursor.execute(
            """
            UPDATE senha_recuperacao_tokens
               SET usado_em = NOW(),
                   ativo = FALSE
             WHERE id = %s
            """,
            (reset["id"],),
        )
        cursor.execute(
            """
            UPDATE senha_recuperacao_tokens
               SET ativo = FALSE
             WHERE cpf = %s
               AND id <> %s
               AND usado_em IS NULL
            """,
            (reset["cpf"], reset["id"]),
        )

    return {"mensagem": "Senha redefinida com sucesso. Faca login com a nova senha."}


def _validar_idade_cadastro(idade):
    if idade < 0:
        raise BusinessRuleError("Data de nascimento nao pode ser futura.", code="birthdate_in_future")
    if idade > 120:
        raise BusinessRuleError("Data de nascimento invalida.", code="invalid_birthdate")


def _responsavel_e_adulto(responsible_cpf):
    patient = fetch_one(
        "SELECT data_nascimento FROM pacientes WHERE cpf = %s",
        (responsible_cpf,),
    )
    if not patient or not patient.get("data_nascimento"):
        raise BusinessRuleError(
            "CPF do responsavel precisa possuir cadastro de paciente/responsavel.",
            code="responsible_patient_record_required",
        )
    idade = age_from_birthdate(patient["data_nascimento"])
    if idade < Config.MINOR_CONFIRMATION_AGE:
        raise BusinessRuleError(
            "CPF do responsavel precisa ser de uma pessoa maior de idade.",
            code="responsible_must_be_adult",
        )


def _registrar_falha_login(user):
    tentativas = int(user.get("tentativas_login") or 0) + 1
    bloqueado_ate = None
    if tentativas >= Config.LOGIN_MAX_ATTEMPTS:
        bloqueado_ate = datetime.now() + timedelta(minutes=Config.LOGIN_BLOCK_MINUTES)
    with db_cursor(commit=True) as cursor:
        cursor.execute(
            """
            UPDATE usuarios
               SET tentativas_login = %s,
                   bloqueado_ate = %s
             WHERE cpf = %s
            """,
            (tentativas, bloqueado_ate, user["cpf"]),
        )
    if bloqueado_ate:
        raise UnauthorizedError(
            f"Conta bloqueada por {Config.LOGIN_BLOCK_MINUTES} minutos apos muitas tentativas.",
            code="account_locked",
            status_code=423,
        )


def _registrar_login_sucesso(cpf):
    with db_cursor(commit=True) as cursor:
        cursor.execute(
            "UPDATE usuarios SET tentativas_login = 0, bloqueado_ate = NULL WHERE cpf = %s",
            (cpf,),
        )


def authenticate_user(cpf, password):
    normalized = normalize_cpf(cpf)
    user = fetch_one(
        """
        SELECT id, cpf, nome, email, senha_hash, tipo_usuario, ativo,
               tentativas_login, bloqueado_ate
          FROM usuarios
         WHERE cpf = %s
        """,
        (normalized,),
    )
    if not user or not user["ativo"]:
        raise UnauthorizedError("CPF ou senha invalidos.", code="invalid_credentials")

    bloqueado_ate = user.get("bloqueado_ate")
    if bloqueado_ate and bloqueado_ate > datetime.now():
        raise UnauthorizedError(
            "Conta temporariamente bloqueada por excesso de tentativas.",
            code="account_locked",
            status_code=423,
        )

    if not verify_password(password, user["senha_hash"]):
        _registrar_falha_login(user)
        raise UnauthorizedError("CPF ou senha invalidos.", code="invalid_credentials")

    _registrar_login_sucesso(user["cpf"])
    token = create_token(user)
    return {
        "id": user["id"],
        "cpf": user["cpf"],
        "nome": user["nome"],
        "email": user["email"],
        "tipo_usuario": user["tipo_usuario"],
        "token": token,
    }


def create_user(data):
    cpf = normalize_cpf(data.get("cpf"))
    name = (data.get("nome") or "").strip()
    email = validate_email(data.get("email"), required=True)
    phone = validate_phone(data.get("telefone"), required=False)
    birthdate = parse_date(data.get("data_nascimento"), "data_nascimento")
    user_type = data.get("tipo_usuario") or "paciente"
    responsible_cpf = data.get("cpf_responsavel")

    if not name:
        raise BusinessRuleError("Nome e obrigatorio.", code="missing_name")
    if len(name) > 120:
        raise BusinessRuleError("Nome muito longo.", code="name_too_long")
    if user_type not in VALID_USER_TYPES:
        raise BusinessRuleError("Tipo de usuario invalido.", code="invalid_user_type")

    patient_age = age_from_birthdate(birthdate)
    _validar_idade_cadastro(patient_age)

    normalized_responsible = None
    if patient_age < Config.MINOR_CONFIRMATION_AGE:
        if user_type == "responsavel":
            raise BusinessRuleError("Menor de 18 anos nao pode ser cadastrado como responsavel.", code="minor_cannot_be_responsible")
        if not responsible_cpf:
            raise BusinessRuleError(
                "Menor de 18 anos precisa de CPF de responsavel.",
                code="minor_requires_responsible",
            )
        normalized_responsible = normalize_cpf(responsible_cpf, "cpf_responsavel")
        if normalized_responsible == cpf:
            raise BusinessRuleError("CPF do responsavel deve ser diferente do CPF do paciente.", code="responsible_must_differ")
    elif responsible_cpf:
        normalized_responsible = normalize_cpf(responsible_cpf, "cpf_responsavel")
        if normalized_responsible == cpf:
            raise BusinessRuleError("CPF do responsavel deve ser diferente do CPF do paciente.", code="responsible_must_differ")

    existing_email = fetch_one(
        "SELECT cpf FROM usuarios WHERE email = %s AND ativo = TRUE AND cpf <> %s LIMIT 1",
        (email, cpf),
    )
    if existing_email:
        raise BusinessRuleError("E-mail ja cadastrado em outra conta.", code="email_already_exists")

    if normalized_responsible:
        responsible = fetch_one(
            "SELECT cpf, tipo_usuario, ativo FROM usuarios WHERE cpf = %s",
            (normalized_responsible,),
        )
        if not responsible or not responsible["ativo"]:
            raise BusinessRuleError(
                "CPF do responsavel precisa estar cadastrado e ativo.",
                code="responsible_must_exist",
            )
        if responsible["tipo_usuario"] not in RESPONSIBLE_USER_TYPES:
            raise BusinessRuleError(
                "CPF do responsavel precisa ser de um usuario do tipo responsavel ou paciente.",
                code="responsible_must_have_responsible_type",
            )
        _responsavel_e_adulto(normalized_responsible)

    password_hash = hash_password(data.get("senha"))

    try:
        with db_cursor(commit=True) as cursor:
            cursor.execute(
                """
                INSERT INTO usuarios (cpf, nome, telefone, email, senha_hash, tipo_usuario)
                VALUES (%s, %s, %s, %s, %s, %s)
                """,
                (cpf, name, phone, email, password_hash, user_type),
            )
            user_id = cursor.lastrowid

            if user_type in {"paciente", "responsavel"}:
                cursor.execute(
                    """
                    INSERT INTO pacientes (cpf, nome, data_nascimento, cpf_responsavel)
                    VALUES (%s, %s, %s, %s)
                    """,
                    (cpf, name, birthdate, normalized_responsible),
                )
                patient_id = cursor.lastrowid
            else:
                patient_id = None
    except IntegrityError as error:
        if error.errno == 1062:
            message = str(error).lower()
            if "email" in message or "uk_usuarios_email" in message:
                raise BusinessRuleError("E-mail ja cadastrado em outra conta.", code="email_already_exists")
            raise BusinessRuleError("CPF ja cadastrado. Faca login.", code="cpf_already_exists")
        raise

    return {
        "id": user_id,
        "id_paciente": patient_id,
        "cpf": cpf,
        "nome": name,
        "menor": patient_age < Config.MINOR_CONFIRMATION_AGE,
    }
