import base64
import os
import random
import sys
from datetime import date, timedelta
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import urljoin, urlparse

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

TEST_DIR = Path(__file__).resolve().parent / ".tmp"
TEST_DB = TEST_DIR / "neurolab_test.sqlite3"
TEST_DIR.mkdir(parents=True, exist_ok=True)
if TEST_DB.exists():
    TEST_DB.unlink()

os.environ["DB_DRIVER"] = "sqlite"
os.environ["SQLITE_PATH"] = str(TEST_DB)

from back_end.app import app  # noqa: E402


PASSWORD = "Senha123"


def cpf_digit(numbers):
    total = sum(number * weight for number, weight in zip(numbers, range(len(numbers) + 1, 1, -1)))
    remainder = total % 11
    return 0 if remainder < 2 else 11 - remainder


def make_cpf():
    while True:
        numbers = [random.randint(0, 9) for _ in range(9)]
        if len(set(numbers)) == 1:
            continue
        numbers.append(cpf_digit(numbers))
        numbers.append(cpf_digit(numbers))
        return "".join(map(str, numbers))


def json(response):
    return response.get_json(silent=True) or {}


def auth_headers(token):
    return {"Authorization": f"Bearer {token}"}


def test_health_and_catalogs_are_available():
    client = app.test_client()

    health = client.get("/api/health")
    assert health.status_code == 200
    assert json(health)["status"] == "online"
    assert json(health)["database"] == "sqlite"

    expected_keys = {
        "/api/unidades": "unidades",
        "/api/medicos": "medicos",
        "/api/convenios": "convenios",
        "/api/exames": "exames",
    }
    for path, key in expected_keys.items():
        response = client.get(path)
        assert response.status_code == 200
        assert json(response)[key]


def test_full_patient_portal_document_family_and_appointment_journey():
    client = app.test_client()
    suffix = random.randint(100000, 999999)
    adult_cpf = make_cpf()
    child_cpf = make_cpf()
    adult_email = f"pytest.adulto.{suffix}@exemplo.com"
    child_email = f"pytest.filho.{suffix}@exemplo.com"

    created = client.post(
        "/api/cadastro",
        json={
            "cpf": adult_cpf,
            "nome": "Pytest Adulto Funcional",
            "email": adult_email,
            "telefone": "11988887777",
            "data_nascimento": "1991-05-21",
            "senha": PASSWORD,
            "tipo_usuario": "paciente",
        },
    )
    assert created.status_code == 201
    assert json(created)["cpf"] == adult_cpf

    login = client.post("/api/login", json={"cpf": adult_cpf, "senha": PASSWORD})
    assert login.status_code == 200
    token = json(login)["token"]
    headers = auth_headers(token)

    panel = client.get("/api/portal/painel", headers=headers)
    assert panel.status_code == 200
    assert json(panel)["perfil_ativo"]["cpf"] == adult_cpf

    updated_email = f"pytest.atualizado.{suffix}@exemplo.com"
    form = client.put(
        "/api/portal/formularios/dados_cadastrais",
        headers=headers,
        json={
            "email": updated_email,
            "telefone": "11977776666",
            "cep": "09000000",
            "emergencia_nome": "Contato Emergencia",
            "emergencia_telefone": "11966665555",
        },
    )
    assert form.status_code == 200
    assert json(form)["tipo_formulario"] == "dados_cadastrais"

    user = client.get(f"/api/usuarios/{adult_cpf}")
    assert user.status_code == 200
    assert json(user)["email"] == updated_email
    assert json(user)["telefone"] == "11977776666"

    preferences = client.put(
        "/api/portal/preferencias",
        headers=headers,
        json={"whatsapp": False, "email": True, "sms": True},
    )
    assert preferences.status_code == 200
    assert json(preferences)["whatsapp"] is False
    assert json(preferences)["sms"] is True

    preconsultation = client.put(
        "/api/portal/preconsulta",
        headers=headers,
        json={
            "sintomas": "Cefaleia leve ha dois dias",
            "medicamentos": "Nenhum",
            "observacoes": "Teste funcional automatizado",
            "sem_queixas": False,
            "consentimento_triagem": True,
        },
    )
    assert preconsultation.status_code == 200
    assert "Cefaleia" in json(preconsultation)["sintomas"]

    document_payload = "data:application/pdf;base64," + base64.b64encode(
        b"%PDF-1.4\n% neuro lab test\n"
    ).decode("ascii")
    document = client.post(
        "/api/portal/documentos",
        headers=headers,
        json={
            "nome_arquivo": "pedido-pytest.pdf",
            "tipo_arquivo": "pdf",
            "categoria": "pedido_medico",
            "consentimento_lgpd": True,
            "conteudo_base64": document_payload,
        },
    )
    assert document.status_code == 201
    document_id = json(document)["id"]

    documents = client.get("/api/portal/documentos", headers=headers)
    assert documents.status_code == 200
    assert any(item["id"] == document_id for item in json(documents))

    loaded_document = client.get(f"/api/portal/documentos/{document_id}", headers=headers)
    assert loaded_document.status_code == 200
    assert json(loaded_document)["conteudo_base64"]

    removed_document = client.delete(f"/api/portal/documentos/{document_id}", headers=headers)
    assert removed_document.status_code == 200
    assert json(removed_document)["removido"] is True

    family_member = client.post(
        "/api/portal/familia/membro",
        headers=headers,
        json={
            "cpf": child_cpf,
            "nome": "Pytest Filho Funcional",
            "email": child_email,
            "telefone": "11955554444",
            "data_nascimento": "2018-03-10",
            "senha": PASSWORD,
            "papel": "Filho",
        },
    )
    assert family_member.status_code == 201
    assert json(family_member)["cpf"] == child_cpf
    assert json(family_member)["vinculado"] is True

    family = client.get("/api/portal/familia", headers=headers)
    assert family.status_code == 200
    assert any(profile["cpf"] == child_cpf for profile in json(family)["perfis"])

    unlinked = client.delete(f"/api/portal/familia/{child_cpf}", headers=headers)
    assert unlinked.status_code == 200
    assert json(unlinked)["cpf_membro"] == child_cpf

    appointment_date = (date.today() + timedelta(days=23)).isoformat()
    new_appointment_date = (date.today() + timedelta(days=24)).isoformat()
    appointment = client.post(
        "/api/agendamentos",
        json={
            "cpf_cliente": adult_cpf,
            "tipo_consulta": "consulta",
            "tipo_atendimento": "particular",
            "id_medico": 2,
            "id_unidade": 1,
            "data_consulta": appointment_date,
            "hora_consulta": "16:10",
            "observacao": "Agendamento Pytest",
        },
    )
    assert appointment.status_code == 201
    appointment_id = json(appointment)["id"]
    assert json(appointment)["status"] == "confirmado"

    availability = client.get(
        f"/api/agendamentos/disponibilidade?id_medico=2&id_unidade=1&data={appointment_date}"
    )
    assert availability.status_code == 200
    assert "16:10:00" in json(availability)["disponibilidade"]["horarios_ocupados"]

    rescheduled = client.put(
        f"/api/agendamentos/{appointment_id}",
        json={
            "cpf_cliente": adult_cpf,
            "id_medico": 2,
            "id_unidade": 1,
            "data_consulta": new_appointment_date,
            "hora_consulta": "16:20",
        },
    )
    assert rescheduled.status_code == 200
    assert json(rescheduled)["data_consulta"] == new_appointment_date

    canceled = client.delete(
        f"/api/agendamentos/{appointment_id}",
        json={"cpf_cliente": adult_cpf, "motivo": "Teste Pytest cancelamento"},
    )
    assert canceled.status_code == 200
    assert json(canceled)["status"] == "cancelado"

    appointments = client.get(f"/api/agendamentos?cpf={adult_cpf}")
    assert appointments.status_code == 200
    assert any(item["id"] == appointment_id for item in json(appointments)["agendamentos"])


def test_feedback_public_endpoints():
    client = app.test_client()

    response = client.get("/api/feedback/medicos/1/media")
    assert response.status_code == 200
    assert "resultado" in json(response)

    comments = client.get("/api/feedback/medicos/1/comentarios")
    assert comments.status_code == 200
    assert "comentarios" in json(comments)


class AssetParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.assets = []

    def handle_starttag(self, tag, attrs):
        data = dict(attrs)
        if tag == "script" and data.get("src"):
            self.assets.append(data["src"])
        elif tag == "img" and data.get("src"):
            self.assets.append(data["src"])
        elif tag == "link" and data.get("href"):
            rel = " ".join(data.get("rel", "").lower().split())
            href = data["href"]
            if "stylesheet" in rel or href.endswith((".css", ".ico", ".png", ".jpg", ".jpeg", ".webp")):
                self.assets.append(href)


def test_static_pages_reference_existing_local_assets():
    root = Path(__file__).resolve().parents[2]
    pages = [root / "index.html", *sorted((root / "app" / "views").glob("*.html"))]
    missing = []

    for page in pages:
        parser = AssetParser()
        parser.feed(page.read_text(encoding="utf-8"))
        base = "http://127.0.0.1:8090/" + page.relative_to(root).as_posix()
        for raw_asset in parser.assets:
            resolved = urljoin(base, raw_asset)
            parsed = urlparse(resolved)
            if parsed.scheme in {"http", "https"} and parsed.netloc not in {
                "127.0.0.1:8090",
                "localhost:8090",
            }:
                continue
            local_path = root / parsed.path.lstrip("/")
            if not local_path.exists():
                missing.append((page.relative_to(root).as_posix(), raw_asset))

    assert not missing
