from flask import Blueprint, g, jsonify, request

from back_end.services.familia_service import (
    cadastrar_e_vincular_familiar,
    desvincular_familiar,
    listar_perfis_acessiveis,
)
from back_end.services.portal_service import (
    criar_documento,
    obter_painel,
    obter_preconsulta,
    obter_preferencias,
    listar_documentos,
    listar_exames,
    obter_documento,
    obter_formulario,
    remover_documento,
    salvar_exame,
    salvar_foto_perfil,
    salvar_formulario,
    salvar_preconsulta,
    salvar_preferencias,
)
from back_end.utils.auth_decorators import require_auth
from back_end.utils.responses import created, ok

bp = Blueprint("portal", __name__)


def _perfil_query():
    return request.args.get("perfil_cpf") or g.cpf


def _dados_formulario_payload(data):
    """Aceita tanto {dados: {...}} quanto campos diretos enviados pelo front-end."""
    if isinstance(data.get("dados"), dict):
        return data["dados"]
    return {
        chave: valor
        for chave, valor in data.items()
        if chave not in {"perfil_cpf", "cpf_perfil", "cpf_titular"}
    }


@bp.get("/portal/painel")
@require_auth
def painel():
    payload, status = ok(obter_painel(g.cpf, _perfil_query()))
    return jsonify(payload), status


@bp.get("/portal/documentos")
@require_auth
def documentos_listar():
    payload, status = ok(listar_documentos(g.cpf, _perfil_query()))
    return jsonify(payload), status


@bp.post("/portal/documentos")
@require_auth
def documentos_criar():
    data = request.get_json(silent=True) or {}
    payload, status = created(criar_documento(g.cpf, data.get("perfil_cpf") or _perfil_query(), data))
    return jsonify(payload), status


@bp.get("/portal/documentos/<int:doc_id>")
@require_auth
def documentos_obter(doc_id):
    payload, status = ok(obter_documento(g.cpf, _perfil_query(), doc_id))
    return jsonify(payload), status


@bp.delete("/portal/documentos/<int:doc_id>")
@require_auth
def documentos_remover(doc_id):
    payload, status = ok(remover_documento(g.cpf, _perfil_query(), doc_id))
    return jsonify(payload), status


@bp.get("/portal/preconsulta")
@require_auth
def preconsulta_obter():
    payload, status = ok(obter_preconsulta(g.cpf, _perfil_query()))
    return jsonify(payload), status


@bp.put("/portal/preconsulta")
@require_auth
def preconsulta_salvar():
    data = request.get_json(silent=True) or {}
    payload, status = ok(salvar_preconsulta(g.cpf, data.get("perfil_cpf") or _perfil_query(), data))
    return jsonify(payload), status


@bp.get("/portal/exames")
@require_auth
def exames_listar():
    payload, status = ok(listar_exames(g.cpf, _perfil_query()))
    return jsonify(payload), status


@bp.post("/portal/exames")
@require_auth
def exames_salvar():
    data = request.get_json(silent=True) or {}
    payload, status = ok(salvar_exame(g.cpf, data.get("perfil_cpf") or _perfil_query(), data))
    return jsonify(payload), status




@bp.get("/portal/formularios/<tipo>")
@require_auth
def formulario_obter(tipo):
    payload, status = ok(obter_formulario(g.cpf, _perfil_query(), tipo))
    return jsonify(payload), status


@bp.put("/portal/formularios/<tipo>")
@require_auth
def formulario_salvar(tipo):
    data = request.get_json(silent=True) or {}
    payload, status = ok(salvar_formulario(g.cpf, data.get("perfil_cpf") or _perfil_query(), tipo, _dados_formulario_payload(data)))
    return jsonify(payload), status


@bp.get("/portal/preferencias")
@require_auth
def preferencias_obter():
    payload, status = ok(obter_preferencias(g.cpf, _perfil_query()))
    return jsonify(payload), status


@bp.put("/portal/preferencias")
@require_auth
def preferencias_salvar():
    data = request.get_json(silent=True) or {}
    payload, status = ok(salvar_preferencias(g.cpf, data.get("perfil_cpf") or _perfil_query(), data))
    return jsonify(payload), status


@bp.put("/portal/foto")
@require_auth
def foto_salvar():
    data = request.get_json(silent=True) or {}
    payload, status = ok(
        salvar_foto_perfil(g.cpf, data.get("perfil_cpf") or _perfil_query(), data.get("foto_base64"))
    )
    return jsonify(payload), status


@bp.get("/portal/familia")
@require_auth
def familia_listar():
    payload, status = ok({"perfis": listar_perfis_acessiveis(g.cpf)})
    return jsonify(payload), status


@bp.post("/portal/familia/membro")
@require_auth
def familia_cadastrar_membro():
    """Cadastro completo (mesmo de /cadastro) + vinculo a conta familia."""
    data = request.get_json(silent=True) or {}
    payload, status = created(cadastrar_e_vincular_familiar(g.cpf, data))
    return jsonify(payload), status


@bp.delete("/portal/familia/<cpf_membro>")
@require_auth
def familia_desvincular(cpf_membro):
    payload, status = ok(desvincular_familiar(g.cpf, cpf_membro))
    return jsonify(payload), status
