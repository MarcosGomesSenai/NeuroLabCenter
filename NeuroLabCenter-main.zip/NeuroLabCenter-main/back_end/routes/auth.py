from flask import Blueprint, jsonify, request

from back_end.services.auth_service import (
    authenticate_user,
    create_user,
    redefinir_senha_por_token,
    solicitar_recuperacao_senha,
)
from back_end.utils.responses import created, ok

bp = Blueprint("auth", __name__)


@bp.post("/login")
def login():
    data = request.get_json(silent=True) or {}
    payload, status = ok(authenticate_user(data.get("cpf"), data.get("senha")))
    return jsonify(payload), status


@bp.post("/usuarios")
def register_user():
    data = request.get_json(silent=True) or {}
    payload, status = created(create_user(data))
    return jsonify(payload), status


@bp.post("/cadastro")
def cadastro():
    data = request.get_json(silent=True) or {}
    payload, status = created(create_user(data))
    return jsonify(payload), status


@bp.post("/esqueci-senha")
@bp.post("/auth/esqueci-senha")
@bp.post("/auth/forgot-password")
def esqueci_senha():
    data = request.get_json(silent=True) or {}
    payload, status = ok(
        solicitar_recuperacao_senha(
            data,
            ip=request.headers.get("X-Forwarded-For", request.remote_addr),
            user_agent=request.headers.get("User-Agent", ""),
        )
    )
    return jsonify(payload), status


@bp.post("/redefinir-senha")
@bp.post("/auth/redefinir-senha")
@bp.post("/auth/reset-password")
def redefinir_senha():
    data = request.get_json(silent=True) or {}
    payload, status = ok(redefinir_senha_por_token(data))
    return jsonify(payload), status
