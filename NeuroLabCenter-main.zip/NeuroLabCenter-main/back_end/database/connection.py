from contextlib import contextmanager
from datetime import date, datetime, time
import re
import sqlite3

import mysql.connector
from mysql.connector import pooling
from mysql.connector import IntegrityError

from back_end.config import Config
from back_end.database.sqlite_dev import initialize_sqlite_database

_pool = None
_driver = None
_sqlite_initialized = False


def _normalize_driver():
    driver = (Config.DB_DRIVER or "auto").lower()
    if driver not in {"auto", "mysql", "sqlite"}:
        return "auto"
    return driver


def database_driver():
    return _driver or _normalize_driver()


def get_pool():
    global _pool
    if _pool is None:
        _pool = pooling.MySQLConnectionPool(
            pool_name=Config.MYSQL_POOL_NAME,
            pool_size=Config.MYSQL_POOL_SIZE,
            host=Config.MYSQL_HOST,
            port=Config.MYSQL_PORT,
            user=Config.MYSQL_USER,
            password=Config.MYSQL_PASSWORD,
            database=Config.MYSQL_DATABASE,
            autocommit=False,
        )
    return _pool


def _ensure_sqlite_initialized():
    global _sqlite_initialized
    if not _sqlite_initialized:
        initialize_sqlite_database(Config.SQLITE_PATH)
        _sqlite_initialized = True


def _sqlite_connection():
    _ensure_sqlite_initialized()
    connection = sqlite3.connect(Config.SQLITE_PATH)
    connection.row_factory = sqlite3.Row
    return SQLiteConnection(connection)


def get_connection():
    global _driver
    requested = _normalize_driver()

    if requested == "sqlite" or _driver == "sqlite":
        _driver = "sqlite"
        return _sqlite_connection()

    try:
        connection = get_pool().get_connection()
        _driver = "mysql"
        return connection
    except mysql.connector.Error:
        if requested == "mysql":
            raise
        _driver = "sqlite"
        return _sqlite_connection()


def _parse_value(key, value):
    if value is None or isinstance(value, (date, datetime, time)):
        return value
    if not isinstance(value, str):
        return value

    lowered = str(key).lower()
    try:
        if lowered.startswith("data_") and len(value) >= 10:
            return date.fromisoformat(value[:10])
        if lowered.startswith("hora_") or lowered.startswith("horario_"):
            return time.fromisoformat(value if len(value) > 5 else f"{value}:00")
        if lowered.endswith("_em") or lowered.endswith("_ate") or lowered in {"criado_em", "atualizado_em"}:
            return datetime.fromisoformat(value.replace(" ", "T"))
    except ValueError:
        return value
    return value


def _row_to_dict(row):
    if row is None:
        return None
    data = dict(row)
    return {key: _parse_value(key, value) for key, value in data.items()}


def _sqlite_integrity_error(error):
    return IntegrityError(msg=str(error), errno=1062)


class SQLiteConnection:
    def __init__(self, connection):
        self._connection = connection

    def cursor(self, dictionary=True):
        return SQLiteCursor(self._connection.cursor())

    def commit(self):
        self._connection.commit()

    def rollback(self):
        self._connection.rollback()

    def close(self):
        self._connection.close()


class SQLiteCursor:
    def __init__(self, cursor):
        self._cursor = cursor
        self.lastrowid = None
        self.rowcount = -1

    def execute(self, query, params=None):
        translated = _translate_sqlite_query(query)
        try:
            self._cursor.execute(translated, _normalize_sqlite_params(params))
        except sqlite3.IntegrityError as error:
            raise _sqlite_integrity_error(error) from error
        self.lastrowid = self._cursor.lastrowid
        self.rowcount = self._cursor.rowcount
        return self

    def executemany(self, query, values):
        translated = _translate_sqlite_query(query)
        try:
            self._cursor.executemany(
                translated,
                [_normalize_sqlite_params(row) for row in values],
            )
        except sqlite3.IntegrityError as error:
            raise _sqlite_integrity_error(error) from error
        self.lastrowid = self._cursor.lastrowid
        self.rowcount = self._cursor.rowcount
        return self

    def fetchone(self):
        return _row_to_dict(self._cursor.fetchone())

    def fetchall(self):
        return [_row_to_dict(row) for row in self._cursor.fetchall()]

    def close(self):
        self._cursor.close()


def _replace_left_calls(query):
    pattern = re.compile(r"LEFT\(([^,()]+),\s*([^)]+)\)", flags=re.IGNORECASE)
    previous = None
    while previous != query:
        previous = query
        query = pattern.sub(r"substr(\1, 1, \2)", query)
    return query


def _normalize_sqlite_value(value):
    if isinstance(value, datetime):
        return value.isoformat(sep=" ")
    if isinstance(value, date):
        return value.isoformat()
    if isinstance(value, time):
        return value.isoformat()
    return value


def _normalize_sqlite_params(params):
    if not params:
        return ()
    if isinstance(params, dict):
        return {key: _normalize_sqlite_value(value) for key, value in params.items()}
    return tuple(_normalize_sqlite_value(value) for value in params)


def _replace_interval_queries(query):
    query = re.sub(
        r"DATE_SUB\(NOW\(\),\s*INTERVAL\s*\?\s*MINUTE\)",
        "datetime('now', '-' || ? || ' minutes')",
        query,
        flags=re.IGNORECASE,
    )
    query = re.sub(
        r"DATE_SUB\((?:NOW\(\)|CURRENT_TIMESTAMP),\s*INTERVAL\s+(\d+)\s+DAY\)",
        lambda match: f"datetime('now', '-{match.group(1)} days')",
        query,
        flags=re.IGNORECASE,
    )
    return query


def _replace_upsert(query):
    normalized = " ".join(query.split()).lower()
    if "on duplicate key update" not in normalized:
        return query

    if "insert into formularios_paciente" in normalized:
        return re.sub(
            r"ON DUPLICATE KEY UPDATE.*",
            """
            ON CONFLICT(cpf_paciente, tipo_formulario) DO UPDATE SET
                dados_json = excluded.dados_json,
                atualizado_em = CURRENT_TIMESTAMP
            """,
            query,
            flags=re.IGNORECASE | re.DOTALL,
        )

    if "insert into preconsulta_paciente" in normalized:
        return re.sub(
            r"ON DUPLICATE KEY UPDATE.*",
            """
            ON CONFLICT(cpf_paciente) DO UPDATE SET
                sintomas = excluded.sintomas,
                medicamentos = excluded.medicamentos,
                observacoes = excluded.observacoes,
                sem_queixas = excluded.sem_queixas,
                consentimento_triagem = excluded.consentimento_triagem,
                atualizado_em = CURRENT_TIMESTAMP
            """,
            query,
            flags=re.IGNORECASE | re.DOTALL,
        )

    if "insert into preferencias_paciente" in normalized:
        return re.sub(
            r"ON DUPLICATE KEY UPDATE.*",
            """
            ON CONFLICT(cpf_paciente) DO UPDATE SET
                whatsapp = excluded.whatsapp,
                email = excluded.email,
                sms = excluded.sms,
                atualizado_em = CURRENT_TIMESTAMP
            """,
            query,
            flags=re.IGNORECASE | re.DOTALL,
        )

    return query


def _translate_sqlite_query(query):
    translated = str(query)
    translated = translated.replace("%s", "?")
    translated = re.sub(r"\bTRUE\b", "1", translated, flags=re.IGNORECASE)
    translated = re.sub(r"\bFALSE\b", "0", translated, flags=re.IGNORECASE)
    translated = _replace_interval_queries(translated)
    translated = re.sub(r"\bNOW\(\)", "CURRENT_TIMESTAMP", translated, flags=re.IGNORECASE)
    translated = re.sub(r"\bCURDATE\(\)", "CURRENT_DATE", translated, flags=re.IGNORECASE)
    translated = _replace_left_calls(translated)
    translated = _replace_upsert(translated)
    return translated


@contextmanager
def db_cursor(commit=False):
    connection = get_connection()
    cursor = connection.cursor(dictionary=True)
    try:
        yield cursor
        if commit:
            connection.commit()
    except Exception:
        connection.rollback()
        raise
    finally:
        cursor.close()
        connection.close()


def fetch_one(query, params=None):
    with db_cursor() as cursor:
        cursor.execute(query, params or ())
        return cursor.fetchone()


def fetch_all(query, params=None):
    with db_cursor() as cursor:
        cursor.execute(query, params or ())
        return cursor.fetchall()


def execute(query, params=None):
    with db_cursor(commit=True) as cursor:
        cursor.execute(query, params or ())
        return cursor.lastrowid
