from pathlib import Path
import re

import mysql.connector

from back_end.config import Config


def _quote_identifier(identifier):
    """Escapa nomes de banco/tabela usados em comandos DDL.

    MySQL nao aceita parametros bind para identificadores. Por isso, antes de
    interpolar o nome do banco vindo do .env, validamos o formato para evitar
    SQL injection e problemas de sintaxe.
    """
    value = str(identifier or "").strip()
    if not re.fullmatch(r"[A-Za-z0-9_]+", value):
        raise ValueError("MYSQL_DATABASE deve conter apenas letras, numeros e underscore.")
    return f"`{value}`"


def _render_sql(sql):
    """Aplica o nome do banco configurado no .env aos arquivos SQL.

    Os arquivos .sql continuam executaveis diretamente no MySQL Workbench com o
    banco padrao neurolabcenter, mas o init_db.py respeita MYSQL_DATABASE quando
    o professor/aluno decidir usar outro nome no .env.
    """
    db = _quote_identifier(Config.MYSQL_DATABASE)
    sql = re.sub(r"CREATE\s+DATABASE\s+IF\s+NOT\s+EXISTS\s+`?neurolabcenter`?",
                 f"CREATE DATABASE IF NOT EXISTS {db}", sql, flags=re.IGNORECASE)
    sql = re.sub(r"USE\s+`?neurolabcenter`?\s*;", f"USE {db};", sql, flags=re.IGNORECASE)
    return sql


def _run_sql_file(cursor, path):
    sql = _render_sql(Path(path).read_text(encoding="utf-8"))
    for statement in sql.split(";"):
        statement = statement.strip()
        if statement:
            cursor.execute(statement)




def _table_exists(cursor, table):
    cursor.execute(
        """
        SELECT COUNT(*) AS total
          FROM information_schema.TABLES
         WHERE TABLE_SCHEMA = %s
           AND TABLE_NAME = %s
        """,
        (Config.MYSQL_DATABASE, table),
    )
    row = cursor.fetchone()
    if isinstance(row, dict):
        return bool(row.get("total"))
    return bool(row[0])


def _assert_required_schema(cursor):
    required = {
        "usuarios": {"cpf", "email", "senha_hash", "tipo_usuario", "ativo", "tentativas_login", "bloqueado_ate"},
        "senha_recuperacao_tokens": {"cpf", "token_hash", "expira_em", "usado_em", "ativo"},
        "pacientes": {"cpf", "nome", "data_nascimento", "cpf_responsavel", "foto_perfil"},
        "agendamentos": {"id_paciente", "id_medico", "id_unidade", "tipo_consulta", "tipo_atendimento", "status", "slot_ativo"},
        "conta_familia_vinculos": {"cpf_titular", "cpf_membro", "papel"},
        "documentos_paciente": {"cpf_paciente", "nome_arquivo", "tipo_arquivo", "categoria", "tamanho_kb", "consentimento_lgpd", "conteudo_base64"},
        "preconsulta_paciente": {"cpf_paciente", "sintomas", "medicamentos", "observacoes", "sem_queixas", "consentimento_triagem"},
        "formularios_paciente": {"cpf_paciente", "tipo_formulario", "dados_json"},
        "preferencias_paciente": {"cpf_paciente", "whatsapp", "email", "sms"},
        "exames_paciente": {"cpf_paciente", "nome", "status", "preparo", "data_referencia"},
    }
    missing = []
    for table, columns in required.items():
        if not _table_exists(cursor, table):
            missing.append(f"tabela {table}")
            continue
        for column in sorted(columns):
            if not _column_exists(cursor, table, column):
                missing.append(f"{table}.{column}")
    required_indexes = {
        "usuarios": {"uk_usuarios_cpf", "uk_usuarios_email"},
        "agendamentos": {"uk_agendamento"},
        "conta_familia_vinculos": {"uk_familia_titular_membro"},
        "senha_recuperacao_tokens": {"uk_senha_recuperacao_token_hash"},
    }
    for table, indexes in required_indexes.items():
        if not _table_exists(cursor, table):
            continue
        for index_name in sorted(indexes):
            if not _index_exists(cursor, table, index_name):
                missing.append(f"indice {table}.{index_name}")

    if missing:
        raise RuntimeError(
            "Schema MySQL incompleto. Execute back_end/database/init_db.py novamente. Faltando: "
            + ", ".join(missing)
        )


def _column_exists(cursor, table, column):
    cursor.execute(
        """
        SELECT COUNT(*) AS total
          FROM information_schema.COLUMNS
         WHERE TABLE_SCHEMA = %s
           AND TABLE_NAME = %s
           AND COLUMN_NAME = %s
        """,
        (Config.MYSQL_DATABASE, table, column),
    )
    row = cursor.fetchone()
    if isinstance(row, dict):
        return bool(row.get("total"))
    return bool(row[0])


def _add_column_if_missing(cursor, table, column, ddl):
    if not _column_exists(cursor, table, column):
        cursor.execute(f"ALTER TABLE {table} ADD COLUMN {ddl}")


def _index_exists(cursor, table, index_name):
    cursor.execute(
        """
        SELECT COUNT(*) AS total
          FROM information_schema.STATISTICS
         WHERE TABLE_SCHEMA = %s
           AND TABLE_NAME = %s
           AND INDEX_NAME = %s
        """,
        (Config.MYSQL_DATABASE, table, index_name),
    )
    row = cursor.fetchone()
    if isinstance(row, dict):
        return bool(row.get("total"))
    return bool(row[0])


def _add_index_if_missing(cursor, table, index_name, ddl):
    if not _index_exists(cursor, table, index_name):
        cursor.execute(f"ALTER TABLE {table} ADD INDEX {index_name} {ddl}")


def _add_unique_index_if_missing(cursor, table, index_name, ddl):
    if not _index_exists(cursor, table, index_name):
        cursor.execute(f"ALTER TABLE {table} ADD UNIQUE KEY {index_name} {ddl}")


def _ensure_incremental_columns(cursor):
    """Garante colunas novas mesmo se o banco ja existia de uma versao antiga."""
    cursor.execute(f"USE {_quote_identifier(Config.MYSQL_DATABASE)}")

    _add_column_if_missing(cursor, "pacientes", "foto_perfil", "foto_perfil LONGTEXT NULL AFTER nome")

    _add_column_if_missing(
        cursor,
        "documentos_paciente",
        "categoria",
        "categoria VARCHAR(80) NOT NULL DEFAULT 'outros' AFTER tipo_arquivo",
    )
    _add_column_if_missing(
        cursor,
        "documentos_paciente",
        "tamanho_kb",
        "tamanho_kb INT NULL AFTER categoria",
    )
    _add_column_if_missing(
        cursor,
        "documentos_paciente",
        "consentimento_lgpd",
        "consentimento_lgpd BOOLEAN NOT NULL DEFAULT FALSE AFTER tamanho_kb",
    )
    _add_column_if_missing(
        cursor,
        "documentos_paciente",
        "conteudo_base64",
        "conteudo_base64 LONGTEXT NULL AFTER status",
    )
    _add_column_if_missing(
        cursor,
        "documentos_paciente",
        "criado_em",
        "criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP",
    )
    _add_index_if_missing(cursor, "documentos_paciente", "idx_documentos_paciente_cpf", "(cpf_paciente)")
    _add_index_if_missing(cursor, "documentos_paciente", "idx_documentos_paciente_categoria", "(categoria)")

    _add_column_if_missing(
        cursor,
        "preconsulta_paciente",
        "sem_queixas",
        "sem_queixas BOOLEAN NOT NULL DEFAULT FALSE AFTER observacoes",
    )
    _add_column_if_missing(
        cursor,
        "preconsulta_paciente",
        "consentimento_triagem",
        "consentimento_triagem BOOLEAN NOT NULL DEFAULT FALSE AFTER sem_queixas",
    )
    _add_column_if_missing(
        cursor,
        "preconsulta_paciente",
        "atualizado_em",
        "atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP",
    )

    _add_column_if_missing(cursor, "usuarios", "tentativas_login", "tentativas_login INT NOT NULL DEFAULT 0")
    _add_column_if_missing(cursor, "usuarios", "bloqueado_ate", "bloqueado_ate DATETIME NULL")
    _add_index_if_missing(cursor, "usuarios", "idx_usuarios_bloqueado_ate", "(bloqueado_ate)")
    _add_unique_index_if_missing(cursor, "usuarios", "uk_usuarios_email", "(email)")


def init_database(with_seed=True):
    connection = mysql.connector.connect(
        host=Config.MYSQL_HOST,
        port=Config.MYSQL_PORT,
        user=Config.MYSQL_USER,
        password=Config.MYSQL_PASSWORD,
        autocommit=False,
    )
    cursor = connection.cursor(dictionary=True)
    base_dir = Path(__file__).resolve().parent
    try:
        _run_sql_file(cursor, base_dir / "schema.sql")
        migrations_dir = base_dir / "migrations"
        for migration in sorted(migrations_dir.glob("*.sql")):
            _run_sql_file(cursor, migration)
        _ensure_incremental_columns(cursor)
        _assert_required_schema(cursor)
        if with_seed:
            _run_sql_file(cursor, base_dir / "seed.sql")
        connection.commit()
    except Exception:
        connection.rollback()
        raise
    finally:
        cursor.close()
        connection.close()


if __name__ == "__main__":
    init_database(with_seed=True)
    print("Banco NeuroLab Center inicializado e regras de negocio verificadas.")
