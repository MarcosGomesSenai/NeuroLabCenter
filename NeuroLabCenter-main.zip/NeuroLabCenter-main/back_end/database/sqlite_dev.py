from datetime import date, timedelta
from pathlib import Path

import bcrypt


DEV_PASSWORD = "Senha123"


SCHEMA = """
CREATE TABLE IF NOT EXISTS usuarios (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    cpf TEXT NOT NULL UNIQUE,
    nome TEXT NOT NULL,
    telefone TEXT,
    email TEXT NOT NULL UNIQUE,
    senha_hash TEXT NOT NULL,
    tipo_usuario TEXT NOT NULL DEFAULT 'paciente',
    data_cadastro TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    ativo INTEGER NOT NULL DEFAULT 1,
    tentativas_login INTEGER NOT NULL DEFAULT 0,
    bloqueado_ate TEXT
);

CREATE TABLE IF NOT EXISTS senha_recuperacao_tokens (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    cpf TEXT NOT NULL,
    token_hash TEXT NOT NULL UNIQUE,
    criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    expira_em TEXT NOT NULL,
    usado_em TEXT,
    ip_solicitante TEXT,
    user_agent TEXT,
    ativo INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS pacientes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    cpf TEXT NOT NULL UNIQUE,
    nome TEXT NOT NULL,
    foto_perfil TEXT,
    data_nascimento TEXT NOT NULL,
    cpf_responsavel TEXT,
    criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    atualizado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS unidades (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    endereco TEXT NOT NULL,
    cidade TEXT NOT NULL,
    cep TEXT NOT NULL,
    telefone TEXT,
    horario_ini TEXT NOT NULL,
    horario_fim TEXT NOT NULL,
    aceita_sus INTEGER NOT NULL DEFAULT 1,
    ativo INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS convenios (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL UNIQUE,
    ativo INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS unidades_convenios (
    id_unidade INTEGER NOT NULL,
    id_convenio INTEGER NOT NULL,
    PRIMARY KEY (id_unidade, id_convenio)
);

CREATE TABLE IF NOT EXISTS exames (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL UNIQUE,
    descricao TEXT,
    preparo_recomendado TEXT,
    duracao_minutos INTEGER,
    ativo INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS medicos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    id_usuario INTEGER NOT NULL UNIQUE,
    crm TEXT NOT NULL UNIQUE,
    especialidade TEXT NOT NULL,
    ativo INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS medicos_unidades (
    id_medico INTEGER NOT NULL,
    id_unidade INTEGER NOT NULL,
    aceita_particular INTEGER NOT NULL DEFAULT 1,
    aceita_convenio INTEGER NOT NULL DEFAULT 1,
    aceita_sus INTEGER NOT NULL DEFAULT 0,
    aceita_teleconsulta INTEGER NOT NULL DEFAULT 0,
    ativo INTEGER NOT NULL DEFAULT 1,
    PRIMARY KEY (id_medico, id_unidade)
);

CREATE TABLE IF NOT EXISTS agendamentos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    id_paciente INTEGER NOT NULL,
    id_medico INTEGER NOT NULL,
    id_unidade INTEGER NOT NULL,
    id_convenio INTEGER,
    id_exame INTEGER,
    data_consulta TEXT NOT NULL,
    hora_consulta TEXT NOT NULL,
    tipo_consulta TEXT NOT NULL,
    tipo_atendimento TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pendente',
    observacao TEXT,
    cpf_responsavel_confirmacao TEXT,
    confirmacao_token TEXT,
    confirmacao_expira_em TEXT,
    confirmado_em TEXT,
    cancelado_em TEXT,
    reagendamentos_count INTEGER NOT NULL DEFAULT 0,
    ultimo_reagendamento_em TEXT,
    criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    atualizado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE UNIQUE INDEX IF NOT EXISTS uk_agendamento_slot_ativo
ON agendamentos (id_unidade, id_medico, data_consulta, hora_consulta)
WHERE status IN ('pendente', 'confirmado');

CREATE TABLE IF NOT EXISTS agendamento_eventos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    id_agendamento INTEGER NOT NULL,
    tipo_evento TEXT NOT NULL,
    cpf_autor TEXT,
    detalhe TEXT,
    criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS feedback (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    id_agendamento INTEGER NOT NULL UNIQUE,
    nota INTEGER NOT NULL,
    comentario TEXT,
    data_feedback TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS conta_familia_vinculos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    cpf_titular TEXT NOT NULL,
    cpf_membro TEXT NOT NULL,
    papel TEXT NOT NULL,
    criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (cpf_titular, cpf_membro)
);

CREATE TABLE IF NOT EXISTS documentos_paciente (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    cpf_paciente TEXT NOT NULL,
    nome_arquivo TEXT NOT NULL,
    tipo_arquivo TEXT NOT NULL DEFAULT 'arquivo',
    categoria TEXT NOT NULL DEFAULT 'outros',
    tamanho_kb INTEGER,
    consentimento_lgpd INTEGER NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'enviado',
    conteudo_base64 TEXT,
    criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS preconsulta_paciente (
    cpf_paciente TEXT PRIMARY KEY,
    sintomas TEXT,
    medicamentos TEXT,
    observacoes TEXT,
    sem_queixas INTEGER NOT NULL DEFAULT 0,
    consentimento_triagem INTEGER NOT NULL DEFAULT 0,
    atualizado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS exames_paciente (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    cpf_paciente TEXT NOT NULL,
    nome TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'Agendado',
    preparo TEXT,
    data_referencia TEXT,
    criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    atualizado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS preferencias_paciente (
    cpf_paciente TEXT PRIMARY KEY,
    whatsapp INTEGER NOT NULL DEFAULT 1,
    email INTEGER NOT NULL DEFAULT 1,
    sms INTEGER NOT NULL DEFAULT 0,
    atualizado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS formularios_paciente (
    cpf_paciente TEXT NOT NULL,
    tipo_formulario TEXT NOT NULL,
    dados_json TEXT NOT NULL,
    criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    atualizado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (cpf_paciente, tipo_formulario)
);
"""


def _password_hash():
    return bcrypt.hashpw(DEV_PASSWORD.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")


def _insert_many(connection, query, rows):
    connection.executemany(query, rows)


def initialize_sqlite_database(database_path):
    path = Path(database_path)
    path.parent.mkdir(parents=True, exist_ok=True)

    connection = None
    try:
        import sqlite3

        connection = sqlite3.connect(path)
        connection.executescript(SCHEMA)
        total_users = connection.execute("SELECT COUNT(*) FROM usuarios").fetchone()[0]
        if total_users:
            connection.commit()
            return

        password = _password_hash()
        users = [
            ("12345678909", "Marcos Silva", "11912345678", "marcos@exemplo.com", password, "responsavel"),
            ("98765432100", "Pedro Silva", "11912345679", "pedro@exemplo.com", password, "paciente"),
            ("11144477735", "Dra. Ana Beatriz Ferreira", "(11) 4002-8922", "ana@neurolabcenter.com.br", password, "medico"),
            ("52998224725", "Dr. Carlos Eduardo Moura", "(11) 4002-8922", "carlos@neurolabcenter.com.br", password, "medico"),
            ("70000000078", "Dra. Fernanda Lima Costa", "(11) 4002-8922", "fernanda@neurolabcenter.com.br", password, "medico"),
            ("70000000159", "Dr. Rafael Nogueira", "(11) 4002-8922", "rafael@neurolabcenter.com.br", password, "medico"),
            ("70000000230", "Dra. Marina Azevedo Prado", "(11) 4002-8922", "marina@neurolabcenter.com.br", password, "medico"),
            ("70000000310", "Dr. Henrique Vidal Ramos", "(11) 4002-8922", "henrique@neurolabcenter.com.br", password, "medico"),
            ("70000000400", "Dra. Laura Martins Sato", "(11) 4002-8922", "laura@neurolabcenter.com.br", password, "medico"),
            ("70000000582", "Dr. Bruno Paiva Leal", "(11) 4002-8922", "bruno@neurolabcenter.com.br", password, "medico"),
        ]
        _insert_many(
            connection,
            """
            INSERT OR IGNORE INTO usuarios
                (cpf, nome, telefone, email, senha_hash, tipo_usuario)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            users,
        )

        _insert_many(
            connection,
            """
            INSERT OR IGNORE INTO pacientes
                (cpf, nome, data_nascimento, cpf_responsavel)
            VALUES (?, ?, ?, ?)
            """,
            [
                ("12345678909", "Marcos Silva", "1988-06-10", None),
                ("98765432100", "Pedro Silva", "2017-03-14", "12345678909"),
            ],
        )

        _insert_many(
            connection,
            """
            INSERT OR IGNORE INTO unidades
                (id, nome, endereco, cidade, cep, telefone, horario_ini, horario_fim, aceita_sus, ativo)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            [
                (1, "Santo Andre - Centro", "R. Amazonas, 48 - Centro, Santo Andre - SP", "Santo Andre", "09000000", "(11) 4002-8922", "07:00:00", "19:00:00", 1, 1),
                (2, "Sao Bernardo - Jardim do Mar", "Av. Kennedy, 303 - Jardim do Mar, Sao Bernardo do Campo - SP", "Sao Bernardo do Campo", "09726000", "(11) 4002-8923", "08:00:00", "18:00:00", 0, 1),
                (3, "Teleconsulta NeuroLab", "Atendimento online", "Online", "00000000", "(11) 4002-8922", "07:00:00", "21:00:00", 0, 1),
                (4, "Santo Andre - Vila Pires", "R. Senador Flaquer, 512 - Vila Pires, Santo Andre - SP", "Santo Andre", "09195000", "(11) 4002-8924", "08:00:00", "18:00:00", 0, 1),
                (5, "Moema - Neurodiagnostico", "Av. Ibirapuera, 2120 - Moema, Sao Paulo - SP", "Sao Paulo", "04028001", "(11) 4002-8925", "07:00:00", "19:00:00", 0, 1),
                (6, "Tatuape - Neuropediatria", "R. Itapura, 986 - Tatuape, Sao Paulo - SP", "Sao Paulo", "03310000", "(11) 4002-8926", "08:00:00", "18:00:00", 0, 1),
                (7, "Paulista - Sono e Cognicao", "Av. Paulista, 171 - Bela Vista, Sao Paulo - SP", "Sao Paulo", "01311000", "(11) 4002-8927", "07:00:00", "19:00:00", 0, 1),
            ],
        )

        _insert_many(
            connection,
            "INSERT OR IGNORE INTO convenios (id, nome, ativo) VALUES (?, ?, ?)",
            [
                (1, "Unimed", 1),
                (2, "Bradesco Saude", 1),
                (3, "SulAmerica", 1),
                (4, "Amil", 1),
                (5, "Porto Seguro Saude", 1),
                (6, "NotreDame Intermedica", 1),
                (7, "Care Plus", 1),
                (8, "Omint", 1),
                (9, "Golden Cross", 1),
                (10, "Alice", 1),
                (11, "Prevent Senior", 1),
                (12, "Sompo Saude", 1),
                (13, "Mediservice", 1),
                (14, "Cassi", 1),
            ],
        )

        _insert_many(
            connection,
            "INSERT OR IGNORE INTO unidades_convenios (id_unidade, id_convenio) VALUES (?, ?)",
            [
                (1, 1), (1, 2), (1, 3), (1, 4),
                (2, 1), (2, 2),
                (3, 1), (3, 2), (3, 3), (3, 4),
                (4, 1), (4, 2), (4, 3), (4, 4), (4, 5),
                (5, 1), (5, 2), (5, 3), (5, 4), (5, 5), (5, 8), (5, 12), (5, 14),
                (6, 1), (6, 4), (6, 6), (6, 7), (6, 10),
                (7, 2), (7, 3), (7, 7), (7, 8), (7, 9), (7, 11),
            ],
        )

        _insert_many(
            connection,
            """
            INSERT OR IGNORE INTO exames
                (id, nome, descricao, preparo_recomendado, duracao_minutos, ativo)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            [
                (1, "Eletroencefalograma", "Exame EEG para avaliacao de atividade cerebral.", "Cabelos limpos e secos, sem gel ou creme.", 40, 1),
                (2, "Eletroneuromiografia", "Avaliacao neurofisiologica de nervos e musculos.", "Evitar cremes na pele no dia do exame.", 60, 1),
                (3, "Polissonografia", "Exame do sono.", "Seguir rotina habitual de sono e levar itens pessoais.", 480, 1),
            ],
        )

        doctor_seed = [
            (1, "11144477735", "CRM/SP 84201", "Neurologia Geral e Epilepsia"),
            (2, "52998224725", "CRM/SP 67453", "Sono e Cognicao"),
            (3, "70000000078", "CRM/SP 91077", "Neuropediatria e desenvolvimento"),
            (4, "70000000159", "CRM/SP 76118", "Exames neurofisiologicos"),
            (5, "70000000230", "CRM/SP 102884", "Cefaleia, enxaqueca e dor neuropatica"),
            (6, "70000000310", "CRM/SP 73904", "Memoria, cognicao e Alzheimer"),
            (7, "70000000400", "CRM/SP 88612", "Neuropediatria e desenvolvimento infantil"),
            (8, "70000000582", "CRM/SP 69450", "Disturbios do movimento e Parkinson"),
        ]
        for doctor_id, cpf, crm, specialty in doctor_seed:
            connection.execute(
                """
                INSERT OR IGNORE INTO medicos (id, id_usuario, crm, especialidade)
                SELECT ?, id, ?, ? FROM usuarios WHERE cpf = ?
                """,
                (doctor_id, crm, specialty, cpf),
            )

        _insert_many(
            connection,
            """
            INSERT OR IGNORE INTO medicos_unidades
                (id_medico, id_unidade, aceita_particular, aceita_convenio, aceita_sus, aceita_teleconsulta, ativo)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            [
                (1, 1, 1, 1, 1, 1, 1),
                (1, 3, 1, 1, 0, 1, 1),
                (2, 1, 1, 1, 0, 1, 1),
                (2, 2, 1, 1, 0, 0, 1),
                (2, 3, 1, 1, 0, 1, 1),
                (3, 1, 1, 1, 0, 0, 1),
                (3, 2, 1, 1, 0, 0, 1),
                (4, 1, 1, 1, 1, 0, 1),
                (4, 4, 1, 1, 0, 0, 1),
                (5, 5, 1, 1, 0, 1, 1),
                (6, 7, 1, 1, 0, 1, 1),
                (7, 6, 1, 1, 0, 0, 1),
                (7, 1, 1, 1, 0, 0, 1),
                (8, 1, 1, 1, 1, 0, 1),
                (8, 7, 1, 1, 0, 0, 1),
            ],
        )

        past = date.today() - timedelta(days=7)
        future = date.today() + timedelta(days=7)
        connection.execute(
            """
            INSERT OR IGNORE INTO agendamentos (
                id, id_paciente, id_medico, id_unidade, id_convenio, id_exame,
                data_consulta, hora_consulta, tipo_consulta, tipo_atendimento,
                status, observacao, cpf_responsavel_confirmacao, confirmado_em
            )
            SELECT 1, p.id, 1, 1, NULL, NULL, ?, '10:00:00', 'consulta',
                   'particular', 'confirmado', 'Consulta confirmada para exemplo de feedback.',
                   p.cpf_responsavel, CURRENT_TIMESTAMP
              FROM pacientes p
             WHERE p.cpf = '98765432100'
            """,
            (past.isoformat(),),
        )
        connection.execute(
            """
            INSERT OR IGNORE INTO agendamentos (
                id, id_paciente, id_medico, id_unidade, id_convenio, id_exame,
                data_consulta, hora_consulta, tipo_consulta, tipo_atendimento,
                status, observacao, cpf_responsavel_confirmacao, confirmacao_token, confirmacao_expira_em
            )
            SELECT 2, p.id, 1, 1, NULL, 1, ?, '11:00:00', 'exame',
                   'particular', 'pendente', 'Exame pendente aguardando confirmacao do responsavel.',
                   p.cpf_responsavel, '00000000-0000-0000-0000-000000000001',
                   datetime('now', '+12 hours')
              FROM pacientes p
             WHERE p.cpf = '98765432100'
            """,
            (future.isoformat(),),
        )
        _insert_many(
            connection,
            "INSERT OR IGNORE INTO agendamento_eventos (id, id_agendamento, tipo_evento, cpf_autor, detalhe) VALUES (?, ?, ?, ?, ?)",
            [
                (1, 1, "criado", "98765432100", "status=confirmado"),
                (2, 1, "confirmado", "12345678909", "confirmado pelo responsavel"),
                (3, 2, "criado", "98765432100", "status=pendente"),
                (4, 1, "feedback", "98765432100", "nota=5"),
            ],
        )
        connection.execute(
            "INSERT OR IGNORE INTO feedback (id_agendamento, nota, comentario) VALUES (1, 5, 'Otimo atendimento.')"
        )
        connection.commit()
    finally:
        if connection is not None:
            connection.close()
