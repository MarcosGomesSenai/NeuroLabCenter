USE neurolabcenter;

CREATE TABLE IF NOT EXISTS conta_familia_vinculos (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    cpf_titular     VARCHAR(11) NOT NULL COMMENT 'CPF do titular logado que gerencia a familia',
    cpf_membro      VARCHAR(11) NOT NULL COMMENT 'CPF do familiar com conta propria',
    papel           VARCHAR(40) NOT NULL COMMENT 'Parentesco: Mae, Pai, Filho, etc.',
    criado_em       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

    UNIQUE KEY uk_familia_titular_membro (cpf_titular, cpf_membro),
    INDEX idx_familia_membro (cpf_membro),
    CONSTRAINT fk_familia_titular FOREIGN KEY (cpf_titular) REFERENCES usuarios(cpf) ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_familia_membro FOREIGN KEY (cpf_membro) REFERENCES usuarios(cpf) ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT chk_familia_diferente CHECK (cpf_titular <> cpf_membro)
) COMMENT 'Vinculos da conta familia — cada membro tem CPF e cadastro completo';

CREATE TABLE IF NOT EXISTS documentos_paciente (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    cpf_paciente    VARCHAR(11) NOT NULL,
    nome_arquivo    VARCHAR(255) NOT NULL,
    tipo_arquivo    VARCHAR(40) NOT NULL DEFAULT 'arquivo',
    categoria       VARCHAR(80) NOT NULL DEFAULT 'outros',
    tamanho_kb      INT NULL,
    consentimento_lgpd BOOLEAN NOT NULL DEFAULT FALSE,
    status          VARCHAR(40) NOT NULL DEFAULT 'enviado',
    conteudo_base64 LONGTEXT COMMENT 'Arquivo em base64 quando nao houver storage externo',
    criado_em       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

    INDEX idx_documentos_cpf (cpf_paciente),
    CONSTRAINT fk_documentos_paciente FOREIGN KEY (cpf_paciente) REFERENCES pacientes(cpf) ON UPDATE CASCADE ON DELETE CASCADE
) COMMENT 'Documentos enviados na Area do Paciente';

CREATE TABLE IF NOT EXISTS preconsulta_paciente (
    cpf_paciente    VARCHAR(11) PRIMARY KEY,
    sintomas        TEXT,
    medicamentos    TEXT,
    observacoes     TEXT,
    sem_queixas     BOOLEAN NOT NULL DEFAULT FALSE,
    consentimento_triagem BOOLEAN NOT NULL DEFAULT FALSE,
    atualizado_em   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    CONSTRAINT fk_preconsulta_paciente FOREIGN KEY (cpf_paciente) REFERENCES pacientes(cpf) ON UPDATE CASCADE ON DELETE CASCADE
) COMMENT 'Formulario de pre-consulta por paciente';

CREATE TABLE IF NOT EXISTS exames_paciente (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    cpf_paciente    VARCHAR(11) NOT NULL,
    nome            VARCHAR(120) NOT NULL,
    status          VARCHAR(80) NOT NULL DEFAULT 'Agendado',
    preparo         TEXT,
    data_referencia VARCHAR(40),
    criado_em       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    atualizado_em   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    INDEX idx_exames_paciente_cpf (cpf_paciente),
    CONSTRAINT fk_exames_paciente FOREIGN KEY (cpf_paciente) REFERENCES pacientes(cpf) ON UPDATE CASCADE ON DELETE CASCADE
) COMMENT 'Exames e laudos do paciente na Area do Paciente';

CREATE TABLE IF NOT EXISTS preferencias_paciente (
    cpf_paciente    VARCHAR(11) PRIMARY KEY,
    whatsapp        BOOLEAN NOT NULL DEFAULT TRUE,
    email           BOOLEAN NOT NULL DEFAULT TRUE,
    sms             BOOLEAN NOT NULL DEFAULT FALSE,
    atualizado_em   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    CONSTRAINT fk_preferencias_paciente FOREIGN KEY (cpf_paciente) REFERENCES pacientes(cpf) ON UPDATE CASCADE ON DELETE CASCADE
) COMMENT 'Lembretes e canais de notificacao';

-- Execute manualmente se as colunas ainda nao existirem:
-- ALTER TABLE pacientes ADD COLUMN foto_perfil LONGTEXT NULL COMMENT 'Foto base64' AFTER nome;
-- ALTER TABLE usuarios ADD COLUMN tentativas_login INT NOT NULL DEFAULT 0;
-- ALTER TABLE usuarios ADD COLUMN bloqueado_ate DATETIME NULL;
