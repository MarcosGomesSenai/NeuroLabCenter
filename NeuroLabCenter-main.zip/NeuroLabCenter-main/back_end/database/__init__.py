"""Camada de banco MySQL."""
