from datetime import datetime, timezone
import hashlib
import secrets

import bcrypt
import jwt

from back_end.config import Config
from back_end.utils.errors import UnauthorizedError


def hash_password(password):
    raw = str(password or "")
    if len(raw) < 8:
        raise UnauthorizedError("A senha deve ter pelo menos 8 caracteres.", code="weak_password", status_code=400)
    if not any(char.isupper() for char in raw):
        raise UnauthorizedError("A senha deve conter pelo menos uma letra maiuscula.", code="weak_password", status_code=400)
    if not any(char.islower() for char in raw):
        raise UnauthorizedError("A senha deve conter pelo menos uma letra minuscula.", code="weak_password", status_code=400)
    if not any(char.isdigit() for char in raw):
        raise UnauthorizedError("A senha deve conter pelo menos um numero.", code="weak_password", status_code=400)
    return bcrypt.hashpw(raw.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")


def verify_password(password, password_hash):
    if not password or not password_hash:
        return False
    try:
        return bcrypt.checkpw(str(password).encode("utf-8"), password_hash.encode("utf-8"))
    except ValueError:
        return False


def create_token(user):
    now = datetime.now(timezone.utc)
    payload = {
        "sub": str(user["id"]),
        "cpf": user["cpf"],
        "tipo_usuario": user["tipo_usuario"],
        "iat": int(now.timestamp()),
        "exp": int((now + Config.JWT_EXPIRES_IN).timestamp()),
    }
    return jwt.encode(payload, Config.JWT_SECRET, algorithm="HS256")


def decode_token(token):
    try:
        return jwt.decode(token, Config.JWT_SECRET, algorithms=["HS256"])
    except jwt.PyJWTError:
        raise UnauthorizedError("Token invalido ou expirado.", code="invalid_token")


def generate_password_reset_token():
    return secrets.token_urlsafe(32)


def hash_password_reset_token(token):
    raw = str(token or "").strip()
    if not raw:
        return ""
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()
