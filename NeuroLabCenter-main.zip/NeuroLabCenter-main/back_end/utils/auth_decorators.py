from functools import wraps

from flask import g, request

from back_end.utils.errors import UnauthorizedError
from back_end.utils.security import decode_token


def _extract_bearer_token():
    header = request.headers.get("Authorization", "")
    if header.startswith("Bearer "):
        return header[7:].strip()
    return None


def require_auth(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        token = _extract_bearer_token()
        if not token:
            raise UnauthorizedError("Autenticacao obrigatoria.", code="auth_required")
        payload = decode_token(token)
        g.auth = payload
        g.cpf = payload.get("cpf")
        g.user_id = int(payload.get("sub"))
        g.tipo_usuario = payload.get("tipo_usuario")
        return view(*args, **kwargs)

    return wrapped
