import base64
import binascii
import re
from datetime import date

from back_end.utils.errors import BusinessRuleError

_EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
_TRUE_VALUES = {"1", "true", "t", "sim", "s", "yes", "y", "on"}
_FALSE_VALUES = {"0", "false", "f", "nao", "não", "n", "no", "off"}


def parse_bool(value, default=False, field_name="campo"):
    """Converte booleanos vindos do front-end sem transformar 'false' em True."""
    if value is None or value == "":
        return default
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)) and value in (0, 1):
        return bool(value)
    text = str(value).strip().lower()
    if text in _TRUE_VALUES:
        return True
    if text in _FALSE_VALUES:
        return False
    raise BusinessRuleError(f"{field_name} deve ser verdadeiro ou falso.", code="invalid_boolean")


def positive_int(value, field_name, required=True):
    if value is None or value == "":
        if required:
            raise BusinessRuleError(f"{field_name} e obrigatorio.", code=f"missing_{field_name}")
        return None
    try:
        number = int(value)
    except (TypeError, ValueError):
        raise BusinessRuleError(f"{field_name} deve ser numerico.", code=f"invalid_{field_name}")
    if number <= 0:
        raise BusinessRuleError(f"{field_name} deve ser maior que zero.", code=f"invalid_{field_name}")
    return number


def validate_email(value, required=False, field_name="email"):
    email = str(value or "").strip().lower()
    if not email:
        if required:
            raise BusinessRuleError(f"{field_name} e obrigatorio.", code="missing_email")
        return None
    if len(email) > 120 or not _EMAIL_RE.match(email):
        raise BusinessRuleError(f"{field_name} invalido.", code="invalid_email")
    return email


def validate_phone(value, required=False, field_name="telefone"):
    phone = str(value or "").strip()
    if not phone:
        if required:
            raise BusinessRuleError(f"{field_name} e obrigatorio.", code="missing_phone")
        return None
    digits = "".join(ch for ch in phone if ch.isdigit())
    if len(digits) not in (10, 11):
        raise BusinessRuleError(f"{field_name} deve ter 10 ou 11 digitos.", code="invalid_phone")
    return phone


def validate_cep(value, required=False):
    digits = "".join(ch for ch in str(value or "") if ch.isdigit())
    if not digits:
        if required:
            raise BusinessRuleError("CEP e obrigatorio.", code="missing_zipcode")
        return None
    if len(digits) != 8:
        raise BusinessRuleError("CEP deve ter 8 digitos.", code="invalid_zipcode")
    return digits


def ensure_not_future_date(value, field_name="data"):
    if value and value > date.today():
        raise BusinessRuleError(f"{field_name} nao pode ser futura.", code="date_in_future")
    return value


def validate_data_uri_base64(data_uri, allowed_prefixes, max_bytes, code_prefix="file"):
    content = str(data_uri or "")
    lower = content.lower()
    if not any(lower.startswith(prefix) for prefix in allowed_prefixes):
        raise BusinessRuleError("Formato de arquivo invalido.", code=f"invalid_{code_prefix}_payload")
    try:
        encoded = content.split(",", 1)[1]
    except IndexError:
        raise BusinessRuleError("Arquivo em base64 invalido.", code=f"invalid_{code_prefix}_payload")
    try:
        raw = base64.b64decode(encoded, validate=True)
    except (binascii.Error, ValueError):
        raise BusinessRuleError("Arquivo em base64 invalido.", code=f"invalid_{code_prefix}_base64")
    if len(raw) == 0:
        raise BusinessRuleError("Arquivo vazio nao pode ser enviado.", code=f"empty_{code_prefix}")
    if len(raw) > max_bytes:
        raise BusinessRuleError("Arquivo acima do limite permitido.", code=f"{code_prefix}_too_large")
    return raw
