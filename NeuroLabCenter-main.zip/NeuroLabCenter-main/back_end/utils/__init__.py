"""Utilitarios do back-end."""
